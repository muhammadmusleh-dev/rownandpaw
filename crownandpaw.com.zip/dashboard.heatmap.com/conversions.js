class ConversionsHandler {
    constructor(a = 0) {
        this.siteId = 0;
        this.urlParams = null;
        this.sendLambdaDataLayerObject = this.heatmapExecuteGTMDataLayerState = this.heatmapThankYouHasSentTrx = this.heatmapSentTransaction = !1;
        this.heatmapNewVisitor = this.tempHeatmapSiteId = this.heatmapUpSellCount = 0;
        this.heatmapDoNotSend = !1;
        this.timeSincePageReady = 0;
        this.HeatMapAuditKey = "";
        this.clientVisitId = null;
        this.apiPaths = {};
        this.loadSiteScript = !1;
        this.dateObj = new Date;
        this.dataLayerObject = [];
        this.websitesList = [2055, 337];
        this.dataLayerSet =
            new Set("checkoutSuccessful transactionSuccess conversion complete convert_purchase_usd dl_purchase success checkout transaction vp_purchase al_purchase purchase purchase_ga4 Checkout_Step_Completed gtm-purchase product-purchase subscription_created FundraiseUp.donationComplete".split(" "));
        this.siteId = a;
        this.urlParams = new URLSearchParams(window.location.search)
    }
    init() {
        this.apiPaths = {
            origin: window.location.origin,
            href: window.location.href,
            api: "https://conversions.heatmapcore.com/",
            kinesis: "https://kns.heatmap.com/data",
            bigcommerce: "https://checkout-sdk.bigcommerce.com/v1/loader.js",
            recording: "wss://service.heatmap.com/ws/record/events?env=live",
            lambda: "https://stage1.heatmapcore.com/backend/tracking/dlayer",
            recordings: "https://ws.heatmap.com/data/conversion"
        };
        this.apiPaths.trackerURL = `${this.apiPaths.api}heatmap.php`;
        this.HeatMapAuditKey = this.getLocalWithExpiry("_heat_audit");
        this.clientVisitId = localStorage.getItem("_heatVid");
        this.tempHeatmapSiteId = this.siteId = this.getSiteId();
        setTimeout(() => {
            if (!localStorage.getItem("_heatVid")) {
                let a =
                    this.getHeatmapCrossDomainCookie(`_heatVid_${this.siteId}`);
                a && (localStorage.setItem("_heatVid", a), localStorage.setItem(`_heatVid_${this.siteId}`, a))
            }
            this.lambdaDataLayerObject()
        }, 1E3)
    }
    loadScript(a) {
        try {
            var b = document.createElement("script");
            b.type = "text/javascript";
            b.src = a;
            b.async = !1;
            b.defer = !0;
            document.head.appendChild(b)
        } catch (c) {}
    }
    sendExitEvents() {
        try {
            if (![1722].includes(this.siteId) && "undefined" === typeof pagePerformanceMetrics) {
                var a = JSON.parse(localStorage.getItem("_heatmap_unsent"));
                a && (navigator.sendBeacon(this.apiPaths.kinesis,
                    JSON.stringify(a)), localStorage.removeItem("_heatmap_unsent"));
                var b = JSON.parse(localStorage.getItem("heat_last_record_before_unload_event"));
                b && (this.heatmapSessionRecording(b), navigator.sendBeacon(`${b.streamGateway}`, JSON.stringify(b.recording_record.Data)), localStorage.removeItem("heat_last_record_before_unload_event"))
            }
        } catch (c) {}
    }
    lambdaDataLayerObject() {
        if ("undefined" !== typeof dataLayer) try {
            if (!this.sendLambdaDataLayerObject) {
                var a = dataLayer.filter(c => (c = c.event || c.vrio_event || "event" === c[0] &&
                    c[1]) && this.dataLayerSet.has(c));
                if ("undefined" !== typeof a && a.length) {
                    a[0].idsite = this.siteId;
                    a[0]._idv = this.getCookie(`_heatVid_${this.siteId}`);
                    a[0].created_at = this.dateObj.toISOString();
                    a[0].user_agent = navigator.userAgent;
                    a[0]._id = this.heatmapVisitIdFromStore();
                    a[0].device_type = this.heatmapGetDeviceFromStore();
                    a[0].parent_idv = this.getCookie(`_heatVid_${this.siteId}`);
                    ("undefined" !== typeof checkoutKitLoader || (/checkout/ig.test(window.location.href) || /checkouts/ig.test(window.location.href)) && this.websitesList.includes(this.siteId)) &&
                    this.heatmapProcessBCConversionData(a);
                    var b = {
                        idsite: this.siteId,
                        layer: a,
                        device_type: this.heatmapGetDeviceFromStore(),
                        referrer: this.apiPaths.origin,
                        href: this.cleanUpUrlHref(this.apiPaths.href),
                        _idv: this.getCookie(`_heatVid_${this.siteId}`)
                    };
                    navigator.sendBeacon(this.apiPaths.lambda, JSON.stringify(b));
                    this.sendLambdaDataLayerObject = !0
                }
            }
        } catch (c) {
            console.log(c)
        }
    }
    getCookie(a = "") {
        const b = document.cookie.split("; ");
        for (let c of b) {
            const [d, e] = c.split("=");
            if (d === a) return decodeURIComponent(e).trim()
        }
        return (a =
            localStorage.getItem("_heatVid")) ? a : null
    }
    getLocalWithExpiry(a) {
        var b = localStorage.getItem(a);
        if (!b) return null;
        b = JSON.parse(b);
        return this.dateObj.getTime() > b.expiry ? (localStorage.removeItem(a), null) : b.value
    }
    getSiteId() {
        if ("undefined" !== typeof preHeatmapSiteId) return this.siteId = preHeatmapSiteId;
        var a = document.body.innerHTML.replace(/&amp;/g, "&"),
            b = document.head.innerHTML.replace(/&amp;/g, "&");
        a = /conversions\.js\?(?:.*&)?siteId=(\d+)|conversions-dev\.js\?(?:.*&)?siteId=(\d+)/g.exec(a + b);
        return this.siteId ?
            this.siteId : a && (a[1] || a[2]) ? parseInt(a[1] ? a[1] : a[2]) : this.siteId || "undefined" === typeof preHeatmapSiteId ? this.siteId : preHeatmapSiteId
    }
    heatmapVisitIdFromStore() {
        localStorage.setItem("_user_agent", navigator.userAgent);
        var a = localStorage.getItem("_mr_vid");
        if (a) return this.heatmapDoNotSend = !0, a;
        document.cookie.split(";").forEach(b => {
            var [c, d] = b.split("=");
            if (-1 < c.indexOf(`_pk_id.${this.siteId}`)) return d.trim().split(".")[0]
        });
        this.heatmapDoNotSend = !1;
        return a
    }
    heatmapGetDeviceFromStore() {
        if ("undefined" ===
            typeof navigator) return 1;
        const a = window.innerWidth || screen.width || 0,
            b = window.innerHeight || screen.height || 0,
            c = b / Math.max(1, a);
        return "function" === typeof matchMedia && matchMedia("(pointer:coarse)").matches || 1.2 < c || 480 >= Math.min(a, b) ? 3 : 1024 >= a || 1024 >= b || 1.1 < c ? 2 : 1
    }
    heatmapSessionRecording(a) {
        try {
            if ("undefined" === typeof pagePerformanceMetrics && a && ![1722].includes(this.siteId)) {
                const b = new WebSocket(this.apiPaths.recording);
                b.onopen = () => {
                    b.readyState && b.readyState === WebSocket.OPEN && (b.send(JSON.stringify(a.recording_record),
                        "recordings"), localStorage.removeItem("heat_last_record_before_unload_event"))
                }
            }
        } catch (b) {}
    }
    isLeadGenWebsite() {
        if ("undefined" !== typeof preHeatmapSiteId) return this.siteId = preHeatmapSiteId;
        var a = document.body.innerHTML.replace(/&amp;/g, "&"),
            b = document.head.innerHTML.replace(/&amp;/g, "&"),
            c = /conversions\.js\?mode=leads&siteId=\d+/;
        a = c.exec(a);
        b = c.exec(b);
        return a || b ? navigator.sendBeacon(this.apiPaths.trackerURL, JSON.stringify({
                idsite: this.siteId,
                url: this.apiPaths.origin,
                href: this.cleanUpUrlHref(this.apiPaths.href)
            })) :
            !1
    }
    heatmapLogAudits(a) {
        if (this.HeatMapAuditKey) {
            var b = JSON.parse(localStorage.getItem("_heat_audit_trans")) || [];
            b.push({
                _idorder: a,
                _heat_audit_key: this.HeatMapAuditKey
            });
            localStorage.setItem("_heat_audit_trans", JSON.stringify(b))
        }
    }
    heatRetrieveStore(a, b = null) {
        if (!localStorage.getItem(a)) return null;
        a = localStorage.getItem(a);
        if (null == b) return a;
        a = JSON.parse(a);
        return a[b] ? a[b] : null
    }
    heatSaveStore(a, b, c = "allHeatmapsIds") {
        a = heatCleanUrl(a);
        let d = {},
            e = this.heatRetrieveStore(`${c}`);
        e && (d = JSON.parse(e));
        d[a] = b;
        return localStorage.setItem(`${c}`, JSON.stringify(d))
    }
    thankYouUserJourney() {
        if (localStorage.getItem("heatWPx")) {
            let a = JSON.parse(localStorage.getItem("heatWPx"));
            if (a.idsite) try {
                this.siteId = a.idsite;
                let b = this.getHeatmapCrossDomainCookie(`_heatVid_${this.siteId}`);
                b && (localStorage.setItem("_heatVid", b), localStorage.setItem(`_heatVid_${this.siteId}`, b), a._idv = b);
                a.device_type = this.heatmapGetDeviceFromStore();
                localStorage.setItem("heatIsGoalBuyer", 1);
                localStorage.setItem("heatIsGoalBuyerCurrency",
                    a.currency);
                localStorage.setItem("heatIsGoalBuyerValue", a.revenue);
                [3193].includes(this.siteId) && navigator.sendBeacon(`https://stage1.heatmapcore.com/heatmap.php?type=pixel&idorder=${a.idorder}&idsite=${a.idsite}&revenue=${a.revenue}&_idv=${a._idv}&device_type=${a.device_type}`, JSON.stringify(a));
                navigator.sendBeacon(`${a.path}heatmap.php?type=pixel&idorder=${a.idorder}&idsite=${a.idsite}&rev=${a.revenue}&_idv=${a._idv}&_dev=${a.device_type}`, JSON.stringify(a));
                localStorage.removeItem("heatWPx")
            } catch (b) {}
        }
    }
    heatmapSendFinalBeacon(a,
        b) {
        const c = 850 < window.innerWidth,
            d = /Edge\/\d./i.test(navigator.userAgent),
            e = /Edg\/\d./i.test(navigator.userAgent),
            f = Object.entries(b).map(([g, h]) => "items" === g ? `${encodeURIComponent(g)}=${encodeURIComponent(JSON.stringify(h))}` : `${encodeURIComponent(g)}=${encodeURIComponent(h)}`).join("&");
        this.heatmapThankYouHasSentTrx = !0;
        if (c && d || c && e) window.fetch(`${a}&${f}`);
        else try {
            delete b.items, b.url = this.cleanUpUrlHref(window.location.href), b.date = this.dateObj.toISOString(), b.hasOwnProperty("type") || (b.type =
                "heatmapConversion"), navigator.sendBeacon(`${this.apiPaths.trackerURL}?data=` + btoa(encodeURIComponent(JSON.stringify(b))))
        } catch (g) {
            window.fetch(`${a}&${f}`)
        }
        this.tempHeatmapTrackerURL = a;
        localStorage.removeItem("order");
        localStorage.removeItem("vivo_transaction");
        localStorage.removeItem("mage-cache-storage");
        localStorage.removeItem("cheeseOrderDetail");
        localStorage.removeItem("trackedCompleteOrderSourceId");
        localStorage.setItem("tempHeatmapTrackerURL", a);
        console.log("%c \u25ba Heatmap.com -: Transaction data successfully sent.",
            "background-color: #43a047; color: #fff; padding: 5px;")
    }
    cleanUpUrlHref(a) {
        a = new URL(a);
        a.searchParams.delete("orderDetails");
        return a.toString()
    }
    heatmapThankYouSendBeacon(a, b, c, d) {
        if (1 == this.heatmapThankYouHasSentTrx) return !0;
        b.referrer = this.cleanUpUrlHref(this.apiPaths.href);
        b._idv = this.getCookie(`_heatVid_${this.siteId}`);
        b._id = this.heatmapVisitIdFromStore();
        b.idsite = this.siteId;
        b.quicktransaction = 1;
        b.agent = navigator.userAgent;
        b.audit_key = this.HeatMapAuditKey;
        b.created_at = this.dateObj.toISOString();
        b.device_type = this.heatmapGetDeviceFromStore();
        b.parent_idv = this.getCookie(`_heatVid_${this.siteId}`);
        if ("undefined" == typeof b.revenue) return !0;
        a = `${this.clientVisitId}_${b.revenue}`;
        var e = localStorage.getItem("lastTransaction");
        if (e && e == a) return this.heatmapThankYouHasSentTrx = !0;
        "undefined" !== typeof Shopify && "undefined" !== typeof Shopify.country && (b.country = Shopify.country);
        try {
            b.items_count = b.items.length
        } catch (f) {}
        e = `&request=conversion&siteId=${this.siteId}&idorder=${d}&_idv=${b._idv}&revenue=${b.revenue}`;
        navigator.sendBeacon(`https://conversions.heatmapcore.com/heatmap.php?data=${window.btoa(encodeURIComponent(JSON.stringify(b)))}${e}`);
        navigator.sendBeacon(`${this.apiPaths.recordings}`, JSON.stringify({
            idorder: d,
            revenue: b.revenue,
            currency: b.currency,
            idsite: this.siteId,
            idvisit: b._idv,
            device_type: b.device_type
        }));
        this.heatmapLogAudits(d);
        this.tempHeatmapSiteId = c;
        localStorage.setItem("heatIsGoalBuyer", 1);
        localStorage.setItem("heatIsGoalBuyerCurrency", b.currency);
        localStorage.setItem("heatIsGoalBuyerValue",
            b.revenue);
        localStorage.setItem("heatIsGoalBuyerAmount", b.revenue);
        localStorage.setItem("lastTransaction", a);
        localStorage.setItem("tempHeatmapSiteId", this.tempHeatmapSiteId);
        "undefined" !== typeof window.ipoet && (window.ipoet("checkout_started", "checkout_started"), window.ipoet("checkout_completed", "checkout_completed"))
    }
    heatmapGetBCOrderId() {
        var a = 0,
            b = document.querySelector('[data-test="order-confirmation-order-number-text"]');
        b && (b = b.querySelector("strong"), void 0 !== b && null !== b && (a = b.textContent));
        0 == a && (b = document.querySelector(".orderConfirmation-section")) && (a = b.innerHTML.match(/Order (\d+)/)[1] ? ? 0);
        if (0 == a) {
            b = document.getElementsByTagName("script");
            for (var c = 0; c < b.length; c++) {
                var d = b[c];
                if (d.innerHTML.includes("checkoutLoader.loadFiles({")) {
                    (a = d.innerHTML.match(/orderId:\s*'(\d+)'/)) && "undefined" !== typeof a[1] && (a = a[1]);
                    break
                }
            }
        }
        return parseInt(a)
    }
    heatmapManipulateBCConversionData(a) {
        var b = {
            order_number: a.orderId,
            totalPrice: a.orderAmount,
            discount: a.discountAmount,
            shipping: a.shippingCostTotal,
            productsList: []
        };
        const c = d => {
            d.forEach(function(e) {
                e = {
                    sku: e.sku,
                    price: e.salePrice,
                    quantity: e.quantity,
                    title: e.name.replace(/['"]+/g, "")
                };
                b.productsList.push(e)
            })
        };
        c(a.lineItems.physicalItems);
        c(a.lineItems.digitalItems);
        c(a.lineItems.giftCertificates);
        this.heatmapTransactionId = a.orderId;
        return this.heatmapRawConversionTransaction(b)
    }
    processToddlegramTransaction() {
        if (!this.heatmapThankYouHasSentTrx) {
            var a = document.querySelector(".order-summary-toggle__text--show");
            if (!a || Shopify.checkout || Shopify.order) return !0;
            a.click();
            a = b => {
                var c = document.querySelector(`[${b}]`);
                if (c) return (b = c.innerText.match(/[0-9.]+/g)) ? b.join("") : "";
                if (b.includes("currency") || b.includes("order"))
                    if (c = document.getElementsByClassName(b), b = b.includes("currency") ? !0 : !1, 0 < c.length) return c = c[0].innerText, c = c.replace(/order/gi, "").trim(), b && !c.length ? "INR" : c;
                return 0
            };
            a = {
                discount: a("data-checkout-discount-amount-target"),
                shipment: a("data-checkout-total-shipping-target"),
                revenue: a("data-checkout-payment-due-target"),
                currency: "undefined" !==
                    typeof Shopify.currency && Shopify.currency.active ? Shopify.currency.active : "INR",
                items: (() => {
                    const b = [],
                        c = document.querySelector("tbody[data-order-summary-section]");
                    c && c.querySelectorAll("tr[data-product-id]").forEach(d => {
                        var e = d.querySelector("span.product__description__name");
                        e = e ? e.innerText.trim() : "";
                        var f = d.querySelector("span.order-summary__price");
                        d = (d = d.querySelector("span.product-thumbnail__quantity")) ? d.innerText : 1;
                        f = (f ? f.innerText.trim() : "").replace(/[^\d.]/g, "");
                        e.length && b.push({
                            title: e,
                            price: f,
                            quantity: d,
                            sku: ""
                        })
                    });
                    return b
                })(),
                idorder: a("os-order-number"),
                request_source: "heatmapCheckoutOrder"
            };
            return 0 == a.revenue ? !0 : this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?type=processToddlegram&siteId=${this.siteId}`, a, this.siteId, a.idorder)
        }
    }
    initVivoTransaction() {
        if ("undefined" !== typeof dataLayer && !this.heatmapThankYouHasSentTrx) {
            var a = {};
            for (var b of dataLayer)
                if ("eec.purchase" === b.event) {
                    a = b.ecommerce;
                    b = a.purchase;
                    a = {
                        currency: a ? .currencyCode,
                        revenue: b ? .actionField ? .revenue,
                        shipment: b ? .actionField ? .shipping,
                        tax: b ? .actionField.tax,
                        idorder: b ? .actionField.id,
                        items: b ? .products.map(c => ({
                            id: c ? .id,
                            quantity: c ? .quantity,
                            price: c ? .price
                        }))
                    };
                    break
                }
            if (Object.keys(a).length) return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${a.idorder}`, a, this.siteId, a.idorder)
        }
    }
    sendVivoTransaction() {
        this.initVivoTransaction();
        if (!this.heatmapThankYouHasSentTrx) {
            var a = !!localStorage.getItem("mage-cache-storage"),
                b = /checkout/gi.test(window.location.href);
            if (a && b) {
                let c = {},
                    d = JSON.parse(localStorage.getItem("mage-cache-storage")) || JSON.parse(localStorage.getItem("vivo_transaction"));
                const e = g => {
                        Array.from(g.getElementsByTagName("script")).find(h => h.src.includes("/api/v2/referreroffer/")) ? .src.split("?")[1] ? .split("&").forEach(h => {
                            const [k, m] = h.split("=");
                            c[k] = m
                        })
                    },
                    f = () => {
                        if (b && (d || localStorage.getItem("vivo_transaction")) && (d || (d = JSON.parse(localStorage.getItem("vivo_transaction")), localStorage.setItem("vivo_transaction", JSON.stringify(d))), e(document.head),
                                d.cart && (c.order_number || document.querySelector("body .orderDetailsRow")))) {
                            this.heatmapThankYouHasSentTrx = !1;
                            var g = d.cart.line_items.map(h => ({
                                price: h.unit_price,
                                quantity: h.quantity,
                                title: h.name.replace(/['"]+/g, ""),
                                sku: h.sku_code
                            }));
                            g = {
                                idorder: c.order_number,
                                revenue: c.order_total,
                                items: g,
                                discount: d.cart.coupon_discount ? ? 0,
                                shipment: d.cart.shipping_cost ? ? 0,
                                currency: c.order_currency || "USD",
                                request_source: "vivoTransaction"
                            };
                            return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?type=vivoTransaction&siteId=${this.siteId}`,
                                g, this.siteId, g.idorder)
                        }
                    };
                setInterval(() => {
                    f()
                }, 5E3)
            }
        }
    }
    sendTuningTransaction() {
        if ("undefined" !== typeof dataLayer && !this.heatmapThankYouHasSentTrx) {
            var a = dataLayer.find(e => "fireEvent" === e.event),
                b = dataLayer.find(e => "fireConversion" === e.event),
                c = {},
                d = [];
            a && (a = a.ecommerce, c = {
                ecommerce: a
            }, d = a.purchase.products.map(function(e) {
                return {
                    price: e.price,
                    quantity: e.quantity,
                    title: e.name.replace(/['"]+/g, ""),
                    sku: e.id
                }
            }));
            if (b) {
                const {
                    conversionValue: e,
                    conversionCurrency: f,
                    conversionOrderID: g
                } = b;
                c = { ...c,
                    conversionValue: e,
                    conversionCurrency: f,
                    conversionOrderID: g
                }
            }
            if (0 === Object.keys(c).length) return !0;
            b = {
                idorder: c.conversionOrderID,
                revenue: c.conversionValue,
                items: d,
                currency: "undefined" !== typeof c.conversionCurrency ? c.conversionCurrency : "USD",
                shipping: c.ecommerce.purchase.actionField.shipping,
                request_source: "heatmapWikinggruppenSnippet"
            };
            return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?type=Wikinggruppen&siteId=${this.siteId}`, b, this.siteId, b.idorder)
        }
    }
    cheeseAndWineTransaction() {
        if (!this.heatmapThankYouHasSentTrx) {
            var a =
                localStorage.getItem("cheeseOrderDetail"),
                b = localStorage.getItem("trackedCompleteOrderSourceId");
            if (a && b && "null" !== b) {
                a = JSON.parse(a);
                if ("undefined" == typeof a[0]) return !0;
                b = [];
                a = a[0][2];
                b = a.items.map(function(c) {
                    return {
                        price: c.price,
                        quantity: c.quantity,
                        title: c.item_name.replace(/['"]+/g, ""),
                        sku: c.sku
                    }
                });
                a = {
                    idorder: a.cart_id,
                    revenue: a.value,
                    items: b,
                    currency: a.currency,
                    request_source: "cheeseAndWineTransaction"
                };
                return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?type=cheeseAndWineTransaction&siteId=${this.siteId}`,
                    a, this.siteId, a.idorder)
            }
        }
    }
    lifeTroveConversion() {
        if ("undefined" !== typeof getOrderDataObj) {
            let a = getOrderDataObj();
            if ("undefined" !== typeof a.orderData) try {
                let b = {
                    currency: a.orderData.currencyCode || a.orderData.baseCurrencyCode || "USD",
                    idorder: a.orderData.orderId || "",
                    revenue: a.orderData.orderValue || 0,
                    created_at: this.dateObj.toISOString(),
                    shipment: a.orderData.shipTotal || 0,
                    items: a ? .orderData ? .items ? .map(c => ({
                        sku: c.variantSku || c.externalProductId,
                        quantity: c.productQty,
                        title: c.name,
                        price: c.price
                    }))
                };
                if (b.idorder) return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${b.idorder}`,
                    b, this.siteId, b.idorder)
            } catch (b) {
                console.log(b)
            }
        }
    }
    heatmapSkinnyRxTransaction() {
        if (!this.heatmapThankYouHasSentTrx) {
            var a = new URLSearchParams(window.location.search),
                b = a.get("txid");
            a = a.get("ot");
            if (!b || !a) return !0;
            var c = [{
                price: a,
                quantity: 1,
                product: {
                    title: "Weight Loss Subscription"
                },
                sku: Math.floor(this.dateObj.getTime() / 1E3)
            }];
            b = {
                currency: "USD",
                idorder: Number(b).toString(),
                revenue: a,
                created_at: this.dateObj.toISOString(),
                items: c
            };
            return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${b.idorder}`,
                b, this.siteId, b.idorder)
        }
    }
    loadDataLayer() {
        if ("undefined" !== typeof dataLayer && !this.heatmapThankYouHasSentTrx) {
            var a = dataLayer.filter(b => (b = b.event || b.vrio_event || "event" === b[0] && b[1]) && this.dataLayerSet.has(b));
            if (a.length) {
                a = JSON.stringify({
                    sample: a,
                    siteId: this.siteId,
                    request: "debug"
                });
                try {
                    navigator.sendBeacon("https://stage1.heatmapcore.com/backend/tracking/gtm", a)
                } catch (b) {
                    window.fetch("https://stage1.heatmapcore.com/backend/tracking/gtm", {
                        method: "POST",
                        body: a
                    })
                }
            }
        }
    }
    AutoGenerateSnippet() {
        try {
            "undefined" ===
            typeof dataLayer || this.loadSiteScript || (this.loadScript(`https://c.heatmap.com/conversions/data_layer_${this.siteId}.js`), this.loadSiteScript = !0), setTimeout(() => {
                this.loadDataLayer()
            }, 2E3)
        } catch (a) {}
    }
    hollowayTransaction() {
        if (!this.heatmapThankYouHasSentTrx && 1906 === this.siteId) {
            var a = () => {
                    var c = document.querySelectorAll("div");
                    for (const d of c)
                        if (c = Array.from(d.getElementsByTagName("div")).find(e => e.textContent.includes("Total:")))
                            if (c = (c = c.nextElementSibling) ? b(c) : 0) return c;
                    return 0
                },
                b = c => (c = Array.from(c.getElementsByTagName("span")).find(d =>
                    d.textContent.trim().startsWith("$"))) ? (c = parseFloat(c.textContent.trim().substring(1)), isNaN(c) ? 0 : c) : 0;
            try {
                const c = a();
                if (c) {
                    const d = [{
                        price: c,
                        quantity: 1,
                        product: {
                            title: "Weight Loss Subscription"
                        },
                        sku: Math.floor(this.dateObj.getTime() / 1E3)
                    }];
                    let e = {
                        currency: "USD",
                        idorder: this.dateObj.getTime().toString(),
                        revenue: c,
                        items: d
                    };
                    return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${e.idorder}`, e, this.siteId, e.idorder)
                }
            } catch (c) {}
        }
    }
    modifyHealth() {
        if (!this.heatmapThankYouHasSentTrx) {
            var a =
                document.querySelector('.cart__submit-controls input[name="checkout"]'),
                b = localStorage.getItem("modifyHealthOrderDetail");
            a && b && (b = JSON.parse(b)[0], a.addEventListener("click", () => {
                let c = [];
                b.productPrice.forEach((e, f) => {
                    c.push({
                        price: e,
                        quantity: b.productQuantity[f],
                        product: {
                            title: b.productName[f]
                        },
                        sku: b.productSKU[f]
                    })
                });
                let d = {
                    currency: b.currency,
                    revenue: b.totalValue,
                    idorder: this.dateObj.getTime().toString(),
                    items: c
                };
                return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${d.idorder}`,
                    d, this.siteId, d.idorder)
            }))
        }
    }
    enformayaConversion() {
        if (!this.heatmapThankYouHasSentTrx && 1947 === this.siteId && "undefined" !== typeof jQuery) $('div[data-page-element="Button/V1"] a[href="#submit-checkout-form"]').on("click", () => {
            try {
                var a = document.querySelector(".elOrderSummaryTotalPrice");
                if (a) {
                    var b = a.querySelectorAll("font");
                    if (2 === b.length) {
                        var c = b[1].textContent.trim(),
                            d = c.replace("$", "");
                        a = [];
                        a.push({
                            price: d,
                            quantity: 1,
                            product: {
                                title: "In Shape Now"
                            }
                        });
                        if (c) {
                            let e = {
                                currency: "USD",
                                revenue: d,
                                idorder: this.dateObj.getTime().toString(),
                                items: a
                            };
                            return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${e.idorder}`, e, this.siteId, e.idorder)
                        }
                    }
                }
            } catch (e) {}
        })
    }
    processTachaConversion() {
        if (!this.heatmapThankYouHasSentTrx) {
            var a = e => document.querySelector(e) ? document.querySelector(e) : !1;
            if (a(".order-number")) {
                var b = [],
                    c = f => {
                        if (!f || !a(f)) return 0;
                        f = a(f).textContent.trim();
                        return (f = f.match(/\d+(\.\d+)?/)) ? parseFloat(f[0]) : 0
                    },
                    d = document.querySelectorAll(".product-list-items");
                d.length && d.forEach(f => {
                    f.querySelectorAll(".product-line-item").forEach(g => {
                        if (g = g.querySelector("[data-ga-product-info]")) try {
                            const h = g.getAttribute("data-ga-product-info");
                            b.push(JSON.parse(h).items[0])
                        } catch (h) {}
                    })
                });
                d = c(".grand-total-sum");
                let e = c(".shipping-total-cost");
                c = {
                    items: b,
                    idorder: c(".order-number"),
                    tax: c(".tax-total"),
                    revenue: 0 < d ? d : c(".grand-total"),
                    shipment: 0 < e ? e : c(".shipping-cost"),
                    currency: "undefined" !== typeof b[0] ? b[0].currency : "USD"
                };
                0 == c.revenue && (c.revenue = c.shipment + c.tax);
                if (d = (() => {
                        var f = document.querySelector(".container.receipt");
                        if (!f) return !1;
                        if (f = f ? .dataset ? .gtmdata)
                            if (f = JSON.parse(f).ecommerce.purchase, "undefined" !== typeof f.actionField) return {
                                revenue: f.actionField.cartTotal,
                                shipment: f.actionField.shipping,
                                tax: f.actionField.tax,
                                idorder: f.actionField.id,
                                currency: f.actionField.currency || "USD",
                                items: f.products.map(g => ({
                                    price: g.price,
                                    quantity: g.quantity,
                                    title: g.name,
                                    sku: g.id
                                }))
                            };
                        return !1
                    })()) c.revenue = d.revenue, c.shipment = 0 < d.shipment ? d.shipment : c.shipment, c.tax = 0 < d.tax ? d.tax : c.tax, c.currency = d.currency, c.items = d.items, c.idorder = d.idorder;
                return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${c.idorder}`, c, this.siteId, c.idorder)
            }
        }
    }
    processImmersiveGames() {
        if (1 == this.heatmapThankYouHasSentTrx) return !0;
        var a = window.location.search;
        if (!a.length || !window.location.search.includes("?orderDetails=")) return !0;
        a = new URLSearchParams(a);
        a = JSON.parse(a.get("orderDetails"));
        if (!a) return !0;
        a = {
            items: a.bookings[0].tickets.map(b => ({
                sku: b.reference,
                quantity: 1,
                title: b.tier.name,
                price: b.total
            })),
            idorder: a.id,
            revenue: a.total,
            currency: a.currency
        };
        return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${a.idorder}`, a, this.siteId, a.idorder)
    }
    getHeatmapCrossDomainCookie(a) {
        var b = document.cookie.split(";");
        try {
            for (var c = null, d = 0; d < b.length; d++) {
                var e = b[d].split("="),
                    f = e[1];
                if (e[0].trim() === a.trim()) {
                    c = f;
                    break
                }
            }
            return c
        } catch (g) {
            return null
        }
    }
    publishingConversion() {
        if (1 == this.heatmapThankYouHasSentTrx) return !0;
        if ("undefined" === typeof window.publishingConv) {
            var a = this.getHeatmapCrossDomainCookie(`_pubConv_${this.siteId}`);
            if (!a) return !0;
            a = JSON.parse(decodeURIComponent(a));
            window.publishingConv = a
        }
        a = {
            items: [window.publishingConv.product],
            idorder: this.dateObj.getTime().toString(),
            revenue: window.publishingConv.revenue.replace(/[^\d.]/g, ""),
            currency: "USD"
        };
        this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${a.idorder}`, a, this.siteId, a.idorder);
        document.cookie = `_pubConv_${this.siteId}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=.publishing.com;`;
        return !0
    }
    heatmapCustomGTMSnippet(a,
        b, c, d) {
        return this.heatmapThankYouSendBeacon(a, b, c, d)
    }
    heatmapCustomConversion(a = "heatmapConversion") {
        if (1 == this.heatmapThankYouHasSentTrx) return !0;
        if ("undefined" !== typeof window.heatmapPayload) return a = window.heatmapPayload, a.idsite = this.siteId, this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?type=customConversion&siteId=${this.siteId}`, a, this.siteId, a.idorder);
        if ("undefined" !== typeof window.Shopify) {
            var b = "undefined" !== typeof window.Shopify.order ? window.Shopify.order : window.Shopify.checkout;
            if ("undefined" !== typeof b) {
                if (1 == this.heatmapThankYouHasSentTrx) return !0;
                var c = [];
                c = "undefined" !== typeof window.Shopify.order ? b.lineItems.map(function(h) {
                    return {
                        price: h.price,
                        quantity: h.quantity,
                        product: {
                            title: h.title
                        },
                        sku: h.variant.sku
                    }
                }) : b.line_items.map(function(h) {
                    return {
                        price: h.price,
                        quantity: h.quantity,
                        product: {
                            title: h.title
                        },
                        sku: h.sku
                    }
                });
                var d = "undefined" !== typeof b.order_number ? b.order_number : "undefined" !== typeof b.order_id ? b.order_id : b.id;
                let e = 0;
                "undefined" !== typeof b.discounts && null !==
                    b.discounts ? "undefined" !== typeof b.discounts[0].amount && (e = parseFloat(b.discounts[0].amount)) : "undefined" !== typeof b.discount && null !== b.discount && "undefined" !== typeof b.discount.amount ? e = b.discount.amount : "undefined" !== typeof b.discount && (e = b.discount);
                let f = 0,
                    g = this.dateObj.toISOString();
                b.shipping && (f = b.shipping);
                b.shipping_rate && (f = b.shipping_rate.price ? b.shipping_rate.price : b.shipping_rate);
                "undefined" !== typeof b.created_at && (g = b.created_at);
                b = {
                    currency: "undefined" !== typeof b.currency ? b.currency : "USD",
                    idorder: Number(d).toString(),
                    revenue: "undefined" !== typeof b.totalPrice ? b.totalPrice : b.total_price,
                    created_at: g,
                    shipping: f,
                    discount: e,
                    items: c
                };
                if (!b.idorder.length) return !0;
                this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?type=${a}&siteId=${this.siteId}`, b, this.siteId, b.idorder)
            }
        }
        if ("undefined" !== typeof betterCartData) return this.heatmapBetterCartSnippet(betterCartData);
        if ([3354].includes(this.siteId)) try {
            fetch(`https://api.inspireuplift.com/api/order${window.location.pathname}`, {
                method: "GET",
                headers: {
                    Referer: window.location.origin,
                    "X-Custom-Origin": window.location.origin,
                    Cookie: document.cookie,
                    Accept: "application/json"
                },
                credentials: "include"
            }).then(e => e.json()).then(e => {
                e = {
                    idorder: e.data.id,
                    shipment: e.data.total_shipping,
                    discount: e.data.total_discount,
                    revenue: e.data.grand_total,
                    items: e.data.line_items.map(f => ({
                        id: f.id,
                        sku: f.sku,
                        price: f.price,
                        quantity: f.quantity,
                        title: f.name,
                        product: {
                            title: f.name
                        }
                    })),
                    created_at: e.data.created_at
                };
                return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?type=dataLayer&siteId=${this.siteId}`,
                    e, this.siteId, e.idorder)
            }).catch(e => {})
        } catch (e) {}
        if (localStorage.getItem("cleanco-cart") || localStorage.getItem("cleanco-cart")) {
            a = "";
            a = localStorage.getItem("nutrisense:purchase") ? JSON.parse(localStorage.getItem("nutrisense:purchase")) : JSON.parse(localStorage.getItem("cleanco-cart"));
            c = [];
            if ("undefined" !== typeof a.products)
                for (d = a.products, b = 0; b < d.length; b++) c.push({
                    sku: d[b].id,
                    quantity: d[b].quantity,
                    price: d[b].price,
                    product: {
                        title: d[b].name.replace(/['"]+/g, "")
                    }
                });
            if (a.length) return a = {
                currency: "undefined" !==
                    typeof HOrder.currency ? HOrder.currency : "USD",
                idorder: "undefined" !== typeof checkout_order_id ? checkout_order_id : a.transactionId,
                revenue: "undefined" !== typeof a.revenue ? a.revenue : a.transactionTotal,
                items: c,
                request_source: "cleanCoNutrisense"
            }, this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?type=${a.request_source}&siteId=${this.siteId}`, a, this.siteId, a.idorder)
        }
        if (localStorage.getItem("order") && (a = JSON.parse(localStorage.getItem("order")), a.state && a.state.orders.length && (a = a.state.orders[0],
                "undefined" !== typeof a.items))) return b = [], b = a.items.map(function(e) {
            return {
                price: e.price,
                quantity: e.quantity,
                title: e.productName.replace(/['"]+/g, ""),
                sku: e.sku
            }
        }), a = {
            discount: 0 !== a.totals.discount ? a.totals.discount / 100 : a.totals.discount,
            shipment: 0 !== a.totals.shipping ? a.totals.shipping / 100 : a.totals.shipping,
            revenue: a.totals.grandTotal / 100,
            currency: a.currency,
            items: b,
            idorder: a.uid,
            request_source: "betterCart",
            idsite: this.siteId
        }, this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?type=betterCart&siteId=${this.siteId}`,
            a, this.siteId, a.idorder)
    }
    heatmapPushTransactionData(a) {
        var b = [];
        a.lineItems && (b = a.lineItems.map(function(c) {
            return {
                price: c.price,
                quantity: c.quantity,
                product: {
                    title: c.title
                },
                sku: c.sku
            }
        }));
        a = {
            currency: "undefined" !== typeof a.currency ? a.currency : "USD",
            idorder: a.id,
            revenue: a.totalPrice,
            items: b,
            request_source: "heatmapPushTransactionData"
        };
        return a.idorder ? this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?type=${a.request_source}&siteId=${this.siteId}`, a, this.siteId, a.idorder) : !0
    }
    heatmapBetterCartSnippet(a) {
        if (a.order) {
            let b =
                a.order,
                c = 0,
                d = b.lineItems,
                e = [];
            for (a = 0; a < d.length; a++) c += Number(parseFloat(d[a].variant.price).toFixed(2)), e.push({
                sku: d[a].variant.sku,
                quantity: d[a].quantity,
                price: Number(parseFloat(d[a].variant.price).toFixed(2)),
                title: d[a].variant.product.title.replace(/['"]+/g, "")
            });
            a = {
                idorder: b.id,
                revenue: b.total,
                items: e,
                currency: "undefined" !== typeof b.currency ? b.currency : "USD",
                shipment: "" == b.shipping ? 0 : parseInt(b.shipping),
                shipping: "" == b.shipping ? 0 : parseInt(b.shipping),
                discount: parseInt(b.savings),
                request_source: "heatmapBetterCartSnippet",
                type: "betterCart"
            };
            return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?type=betterCart&siteId=${this.siteId}`, a, this.siteId, a.idorder)
        }
    }
    heatmapRawConversionTransaction(a) {
        if (!a) return !0;
        var b = [];
        a.productsList && a.productsList.length && (b = a.productsList.map(function(c) {
            return {
                price: c.price,
                quantity: c.quantity,
                title: c.title.replace(/['"]+/g, ""),
                sku: c.sku
            }
        }));
        if (5 == a.order_number && 200 == a.discount && 300 == a.shipping) return this.heatmapThankYouHasSentTrx = !0, !1;
        b = {
            idorder: a.order_number,
            revenue: a.totalPrice,
            items: b,
            discount: a.discount ? ? 0,
            shipment: a.shipping ? ? 0,
            currency: a.currency ? ? "USD",
            request_source: "heatmapRawConversionTransaction"
        };
        return b.idorder ? this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${a.order_number}`, b, this.siteId, b.idorder) : !0
    }
    heatmapProcessCheckoutAmended(a, b, c) {
        var d = c.lineItems.map(function(e) {
            return e.id
        });
        a = b.lineItems.filter(function(e) {
            return 0 > d.indexOf(e.id)
        });
        if (0 !== a.length) return a.map(function(e) {
            return {
                price: e.price,
                quantity: e.quantity,
                product: {
                    title: e.title.replace(/['"]+/g, "")
                },
                sku: e.variant.sku
            }
        }).reduce(function(e, f) {
            return e + Number(f.price)
        }, 0), this.heatmapThankYouHasSentTrx = !1, this.heatmapCustomConversion("heatmapProcessCheckoutAmended")
    }
    retrieveTransaction(a) {
        var b = [],
            c = [];
        a ? .map(d => {
            "undefined" !== typeof d[1] && "undefined" !== typeof d[2] ? ["purchase"].includes(d[1]) && ("undefined" !== typeof d[2].page_type ? c = d : b = d) : "undefined" !== typeof d.event && "purchase" === d.event && "undefined" !== typeof d.ecommerce && (c = d.ecommerce)
        });
        return c ?
            c : b
    }
    ginovaTransaction() {
        if (!this.heatmapThankYouHasSentTrx && window.location.href.includes("id_cart") && window.location.href.includes("id_order")) try {
            if (!document.querySelectorAll(".order-line").length) return !0;
            const a = [];
            let b = 0,
                c = null;
            document.querySelectorAll(".order-line").forEach(h => {
                const k = h.querySelector(".details span").textContent.trim(),
                    m = parseInt(h.querySelector(".col-xs-2").textContent.trim());
                h = parseFloat(h.querySelector(".col-xs-5.text-xs-right.bold").textContent.trim().replace("\u20ac",
                    "").replace(",", "."));
                b += h * m;
                a.push({
                    title: k,
                    quantity: m,
                    price: h
                })
            });
            const d = document.querySelector(".total td:last-child");
            d && (b = parseFloat(d.textContent.trim().replace("\u20ac", "").replace(",", ".")));
            const e = [...document.querySelectorAll("table tr")].find(h => h.textContent.includes("Shipping and handling"));
            if (e) {
                const h = e.querySelector("td:last-child").textContent.trim();
                c = "Free" === h ? 0 : parseFloat(h.replace("\u20ac", "").replace(",", "."))
            }
            const f = [...document.querySelectorAll("table tr")].find(h =>
                h.textContent.includes("Tax"));
            f && parseFloat(f.querySelector("td:last-child").textContent.trim().replace("\u20ac", "").replace(",", "."));
            let g = {
                idorder: this.urlParams.get("id_order"),
                revenue: b,
                items: a,
                currency: "EUR",
                shipment: c,
                shipping: c,
                discount: 0,
                request_source: "ginovaTransaction"
            };
            return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${g.idorder}`, g, this.siteId, g.idorder)
        } catch (a) {}
    }
    pourMoiTransaction() {
        if ("undefined" !== typeof dataLayer) try {
            const e = dataLayer.find(k =>
                "purchase" === k.event || "dl_purchase" === k.event);
            if (!e) return null;
            const f = ("undefined" !== typeof e.ecommerce.items ? e.ecommerce.items : e.ecommerce.purchase.products).map(k => ({
                    title: k.name || k.item_name || k.title,
                    quantity: k.quantity,
                    sku: k.SKU || k.item_id || k.id,
                    price: k.price
                })),
                g = "undefined" !== typeof e.ecommerce.purchase ? e.ecommerce.purchase.actionField : e.ecommerce;
            var a = g.revenue || g.value || 0,
                b = g.shipping || g.shippingAmount || 0,
                c = e.transactionOrderDiscountsTotal || 0,
                d = null;
            d = "undefined" !== typeof g.id ? g.id : "undefined" !==
                typeof e.ecommerce.transaction_id ? e.ecommerce.transaction_id : "undefined" !== typeof e.ecommerce.orderId ? e.ecommerce.orderId : Math.floor(Date.now() / 1E3).toString();
            const h = {
                idsite: this.siteId,
                idorder: d,
                revenue: a,
                items: f,
                currency: e.ecommerce.currency || e.ecommerce.currencyCode || "USD",
                shipment: b,
                discount: c,
                quicktransaction: 1
            };
            return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${h.idorder}`, h, this.siteId, h.idorder)
        } catch (e) {}
    }
    haengemattengigantConversion() {
        if ("undefined" !==
            typeof dataLayer) {
            var a = new Set(["purchase_ga4", "transaction", "FundraiseUp.donationComplete"]),
                b = new Set(["purchase"]),
                c = dataLayer.filter(d => (d = d.event || d.vrio_event || "event" === d[0] && d[1]) && a.has(d));
            try {
                if (0 === c.length && (c = dataLayer.filter(l => (l = l.event || l.vrio_event || "event" === l[0] && l[1]) && b.has(l)), 0 === c.length)) return;
                const d = c[0].ecommerce,
                    e = d ? .transaction_id || Date.now().toString(),
                    f = (d.items || d ? .purchase_notGA ? .products || []).map(l => ({
                        title: l.item_name || l.name || "Unknown Item",
                        sku: l.item_id ||
                            l.id || "N/A",
                        quantity: l.quantity || 0,
                        price: parseFloat(l.price) || 0
                    })),
                    g = d.value || c[0] ? .ecomm_totalvalue || 0,
                    h = parseFloat(d.shipping) || 0,
                    k = d.currency || c[0] ? .currencyCode || "USD",
                    m = {
                        idorder: e,
                        idsite: this.siteId,
                        items: f,
                        revenue: parseFloat(g),
                        shipment: h,
                        discount: 0,
                        currency: k
                    };
                return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${m.idorder}&revenue=${m.revenue}`, m, this.siteId, m.idorder)
            } catch (d) {}
        }
    }
    processToolNutConversion() {
        var a = [],
            b = [],
            c = 0,
            d = !1;
        try {
            if ("undefined" !==
                typeof dataLayer) {
                for (var e of dataLayer)
                    if ("purchase" === e.event) {
                        var f = e.ecommerce;
                        a = f;
                        d = !0;
                        try {
                            let g = "undefined" !== typeof a.items ? a.items : [];
                            "undefined" !== typeof e.ecommerce.purchase && (f = e.ecommerce.purchase, "undefined" !== typeof e.ecommerce.purchase.actionField && (g = e.ecommerce.purchase.products, f = e.ecommerce.purchase.actionField));
                            b = g;
                            c = "undefined" !== typeof b ? b.length : c;
                            a = f
                        } catch (g) {}
                    }
                if (d && "undefined" !== typeof a.transaction_id) {
                    d = [];
                    for (f = e = 0; f < c; f++) e += parseFloat(b[f].price), d.push({
                        product: {
                            title: "undefined" !==
                                typeof b[f].item_name ? b[f].item_name.replace(/['"]+/g, "") : "Product"
                        },
                        quantity: b[f].quantity,
                        sku: b[f].sku,
                        price: b[f].price,
                        item_id: b[f].item_id
                    });
                    let g = {
                            currency: "undefined" !== typeof a.currency ? a.currency : "undefined" !== typeof a.currencyCode ? a.currencyCode : "USD",
                            idorder: a.transaction_id,
                            shipping: "undefined" !== typeof a.shipping ? a.shipping : 0,
                            discount: "undefined" !== typeof a.discount ? a.discount : 0,
                            items: d
                        },
                        h = parseFloat(void 0 !== a.value ? a.value : e);
                    g.revenue = Number(parseFloat(void 0 !== a.value ? a.value : e).toFixed(2));
                    "undefined" !== typeof h && h !== e && 0 == g.discount && (g.discount = e - h);
                    this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${g.idorder}`, g, this.siteId, g.idorder)
                }
            }
        } catch (g) {}
    }
    vetrinexlabsConversion() {
        if (!this.heatmapThankYouHasSentTrx) {
            if (2184 !== this.siteId) return !0;
            var a = () => {
                    var d = document.querySelector(".elOrderSummaryV2");
                    if (!(d && 0 < d.offsetWidth && 0 < d.offsetHeight)) return [];
                    let e = [];
                    const f = g => (g = g.match(/\d+/)) ? parseInt(g[0], 10) : null;
                    d.querySelectorAll(".elOrderSummaryProduct").forEach(g => {
                        if (g = g.querySelector(".elOrderSummaryProductInfoWrapper")) {
                            var h = g.querySelector("span:first-child");
                            g = g.querySelectorAll("div span");
                            if (h && 2 <= g.length) {
                                h = h.textContent.trim();
                                const k = f(g[1].textContent.trim());
                                g = f(g[2].textContent.trim().replace(/[^\d.-]/g, ""));
                                k && g && e.push({
                                    title: h,
                                    quantity: k,
                                    price: g,
                                    sku: h
                                })
                            }
                        }
                    });
                    d = (d = document.querySelector(".elOrderSummaryTotalWrapper")) ? parseFloat(d.textContent.trim().replace(/[^\d.-]/g, "")) : 0;
                    return {
                        products: e,
                        revenue: d
                    }
                },
                b = d => 0 < d.offsetWidth && 0 < d.offsetHeight &&
                "hidden" !== window.getComputedStyle(d).visibility,
                c = () => {
                    var d = a();
                    d = {
                        idorder: Math.floor((new Date).getTime() / 1E3),
                        request_source: "vetrinexlabsConversion",
                        revenue: d.revenue,
                        items: d.products,
                        currency: "USD"
                    };
                    return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${d.idorder}`, d, this.siteId, d.idorder)
                };
            window.addEventListener("click", () => {
                a: {
                    var d = document.querySelectorAll('[data-page-element="CheckoutStepButton/V1"] .elButton');
                    for (const e of d)
                        if (b(e)) {
                            d = e;
                            break a
                        }
                    d = null
                }
                d && d.addEventListener("click", c)
            })
        }
    }
    processSkinnyrx() {
        if (!this.heatmapThankYouHasSentTrx) {
            if (1910 !== this.siteId) return !0;
            var a = () => {
                    let c = 0;
                    document.querySelectorAll("div").forEach(d => {
                        /\$\d/.test(d.innerHTML) && (c = (d = d.innerHTML.match(/\$([\d,]+)/)) ? parseFloat(d[1].replace(/,/g, "")) : 0)
                    });
                    console.log("Total Value:", c);
                    0 < c && clearInterval(skinnyInterval)
                },
                b = c => {
                    c.querySelectorAll('button[type="submit"]').forEach(d => {
                        if (d.innerHTML.includes("Checkout")) {
                            const e = function(f) {
                                a();
                                d.removeEventListener("click",
                                    e)
                            };
                            d.addEventListener("click", e)
                        }
                    })
                };
            document.querySelectorAll("form").forEach(c => {
                const d = c.querySelector("#cardNumber"),
                    e = c.querySelector("#cardHolderName");
                d && e && b(c)
            })
        }
    }
    heatmapProcessBCConversionData(a = []) {
        try {
            var b = this.heatmapGetBCOrderId();
            if (isNaN(b)) return !0;
            "undefined" !== typeof b && 0 !== b && (this.loadScript(this.apiPaths.bigcommerce), setTimeout(async () => {
                if ("undefined" !== typeof checkoutKitLoader) {
                    const f = (await (await checkoutKitLoader.load("checkout-sdk")).createCheckoutService().loadOrder(b)).data.getOrder();
                    return this.heatmapManipulateBCConversionData(f)
                }
            }, 500));
            if ("undefined" !== typeof checkoutKitLoader && /checkout/ig.test(window.location.href)) {
                var c = this.retrieveTransaction(a),
                    d = [];
                c[2] ? .items ? .forEach(function(f) {
                    f = {
                        sku: f.item_id,
                        price: f.price,
                        quantity: f.quantity,
                        title: ("undefined" !== typeof f ? .item_name ? f ? .item_name : f ? .name).replace(/['"]+/g, "")
                    };
                    d.push(f)
                });
                var e = {
                    idorder: c[2] ? .transaction_id,
                    revenue: c[2] ? .value,
                    items: d,
                    shipment: c[2] ? .shipping,
                    currency: c[2] ? .currency
                };
                return this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${e.idorder}`,
                    e, this.siteId, e.idorder)
            }
        } catch (f) {}
    }
    extractOrderFromShopSerabel() {
        if ([3630].includes(this.siteId)) {
            if (!document.querySelectorAll(".order-summary-link-container")) return null;
            var a = document.querySelectorAll(".product_wrapper[data-variant-id]"),
                b = [];
            a && a.forEach(c => {
                const d = c.querySelector(".os-name span") ? .innerText.trim() || "",
                    e = c.querySelector(".qty") ? .innerText.trim() || "",
                    f = c.querySelector(".finalPrice strong") ? .innerText.trim() || "";
                c = c.getAttribute("data-variant-id") || "";
                b.push({
                    title: d,
                    quantity: parseInt(e,
                        10),
                    price: f.replace(/[^\d.,]/g, "").replace(",", "."),
                    sku: c
                })
            });
            a = {
                revenue: document.querySelector(".grandTotal").innerHTML.replace(/[^\d.,]/g, "").replace(",", "."),
                items: b,
                currency: "USD"
            };
            localStorage.setItem("uOrder", JSON.stringify(a))
        }
    }
    nativePathConversion(a) {
        if ("undefined" !== typeof dataLayer) try {
            this.extractOrderFromShopSerabel();
            a = {
                discount: 0,
                shipment: 0,
                revenue: 0,
                currency: "",
                items: [],
                idorder: ""
            };
            let b = dataLayer.find(c => "event" === c[0] && "purchase" === c[1]);
            [3454, 3549, 3630, 3663].includes(this.siteId) &&
                (b = dataLayer.find(c => "event" === c[0] && "purchase" === c[1] && "undefined" !== typeof c[2].shipping));
            3443 === this.siteId && (b = dataLayer.find(c => "Purchase" === c.event)) && (a.revenue = b.value || 0, a.currency = b.currency || b.currencyCode || "", a.idorder = (new URLSearchParams(window.location.search)).get("o") || Date.now(), a.shipment = b.shipping || 0, a.items = {
                title: b.content_name || "",
                price: parseFloat(b.value) || 0,
                quantity: 1,
                sku: ""
            });
            if (b && b[2]) {
                const c = b[2];
                a.revenue = c.value || 0;
                a.currency = c.currency || c.currencyCode || "";
                a.idorder =
                    c.transaction_id || "";
                a.shipment = c.shipping || 0;
                c.items && Array.isArray(c.items) && (a.items = c.items.map(d => ({
                    title: d.item_name || "",
                    price: parseFloat(d.price) || 0,
                    quantity: d.quantity || 1,
                    sku: d.item_id || ""
                })))
            }!localStorage.getItem(`purch_${this.getCookie(`_heatVid_${this.siteId}`)}`) && a.idorder && (a._idv = this.getCookie(`_heatVid_${this.siteId}`), a.idsite = this.siteId, a.device_type = this.heatmapGetDeviceFromStore(), navigator.sendBeacon(`${this.apiPaths.trackerURL}?data=${window.btoa(encodeURIComponent(JSON.stringify(a)))}&request=conversion&siteId=${this.siteId}`),
                localStorage.setItem("heatIsGoalBuyer", 1), localStorage.setItem("heatIsGoalBuyerCurrency", a.currency), localStorage.setItem("heatIsGoalBuyerValue", a.revenue), localStorage.setItem("heatIsGoalBuyerAmount", a.revenue), localStorage.setItem(`purch_${this.getCookie(`_heatVid_${a.revenue}`)}`, 1))
        } catch (b) {
            console.log(b)
        }
    }
    processTransactionZyrofisher() {
        try {
            if ("undefined" !== typeof dataLayer)
                for (var a of dataLayer)
                    if ("transactionCompleted" === a.event) {
                        var b = a.ecommerce ? .purchase;
                        const c = b ? .actionField || {},
                            d = b ? .products || [];
                        if (c.id) {
                            a = [];
                            b = 0;
                            for (let g of d) {
                                let h = parseFloat(g.price || 0),
                                    k = parseInt(g.quantity || 1);
                                b += h * k;
                                a.push({
                                    product: {
                                        title: (g.name || "Product").replace(/['"]+/g, "")
                                    },
                                    quantity: k,
                                    sku: g.id || "",
                                    price: h,
                                    item_id: g.id || ""
                                })
                            }
                            const e = {
                                    currency: "USD",
                                    idorder: c.id,
                                    shipping: parseFloat(c.shipping || 0),
                                    discount: 0,
                                    items: a
                                },
                                f = parseFloat(c.revenue || b);
                            e.revenue = Number(f.toFixed(2));
                            this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${e.idorder}`, e, this.siteId, e.idorder);
                            break
                        }
                    }
        } catch (c) {
            console.error("Error in processTransactionCompletedConversion:",
                c)
        }
    }
    goNutreConversion() {
        var a = localStorage.getItem("kl-post-identification-sync"),
            b = localStorage.getItem("kl-post-identification-synctemp");
        if (a || b)
            if (a = JSON.parse(a), b ? a = b = JSON.parse(b) : localStorage.setItem("kl-post-identification-synctemp", JSON.stringify(a)), 0 < a.length) {
                b = [];
                for (var c = a.length - 1; 0 <= c; c--)
                    if ("Added to Cart" === a[c].name) {
                        b = a[c];
                        break
                    }
                a = b ? .properties ? .Items ? .map(d => ({
                    title: d.ProductName.replace(/"/g, ""),
                    quantity: d.Quantity,
                    sku: d.ProductID,
                    price: d.RowTotal
                }));
                a = {
                    idorder: 0,
                    revenue: b ? .properties ? .$value,
                    items: a,
                    currency: "USD"
                };
                if ("undefined" !== typeof dataLayer) {
                    c = b = !1;
                    for (let d of dataLayer) "subscription_created" === d.event && (a.idorder = d.subscription_id, a.discount = d.discount_amount, a.revenue = d.net_amount, a.currency = d.currency, b = !0), b || ("undefined" !== typeof d["gtm.elementId"] && "gtm.formSubmit" === d.event && "checkout-form" == d["gtm.elementId"] && (c = !0), "undefined" !== typeof d.user_id && "page_view" == d.event && (a.idorder = d.user_id, c = !0));
                    if (b || c) this.heatmapThankYouSendBeacon(`${this.apiPaths.trackerURL}?siteId=${this.siteId}&idorder=${a.idorder}`,
                        a, this.siteId, a.idorder), localStorage.removeItem("kl-post-identification-synctemp")
                }
            }
    }
    getEventKey(a) {
        return "undefined" !== typeof a[0] && "undefined" !== typeof a[1] ? a[1] : "undefined" !== typeof a.event ? a.event : ""
    }
    matchEventToTracker(a) {
        if (!a) return null;
        var b = [{
            patterns: [/purchase_ga4/, /purchase/i, /order_complete/i, /transactionSuccess/i, /gtm-purchase/i, /dl_purchase/i, /vp_purchase/i, /subscription_created/i, /trytagging_purchase/i, /trytagging_transaction/i, /order-received/i],
            handlerTag: "checkout_completed",
            processingTag: "hPurchase"
        }];
        for (const c of b)
            for (const d of c.patterns)
                if (d.test(a)) return c;
        return null
    }
    setupDataLayerListener() {
        "undefined" === typeof window.dataLayer && (window.dataLayer = []);
        const a = window.dataLayer.push;
        window.dataLayer.push = function() {
            const b = a.apply(this, arguments),
                c = arguments[0];
            if (c) try {
                const d = this.getEventKey(c),
                    e = this.matchEventToTracker(d);
                e && "checkout_completed" === e.handlerTag && (this.lambdaDataLayerObject(), this.clientsToTrigger())
            } catch (d) {}
            return b
        }
    }
    clientsToTrigger() {
        this.goNutreConversion();
        this.processToolNutConversion();
        this.processToddlegramTransaction();
        this.pourMoiTransaction();
        this.lifeTroveConversion();
        this.cheeseAndWineTransaction();
        this.sendVivoTransaction();
        this.heatmapSkinnyRxTransaction();
        this.hollowayTransaction();
        this.modifyHealth();
        this.nativePathConversion("first");
        this.haengemattengigantConversion();
        this.ginovaTransaction();
        this.processTachaConversion();
        this.processImmersiveGames();
        this.enformayaConversion();
        this.heatmapProcessBCConversionData();
        this.sendTuningTransaction();
        this.publishingConversion();
        this.processTransactionZyrofisher()
    }
    triggerCustomSiteSnippets() {
        setTimeout(() => {
            this.setupDataLayerListener();
            this.clientsToTrigger()
        }, 1E3);
        setTimeout(() => {
            this.clientsToTrigger();
            this.lambdaDataLayerObject()
        }, 3E3)
    }
}
var convObj = [];
convObj.apiPaths || (convObj = new ConversionsHandler, convObj.init());
const heatmapRawConversionTransaction = (a, b, c) => {
        convObj.heatmapRawConversionTransaction(c)
    },
    processSkinnyrx = a => {
        convObj.processSkinnyrx(a)
    },
    vetrinexlabsConversion = a => {
        convObj.vetrinexlabsConversion(a)
    },
    heatmapProcessBCConversionData = () => {},
    heatmapPushTransactionData = (a, b) => {
        convObj.heatmapPushTransactionData(b)
    },
    heatmapCustomGTMSnippet = (a, b, c, d) => {
        convObj.heatmapCustomGTMSnippet(a, b, c, d)
    },
    heatmapPushTransaction = () => {},
    heatmapThankYouPushTransaction = () => {},
    heatmapExecuteGTMDataLayer = () => {},
    cheeseAndWineTransaction =
    () => {
        convObj.triggerCustomSiteSnippets()
    };
if ("function" === typeof Shopify && "function" === typeof Shopify.on) Shopify.on("CheckoutAmended", function(a, b) {
    convObj.heatmapProcessCheckoutAmended(window.Shopify.order.id, a, b)
});
setTimeout(() => {
    convObj.heatmapCustomConversion("heatmapThankYouPushTransaction");
    convObj.triggerCustomSiteSnippets();
    window.addEventListener("beforeunload", () => {
        convObj.clientsToTrigger()
    })
}, 1E3);