! function(e, t) {
    if (!e.SearchaniseIncluded) {
        e.SearchaniseIncluded = !0;
        for (var a = e.Searchanise || {}, o = ["searchanise.com", "www.searchanise.com", "www.searchserverapi.com", "searchserverapi.com", "searchserverapi1.com", "searchserverapi2.com", "searchserverapi3.com", "searchanise-cloud.com"], s = document.getElementsByTagName("script"), n = 0; n < s.length; n++)
            if (s[n].src) {
                var i = s[n].src.indexOf("/widgets/shopify/init");
                if (-1 != i) {
                    var r = s[n].src.indexOf("//");
                    if (-1 != r) {
                        var l = /a=(?:\s*)([a-zA-Z0-9]{10})/.exec(decodeURIComponent(s[n].src));
                        if (l[1]) {
                            var c = s[n].src.substring(r + 2, i);
                            a.host = "searchanise-ef84.kxcdn.com" == c ? "searchserverapi1.com" : c, a.ApiKey = l[1], a.SearchInput = 'input[name="q"],.mm-search > input[type="text"]', a.options = a.options || {}, a.options.Platform = "shopify", a.options.ResultsDiv = "#snize_results", a.options.ResultsFormPath = "/pages/search-results-page";
                            break
                        }
                    }
                }
            }
        if (a.passiveListenerSupported = !1, a.userOptions = a.options || {}, a.AutoCmpParams = a.AutoCmpParams || {}, a.ResultsParams = a.ResultsParams || {}, a.userOptions.api_key = a.AutoCmpParams.api_key = a.ResultsParams.api_key = a.api_key || a.ApiKey, a.userOptions.SearchInput = a.SearchInput, a.paths = {}, "8e6e2L2f1Z" == a.ApiKey || "5n6r8N5U9E" == a.ApiKey || !1 === a.useCDN ? a.prefix = "//s3.amazonaws.com/static.searchanise.com/" : a.prefix = "//searchanise-ef84.kxcdn.com/", a.paths.jq = a.jq || "//ajax.aspnetcdn.com/ajax/jQuery/jquery-3.7.1.min.js", a.paths.jqRollback = "//ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js", o.includes(a.host) ? (a.rest_host = "https://rest.searchserverapi1.com", a.athena_host = "https://athena.searchserverapi1.com") : (a.rest_host = "https://rest-" + a.host, a.athena_host = "https://athena-" + a.host), o.includes(a.host) ? a.paths.widgets = a.widgets || a.prefix + "widgets.70528.min.js" : a.paths.widgets = "//" + a.host + "/widgets/v2.0/compiled/widgets.min.js", a.paths.tpl = a.tpl || a.prefix + "templates.[API_KEY].js".split("[API_KEY]").join(a.userOptions.api_key), a.paths.styles = a.styles || [], a.paths.preload = a.preload || a.prefix + "preload_data.[API_KEY].js".split("[API_KEY]").join(a.userOptions.api_key), a.userOptions.api_key) {
            try {
                window.addEventListener("snize_test", null, Object.defineProperty({}, "passive", {
                    get: function() {
                        a.passiveListenerSupported = !0
                    }
                }))
            } catch (e) {}
            a.loadScript = function(e, t, a) {
                var o = document.createElement("script");
                o.charset = "utf-8", o.src = e, o.onload = o.onreadystatechange = function() {
                    o.readyState && !/loaded|complete/.test(o.readyState) || (o.onload = o.onreadystatechange = null, o = void 0, t && t())
                }, o.onerror = function() {
                    a && a()
                }, document.getElementsByTagName("head")[0].appendChild(o)
            }, a.loadCss = function(e, t) {
                var a = document.createElement("link");
                a.rel = "stylesheet", a.href = e, a.className = "snize_widget_css";
                var o = setTimeout((function() {
                    a.onload = null, t && t()
                }), 5e3);
                a.onload = function() {
                    clearTimeout(o), t && t()
                }, document.getElementsByTagName("head")[0].appendChild(a)
            }, a.getStyles = function(e) {
                var t = e.AutocompleteStyle ? e.AutocompleteStyle : "ITEMS_MODERN",
                    s = e.ResultsStyle ? e.ResultsStyle : "RESULTS_BIG_PICTURES",
                    n = e.WidgetsEnabled ? e.WidgetsEnabled : "Y",
                    i = e.AutocompleteShow ? e.AutocompleteShow : "Y",
                    r = e.AutocompleteShowMobileWidget ? e.AutocompleteShowMobileWidget : "Y",
                    l = e.ResultsShow ? e.ResultsShow : "N",
                    c = 820,
                    d = [],
                    u = {
                        autocomplete: "",
                        autocompleteMobile: "",
                        results: "",
                        resultsMobile: "",
                        recommendation: "recommendation",
                        quickView: ""
                    };
                if ("N" == n) return d;
                if ("Y" == i && (u.autocomplete = t.toLowerCase(), "Y" == r && (u.autocompleteMobile = u.autocomplete + ".mobile")), "Y" == l) {
                    u.results = s.toLowerCase();
                    for (var p = ["4Q9t1C1f2m", "4U2i7Q9V8K", "2v9E8J8u9L", "1v4z8w8G5o", "1U7i8Y7X7g", "9O6K4x6z8w", "8t9p2u5Q7T", "9Y2d0Z1G9e"], m = ["0p3K6C8h9t"], h = 0; h < p.length; h++) a.ApiKey == p[h] && (c = 1025);
                    for (var f = 0; f < m.length; f++) a.ApiKey == m[f] && (c = 1e3);
                    window.innerWidth <= c && (u.resultsMobile = u.results + ".mobile")
                }
                if (("quick_view" == e.ResultsShowActionButton || "quick_view" == e.RecommendationShowActionButton || ["layout1", "layout2", "layout3", "layout5", "layout6"].includes(e.ResultsActionButtonPlacement)) && (u.quickView = "quick-view"), o.includes(a.host))
                    for (var y in u) u[y] && d.push(a.prefix + u[y] + ".70528.css".split("[API_KEY]").join(a.userOptions.api_key));
                else
                    for (var y in u) u[y] && d.push("//" + a.host + "/widgets_src/css/" + u[y] + ".css");
                return d
            }, a.triggerDocumentEvent = function(e) {
                var t;
                "function" == typeof Event ? t = new Event(e) : (t = document.createEvent("Event")).initEvent(e, !0, !1), document.dispatchEvent(t)
            }, a.GetUrlParam = function(e) {
                var t = new RegExp("[?&]" + e + "=([^&#]*)").exec(window.location.href);
                return null === t ? null : decodeURI(t[1]) || 0
            }, a.HandleStart = function() {
                a.Start()
            }, a.loader = {
                ready: null,
                loadedCount: 0,
                loaded: function() {
                    a.loader.loadedCount++, 5 == this.loadedCount && a.loader.ready()
                },
                jqLoaded: function() {
                    if (a.$.event.special.touchstart = {
                            setup: function(e, t, o) {
                                t.includes("noPreventDefault") ? this.addEventListener("touchstart", o, {
                                    passive: !1
                                }) : a.passiveListenerSupported && this.addEventListener("touchstart", o, {
                                    passive: !0
                                })
                            }
                        }, a.loadScript(a.paths.widgets, (function() {
                            a.loader.loaded()
                        })), document.attachEvent ? "complete" === document.readyState : "loading" !== document.readyState) a.loader.loaded();
                    else var e = setInterval((function() {
                        (document.attachEvent ? "complete" === document.readyState : "loading" !== document.readyState) && (a.loader.loaded(), clearInterval(e))
                    }), 100);
                    a.loader.loaded()
                },
                init: function(t) {
                    var o = document.createElement("script");
                    a.loader.ready = t, a.loadScript(a.paths.tpl, (function() {
                        a.templates.CustomJS && (o.innerHTML = a.templates.CustomJS, a.templates.CustomJSPlace && "body" == a.templates.CustomJSPlace ? document.body.appendChild(o) : document.head.appendChild(o));
                        var e = 0;
                        a.paths.styles = a.getStyles(a.templates), a.paths.styles.forEach((function(t, o, s) {
                            e++, a.loadCss(t), e === s.length && a.loader.loaded()
                        })), a.loader.loaded()
                    })), a.forceUseExternalJQuery ? (a.$ = e.jQuery, a.loader.jqLoaded()) : a.loadScript(a.paths.jq, (function() {
                        a.$ = jQuery.noConflict(!0), a.loader.jqLoaded()
                    }), (function() {
                        a.loadScript(a.paths.jqRollback, (function() {
                            a.$ = jQuery.noConflict(!0), a.loader.jqLoaded()
                        }), (function() {
                            console.log("jQuery loading error")
                        }))
                    })), a.loadScript(a.paths.preload)
                }
            }, a.loader.init((function() {
                a.Init(), a.SetPaths(a.paths), a.SetOptions(e.Searchanise.templates), a.SetOptions(a.userOptions), a.SetParams(a.AutoCmpParams), a.SetResultsParams(a.ResultsParams), a.Loaded = !0, a.triggerDocumentEvent("Searchanise.Loaded"), a.HandleStart()
            })), e.Searchanise = a
        }
    }
}(window);