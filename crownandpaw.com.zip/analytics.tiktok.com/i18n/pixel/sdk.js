! function(w, d, t) {
    w.TiktokAnalyticsObject = t;
    var ttq = w[t] = w[t] || [];
    ttq.methods = ["page", "track", "identify", "instances", "debug", "on", "off", "once", "ready", "alias", "group", "enableCookie", "disableCookie", "holdConsent", "revokeConsent", "grantConsent"], ttq.setAndDefer = function(t, e) {
        t[e] = function() {
            t.push([e].concat(Array.prototype.slice.call(arguments, 0)))
        }
    };
    for (var i = 0; i < ttq.methods.length; i++) ttq.setAndDefer(ttq, ttq.methods[i]);
    ttq.instance = function(t) {
        for (var e = ttq._i[t] || [], n = 0; n < ttq.methods.length; n++) ttq.setAndDefer(e, ttq.methods[n]);
        return e
    }, ttq.load = function(e, n) {
        var r = "https://analytics.tiktok.com/i18n/pixel/events.js",
            a = n && n.partner,
            a = (ttq._i = ttq._i || {}, ttq._i[e] = [], ttq._i[e]._u = r, ttq._i[e]._partner = a || "", ttq._t = ttq._t || {}, ttq._t[e] = +new Date, ttq._o = ttq._o || {}, ttq._o[e] = n || {}, ttq._partner = ttq._partner || "", document.createElement("script")),
            n = (a.type = "text/javascript", a.async = !0, a.src = r + "?sdkid=" + e + "&lib=" + t, document.getElementsByTagName("script")[0]);
        n.parentNode.insertBefore(a, n)
    }, ttq.legacyLoad = function(t, e) {
        var n = e && e.partner;
        ttq._i = ttq._i || {}, ttq._i[t] = [], ttq._i[t]._partner = n, ttq._t = ttq._t || {}, ttq._t[t] = +new Date, ttq._o = ttq._o || {}, ttq._o[t] = e || {}, ttq._partner = ttq._partner || n, ttq._legacy = ttq._legacy || [], ttq._legacy.push(t)
    };

    ttq.legacyLoad('BT2N6R5QUU2IQ2BVH5I0');

    ttq.page();
}(window, document, 'ttq');

window[window["TiktokAnalyticsObject"]]._env = {
    "env": "external",
    "key": ""
};
window[window["TiktokAnalyticsObject"]]._variation_id = 'default';
window[window["TiktokAnalyticsObject"]]._vids = '';
window[window["TiktokAnalyticsObject"]]._cc = 'PK';
window[window.TiktokAnalyticsObject]._li || (window[window.TiktokAnalyticsObject]._li = {}), window[window.TiktokAnalyticsObject]._li["BT2N6R5QUU2IQ2BVH5I0"] = "54f5b0c9-e819-11f0-949e-02001732e27c";
window[window["TiktokAnalyticsObject"]]._cde = 390;;
if (!window[window["TiktokAnalyticsObject"]]._server_unique_id) window[window["TiktokAnalyticsObject"]]._server_unique_id = '54f5eb87-e819-11f0-949e-02001732e27c';
window[window["TiktokAnalyticsObject"]]._plugins = {
    "AdvancedMatching": true,
    "AutoAdvancedMatching": true,
    "AutoClick": true,
    "AutoConfig": true,
    "Callback": true,
    "DiagnosticsConsole": true,
    "EnableLPV": true,
    "EnrichIpv6": false,
    "EnrichIpv6V2": false,
    "EventBuilder": true,
    "EventBuilderRuleEngine": true,
    "HistoryObserver": true,
    "Identify": true,
    "JSBridge": false,
    "Metadata": true,
    "Monitor": false,
    "PageData": true,
    "PerformanceInteraction": false,
    "RuntimeMeasurement": false,
    "Shopify": true,
    "WebFL": false
};
window[window["TiktokAnalyticsObject"]]._csid_config = {
    "enable": true
};
window[window["TiktokAnalyticsObject"]]._ttls_config = {
    "key": "ttoclid"
};
window[window["TiktokAnalyticsObject"]]._auto_config = {
    "open_graph": ["audience"],
    "microdata": ["audience"],
    "json_ld": ["audience"],
    "meta": null
};
! function(e, n, i, d, o, t) {
    var u, l, a = g()._static_map || [{
            id: "MTc2YTgwMDRlMA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMw",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlNA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlNQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlNg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlNw",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlOA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlOQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMTA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMTE",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMTI",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMTM",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMTQ",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMTU",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMTY",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMTc",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMTg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMTk",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjE",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjI",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjM",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjQ",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjU",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjY",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjc",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjk",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMzA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMzE",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }],
        e = (g()._static_map = a, l = "https://analytics.tiktok.com/i18n/pixel/static/", null == (e = u = {
            "info": {
                "pixelCode": "BT2N6R5QUU2IQ2BVH5I0",
                "name": "Crown \u0026 Paw TikTok Pixel",
                "status": 0,
                "setupMode": 0,
                "partner": "",
                "advertiserID": "6857532823021027334",
                "is_onsite": false,
                "firstPartyCookieEnabled": true
            },
            "plugins": {
                "Shopify": false,
                "AdvancedMatching": {
                    "email": true,
                    "phone_number": true,
                    "first_name": true,
                    "last_name": true,
                    "city": true,
                    "state": true,
                    "country": true,
                    "zip_code": true
                },
                "AutoAdvancedMatching": null,
                "Callback": true,
                "Identify": true,
                "Monitor": true,
                "PerformanceInteraction": true,
                "WebFL": true,
                "AutoConfig": {
                    "form_rules": null,
                    "vc_rules": {}
                },
                "PageData": {
                    "performance": false,
                    "interaction": true
                },
                "DiagnosticsConsole": true,
                "CompetitorInsight": true,
                "EventBuilder": true,
                "EnrichIpv6": true,
                "HistoryObserver": {
                    "dynamic_web_pageview": true
                },
                "RuntimeMeasurement": true,
                "JSBridge": true,
                "EventBuilderRuleEngine": true,
                "RemoveUnusedCode": true,
                "EnableLPV": true,
                "AutoConfigV2": true
            },
            "rules": [{
                "code_id": 6864997398494576645,
                "pixel_event_id": 6864997398494576645,
                "trigger_type": "PAGEVIEW",
                "conditions": [{
                    "rule_id": 185959,
                    "variable_type": "PAGE_URL",
                    "operator": "CONTAINS",
                    "value": "/thank_you"
                }],
                "code": "\n\u003cscript\u003e\nwindow[window.TiktokAnalyticsObject].instance(\"BT2N6R5QUU2IQ2BVH5I0\").track(\"Purchase\",{\"pixelMethod\":\"standard\"});\n\u003c/script\u003e\n"
            }, {
                "code_id": 6864996000583516165,
                "pixel_event_id": 6864996000583516165,
                "trigger_type": "CLICK",
                "conditions": [{
                    "rule_id": 185957,
                    "variable_type": "ELEMENT",
                    "operator": "EQUALS",
                    "value": "#AddToCart-product, #AddToCartText-product"
                }],
                "code": "\n\u003cscript\u003e\nwindow[window.TiktokAnalyticsObject].instance(\"BT2N6R5QUU2IQ2BVH5I0\").track(\"AddToCart\",{\"pixelMethod\":\"standard\"});\n\u003c/script\u003e\n"
            }, {
                "code_id": 6864996000583532549,
                "pixel_event_id": 6864996000583532549,
                "trigger_type": "CLICK",
                "conditions": [{
                    "rule_id": 185958,
                    "variable_type": "ELEMENT",
                    "operator": "EQUALS",
                    "value": "#checkout-btn"
                }],
                "code": "\n\u003cscript\u003e\nwindow[window.TiktokAnalyticsObject].instance(\"BT2N6R5QUU2IQ2BVH5I0\").track(\"PlaceAnOrder\",{\"pixelMethod\":\"standard\"});\n\u003c/script\u003e\n"
            }, {
                "code_id": 6864996000583499781,
                "pixel_event_id": 6864996000583499781,
                "trigger_type": "PAGEVIEW",
                "conditions": [{
                    "rule_id": 185956,
                    "variable_type": "PAGE_URL",
                    "operator": "CONTAINS",
                    "value": "/products/"
                }],
                "code": "\n\u003cscript\u003e\nwindow[window.TiktokAnalyticsObject].instance(\"BT2N6R5QUU2IQ2BVH5I0\").track(\"ViewContent\",{\"pixelMethod\":\"standard\"});\n\u003c/script\u003e\n"
            }]
        }) || null == (n = e.info) ? void 0 : n.pixelCode);

    function c() {
        return window && window.TiktokAnalyticsObject || "ttq"
    }

    function g() {
        return window && window[c()]
    }

    function M(e, n) {
        n = g()[n];
        return n && n[e] || {}
    }
    var r, v, n = g();
    n || (n = [], window && (window[c()] = n)), Object.assign(u, {
        options: M(e, "_o")
    }), r = u, n._i || (n._i = {}), (v = r.info.pixelCode) && (n._i[v] || (n._i[v] = []), Object.assign(n._i[v], r), n._i[v]._load = +new Date), Object.assign(u.info, {
        loadStart: M(e, "_t"),
        loadEnd: M(e, "_i")._load,
        loadId: n._li && n._li[e] || ""
    }), null != (i = (d = n).instance) && null != (o = i.call(d, e)) && null != (t = o.setPixelInfo) && t.call(o, u.info), r = function(e, n, i) {
        var t = 0 < arguments.length && void 0 !== e ? e : {},
            u = 1 < arguments.length ? n : void 0,
            e = 2 < arguments.length ? i : void 0,
            n = function(e, n) {
                for (var i = 0; i < e.length; i++)
                    if (n.call(null, e[i], i)) return e[i]
            }(a, function(e) {
                for (var i = e.map, n = Object.keys(i), d = function(e) {
                        var n;
                        return "JSBridge" === e ? "external" !== (null == (n = g()._env) ? void 0 : n.env) === i[e] : !(!t[e] || !u[e]) === i[e]
                    }, o = 0; o < n.length; o++)
                    if (!d.call(null, n[o], o)) return !1;
                return !0
            });
        return n ? "".concat(e, "main.").concat(n.id, ".js") : "".concat(e, "main.").concat(a[0].id, ".js")
    }(n._plugins, u.plugins, l), v = e, (void 0 !== self.DedicatedWorkerGlobalScope ? self instanceof self.DedicatedWorkerGlobalScope : "DedicatedWorkerGlobalScope" === self.constructor.name) ? self.importScripts && self.importScripts(r) : ((i = document.createElement("script")).type = "text/javascript", i.async = !0, i.src = r, i.setAttribute("data-id", v), (r = document.getElementsByTagName("script")[0]) && r.parentNode && r.parentNode.insertBefore(i, r))
}();