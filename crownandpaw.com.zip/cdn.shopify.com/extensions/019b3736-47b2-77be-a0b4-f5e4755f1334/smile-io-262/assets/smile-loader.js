(() => {
    "use strict";
    const e = "js.smile.io";
    ! function() {
        function t() {
            for (var t = ["https://" + e + "/v1/smile-shopify.js" + "?shop=" + Shopify.shop], o = 0; o < t.length; o++) {
                var n = document.createElement("script");
                n.type = "text/javascript", n.async = !0, n.src = t[o];
                var i = document.getElementsByTagName("script")[0];
                i.parentNode.insertBefore(n, i)
            }
        }
        window.attachEvent ? window.attachEvent("onload", t) : window.addEventListener("load", t, !1);
        var o = document.querySelector(".shopify-app-block .smile-shopify-init");
        o && document.querySelectorAll(".smile-shopify-init").forEach(function(e) {
            o !== e && e.parentNode.removeChild(e)
        })
    }()
})();