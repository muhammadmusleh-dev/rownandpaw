/*! For license information please see onward.js.LICENSE.txt */ ! function() {
    var e = {
            262: function(e, t) {
                "use strict";
                t.A = (e, t) => {
                    const n = e.__vccOpts || e;
                    for (const [e, a] of t) n[e] = a;
                    return n
                }
            },
            314: function(e) {
                "use strict";
                e.exports = function(e) {
                    var t = [];
                    return t.toString = function() {
                        return this.map(function(t) {
                            var n = e(t);
                            return t[2] ? "@media ".concat(t[2], " {").concat(n, "}") : n
                        }).join("")
                    }, t.i = function(e, n, a) {
                        "string" == typeof e && (e = [
                            [null, e, ""]
                        ]);
                        var r = {};
                        if (a)
                            for (var i = 0; i < this.length; i++) {
                                var o = this[i][0];
                                null != o && (r[o] = !0)
                            }
                        for (var s = 0; s < e.length; s++) {
                            var d = [].concat(e[s]);
                            a && r[d[0]] || (n && (d[2] ? d[2] = "".concat(n, " and ").concat(d[2]) : d[2] = n), t.push(d))
                        }
                    }, t
                }
            },
            376: function(e, t, n) {
                "use strict";
                n.r(t);
                var a = n(314),
                    r = n.n(a)()(function(e) {
                        return e[1]
                    });
                r.push([e.id, "@import url(https://fonts.googleapis.com/css2?family=Nunito+Sans:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap);"]), r.push([e.id, "@import url(https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap);"]), r.push([e.id, ":root{\n  --onward-tw-border-spacing-x: 0;\n  --onward-tw-border-spacing-y: 0;\n  --onward-tw-translate-x: 0;\n  --onward-tw-translate-y: 0;\n  --onward-tw-rotate: 0;\n  --onward-tw-skew-x: 0;\n  --onward-tw-skew-y: 0;\n  --onward-tw-scale-x: 1;\n  --onward-tw-scale-y: 1;\n  --onward-tw-pan-x:  ;\n  --onward-tw-pan-y:  ;\n  --onward-tw-pinch-zoom:  ;\n  --onward-tw-scroll-snap-strictness: proximity;\n  --onward-tw-gradient-from-position:  ;\n  --onward-tw-gradient-via-position:  ;\n  --onward-tw-gradient-to-position:  ;\n  --onward-tw-ordinal:  ;\n  --onward-tw-slashed-zero:  ;\n  --onward-tw-numeric-figure:  ;\n  --onward-tw-numeric-spacing:  ;\n  --onward-tw-numeric-fraction:  ;\n  --onward-tw-ring-inset:  ;\n  --onward-tw-ring-offset-width: 0px;\n  --onward-tw-ring-offset-color: #fff;\n  --onward-tw-ring-color: rgb(59 130 246 / 0.5);\n  --onward-tw-ring-offset-shadow: 0 0 #0000;\n  --onward-tw-ring-shadow: 0 0 #0000;\n  --onward-tw-shadow: 0 0 #0000;\n  --onward-tw-shadow-colored: 0 0 #0000;\n  --onward-tw-blur:  ;\n  --onward-tw-brightness:  ;\n  --onward-tw-contrast:  ;\n  --onward-tw-grayscale:  ;\n  --onward-tw-hue-rotate:  ;\n  --onward-tw-invert:  ;\n  --onward-tw-saturate:  ;\n  --onward-tw-sepia:  ;\n  --onward-tw-drop-shadow:  ;\n  --onward-tw-backdrop-blur:  ;\n  --onward-tw-backdrop-brightness:  ;\n  --onward-tw-backdrop-contrast:  ;\n  --onward-tw-backdrop-grayscale:  ;\n  --onward-tw-backdrop-hue-rotate:  ;\n  --onward-tw-backdrop-invert:  ;\n  --onward-tw-backdrop-opacity:  ;\n  --onward-tw-backdrop-saturate:  ;\n  --onward-tw-backdrop-sepia:  ;\n  --onward-tw-contain-size:  ;\n  --onward-tw-contain-layout:  ;\n  --onward-tw-contain-paint:  ;\n  --onward-tw-contain-style:  ;\n}\n::backdrop{\n  --onward-tw-border-spacing-x: 0;\n  --onward-tw-border-spacing-y: 0;\n  --onward-tw-translate-x: 0;\n  --onward-tw-translate-y: 0;\n  --onward-tw-rotate: 0;\n  --onward-tw-skew-x: 0;\n  --onward-tw-skew-y: 0;\n  --onward-tw-scale-x: 1;\n  --onward-tw-scale-y: 1;\n  --onward-tw-pan-x:  ;\n  --onward-tw-pan-y:  ;\n  --onward-tw-pinch-zoom:  ;\n  --onward-tw-scroll-snap-strictness: proximity;\n  --onward-tw-gradient-from-position:  ;\n  --onward-tw-gradient-via-position:  ;\n  --onward-tw-gradient-to-position:  ;\n  --onward-tw-ordinal:  ;\n  --onward-tw-slashed-zero:  ;\n  --onward-tw-numeric-figure:  ;\n  --onward-tw-numeric-spacing:  ;\n  --onward-tw-numeric-fraction:  ;\n  --onward-tw-ring-inset:  ;\n  --onward-tw-ring-offset-width: 0px;\n  --onward-tw-ring-offset-color: #fff;\n  --onward-tw-ring-color: rgb(59 130 246 / 0.5);\n  --onward-tw-ring-offset-shadow: 0 0 #0000;\n  --onward-tw-ring-shadow: 0 0 #0000;\n  --onward-tw-shadow: 0 0 #0000;\n  --onward-tw-shadow-colored: 0 0 #0000;\n  --onward-tw-blur:  ;\n  --onward-tw-brightness:  ;\n  --onward-tw-contrast:  ;\n  --onward-tw-grayscale:  ;\n  --onward-tw-hue-rotate:  ;\n  --onward-tw-invert:  ;\n  --onward-tw-saturate:  ;\n  --onward-tw-sepia:  ;\n  --onward-tw-drop-shadow:  ;\n  --onward-tw-backdrop-blur:  ;\n  --onward-tw-backdrop-brightness:  ;\n  --onward-tw-backdrop-contrast:  ;\n  --onward-tw-backdrop-grayscale:  ;\n  --onward-tw-backdrop-hue-rotate:  ;\n  --onward-tw-backdrop-invert:  ;\n  --onward-tw-backdrop-opacity:  ;\n  --onward-tw-backdrop-saturate:  ;\n  --onward-tw-backdrop-sepia:  ;\n  --onward-tw-contain-size:  ;\n  --onward-tw-contain-layout:  ;\n  --onward-tw-contain-paint:  ;\n  --onward-tw-contain-style:  ;\n}\n/*\n1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)\n2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)\n*/\n*:where(.onward-tailwind-reset,.onward-tailwind-reset *),\n::before:where(.onward-tailwind-reset,.onward-tailwind-reset *),\n::after:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  box-sizing: border-box; /* 1 */\n  border-width: 0; /* 2 */\n  border-style: solid; /* 2 */\n  border-color: #e5e7eb; /* 2 */\n}\n::before:where(.onward-tailwind-reset,.onward-tailwind-reset *),\n::after:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  --onward-tw-content: '';\n}\n/*\n1. Use a consistent sensible line-height in all browsers.\n2. Prevent adjustments of font size after orientation changes in iOS.\n3. Use a more readable tab size.\n4. Use the user's configured `sans` font-family by default.\n5. Use the user's configured `sans` font-feature-settings by default.\n6. Use the user's configured `sans` font-variation-settings by default.\n7. Disable tap highlights on iOS\n*/\nhtml:where(.onward-tailwind-reset,.onward-tailwind-reset *),\n:host:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  line-height: 1.5; /* 1 */\n  -webkit-text-size-adjust: 100%; /* 2 */\n  -moz-tab-size: 4; /* 3 */\n  -o-tab-size: 4;\n     tab-size: 4; /* 3 */\n  font-family: ui-sans-serif, system-ui, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\"; /* 4 */\n  font-feature-settings: normal; /* 5 */\n  font-variation-settings: normal; /* 6 */\n  -webkit-tap-highlight-color: transparent; /* 7 */\n}\n/*\n1. Remove the margin in all browsers.\n2. Inherit line-height from `html` so users can set them as a class directly on the `html` element.\n*/\nbody:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  margin: 0; /* 1 */\n  line-height: inherit; /* 2 */\n}\n/*\n1. Add the correct height in Firefox.\n2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)\n3. Ensure horizontal rules are visible by default.\n*/\nhr:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  height: 0; /* 1 */\n  color: inherit; /* 2 */\n  border-top-width: 1px; /* 3 */\n}\n/*\nAdd the correct text decoration in Chrome, Edge, and Safari.\n*/\nabbr:where([title]):where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  -webkit-text-decoration: underline dotted;\n          text-decoration: underline dotted;\n}\n/*\nRemove the default font size and weight for headings.\n*/\nh1:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nh2:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nh3:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nh4:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nh5:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nh6:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  font-size: inherit;\n  font-weight: inherit;\n}\n/*\nReset links to optimize for opt-in styling instead of opt-out.\n*/\na:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  color: inherit;\n  text-decoration: inherit;\n}\n/*\nAdd the correct font weight in Edge and Safari.\n*/\nb:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nstrong:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  font-weight: bolder;\n}\n/*\n1. Use the user's configured `mono` font-family by default.\n2. Use the user's configured `mono` font-feature-settings by default.\n3. Use the user's configured `mono` font-variation-settings by default.\n4. Correct the odd `em` font sizing in all browsers.\n*/\ncode:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nkbd:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nsamp:where(.onward-tailwind-reset,.onward-tailwind-reset *),\npre:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace; /* 1 */\n  font-feature-settings: normal; /* 2 */\n  font-variation-settings: normal; /* 3 */\n  font-size: 1em; /* 4 */\n}\n/*\nAdd the correct font size in all browsers.\n*/\nsmall:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  font-size: 80%;\n}\n/*\nPrevent `sub` and `sup` elements from affecting the line height in all browsers.\n*/\nsub:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nsup:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  font-size: 75%;\n  line-height: 0;\n  position: relative;\n  vertical-align: baseline;\n}\nsub:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  bottom: -0.25em;\n}\nsup:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  top: -0.5em;\n}\n/*\n1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)\n2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)\n3. Remove gaps between table borders by default.\n*/\ntable:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  text-indent: 0; /* 1 */\n  border-color: inherit; /* 2 */\n  border-collapse: collapse; /* 3 */\n}\n/*\n1. Change the font styles in all browsers.\n2. Remove the margin in Firefox and Safari.\n3. Remove default padding in all browsers.\n*/\nbutton:where(.onward-tailwind-reset,.onward-tailwind-reset *),\ninput:where(.onward-tailwind-reset,.onward-tailwind-reset *),\noptgroup:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nselect:where(.onward-tailwind-reset,.onward-tailwind-reset *),\ntextarea:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  font-family: inherit; /* 1 */\n  font-feature-settings: inherit; /* 1 */\n  font-variation-settings: inherit; /* 1 */\n  font-size: 100%; /* 1 */\n  font-weight: inherit; /* 1 */\n  line-height: inherit; /* 1 */\n  letter-spacing: inherit; /* 1 */\n  color: inherit; /* 1 */\n  margin: 0; /* 2 */\n  padding: 0; /* 3 */\n}\n/*\nRemove the inheritance of text transform in Edge and Firefox.\n*/\nbutton:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nselect:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  text-transform: none;\n}\n/*\n1. Correct the inability to style clickable types in iOS and Safari.\n2. Remove default button styles.\n*/\nbutton:where(.onward-tailwind-reset,.onward-tailwind-reset *),\ninput:where([type='button']):where(.onward-tailwind-reset,.onward-tailwind-reset *),\ninput:where([type='reset']):where(.onward-tailwind-reset,.onward-tailwind-reset *),\ninput:where([type='submit']):where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  -webkit-appearance: button; /* 1 */\n  background-color: transparent; /* 2 */\n  background-image: none; /* 2 */\n}\n/*\nUse the modern Firefox focus style for all focusable elements.\n*/\n:-moz-focusring:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  outline: auto;\n}\n/*\nRemove the additional `:invalid` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)\n*/\n:-moz-ui-invalid:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  box-shadow: none;\n}\n/*\nAdd the correct vertical alignment in Chrome and Firefox.\n*/\nprogress:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  vertical-align: baseline;\n}\n/*\nCorrect the cursor style of increment and decrement buttons in Safari.\n*/\n::-webkit-inner-spin-button:where(.onward-tailwind-reset,.onward-tailwind-reset *),\n::-webkit-outer-spin-button:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  height: auto;\n}\n/*\n1. Correct the odd appearance in Chrome and Safari.\n2. Correct the outline style in Safari.\n*/\n[type='search']:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  -webkit-appearance: textfield; /* 1 */\n  outline-offset: -2px; /* 2 */\n}\n/*\nRemove the inner padding in Chrome and Safari on macOS.\n*/\n::-webkit-search-decoration:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  -webkit-appearance: none;\n}\n/*\n1. Correct the inability to style clickable types in iOS and Safari.\n2. Change font properties to `inherit` in Safari.\n*/\n::-webkit-file-upload-button:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  -webkit-appearance: button; /* 1 */\n  font: inherit; /* 2 */\n}\n/*\nAdd the correct display in Chrome and Safari.\n*/\nsummary:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  display: list-item;\n}\n/*\nRemoves the default spacing and border for appropriate elements.\n*/\nblockquote:where(.onward-tailwind-reset,.onward-tailwind-reset *),\ndl:where(.onward-tailwind-reset,.onward-tailwind-reset *),\ndd:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nh1:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nh2:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nh3:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nh4:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nh5:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nh6:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nhr:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nfigure:where(.onward-tailwind-reset,.onward-tailwind-reset *),\np:where(.onward-tailwind-reset,.onward-tailwind-reset *),\npre:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  margin: 0;\n}\nfieldset:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  margin: 0;\n  padding: 0;\n}\nlegend:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  padding: 0;\n}\nol:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nul:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nmenu:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n/*\nReset default styling for dialogs.\n*/\ndialog:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  padding: 0;\n}\n/*\nPrevent resizing textareas horizontally by default.\n*/\ntextarea:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  resize: vertical;\n}\n/*\n1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)\n2. Set the default placeholder color to the user's configured gray 400 color.\n*/\ninput::-moz-placeholder:where(.onward-tailwind-reset,.onward-tailwind-reset *), textarea::-moz-placeholder:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  opacity: 1; /* 1 */\n  color: #9ca3af; /* 2 */\n}\ninput::placeholder:where(.onward-tailwind-reset,.onward-tailwind-reset *),\ntextarea::placeholder:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  opacity: 1; /* 1 */\n  color: #9ca3af; /* 2 */\n}\n/*\nSet the default cursor for buttons.\n*/\nbutton:where(.onward-tailwind-reset,.onward-tailwind-reset *),\n[role=\"button\"]:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  cursor: pointer;\n}\n/*\nMake sure disabled buttons don't get the pointer cursor.\n*/\n:disabled:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  cursor: default;\n}\n/*\n1. Make replaced elements `display: block` by default. (https://github.com/mozdevs/cssremedy/issues/14)\n2. Add `vertical-align: middle` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)\n   This can trigger a poorly considered lint error in some tools but is included by design.\n*/\nimg:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nsvg:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nvideo:where(.onward-tailwind-reset,.onward-tailwind-reset *),\ncanvas:where(.onward-tailwind-reset,.onward-tailwind-reset *),\naudio:where(.onward-tailwind-reset,.onward-tailwind-reset *),\niframe:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nembed:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nobject:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  display: block; /* 1 */\n  vertical-align: middle; /* 2 */\n}\n/*\nConstrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)\n*/\nimg:where(.onward-tailwind-reset,.onward-tailwind-reset *),\nvideo:where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  max-width: 100%;\n  height: auto;\n}\n/* Make elements with the HTML hidden attribute stay hidden by default */\n[hidden]:where(:not([hidden=\"until-found\"])):where(.onward-tailwind-reset,.onward-tailwind-reset *) {\n  display: none;\n}\n.onward-sr-only{\n  position: absolute !important;\n  width: 1px !important;\n  height: 1px !important;\n  padding: 0 !important;\n  margin: -1px !important;\n  overflow: hidden !important;\n  clip: rect(0, 0, 0, 0) !important;\n  white-space: nowrap !important;\n  border-width: 0 !important;\n}\n.onward-pointer-events-none{\n  pointer-events: none !important;\n}\n.onward-absolute{\n  position: absolute !important;\n}\n.onward-relative{\n  position: relative !important;\n}\n.onward--inset-px{\n  inset: -1px !important;\n}\n.onward-bottom-0{\n  bottom: 0 !important;\n}\n.onward-left-0{\n  left: 0 !important;\n}\n.onward-right-0{\n  right: 0 !important;\n}\n.onward-top-0{\n  top: 0 !important;\n}\n.onward-top-4{\n  top: 16px !important;\n}\n.onward-z-10{\n  z-index: 10 !important;\n}\n.onward-z-\\[2147483647\\]{\n  z-index: 2147483647 !important;\n}\n.onward-col-span-2{\n  grid-column: span 2 / span 2 !important;\n}\n.onward-m-0{\n  margin: 0 !important;\n}\n.onward-m-auto{\n  margin: auto !important;\n}\n.onward-mx-auto{\n  margin-left: auto !important;\n  margin-right: auto !important;\n}\n.onward-my-1{\n  margin-top: 4px !important;\n  margin-bottom: 4px !important;\n}\n.onward-my-4{\n  margin-top: 16px !important;\n  margin-bottom: 16px !important;\n}\n.onward-my-auto{\n  margin-top: auto !important;\n  margin-bottom: auto !important;\n}\n.onward-mb-0{\n  margin-bottom: 0 !important;\n}\n.onward-mb-2{\n  margin-bottom: 8px !important;\n}\n.onward-mb-3{\n  margin-bottom: 12px !important;\n}\n.onward-mb-4{\n  margin-bottom: 16px !important;\n}\n.onward-mb-5{\n  margin-bottom: 20px !important;\n}\n.onward-ml-0{\n  margin-left: 0 !important;\n}\n.onward-ml-1{\n  margin-left: 4px !important;\n}\n.onward-ml-\\[1px\\]{\n  margin-left: 1px !important;\n}\n.onward-ml-\\[4px\\]{\n  margin-left: 4px !important;\n}\n.onward-ml-auto{\n  margin-left: auto !important;\n}\n.onward-mr-0{\n  margin-right: 0 !important;\n}\n.onward-mr-1{\n  margin-right: 4px !important;\n}\n.onward-mr-2{\n  margin-right: 8px !important;\n}\n.onward-mt-1{\n  margin-top: 4px !important;\n}\n.onward-mt-2{\n  margin-top: 8px !important;\n}\n.onward-mt-3{\n  margin-top: 12px !important;\n}\n.onward-mt-4{\n  margin-top: 16px !important;\n}\n.onward-mt-6{\n  margin-top: 24px !important;\n}\n.onward-mt-8{\n  margin-top: 32px !important;\n}\n.onward-mt-\\[10px\\]{\n  margin-top: 10px !important;\n}\n.onward-box-border{\n  box-sizing: border-box !important;\n}\n.onward-block{\n  display: block !important;\n}\n.onward-inline-block{\n  display: inline-block !important;\n}\n.onward-inline{\n  display: inline !important;\n}\n.onward-flex{\n  display: flex !important;\n}\n.onward-inline-flex{\n  display: inline-flex !important;\n}\n.onward-grid{\n  display: grid !important;\n}\n.onward-hidden{\n  display: none !important;\n}\n.\\!onward-h-7{\n  height: 28px !important;\n}\n.onward-h-3{\n  height: 12px !important;\n}\n.onward-h-6{\n  height: 24px !important;\n}\n.onward-h-\\[12px\\]{\n  height: 12px !important;\n}\n.onward-h-\\[13px\\]{\n  height: 13px !important;\n}\n.onward-h-\\[16px\\]{\n  height: 16px !important;\n}\n.onward-h-\\[20px\\]{\n  height: 20px !important;\n}\n.onward-h-\\[2px\\]{\n  height: 2px !important;\n}\n.onward-h-fit{\n  height: -moz-fit-content !important;\n  height: fit-content !important;\n}\n.onward-max-h-full{\n  max-height: 100% !important;\n}\n.onward-max-h-none{\n  max-height: none !important;\n}\n.onward-w-3{\n  width: 12px !important;\n}\n.onward-w-6{\n  width: 24px !important;\n}\n.onward-w-8{\n  width: 32px !important;\n}\n.onward-w-\\[100px\\]{\n  width: 100px !important;\n}\n.onward-w-\\[13px\\]{\n  width: 13px !important;\n}\n.onward-w-\\[20px\\]{\n  width: 20px !important;\n}\n.onward-w-\\[30px\\]{\n  width: 30px !important;\n}\n.onward-w-\\[40px\\]{\n  width: 40px !important;\n}\n.onward-w-\\[55px\\]{\n  width: 55px !important;\n}\n.onward-w-\\[70px\\]{\n  width: 70px !important;\n}\n.onward-w-\\[82px\\]{\n  width: 82px !important;\n}\n.onward-w-\\[fit-content\\]{\n  width: -moz-fit-content !important;\n  width: fit-content !important;\n}\n.onward-w-\\[initial\\]{\n  width: auto !important;\n  width: initial !important;\n}\n.onward-w-full{\n  width: 100% !important;\n}\n.onward-min-w-\\[300px\\]{\n  min-width: 300px !important;\n}\n.onward-max-w-\\[285px\\]{\n  max-width: 285px !important;\n}\n.onward-max-w-\\[340px\\]{\n  max-width: 340px !important;\n}\n.onward-max-w-\\[380px\\]{\n  max-width: 380px !important;\n}\n.onward-max-w-\\[400px\\]{\n  max-width: 400px !important;\n}\n.onward-max-w-none{\n  max-width: none !important;\n}\n.onward-max-w-screen-lg{\n  max-width: 1024px !important;\n}\n.onward-flex-1{\n  flex: 1 1 !important;\n}\n.onward-shrink-0{\n  flex-shrink: 0 !important;\n}\n.onward-translate-x-0\\.5{\n  --onward-tw-translate-x: 2px !important;\n  transform: translate(var(--onward-tw-translate-x), var(--onward-tw-translate-y)) rotate(var(--onward-tw-rotate)) skewX(var(--onward-tw-skew-x)) skewY(var(--onward-tw-skew-y)) scaleX(var(--onward-tw-scale-x)) scaleY(var(--onward-tw-scale-y)) !important;\n}\n.onward-translate-x-\\[15\\.5px\\]{\n  --onward-tw-translate-x: 15.5px !important;\n  transform: translate(var(--onward-tw-translate-x), var(--onward-tw-translate-y)) rotate(var(--onward-tw-rotate)) skewX(var(--onward-tw-skew-x)) skewY(var(--onward-tw-skew-y)) scaleX(var(--onward-tw-scale-x)) scaleY(var(--onward-tw-scale-y)) !important;\n}\n@keyframes onward-spin{\n  to{\n    transform: rotate(360deg);\n  }\n}\n.onward-animate-spin{\n  animation: onward-spin 1s linear infinite !important;\n}\n.onward-cursor-pointer{\n  cursor: pointer !important;\n}\n.onward-grid-cols-2{\n  grid-template-columns: repeat(2, minmax(0, 1fr)) !important;\n}\n.onward-flex-row{\n  flex-direction: row !important;\n}\n.onward-flex-row-reverse{\n  flex-direction: row-reverse !important;\n}\n.onward-flex-col{\n  flex-direction: column !important;\n}\n.onward-items-center{\n  align-items: center !important;\n}\n.onward-justify-center{\n  justify-content: center !important;\n}\n.onward-justify-between{\n  justify-content: space-between !important;\n}\n.onward-justify-around{\n  justify-content: space-around !important;\n}\n.onward-gap-1{\n  gap: 4px !important;\n}\n.onward-gap-2{\n  gap: 8px !important;\n}\n.onward-gap-3{\n  gap: 12px !important;\n}\n.onward-gap-x-2{\n  -moz-column-gap: 8px !important;\n       column-gap: 8px !important;\n}\n.onward-gap-x-4{\n  -moz-column-gap: 16px !important;\n       column-gap: 16px !important;\n}\n.onward-gap-y-4{\n  row-gap: 16px !important;\n}\n.onward-gap-y-6{\n  row-gap: 24px !important;\n}\n.onward-space-x-2 > :not([hidden]) ~ :not([hidden]){\n  --onward-tw-space-x-reverse: 0 !important;\n  margin-right: calc(8px * var(--onward-tw-space-x-reverse)) !important;\n  margin-left: calc(8px * calc(1 - var(--onward-tw-space-x-reverse))) !important;\n}\n.onward-space-x-4 > :not([hidden]) ~ :not([hidden]){\n  --onward-tw-space-x-reverse: 0 !important;\n  margin-right: calc(16px * var(--onward-tw-space-x-reverse)) !important;\n  margin-left: calc(16px * calc(1 - var(--onward-tw-space-x-reverse))) !important;\n}\n.onward-space-x-\\[4px\\] > :not([hidden]) ~ :not([hidden]){\n  --onward-tw-space-x-reverse: 0 !important;\n  margin-right: calc(4px * var(--onward-tw-space-x-reverse)) !important;\n  margin-left: calc(4px * calc(1 - var(--onward-tw-space-x-reverse))) !important;\n}\n.onward-space-y-0 > :not([hidden]) ~ :not([hidden]){\n  --onward-tw-space-y-reverse: 0 !important;\n  margin-top: calc(0px * calc(1 - var(--onward-tw-space-y-reverse))) !important;\n  margin-bottom: calc(0px * var(--onward-tw-space-y-reverse)) !important;\n}\n.onward-space-y-1 > :not([hidden]) ~ :not([hidden]){\n  --onward-tw-space-y-reverse: 0 !important;\n  margin-top: calc(4px * calc(1 - var(--onward-tw-space-y-reverse))) !important;\n  margin-bottom: calc(4px * var(--onward-tw-space-y-reverse)) !important;\n}\n.onward-space-y-2 > :not([hidden]) ~ :not([hidden]){\n  --onward-tw-space-y-reverse: 0 !important;\n  margin-top: calc(8px * calc(1 - var(--onward-tw-space-y-reverse))) !important;\n  margin-bottom: calc(8px * var(--onward-tw-space-y-reverse)) !important;\n}\n.onward-space-y-4 > :not([hidden]) ~ :not([hidden]){\n  --onward-tw-space-y-reverse: 0 !important;\n  margin-top: calc(16px * calc(1 - var(--onward-tw-space-y-reverse))) !important;\n  margin-bottom: calc(16px * var(--onward-tw-space-y-reverse)) !important;\n}\n.onward-space-y-6 > :not([hidden]) ~ :not([hidden]){\n  --onward-tw-space-y-reverse: 0 !important;\n  margin-top: calc(24px * calc(1 - var(--onward-tw-space-y-reverse))) !important;\n  margin-bottom: calc(24px * var(--onward-tw-space-y-reverse)) !important;\n}\n.onward-space-y-8 > :not([hidden]) ~ :not([hidden]){\n  --onward-tw-space-y-reverse: 0 !important;\n  margin-top: calc(32px * calc(1 - var(--onward-tw-space-y-reverse))) !important;\n  margin-bottom: calc(32px * var(--onward-tw-space-y-reverse)) !important;\n}\n.onward-overflow-auto{\n  overflow: auto !important;\n}\n.onward-overflow-hidden{\n  overflow: hidden !important;\n}\n.onward-text-ellipsis{\n  text-overflow: ellipsis !important;\n}\n.onward-whitespace-nowrap{\n  white-space: nowrap !important;\n}\n.onward-whitespace-pre-line{\n  white-space: pre-line !important;\n}\n.onward-rounded-2{\n  border-radius: 8px !important;\n}\n.onward-rounded-2xl{\n  border-radius: 1rem !important;\n}\n.onward-rounded-\\[10px\\]{\n  border-radius: 10px !important;\n}\n.onward-rounded-full{\n  border-radius: 9999px !important;\n}\n.onward-rounded-lg{\n  border-radius: 0.5rem !important;\n}\n.onward-rounded-md{\n  border-radius: 0.375rem !important;\n}\n.onward-border{\n  border-width: 1px !important;\n}\n.onward-border-0{\n  border-width: 0px !important;\n}\n.onward-border-2{\n  border-width: 2px !important;\n}\n.onward-border-\\[0\\.5px\\]{\n  border-width: 0.5px !important;\n}\n.onward-border-b-0{\n  border-bottom-width: 0px !important;\n}\n.onward-border-b-2{\n  border-bottom-width: 2px !important;\n}\n.onward-border-l-0{\n  border-left-width: 0px !important;\n}\n.onward-border-r-0{\n  border-right-width: 0px !important;\n}\n.onward-border-t{\n  border-top-width: 1px !important;\n}\n.onward-border-t-2{\n  border-top-width: 2px !important;\n}\n.onward-border-solid{\n  border-style: solid !important;\n}\n.onward-border-none{\n  border-style: none !important;\n}\n.onward-border-border{\n  --onward-tw-border-opacity: 1 !important;\n  border-color: rgb(229 231 235 / 1) !important;\n  border-color: rgb(229 231 235 / var(--onward-tw-border-opacity, 1)) !important;\n}\n.onward-border-gray-200{\n  --onward-tw-border-opacity: 1 !important;\n  border-color: rgb(229 231 235 / 1) !important;\n  border-color: rgb(229 231 235 / var(--onward-tw-border-opacity, 1)) !important;\n}\n.onward-border-gray-300{\n  --onward-tw-border-opacity: 1 !important;\n  border-color: rgb(166 170 179 / 1) !important;\n  border-color: rgb(166 170 179 / var(--onward-tw-border-opacity, 1)) !important;\n}\n.onward-border-gray-600{\n  --onward-tw-border-opacity: 1 !important;\n  border-color: rgb(75 85 99 / 1) !important;\n  border-color: rgb(75 85 99 / var(--onward-tw-border-opacity, 1)) !important;\n}\n.onward-border-indigo-600{\n  --onward-tw-border-opacity: 1 !important;\n  border-color: rgb(79 70 229 / 1) !important;\n  border-color: rgb(79 70 229 / var(--onward-tw-border-opacity, 1)) !important;\n}\n.onward-border-red-600{\n  --onward-tw-border-opacity: 1 !important;\n  border-color: rgb(220 38 38 / 1) !important;\n  border-color: rgb(220 38 38 / var(--onward-tw-border-opacity, 1)) !important;\n}\n.onward-border-transparent{\n  border-color: transparent !important;\n}\n.onward-bg-\\[\\#364154\\]{\n  --onward-tw-bg-opacity: 1 !important;\n  background-color: rgb(54 65 84 / 1) !important;\n  background-color: rgb(54 65 84 / var(--onward-tw-bg-opacity, 1)) !important;\n}\n.onward-bg-gray-100{\n  --onward-tw-bg-opacity: 1 !important;\n  background-color: rgb(241 242 244 / 1) !important;\n  background-color: rgb(241 242 244 / var(--onward-tw-bg-opacity, 1)) !important;\n}\n.onward-bg-gray-200{\n  --onward-tw-bg-opacity: 1 !important;\n  background-color: rgb(229 231 235 / 1) !important;\n  background-color: rgb(229 231 235 / var(--onward-tw-bg-opacity, 1)) !important;\n}\n.onward-bg-gray-400{\n  --onward-tw-bg-opacity: 1 !important;\n  background-color: rgb(156 163 175 / 1) !important;\n  background-color: rgb(156 163 175 / var(--onward-tw-bg-opacity, 1)) !important;\n}\n.onward-bg-gray-700{\n  --onward-tw-bg-opacity: 1 !important;\n  background-color: rgb(92 95 98 / 1) !important;\n  background-color: rgb(92 95 98 / var(--onward-tw-bg-opacity, 1)) !important;\n}\n.onward-bg-primary{\n  --onward-tw-bg-opacity: 1 !important;\n  background-color: rgb(2 35 66 / 1) !important;\n  background-color: rgb(2 35 66 / var(--onward-tw-bg-opacity, 1)) !important;\n}\n.onward-bg-red-50{\n  --onward-tw-bg-opacity: 1 !important;\n  background-color: rgb(254 242 242 / 1) !important;\n  background-color: rgb(254 242 242 / var(--onward-tw-bg-opacity, 1)) !important;\n}\n.onward-bg-transparent{\n  background-color: transparent !important;\n}\n.onward-bg-white{\n  --onward-tw-bg-opacity: 1 !important;\n  background-color: rgb(255 255 255 / 1) !important;\n  background-color: rgb(255 255 255 / var(--onward-tw-bg-opacity, 1)) !important;\n}\n.onward-bg-cover{\n  background-size: cover !important;\n}\n.onward-bg-center{\n  background-position: center !important;\n}\n.onward-bg-no-repeat{\n  background-repeat: no-repeat !important;\n}\n.onward-p-0{\n  padding: 0 !important;\n}\n.onward-p-1{\n  padding: 4px !important;\n}\n.onward-p-2{\n  padding: 8px !important;\n}\n.onward-p-4{\n  padding: 16px !important;\n}\n.onward-px-3\\.5{\n  padding-left: 14px !important;\n  padding-right: 14px !important;\n}\n.onward-px-4{\n  padding-left: 16px !important;\n  padding-right: 16px !important;\n}\n.onward-px-6{\n  padding-left: 24px !important;\n  padding-right: 24px !important;\n}\n.onward-px-\\[24px\\]{\n  padding-left: 24px !important;\n  padding-right: 24px !important;\n}\n.onward-py-2{\n  padding-top: 8px !important;\n  padding-bottom: 8px !important;\n}\n.onward-py-3{\n  padding-top: 12px !important;\n  padding-bottom: 12px !important;\n}\n.onward-py-\\[14px\\]{\n  padding-top: 14px !important;\n  padding-bottom: 14px !important;\n}\n.onward-py-\\[4px\\]{\n  padding-top: 4px !important;\n  padding-bottom: 4px !important;\n}\n.onward-pb-0{\n  padding-bottom: 0 !important;\n}\n.onward-pb-8{\n  padding-bottom: 32px !important;\n}\n.onward-pb-\\[2px\\]{\n  padding-bottom: 2px !important;\n}\n.onward-pl-0{\n  padding-left: 0 !important;\n}\n.onward-pr-0{\n  padding-right: 0 !important;\n}\n.onward-pr-1{\n  padding-right: 4px !important;\n}\n.onward-pr-\\[2px\\]{\n  padding-right: 2px !important;\n}\n.onward-pt-2{\n  padding-top: 8px !important;\n}\n.onward-pt-3{\n  padding-top: 12px !important;\n}\n.onward-pt-4{\n  padding-top: 16px !important;\n}\n.onward-pt-6{\n  padding-top: 24px !important;\n}\n.onward-pt-\\[14px\\]{\n  padding-top: 14px !important;\n}\n.onward-pt-\\[2px\\]{\n  padding-top: 2px !important;\n}\n.onward-pt-\\[35px\\]{\n  padding-top: 35px !important;\n}\n.onward-text-left{\n  text-align: left !important;\n}\n.onward-text-center{\n  text-align: center !important;\n}\n.onward-text-right{\n  text-align: right !important;\n}\n.onward-font-\\[Inter\\]{\n  font-family: Inter !important;\n}\n.onward-font-inherit{\n  font-family: inherit !important;\n}\n.onward-font-inter{\n  font-family: Inter, sans-serif !important;\n}\n.\\!onward-text-\\[13px\\]{\n  font-size: 13px !important;\n}\n.onward-text-\\[10px\\]{\n  font-size: 10px !important;\n}\n.onward-text-\\[11px\\]{\n  font-size: 11px !important;\n}\n.onward-text-\\[12px\\]{\n  font-size: 12px !important;\n}\n.onward-text-\\[13px\\]{\n  font-size: 13px !important;\n}\n.onward-text-\\[36px\\]{\n  font-size: 36px !important;\n}\n.onward-text-\\[9px\\]{\n  font-size: 9px !important;\n}\n.onward-text-base{\n  font-size: 16px !important;\n}\n.onward-text-lg{\n  font-size: 18px !important;\n}\n.onward-text-sm{\n  font-size: 14px !important;\n}\n.onward-text-xs{\n  font-size: 12px !important;\n}\n.onward-font-bold{\n  font-weight: 700 !important;\n}\n.onward-font-light{\n  font-weight: 300 !important;\n}\n.onward-font-medium{\n  font-weight: 500 !important;\n}\n.onward-font-normal{\n  font-weight: 400 !important;\n}\n.onward-font-semibold{\n  font-weight: 600 !important;\n}\n.onward-capitalize{\n  text-transform: capitalize !important;\n}\n.onward-italic{\n  font-style: italic !important;\n}\n.onward-leading-none{\n  line-height: 1 !important;\n}\n.onward-leading-normal{\n  line-height: 1.5 !important;\n}\n.onward-leading-snug{\n  line-height: 1.375 !important;\n}\n.onward-leading-tight{\n  line-height: 1.25 !important;\n}\n.onward-tracking-normal{\n  letter-spacing: 0em !important;\n}\n.\\!onward-text-black{\n  --onward-tw-text-opacity: 1 !important;\n  color: rgb(0 0 0 / 1) !important;\n  color: rgb(0 0 0 / var(--onward-tw-text-opacity, 1)) !important;\n}\n.\\!onward-text-white{\n  --onward-tw-text-opacity: 1 !important;\n  color: rgb(255 255 255 / 1) !important;\n  color: rgb(255 255 255 / var(--onward-tw-text-opacity, 1)) !important;\n}\n.onward-text-\\[\\#270F2F\\]{\n  --onward-tw-text-opacity: 1 !important;\n  color: rgb(39 15 47 / 1) !important;\n  color: rgb(39 15 47 / var(--onward-tw-text-opacity, 1)) !important;\n}\n.onward-text-\\[\\#B3B3B3\\]{\n  --onward-tw-text-opacity: 1 !important;\n  color: rgb(179 179 179 / 1) !important;\n  color: rgb(179 179 179 / var(--onward-tw-text-opacity, 1)) !important;\n}\n.onward-text-black{\n  --onward-tw-text-opacity: 1 !important;\n  color: rgb(0 0 0 / 1) !important;\n  color: rgb(0 0 0 / var(--onward-tw-text-opacity, 1)) !important;\n}\n.onward-text-gray-500{\n  --onward-tw-text-opacity: 1 !important;\n  color: rgb(107 114 128 / 1) !important;\n  color: rgb(107 114 128 / var(--onward-tw-text-opacity, 1)) !important;\n}\n.onward-text-gray-600{\n  --onward-tw-text-opacity: 1 !important;\n  color: rgb(75 85 99 / 1) !important;\n  color: rgb(75 85 99 / var(--onward-tw-text-opacity, 1)) !important;\n}\n.onward-text-gray-700{\n  --onward-tw-text-opacity: 1 !important;\n  color: rgb(92 95 98 / 1) !important;\n  color: rgb(92 95 98 / var(--onward-tw-text-opacity, 1)) !important;\n}\n.onward-text-gray-800{\n  --onward-tw-text-opacity: 1 !important;\n  color: rgb(31 41 55 / 1) !important;\n  color: rgb(31 41 55 / var(--onward-tw-text-opacity, 1)) !important;\n}\n.onward-text-red-900{\n  --onward-tw-text-opacity: 1 !important;\n  color: rgb(127 29 29 / 1) !important;\n  color: rgb(127 29 29 / var(--onward-tw-text-opacity, 1)) !important;\n}\n.onward-text-white{\n  --onward-tw-text-opacity: 1 !important;\n  color: rgb(255 255 255 / 1) !important;\n  color: rgb(255 255 255 / var(--onward-tw-text-opacity, 1)) !important;\n}\n.onward-underline{\n  text-decoration-line: underline !important;\n}\n.onward-no-underline{\n  text-decoration-line: none !important;\n}\n.onward-underline-offset-2{\n  text-underline-offset: 2px !important;\n}\n.onward-underline-offset-4{\n  text-underline-offset: 4px !important;\n}\n.onward-shadow{\n  --onward-tw-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1) !important;\n  --onward-tw-shadow-colored: 0 1px 3px 0 var(--onward-tw-shadow-color), 0 1px 2px -1px var(--onward-tw-shadow-color) !important;\n  box-shadow: 0 0 #0000, 0 0 #0000, var(--onward-tw-shadow) !important;\n  box-shadow: var(--onward-tw-ring-offset-shadow, 0 0 #0000), var(--onward-tw-ring-shadow, 0 0 #0000), var(--onward-tw-shadow) !important;\n}\n.onward-shadow-lg{\n  --onward-tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1) !important;\n  --onward-tw-shadow-colored: 0 10px 15px -3px var(--onward-tw-shadow-color), 0 4px 6px -4px var(--onward-tw-shadow-color) !important;\n  box-shadow: 0 0 #0000, 0 0 #0000, var(--onward-tw-shadow) !important;\n  box-shadow: var(--onward-tw-ring-offset-shadow, 0 0 #0000), var(--onward-tw-ring-shadow, 0 0 #0000), var(--onward-tw-shadow) !important;\n}\n.onward-shadow-sm{\n  --onward-tw-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05) !important;\n  --onward-tw-shadow-colored: 0 1px 2px 0 var(--onward-tw-shadow-color) !important;\n  box-shadow: 0 0 #0000, 0 0 #0000, var(--onward-tw-shadow) !important;\n  box-shadow: var(--onward-tw-ring-offset-shadow, 0 0 #0000), var(--onward-tw-ring-shadow, 0 0 #0000), var(--onward-tw-shadow) !important;\n}\n.onward-ring-0{\n  --onward-tw-ring-offset-shadow: var(--onward-tw-ring-inset) 0 0 0 var(--onward-tw-ring-offset-width) var(--onward-tw-ring-offset-color) !important;\n  --onward-tw-ring-shadow: var(--onward-tw-ring-inset) 0 0 0 calc(0px + var(--onward-tw-ring-offset-width)) var(--onward-tw-ring-color) !important;\n  box-shadow: var(--onward-tw-ring-offset-shadow), var(--onward-tw-ring-shadow), 0 0 #0000 !important;\n  box-shadow: var(--onward-tw-ring-offset-shadow), var(--onward-tw-ring-shadow), var(--onward-tw-shadow, 0 0 #0000) !important;\n}\n.onward-transition{\n  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter !important;\n  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1) !important;\n  transition-duration: 150ms !important;\n}\n.onward-transition-colors{\n  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke !important;\n  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1) !important;\n  transition-duration: 150ms !important;\n}\n.onward-duration-200{\n  transition-duration: 200ms !important;\n}\n.onward-ease-in-out{\n  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1) !important;\n}\n#onward-container {\n   flex-basis: 100%; /* If the parent has been set to flex, use full width */\n}\nli.onward-list-disc::before { display: none !important }\n/*Some themes put their own before tag in (instead of a marker)*/\n:root {\n  --onward-container-min-width: 330px;\n}\n.onward-fill-none {\n  fill: none !important;\n}\n.onward-icon {\n  /*\n  // 100% is relative to the container\n  // if 100% container width minus `$onward-container-min-width`\n  // is equal to or less than 0, the `max-width` is 0 or\n  // negative which makes the element disappear.\n  // By multiplying the result of the calculation by a very\n  // large number, we make sure that the value for `max-width`\n  // is larger than the actual width of the element as long as\n  // 100% - $onward-container-min-width > 0.\n  */\n  max-width: calc((100% - 330px) * 9999);\n  max-width: calc((100% - var(--onward-container-min-width)) * 9999);\n}\n.after\\:onward-absolute::after{\n  content: var(--onward-tw-content) !important;\n  position: absolute !important;\n}\n.after\\:onward-left-2\\/4::after{\n  content: var(--onward-tw-content) !important;\n  left: 50% !important;\n}\n.after\\:onward-top-\\[25px\\]::after{\n  content: var(--onward-tw-content) !important;\n  top: 25px !important;\n}\n.after\\:onward-z-\\[-1\\]::after{\n  content: var(--onward-tw-content) !important;\n  z-index: -1 !important;\n}\n.after\\:onward-h-\\[130\\%\\]::after{\n  content: var(--onward-tw-content) !important;\n  height: 130% !important;\n}\n.after\\:onward-w-px::after{\n  content: var(--onward-tw-content) !important;\n  width: 1px !important;\n}\n.after\\:onward-translate-x-2\\/4::after{\n  content: var(--onward-tw-content) !important;\n  --onward-tw-translate-x: 50% !important;\n  transform: translate(var(--onward-tw-translate-x), var(--onward-tw-translate-y)) rotate(var(--onward-tw-rotate)) skewX(var(--onward-tw-skew-x)) skewY(var(--onward-tw-skew-y)) scaleX(var(--onward-tw-scale-x)) scaleY(var(--onward-tw-scale-y)) !important;\n}\n.after\\:onward-bg-\\[\\#D4587D\\]::after{\n  content: var(--onward-tw-content) !important;\n  --onward-tw-bg-opacity: 1 !important;\n  background-color: rgb(212 88 125 / 1) !important;\n  background-color: rgb(212 88 125 / var(--onward-tw-bg-opacity, 1)) !important;\n}\n.after\\:onward-content-\\[\\'\\'\\]::after{\n  --onward-tw-content: '' !important;\n  content: var(--onward-tw-content) !important;\n}\n.hover\\:onward-border-gray-600:hover{\n  --onward-tw-border-opacity: 1 !important;\n  border-color: rgb(75 85 99 / 1) !important;\n  border-color: rgb(75 85 99 / var(--onward-tw-border-opacity, 1)) !important;\n}\n.hover\\:onward-bg-\\[\\#677489\\]:hover{\n  --onward-tw-bg-opacity: 1 !important;\n  background-color: rgb(103 116 137 / 1) !important;\n  background-color: rgb(103 116 137 / var(--onward-tw-bg-opacity, 1)) !important;\n}\n.hover\\:onward-bg-gray-50:hover{\n  --onward-tw-bg-opacity: 1 !important;\n  background-color: rgb(250 251 252 / 1) !important;\n  background-color: rgb(250 251 252 / var(--onward-tw-bg-opacity, 1)) !important;\n}\n.hover\\:onward-text-gray-900:hover{\n  --onward-tw-text-opacity: 1 !important;\n  color: rgb(17 24 39 / 1) !important;\n  color: rgb(17 24 39 / var(--onward-tw-text-opacity, 1)) !important;\n}\n@media (min-width: 640px){\n  .sm\\:onward-w-\\[440px\\]{\n    width: 440px !important;\n  }\n}\n@media (min-width: 768px){\n  .md\\:onward-col-span-1{\n    grid-column: span 1 / span 1 !important;\n  }\n  .md\\:onward-m-auto{\n    margin: auto !important;\n  }\n  .md\\:onward-ml-auto{\n    margin-left: auto !important;\n  }\n  .md\\:onward-mr-auto{\n    margin-right: auto !important;\n  }\n  .md\\:onward-flex{\n    display: flex !important;\n  }\n  .md\\:onward-space-y-0 > :not([hidden]) ~ :not([hidden]){\n    --onward-tw-space-y-reverse: 0 !important;\n    margin-top: calc(0px * calc(1 - var(--onward-tw-space-y-reverse))) !important;\n    margin-bottom: calc(0px * var(--onward-tw-space-y-reverse)) !important;\n  }\n  .md\\:onward-border-l-2{\n    border-left-width: 2px !important;\n  }\n  .md\\:onward-border-t-0{\n    border-top-width: 0px !important;\n  }\n  .md\\:onward-p-6{\n    padding: 24px !important;\n  }\n  .md\\:onward-p-8{\n    padding: 32px !important;\n  }\n}\n@media (min-width: 1024px){\n  .lg\\:onward-p-4{\n    padding: 16px !important;\n  }\n}\n", ""]), t.default = r
            },
            534: function(e, t, n) {
                "use strict";

                function a(e, t) {
                    for (var n = [], a = {}, r = 0; r < t.length; r++) {
                        var i = t[r],
                            o = i[0],
                            s = {
                                id: e + ":" + r,
                                css: i[1],
                                media: i[2],
                                sourceMap: i[3]
                            };
                        a[o] ? a[o].parts.push(s) : n.push(a[o] = {
                            id: o,
                            parts: [s]
                        })
                    }
                    return n
                }
                n.d(t, {
                    A: function() {
                        return w
                    }
                });
                var r = "undefined" != typeof document;
                if ("undefined" != typeof DEBUG && DEBUG && !r) throw new Error("vue-style-loader cannot be used in a non-browser environment. Use { target: 'node' } in your Webpack config to indicate a server-rendering environment.");
                var i = {},
                    o = r && (document.head || document.getElementsByTagName("head")[0]),
                    s = null,
                    d = 0,
                    l = !1,
                    c = function() {},
                    u = null,
                    p = "data-vue-ssr-id",
                    h = "undefined" != typeof navigator && /msie [6-9]\b/.test(navigator.userAgent.toLowerCase());

                function w(e, t, n, r) {
                    l = n, u = r || {};
                    var o = a(e, t);
                    return g(o),
                        function(t) {
                            for (var n = [], r = 0; r < o.length; r++) {
                                var s = o[r];
                                (d = i[s.id]).refs--, n.push(d)
                            }
                            for (t ? g(o = a(e, t)) : o = [], r = 0; r < n.length; r++) {
                                var d;
                                if (0 === (d = n[r]).refs) {
                                    for (var l = 0; l < d.parts.length; l++) d.parts[l]();
                                    delete i[d.id]
                                }
                            }
                        }
                }

                function g(e) {
                    for (var t = 0; t < e.length; t++) {
                        var n = e[t],
                            a = i[n.id];
                        if (a) {
                            a.refs++;
                            for (var r = 0; r < a.parts.length; r++) a.parts[r](n.parts[r]);
                            for (; r < n.parts.length; r++) a.parts.push(f(n.parts[r]));
                            a.parts.length > n.parts.length && (a.parts.length = n.parts.length)
                        } else {
                            var o = [];
                            for (r = 0; r < n.parts.length; r++) o.push(f(n.parts[r]));
                            i[n.id] = {
                                id: n.id,
                                refs: 1,
                                parts: o
                            }
                        }
                    }
                }

                function m() {
                    var e = document.createElement("style");
                    return e.type = "text/css", o.appendChild(e), e
                }

                function f(e) {
                    var t, n, a = document.querySelector("style[" + p + '~="' + e.id + '"]');
                    if (a) {
                        if (l) return c;
                        a.parentNode.removeChild(a)
                    }
                    if (h) {
                        var r = d++;
                        a = s || (s = m()), t = y.bind(null, a, r, !1), n = y.bind(null, a, r, !0)
                    } else a = m(), t = k.bind(null, a), n = function() {
                        a.parentNode.removeChild(a)
                    };
                    return t(e),
                        function(a) {
                            if (a) {
                                if (a.css === e.css && a.media === e.media && a.sourceMap === e.sourceMap) return;
                                t(e = a)
                            } else n()
                        }
                }
                var b, x = (b = [], function(e, t) {
                    return b[e] = t, b.filter(Boolean).join("\n")
                });

                function y(e, t, n, a) {
                    var r = n ? "" : a.css;
                    if (e.styleSheet) e.styleSheet.cssText = x(t, r);
                    else {
                        var i = document.createTextNode(r),
                            o = e.childNodes;
                        o[t] && e.removeChild(o[t]), o.length ? e.insertBefore(i, o[t]) : e.appendChild(i)
                    }
                }

                function k(e, t) {
                    var n = t.css,
                        a = t.media,
                        r = t.sourceMap;
                    if (a && e.setAttribute("media", a), u.ssrId && e.setAttribute(p, t.id), r && (n += "\n/*# sourceURL=" + r.sources[0] + " */", n += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(r)))) + " */"), e.styleSheet) e.styleSheet.cssText = n;
                    else {
                        for (; e.firstChild;) e.removeChild(e.firstChild);
                        e.appendChild(document.createTextNode(n))
                    }
                }
            },
            571: function(e, t, n) {
                var a = n(376);
                a.__esModule && (a = a.default), "string" == typeof a && (a = [
                    [e.id, a, ""]
                ]), a.locals && (e.exports = a.locals), (0, n(534).A)("d89624f2", a, !1, {})
            },
            700: function(e, t, n) {
                "use strict";
                n.r(t);
                var a = n(314),
                    r = n.n(a)()(function(e) {
                        return e[1]
                    });
                r.push([e.id, "\n.onward-gradient-text {\n  -webkit-text-fill-color: transparent !important;\n  background-image: linear-gradient(to right, #ec595b, #da3daf) !important;\n  -webkit-background-clip: text !important;\n  background-clip: text !important;\n}\n.onward-modal-feature-list .onward-modal-feature:nth-last-child(1) .onward-modal-feature-icon::after {\n  display: none;\n  visibility: hidden;\n}\ndialog#onward-modal::backdrop {\n  background: rgba(0, 0, 0, 0.7);\n}\ndialog#onward-modal:not([open]) {\n  display: none !important;\n}\n", ""]), t.default = r
            },
            771: function(e, t, n) {
                var a = n(700);
                a.__esModule && (a = a.default), "string" == typeof a && (a = [
                    [e.id, a, ""]
                ]), a.locals && (e.exports = a.locals), (0, n(534).A)("1c695603", a, !1, {})
            },
            844: function(e) {
                e.exports = {
                    formatMoney: function(e, t) {
                        let n = 100 * e;
                        "string" == typeof n && (n = n.replace(".", ""));
                        var a = "",
                            r = /\{\{\s*(\w+)\s*\}\}/,
                            i = t || this.money_format;

                        function o(e, t) {
                            return void 0 === e ? t : e
                        }

                        function s(e, t, n, a) {
                            if (t = o(t, 2), n = o(n, ","), a = o(a, "."), isNaN(e) || null == e) return 0;
                            var r = (e = (e / 100).toFixed(t)).split(".");
                            return r[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1" + n) + (r[1] ? a + r[1] : "")
                        }
                        switch (i.match(r)[1]) {
                            case "amount":
                                a = s(n, 2);
                                break;
                            case "amount_no_decimals":
                                a = s(n, 0);
                                break;
                            case "amount_with_comma_separator":
                                a = s(n, 2, ".", ",");
                                break;
                            case "amount_no_decimals_with_comma_separator":
                                a = s(n, 0, ".", ",")
                        }
                        return i.replace(r, a)
                    }
                }
            }
        },
        t = {};

    function n(a) {
        var r = t[a];
        if (void 0 !== r) return r.exports;
        var i = t[a] = {
            id: a,
            exports: {}
        };
        return e[a](i, i.exports, n), i.exports
    }
    n.n = function(e) {
            var t = e && e.__esModule ? function() {
                return e.default
            } : function() {
                return e
            };
            return n.d(t, {
                a: t
            }), t
        }, n.d = function(e, t) {
            for (var a in t) n.o(t, a) && !n.o(e, a) && Object.defineProperty(e, a, {
                enumerable: !0,
                get: t[a]
            })
        }, n.g = function() {
            if ("object" == typeof globalThis) return globalThis;
            try {
                return this || new Function("return this")()
            } catch (e) {
                if ("object" == typeof window) return window
            }
        }(), n.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t)
        }, n.r = function(e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(e, "__esModule", {
                value: !0
            })
        },
        function() {
            "use strict";

            function e(e, t) {
                return t ? `[Onward:${t}] ${e}` : `[Onward] ${e}`
            }
            n(571);
            class t {
                static log(t, n = null) {
                    this.isDebugMode && console.log(e(t, n))
                }
                static error(t, n = null) {
                    console.error(e(t, n))
                }
                constructor(e = null) {
                    this.uuid = e
                }
                log(n, ...a) {
                    t.isDebugMode && console.log(e(n, this.uuid), ...a)
                }
                warn(n, ...a) {
                    t.isDebugMode && console.warn(e(n, this.uuid), ...a)
                }
                error(t, ...n) {
                    console.error(e(t, this.uuid), ...n)
                }
            }
            t.isDebugMode = "true" == new URLSearchParams(window.location.search).get("onwardDebug");
            var a = t;

            function r(e, t) {
                return t.every(t => !t.sellingPlanIdentifier || function(e, t) {
                    return !e.sellingPlanIdentifiers || e.sellingPlanIdentifiers.some(e => e === t)
                }(e, t.sellingPlanIdentifier))
            }
            class i {
                constructor(e, t) {
                    if (this.insuranceVariants = e, this.settings = t, this.insuranceVariants = e.sort((e, t) => e.price.amount !== t.price.amount ? e.price.amount > t.price.amount ? 1 : -1 : e.id < t.id ? -1 : 1), t.maximumInsurancePriceVariantId) {
                        const e = this.insuranceVariants.find(e => e.id == t.maximumInsurancePriceVariantId || e.id == t.maximumInsurancePriceVariantGid),
                            n = null == e ? void 0 : e.price;
                        n && (this.insuranceVariants = this.insuranceVariants.filter(e => e.price.amount <= n.amount))
                    }
                }
                get insuranceFeePercentage() {
                    return this.settings.insuranceFeePercentage / 100
                }
                get rewardsPercentage() {
                    return this.settings.rewardsPercentage / 100
                }
                insurancePrice(e) {
                    const t = this.insureableCartLinesPrice(e);
                    return this.settings.minimumInsurableCartAmountCents > 0 && this.settings.locale.currency_rate && t <= this.settings.minimumInsurableCartAmountCents * parseFloat(this.settings.locale.currency_rate) / 100 ? 0 : t * this.insuranceFeePercentage
                }
                insuranceVariant(e) {
                    const t = this.insurancePrice(e);
                    if (t <= 0) return;
                    if (this.settings.minimumInsurancePriceVariantId) {
                        const e = this.insuranceVariants.find(e => e.id == this.settings.minimumInsurancePriceVariantId || e.id == this.settings.minimumInsurancePriceVariantGid);
                        if ((null == e ? void 0 : e.price) && t < e.price.amount) return e
                    }
                    const n = this.insuranceVariants.find(e => e.price.amount >= t);
                    return !n && this.settings.shouldInsureWithClosestVariant() ? this.findClosestVariant(t) : n
                }
                insuranceVariantsBySellingPlan(e) {
                    const t = this.insureableCartLinesBySellingPlan(e);
                    return Object.keys(t).reduce((e, n) => {
                        const a = t[n],
                            r = this.insuranceVariant(a);
                        return r && (e[n] = r), e
                    }, {})
                }
                insuranceCartLinesToAdd(e) {
                    if (!this.settings.nativeSubscriptionsEnabled) {
                        const t = this.insuranceVariant(this.insureableCartLines(e)),
                            n = [];
                        return t && n.push(this.newCartLine(t, null)), n
                    }
                    const t = this.insureableCartLinesBySellingPlan(e),
                        n = [],
                        a = this.calculateSubscriptionLinesToCombine(t);
                    if (a.length > 0) {
                        const i = a[0].sellingPlanIdentifier,
                            o = e.filter(e => null == e.sellingPlanIdentifier),
                            s = [...new Set([...a, ...o])],
                            d = this.insuranceVariant(s);
                        d && r(d, s) && (n.push(this.newCartLine(d, i)), delete t[i], delete t.none)
                    }
                    return Object.keys(t).forEach(e => {
                        const a = t[e],
                            i = this.insuranceVariant(a);
                        i && r(i, a) && n.push(this.newCartLine(i, e))
                    }), n
                }
                insureableCartLines(e) {
                    return Object.values(this.insureableCartLinesBySellingPlan(e)).flat()
                }
                insureableCartLinesBySellingPlan(e) {
                    return e.reduce((e, t) => {
                        if (1 == t.variant.requiresShipping && !this.insuranceVariants.some(e => e.id == t.variant.id)) {
                            const n = null == t.sellingPlanIdentifier ? "none" : t.sellingPlanIdentifier;
                            e[n] || (e[n] = []), e[n].push(t)
                        }
                        return e
                    }, {})
                }
                calculateInsurablePriceReducer(e, t) {
                    var n;
                    return e + ((null === (n = t.allocatedCost) || void 0 === n ? void 0 : n.amount) >= 0 ? t.allocatedCost : t.cost).amount
                }
                cartLinesPriceWithoutInsurance(e) {
                    return e.filter(e => !this.insuranceVariants.some(t => t.id == e.variant.id)).reduce(this.calculateInsurablePriceReducer, 0)
                }
                insureableCartLinesPrice(e) {
                    return this.insureableCartLines(e).reduce(this.calculateInsurablePriceReducer, 0)
                }
                insureableCartLinesPriceBySellingPlan(e) {
                    const t = this.insureableCartLinesBySellingPlan(e);
                    return Object.keys(t).reduce((e, n) => {
                        const a = t[n];
                        return e[n] = a.reduce((e, t) => e + t.cost.amount, 0), e
                    }, {})
                }
                estimatedRewardAmount(e) {
                    return this.cartLinesPriceWithoutInsurance(e) * this.rewardsPercentage
                }
                hasSellingPlans(e) {
                    return e.some(e => null != e.sellingPlanIdentifier)
                }
                findClosestVariant(e) {
                    if (0 !== this.insuranceVariants.length) return this.insuranceVariants.reduce((t, n) => Math.abs(n.price.amount - e) < Math.abs(t.price.amount - e) ? n : t)
                }
                mostExpensiveSubscriptionIdentifier(e) {
                    let t = 0,
                        n = null;
                    return Object.keys(e).forEach(a => {
                        if ("none" == a) return;
                        const r = e[a].reduce((e, t) => e + t.cost.amount, 0);
                        t < r && (t = r, n = a)
                    }), n
                }
                calculateSubscriptionLinesToCombine(e) {
                    const t = e.none;
                    if (!t) return [];
                    const n = e[this.mostExpensiveSubscriptionIdentifier(e) || "none"],
                        a = n.reduce((e, t) => e + t.cost.amount, 0);
                    return this.insurancePrice([...n, ...t]) / a * 100 <= 10 ? n : []
                }
                newCartLine(e, t) {
                    const n = this.settings.onwardLineitemProperties,
                        a = n && Object.keys(n).length > 0;
                    return {
                        id: null,
                        variant: e,
                        quantity: 1,
                        sellingPlanIdentifier: "none" == t ? null : t,
                        cost: {
                            amount: e.price.amount,
                            currencyCode: null
                        },
                        properties: a ? n : null
                    }
                }
            }
            var o = function(e, t, n, a) {
                return new(n || (n = Promise))(function(r, i) {
                    function o(e) {
                        try {
                            d(a.next(e))
                        } catch (e) {
                            i(e)
                        }
                    }

                    function s(e) {
                        try {
                            d(a.throw(e))
                        } catch (e) {
                            i(e)
                        }
                    }

                    function d(e) {
                        var t;
                        e.done ? r(e.value) : (t = e.value, t instanceof n ? t : new n(function(e) {
                            e(t)
                        })).then(o, s)
                    }
                    d((a = a.apply(e, t || [])).next())
                })
            };
            class s extends Error {
                constructor(e) {
                    super(e), this.name = "InsuranceProductNotAvailable"
                }
            }
            class d {
                fetchInsuranceProduct() {
                    return o(this, void 0, void 0, function*() {
                        try {
                            const e = yield fetch(`/products/${d.insuranceProductKey}.js`), t = yield e.json();
                            return {
                                featuredImage: t.featured_image,
                                variants: t.variants.map(e => {
                                    var t;
                                    return {
                                        id: e.id.toString(),
                                        price: {
                                            amount: e.price / 100,
                                            currencyCode: null
                                        },
                                        sellingPlanIdentifiers: null === (t = e.selling_plan_allocations) || void 0 === t ? void 0 : t.map(e => e.selling_plan_id)
                                    }
                                })
                            }
                        } catch (e) {
                            throw new s("Failed to fetch insurance product.")
                        }
                    })
                }
                static parseCart(e) {
                    var t;
                    return {
                        currency: e.currency || null,
                        items: (null === (t = e.items) || void 0 === t ? void 0 : t.map(t => ({
                            cost: {
                                amount: t.final_line_price / 100,
                                currencyCode: e.currency
                            },
                            allocatedCost: {
                                amount: t.line_price / 100,
                                currencyCode: e.currency
                            },
                            quantity: t.quantity,
                            properties: t.properties || null,
                            sellingPlanIdentifier: t.selling_plan_allocation ? t.selling_plan_allocation.selling_plan.id : null,
                            variant: {
                                price: null,
                                requiresShipping: t.requires_shipping,
                                id: t.variant_id
                            }
                        }))) || []
                    }
                }
                updateCartAttributes(e) {
                    return o(this, void 0, void 0, function*() {
                        return yield fetch("/cart/update.js", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                attributes: e
                            })
                        }).then(e => e.json()).then(d.parseCart)
                    })
                }
                updateCartLines(e) {
                    return o(this, void 0, void 0, function*() {
                        const t = JSON.stringify({
                            updates: e.reduce((e, {
                                variantId: t,
                                quantity: n
                            }) => (e[t.toString()] = n, e), {})
                        });
                        return yield fetch("/cart/update.js", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: t
                        }).then(e => e.json()).then(d.parseCart)
                    })
                }
                addCartLines(e) {
                    return o(this, void 0, void 0, function*() {
                        const t = JSON.stringify({
                            items: e.map(({
                                variantId: e,
                                quantity: t,
                                sellingPlanIdentifier: n,
                                properties: a
                            }) => Object.assign(Object.assign({
                                id: Number(e),
                                quantity: t
                            }, a && {
                                properties: a
                            }), n && {
                                selling_plan: Number(n)
                            }))
                        });
                        return yield fetch("/cart/add.js", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: t
                        }), yield this.fetchCart()
                    })
                }
                fetchCart() {
                    return o(this, void 0, void 0, function*() {
                        return yield fetch("/cart.js").then(e => e.json()).then(d.parseCart)
                    })
                }
                clearCart() {
                    return o(this, void 0, void 0, function*() {
                        return yield fetch("/cart/clear.js", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            }
                        }).then(e => e.json()).then(d.parseCart)
                    })
                }
            }

            function l(e, t, n) {
                var a;
                return {
                    id: "not-used",
                    cost: {
                        amount: n * t.quantity,
                        currencyCode: e
                    },
                    variant: {
                        id: t.variant_id.toString(),
                        price: {
                            amount: n,
                            currencyCode: e
                        },
                        requiresShipping: !0
                    },
                    quantity: t.quantity,
                    sellingPlanIdentifier: null === (a = t.selling_plan_id) || void 0 === a ? void 0 : a.toString()
                }
            }

            function c(e, t) {
                if (!t || 0 === t.length) return a.log("No current product variants provided"), null;
                return t.find(t => t.id == e) || (a.log(`Could not find variant ${e} in walletsCurrentProductVariants`), null)
            }

            function u(e, t, n) {
                var r, i;
                if (!n || 0 == n.length) return a.log("No current product variants to calculate price from, not updating wallets payload"), null;
                if (1 != (null === (r = null == t ? void 0 : t.line_items) || void 0 === r ? void 0 : r.length)) return a.log(`Not updating wallets payload: ${null===(i=null==t?void 0:t.line_items)||void 0===i?void 0:i.length} line items in the wallets request`), null;
                const o = t.line_items[0],
                    s = c(o.variant_id, n);
                if (!s) return a.log("Not updating wallets payload: could not find current variant"), null;
                if (!s.requires_shipping) return a.log("Not updating wallets payload: current variant does not require shipping"), null;
                const d = l(t.presentment_currency, o, s.price / 100);
                return e.insuranceCartLinesToAdd([d]).pop()
            }
            d.insuranceProductKey = "onward-package-protection";
            var p, h, w, g, m, f, b, x = function(e, t, n, a) {
                    return new(n || (n = Promise))(function(r, i) {
                        function o(e) {
                            try {
                                d(a.next(e))
                            } catch (e) {
                                i(e)
                            }
                        }

                        function s(e) {
                            try {
                                d(a.throw(e))
                            } catch (e) {
                                i(e)
                            }
                        }

                        function d(e) {
                            var t;
                            e.done ? r(e.value) : (t = e.value, t instanceof n ? t : new n(function(e) {
                                e(t)
                            })).then(o, s)
                        }
                        d((a = a.apply(e, t || [])).next())
                    })
                },
                y = function(e, t, n, a, r) {
                    if ("m" === a) throw new TypeError("Private method is not writable");
                    if ("a" === a && !r) throw new TypeError("Private accessor was defined without a setter");
                    if ("function" == typeof t ? e !== t || !r : !t.has(e)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
                    return "a" === a ? r.call(e, n) : r ? r.value = n : t.set(e, n), n
                },
                k = function(e, t, n, a) {
                    if ("a" === n && !a) throw new TypeError("Private accessor was defined without a getter");
                    if ("function" == typeof t ? e !== t || !a : !t.has(e)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
                    return "m" === n ? a : "a" === n ? a.call(e) : a ? a.value : t.get(e)
                };
            class v {
                constructor({
                    currency: e,
                    items: t
                }) {
                    p.set(this, void 0), h.set(this, void 0), y(this, h, e, "f"), y(this, p, t || [], "f")
                }
                get lines() {
                    return k(this, p, "f")
                }
                get currency() {
                    return k(this, h, "f")
                }
                totalQuantity() {
                    return k(this, p, "f").reduce(function(e, t) {
                        return e + t.quantity
                    }, 0)
                }
            }
            p = new WeakMap, h = new WeakMap, w = new WeakMap, g = new WeakMap, m = new WeakMap, f = new WeakMap, b = new WeakMap;
            var P = class {
                constructor(e, t) {
                    w.set(this, void 0), g.set(this, void 0), m.set(this, !1), f.set(this, void 0), b.set(this, void 0), this.logger = new a, y(this, f, t, "f"), y(this, g, e, "f")
                }
                initialize() {
                    return x(this, void 0, void 0, function*() {
                        y(this, w, yield k(this, f, "f").fetchInsuranceProduct(), "f"), yield this.syncCart(), this.cart && k(this, w, "f").variants.forEach(e => {
                            e.price.currencyCode = this.cart.currency, e.requiresShipping = !1
                        })
                    })
                }
                setCurrentCart(e) {
                    ! function(e) {
                        const t = e;
                        return t && void 0 !== t.currency && void 0 !== t.items && t.items.every(e => e && void 0 !== e.quantity && void 0 !== e.cost && void 0 !== e.variant && void 0 !== e.variant.id)
                    }(e) ? this.cart = new v(d.parseCart(e)): this.cart = new v(e)
                }
                syncCart() {
                    return x(this, void 0, void 0, function*() {
                        this.setCurrentCart(yield k(this, f, "f").fetchCart())
                    })
                }
                get onwardNetworkCallHappening() {
                    return k(this, m, "f")
                }
                uninsureOrder() {
                    return x(this, void 0, void 0, function*() {
                        const e = this.insuranceCartItems().map(({
                            id: e,
                            properties: t,
                            sellingPlanIdentifier: n,
                            variant: a
                        }) => ({
                            id: e,
                            properties: t,
                            sellingPlanIdentifier: n,
                            quantity: 0,
                            variantId: a.id
                        }));
                        this.logger.log("Uninsuring cart"), yield this.handleNetworkCall(() => x(this, void 0, void 0, function*() {
                            const t = yield k(this, f, "f").updateCartLines(e);
                            this.setCurrentCart(t)
                        })), this.logger.log("Finished uninsuring cart")
                    })
                }
                addItemsToCart(e) {
                    return x(this, void 0, void 0, function*() {
                        const t = e.map(function(e) {
                            const {
                                quantity: t,
                                sellingPlanIdentifier: n,
                                properties: a
                            } = e;
                            return {
                                variantId: e.variant.id,
                                quantity: t,
                                sellingPlanIdentifier: n,
                                properties: a
                            }
                        });
                        yield this.handleNetworkCall(() => x(this, void 0, void 0, function*() {
                            const e = yield k(this, f, "f").addCartLines(t);
                            this.setCurrentCart(e)
                        })), this.logger.log("finished updating the cart")
                    })
                }
                updateCartAttributes(e) {
                    return x(this, void 0, void 0, function*() {
                        window.onwardUpdateCartAttributes ? yield this.handleNetworkCall(() => x(this, void 0, void 0, function*() {
                            yield window.onwardUpdateCartAttributes(e), this.logger.log("finished updating attributes on the cart via window.onwardUpdateCartAttributes", e)
                        })): yield this.handleNetworkCall(() => x(this, void 0, void 0, function*() {
                            const t = yield k(this, f, "f").updateCartAttributes(e);
                            this.logger.log("finished updating attributes on the cart", e, t), this.setCurrentCart(t)
                        }))
                    })
                }
                sortCartForCheckoutDisplay(e) {
                    const t = k(this, w, "f").variants.map(e => e.id.toString()),
                        n = e.reduce((e, t) => {
                            const n = null == t.sellingPlanIdentifier ? "none" : t.sellingPlanIdentifier;
                            return e[n] || (e[n] = []), e[n].push(t), e
                        }, {});
                    return Object.keys(n).sort((e, t) => "none" == e ? -1 : 1).reduce((e, a) => {
                        let r = n[a];
                        return r = r.sort((e, n) => t.includes(e.variantId.toString()) ? -1 : 1), e.push(...r), e
                    }, [])
                }
                insuranceVariant() {
                    return this.insuranceCalculator().insuranceVariant(this.cart.lines)
                }
                insuranceCartItems() {
                    const e = k(this, w, "f").variants.map(e => e.id.toString());
                    return this.cart.lines.filter(t => e.includes(t.variant.id.toString()))
                }
                logoImageSrc(e = "64x64") {
                    var t;
                    return e ? null === (t = k(this, w, "f").featuredImage) || void 0 === t ? void 0 : t.split(".png").join(`_${e}.png`) : k(this, w, "f").featuredImage
                }
                quantityWithoutInsurance() {
                    return this.cart.totalQuantity() - this.insuranceCartItems().reduce((e, t) => e + t.quantity, 0)
                }
                cartPriceWithoutInsurance() {
                    return this.insuranceCalculator().cartLinesPriceWithoutInsurance(this.cart.lines)
                }
                cartPriceWithInsurance() {
                    const e = this.cartPriceWithoutInsurance(),
                        t = this.insuranceVariant();
                    return t ? e + t.price.amount : e
                }
                estimatedRewardsAmount() {
                    return this.insuranceCalculator().estimatedRewardAmount(this.cart.lines)
                }
                insuranceCalculator() {
                    return new i(k(this, w, "f").variants, k(this, g, "f"))
                }
                uninsureOrderIfRequired() {
                    return x(this, void 0, void 0, function*() {
                        if (this.logger.log("uninsureOrderIfRequired"), this.insuranceCartItems().length > 0) return this.uninsureOrder()
                    })
                }
                updatedWalletsPayload(e, t) {
                    const n = JSON.parse(e).checkout,
                        a = u(this.insuranceCalculator(), n, t);
                    if (a) {
                        const e = {
                            variant_id: parseInt(a.variant.id),
                            quantity: 1
                        };
                        a.sellingPlanIdentifier && (e.selling_plan_id = parseInt(a.sellingPlanIdentifier)), k(this, g, "f").onwardLineitemProperties && (e.properties = k(this, g, "f").onwardLineitemProperties), n.line_items.push(e)
                    }
                    return JSON.stringify({
                        checkout: n
                    })
                }
                calculateWalletsInsuranceVariant(e, t) {
                    return u(this.insuranceCalculator(), e, t)
                }
                fixInsuranceInCartIfRequired(e) {
                    return x(this, void 0, void 0, function*() {
                        const t = this.insuranceCartItems().map(e => e.variant.id.toString());
                        if (e) {
                            const e = this.insuranceCalculator().insuranceCartLinesToAdd(this.cart.lines);
                            if (this.logger.log("Insurance was requested"), t.length > 0) {
                                if (function(e, t) {
                                        if (e.length !== t.length) return !1;
                                        const n = e.sort(),
                                            a = t.sort();
                                        return n.every((e, t) => e == a[t])
                                    }(t, e.map(e => e.variant.id.toString()))) return void this.logger.log("Correct insurance already in cart");
                                this.logger.log(`Incorrect insurance in cart, removing ${t.length} insurance lines`), yield this.uninsureOrder()
                            }
                            if (e.length > 0) return this.logger.log(`Insuring cart with ${e.length} lines`), this.addItemsToCart(e);
                            this.logger.log("Expecting variants, but none found")
                        } else {
                            if (t.length > 0) return this.logger.log(`Removing ${t.length} insurance lines`), this.uninsureOrder();
                            this.logger.log("No insurance required, none in the cart")
                        }
                    })
                }
                handleNetworkCall(e) {
                    return x(this, void 0, void 0, function*() {
                        this.setClearNetworkCall(), y(this, m, !0, "f");
                        try {
                            yield e()
                        } catch (e) {
                            a.error(e)
                        } finally {
                            y(this, m, !1, "f")
                        }
                    })
                }
                setClearNetworkCall() {
                    const e = `${Math.random()}`;
                    y(this, b, e, "f"), setTimeout(() => {
                        e === k(this, b, "f") && (this.logger.log(`network call ${e} cleared`), y(this, m, !1, "f"))
                    }, 5e3)
                }
            };

            function C(e, t) {
                return Object.entries(t).reduce((e, t) => e.replaceAll(`{{${t[0]}}}`, `${t[1]||""}`), e)
            }

            function O() {
                const e = [];
                for (let t = 0; t < 4; t++) e.push((65536 * (1 + Math.random()) | 0).toString(16).substring(1));
                return e.join("-")
            }

            function S(e) {
                if (!e) return;
                const t = Object.entries(e);
                return 0 !== t.length ? t.map(([e, t]) => ({
                    key: e,
                    value: t
                })) : void 0
            }
            var _ = {
                    modal: {
                        headline: "Experience VIP protection & guaranteed satisfaction with Onward VIP Protection.",
                        rewardsDisclaimer: {
                            text: "*Reward code will be emailed 30 days after purchase."
                        },
                        rewards: {
                            heading: "Earn {{rewardsPercentage}}% CashBack",
                            text: "Get {{rewardsPercentage}}% back in online store credit to be used on future purchases.*"
                        },
                        protect: {
                            heading: "Shipping Protection",
                            text: "From theft, loss, damage, & more - Onward has you covered."
                        },
                        extendedWarranties: {
                            heading: "Product Protection",
                            text: "From failure due to normal wear and tear and defects after the manufacturer's warranty expires."
                        },
                        carbonOffsets: {
                            heading: "Carbon Neutral Shipping",
                            text: "We'll offset the CO2 emissions of this shipment."
                        },
                        productGuarantees: {
                            heading: "Satisfaction Guarantee",
                            text: "If you have any quality issues within {{days}} days, we'll make it right."
                        },
                        returnsAndExchanges: {
                            heading: "Free Returns & Exchanges",
                            text: "Free return shipping on all US orders for returns & exchanges."
                        },
                        freeReturns: {
                            heading: "Free Returns",
                            text: "Free return shipping on all US orders."
                        },
                        subscriptions: {
                            text: "For subscription orders, Onward Package Protection will be added to each recurring order and may be cancelled at any time."
                        },
                        prioritySupport: {
                            heading: "Priority Support",
                            text: "Skip the line and get expedited customer support."
                        }
                    }
                },
                I = {
                    am: {
                        modal: {
                            headline: "ከ Onward VIP Protection ጋር የ VIP ጥበቃ እና የተረጋገጠ ተስማሚነት ያግኙ።",
                            rewardsDisclaimer: {
                                text: "*የሽልማት ኮድ ከግዢዎ 30 ቀን በኋላ በኢሜይል ይላካል።"
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% ጥሬ ገንዘብ ይቀበሉ",
                                text: "{{rewardsPercentage}}% በዚህ ግዢ የወደፊት ግዢዎች ላይ ለመጠቀም የመደብር ብድር መመለስ ይችላሉ።*"
                            },
                            protect: {
                                heading: "የመላኪያ ጥበቃ",
                                text: "ከስርቆት፣ ከጠፋት፣ ከተጎዳት እና ከሌሎችም — Onward እርዳታ ይሰጣል።"
                            },
                            extendedWarranties: {
                                heading: "የእቃ ጥበቃ",
                                text: "የአምራች ዋስትና ከተያዘ በኋላ ከመደበኛ እንጥረት እና ከጥገኛ ጉዳት የተነሳ ችግኝ ይሸፍናል።"
                            },
                            carbonOffsets: {
                                heading: "ካርቦን ድምር የሌለው መላኪያ",
                                text: "ይህ መላኪያ የሚፈጥረውን CO₂ ልቀት እናካፍላለን።"
                            },
                            productGuarantees: {
                                heading: "የተሟላ መደረሻ ዋስትና",
                                text: "በ {{days}} ቀናት ውስጥ የጥራት ችግኝ ካጋጠመዎ እኛ እንፈታዋለን።"
                            },
                            returnsAndExchanges: {
                                heading: "ነጻ መመለስ እና መቀየር",
                                text: "ለመመለስ እና ለመቀየር በአሜሪካ ውስጥ ሁሉም ትኬቶች ነጻ መመለሻ መላኪያ ይኖራቸዋል።"
                            },
                            freeReturns: {
                                heading: "ነጻ መመለስ",
                                text: "በአሜሪካ ውስጥ ሁሉም ትኬቶች ነጻ መመለሻ መላኪያ ይኖራቸዋል።"
                            },
                            subscriptions: {
                                text: "ለመደበኛ ትኬቶች የ Onward ጥበቃ በየተደጋጋሚ ትኬት ይጨመራል እና በማንኛውም ጊዜ መሰረዝ ይቻላል።"
                            },
                            prioritySupport: {
                                heading: "ቅድሚያ ድጋፍ",
                                text: "መስመሩን ይዘርጉ እና ፈጣን የደንበኛ ድጋፍ ይቀበሉ።"
                            }
                        }
                    },
                    ar: {
                        modal: {
                            headline: "اختبر حماية كبار الشخصيات وضمان الرضا مع Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*سيتم إرسال رمز المكافأة عبر البريد الإلكتروني بعد 30 يومًا من الشراء."
                            },
                            rewards: {
                                heading: "اكسب {{rewardsPercentage}}% استرجاع نقدي",
                                text: "احصل على {{rewardsPercentage}}% رصيد متجر عبر الإنترنت لاستخدامه في المشتريات المستقبلية.*"
                            },
                            protect: {
                                heading: "حماية الشحن",
                                text: "من السرقة والضياع والتلف والمزيد — تغطيك Onward بالكامل."
                            },
                            extendedWarranties: {
                                heading: "حماية المنتج",
                                text: "تغطية للأعطال الناتجة عن التآكل الطبيعي والعيوب بعد انتهاء ضمان الشركة المصنعة."
                            },
                            carbonOffsets: {
                                heading: "شحن محايد للكربون",
                                text: "سنقوم بموازنة انبعاثات ثاني أكسيد الكربون الناتجة عن هذه الشحنة."
                            },
                            productGuarantees: {
                                heading: "ضمان الرضا",
                                text: "إذا واجهت أي مشكلات في الجودة خلال {{days}} يومًا، سنقوم بحلها فورًا."
                            },
                            returnsAndExchanges: {
                                heading: "إرجاع واستبدال مجاني",
                                text: "شحن الإرجاع مجاني على جميع الطلبات داخل الولايات المتحدة للإرجاع والاستبدال."
                            },
                            freeReturns: {
                                heading: "إرجاع مجاني",
                                text: "شحن الإرجاع مجاني على جميع الطلبات داخل الولايات المتحدة."
                            },
                            subscriptions: {
                                text: "بالنسبة لطلبات الاشتراك، ستتم إضافة حماية الطرود من Onward إلى كل طلب متجدد ويمكن إلغاؤها في أي وقت."
                            },
                            prioritySupport: {
                                heading: "دعم أولوية",
                                text: "تجاوز قائمة الانتظار واحصل على دعم عملاء سريع."
                            }
                        }
                    },
                    bg: {
                        modal: {
                            headline: "Изпитайте VIP защита и гарантирано удовлетворение с Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Кодът за награда ще бъде изпратен по имейл 30 дни след покупката."
                            },
                            rewards: {
                                heading: "Спечелете {{rewardsPercentage}}% CashBack",
                                text: "Получете {{rewardsPercentage}}% обратно като кредит в онлайн магазина за бъдещи покупки.*"
                            },
                            protect: {
                                heading: "Защита на доставката",
                                text: "От кражба, загуба, повреда и други — Onward ви покрива."
                            },
                            extendedWarranties: {
                                heading: "Защита на продукта",
                                text: "От повреди поради нормално износване и дефекти след изтичане на гаранцията на производителя."
                            },
                            carbonOffsets: {
                                heading: "Въглеродно неутрална доставка",
                                text: "Ще компенсираме CO2 емисиите от тази доставка."
                            },
                            productGuarantees: {
                                heading: "Гаранция за удовлетворение",
                                text: "Ако имате проблеми с качеството в рамките на {{days}} дни, ще го оправим."
                            },
                            returnsAndExchanges: {
                                heading: "Безплатни връщания и замени",
                                text: "Безплатна доставка за връщане на всички поръчки в САЩ за връщания и замени."
                            },
                            freeReturns: {
                                heading: "Безплатни връщания",
                                text: "Безплатна доставка за връщане на всички поръчки в САЩ."
                            },
                            subscriptions: {
                                text: "За абонаментни поръчки, Onward Package Protection ще бъде добавена към всяка повтаряща се поръчка и може да бъде отменена по всяко време."
                            },
                            prioritySupport: {
                                heading: "Приоритетна поддръжка",
                                text: "Прескочете опашката и получете ускорена клиентска поддръжка."
                            }
                        }
                    },
                    bn: {
                        modal: {
                            headline: "Onward VIP Protection-এর সাথে VIP সুরক্ষা এবং নিশ্চিত সন্তুষ্টি অনুভব করুন।",
                            rewardsDisclaimer: {
                                text: "*পুরস্কার কোড ক্রয়ের 30 দিন পরে ইমেল করা হবে।"
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% ক্যাশব্যাক অর্জন করুন",
                                text: "ভবিষ্যতের ক্রয়ে ব্যবহার করতে {{rewardsPercentage}}% অনলাইন স্টোর ক্রেডিট ফেরত পান।*"
                            },
                            protect: {
                                heading: "শিপিং সুরক্ষা",
                                text: "চুরি, হারানো, ক্ষতি এবং আরও অনেক কিছু থেকে — Onward আপনাকে কভার করে।"
                            },
                            extendedWarranties: {
                                heading: "পণ্য সুরক্ষা",
                                text: "প্রস্তুতকারকের ওয়ারেন্টি শেষ হওয়ার পরে স্বাভাবিক পরিধান এবং ত্রুটির কারণে ব্যর্থতা থেকে।"
                            },
                            carbonOffsets: {
                                heading: "কার্বন নিরপেক্ষ শিপিং",
                                text: "আমরা এই শিপমেন্টের CO2 নির্গমন অফসেট করব।"
                            },
                            productGuarantees: {
                                heading: "সন্তুষ্টি গ্যারান্টি",
                                text: "{{days}} দিনের মধ্যে কোনো মানের সমস্যা থাকলে, আমরা ঠিক করে দেব।"
                            },
                            returnsAndExchanges: {
                                heading: "বিনামূল্যে রিটার্ন এবং এক্সচেঞ্জ",
                                text: "রিটার্ন এবং এক্সচেঞ্জের জন্য সমস্ত মার্কিন অর্ডারে বিনামূল্যে রিটার্ন শিপিং।"
                            },
                            freeReturns: {
                                heading: "বিনামূল্যে রিটার্ন",
                                text: "সমস্ত মার্কিন অর্ডারে বিনামূল্যে রিটার্ন শিপিং।"
                            },
                            subscriptions: {
                                text: "সাবস্ক্রিপশন অর্ডারের জন্য, Onward Package Protection প্রতিটি পুনরাবৃত্ত অর্ডারে যোগ করা হবে এবং যেকোনো সময় বাতিল করা যাবে।"
                            },
                            prioritySupport: {
                                heading: "অগ্রাধিকার সহায়তা",
                                text: "লাইন এড়িয়ে যান এবং দ্রুত গ্রাহক সহায়তা পান।"
                            }
                        }
                    },
                    bs: {
                        modal: {
                            headline: "Doživite VIP zaštitu i garantovano zadovoljstvo sa Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Kod za nagradu bit će poslan e-mailom 30 dana nakon kupovine."
                            },
                            rewards: {
                                heading: "Zaradite {{rewardsPercentage}}% CashBack",
                                text: "Dobijte {{rewardsPercentage}}% nazad kao kredit u online trgovini za buduće kupovine.*"
                            },
                            protect: {
                                heading: "Zaštita dostave",
                                text: "Od krađe, gubitka, oštećenja i više — Onward vas pokriva."
                            },
                            extendedWarranties: {
                                heading: "Zaštita proizvoda",
                                text: "Od kvara uslijed normalnog habanja i nedostataka nakon isteka garancije proizvođača."
                            },
                            carbonOffsets: {
                                heading: "Ugljično neutralna dostava",
                                text: "Kompenzovat ćemo CO2 emisije ove pošiljke."
                            },
                            productGuarantees: {
                                heading: "Garancija zadovoljstva",
                                text: "Ako imate bilo kakvih problema s kvalitetom u roku od {{days}} dana, ispravit ćemo to."
                            },
                            returnsAndExchanges: {
                                heading: "Besplatni povrati i zamjene",
                                text: "Besplatna dostava za povrat na sve narudžbe u SAD-u za povrate i zamjene."
                            },
                            freeReturns: {
                                heading: "Besplatni povrati",
                                text: "Besplatna dostava za povrat na sve narudžbe u SAD-u."
                            },
                            subscriptions: {
                                text: "Za narudžbe pretplate, Onward Package Protection bit će dodana svakoj ponavljajućoj narudžbi i može se otkazati u bilo kojem trenutku."
                            },
                            prioritySupport: {
                                heading: "Prioritetna podrška",
                                text: "Preskočite red i dobijte ubrzanu korisničku podršku."
                            }
                        }
                    },
                    ckb: {
                        modal: {
                            headline: "پاراستنی VIP و دڵنیایی گەرەنتیکراو لەگەڵ Onward VIP Protection تاقی بکەرەوە.",
                            rewardsDisclaimer: {
                                text: "*کۆدی پاداشت ٣٠ ڕۆژ دوای کڕین بە ئیمەیڵ دەنێردرێت."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% پارەی نەقد وەربگرەوە",
                                text: "{{rewardsPercentage}}% وەک کرێدیتی فرۆشگای ئۆنلاین بۆ کڕینەکانی داهاتوو وەربگرەوە.*"
                            },
                            protect: {
                                heading: "پاراستنی گواستنەوە",
                                text: "لە دزی، ونبوون، زیان و زۆر شتی تر — Onward پارێزگاریت دەکات."
                            },
                            extendedWarranties: {
                                heading: "پاراستنی بەرهەم",
                                text: "لە شکستن بەهۆی خراپبوونی ئاسایی و کەموکوڕییەکان دوای تەواوبوونی گەرەنتیی بەرهەمهێنەر."
                            },
                            carbonOffsets: {
                                heading: "گواستنەوەی بێ کاربۆن",
                                text: "ئێمە دەرچوونی CO2 ی ئەم بارەکە هاوسەنگ دەکەینەوە."
                            },
                            productGuarantees: {
                                heading: "گەرەنتیی دڵنیایی",
                                text: "ئەگەر کێشەیەکی کوالیتیت هەبوو لە ماوەی {{days}} ڕۆژدا، چاکی دەکەینەوە."
                            },
                            returnsAndExchanges: {
                                heading: "گەڕاندنەوە و ئاڵوگۆڕی بەخۆڕایی",
                                text: "گواستنەوەی گەڕاندنەوەی بەخۆڕایی بۆ هەموو داواکارییەکانی ئەمریکا بۆ گەڕاندنەوە و ئاڵوگۆڕ."
                            },
                            freeReturns: {
                                heading: "گەڕاندنەوەی بەخۆڕایی",
                                text: "گواستنەوەی گەڕاندنەوەی بەخۆڕایی بۆ هەموو داواکارییەکانی ئەمریکا."
                            },
                            subscriptions: {
                                text: "بۆ داواکارییەکانی بەشداری، Onward Package Protection بۆ هەر داواکارییەکی دووبارەبووەوە زیاد دەکرێت و دەکرێت لە هەر کاتێکدا هەڵبوەشێنرێتەوە."
                            },
                            prioritySupport: {
                                heading: "پشتگیری پێشینەیی",
                                text: "لە ڕیز تێپەڕە و پشتگیری خێرای کڕیار وەربگرە."
                            }
                        }
                    },
                    cs: {
                        modal: {
                            headline: "Zažijte VIP ochranu a zaručenou spokojenost s Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Kód odměny bude zaslán e-mailem 30 dní po nákupu."
                            },
                            rewards: {
                                heading: "Získejte {{rewardsPercentage}}% CashBack",
                                text: "Získejte {{rewardsPercentage}}% zpět jako kredit v online obchodě pro budoucí nákupy.*"
                            },
                            protect: {
                                heading: "Ochrana zásilky",
                                text: "Před krádeží, ztrátou, poškozením a dalšími — Onward vás chrání."
                            },
                            extendedWarranties: {
                                heading: "Ochrana produktu",
                                text: "Před selháním v důsledku běžného opotřebení a vad po vypršení záruky výrobce."
                            },
                            carbonOffsets: {
                                heading: "Uhlíkově neutrální doprava",
                                text: "Kompenzujeme emise CO2 z této zásilky."
                            },
                            productGuarantees: {
                                heading: "Záruka spokojenosti",
                                text: "Pokud máte jakékoli problémy s kvalitou do {{days}} dnů, napravíme to."
                            },
                            returnsAndExchanges: {
                                heading: "Vrácení a výměny zdarma",
                                text: "Doprava zdarma při vrácení na všechny objednávky v USA pro vrácení a výměny."
                            },
                            freeReturns: {
                                heading: "Vrácení zdarma",
                                text: "Doprava zdarma při vrácení na všechny objednávky v USA."
                            },
                            subscriptions: {
                                text: "U předplatných objednávek bude Onward Package Protection přidána ke každé opakující se objednávce a lze ji kdykoli zrušit."
                            },
                            prioritySupport: {
                                heading: "Prioritní podpora",
                                text: "Přeskočte frontu a získejte urychlenou zákaznickou podporu."
                            }
                        }
                    },
                    cy: {
                        modal: {
                            headline: "Profwch amddiffyniad VIP a boddhad gwarantedig gydag Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Bydd y cod gwobrwyo yn cael ei e-bostio 30 diwrnod ar ôl prynu."
                            },
                            rewards: {
                                heading: "Enillwch {{rewardsPercentage}}% Arian yn Ôl",
                                text: "Cael {{rewardsPercentage}}% yn ôl fel credyd siop ar-lein i'w ddefnyddio ar bryniannau yn y dyfodol.*"
                            },
                            protect: {
                                heading: "Amddiffyniad Cludo",
                                text: "Rhag lladrad, colled, difrod, a mwy — mae Onward yn eich diogelu."
                            },
                            extendedWarranties: {
                                heading: "Amddiffyniad Cynnyrch",
                                text: "Rhag methiant oherwydd traul arferol a diffygion ar ôl i warant y gwneuthurwr ddod i ben."
                            },
                            carbonOffsets: {
                                heading: "Cludo Niwtral o ran Carbon",
                                text: "Byddwn yn gwrthbwyso allyriadau CO2 y llwyth hwn."
                            },
                            productGuarantees: {
                                heading: "Gwarant Boddhad",
                                text: "Os oes gennych unrhyw broblemau ansawdd o fewn {{days}} diwrnod, byddwn yn ei gywiro."
                            },
                            returnsAndExchanges: {
                                heading: "Dychweliadau a Chyfnewidiadau Am Ddim",
                                text: "Cludo dychwelyd am ddim ar bob archeb yn yr UD ar gyfer dychweliadau a chyfnewidiadau."
                            },
                            freeReturns: {
                                heading: "Dychweliadau Am Ddim",
                                text: "Cludo dychwelyd am ddim ar bob archeb yn yr UD."
                            },
                            subscriptions: {
                                text: "Ar gyfer archebion tanysgrifio, bydd Onward Package Protection yn cael ei ychwanegu at bob archeb ailadroddol a gellir ei ganslo ar unrhyw adeg."
                            },
                            prioritySupport: {
                                heading: "Cymorth Blaenoriaeth",
                                text: "Sgipiwch y ciw a chael cymorth cwsmeriaid cyflym."
                            }
                        }
                    },
                    da: {
                        modal: {
                            headline: "Oplev VIP-beskyttelse og garanteret tilfredshed med Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Belønningskoden sendes via e-mail 30 dage efter købet."
                            },
                            rewards: {
                                heading: "Optjen {{rewardsPercentage}}% CashBack",
                                text: "Få {{rewardsPercentage}}% tilbage som online butikskredit til fremtidige køb.*"
                            },
                            protect: {
                                heading: "Forsendelsesbeskyttelse",
                                text: "Mod tyveri, tab, skade og mere — Onward dækker dig."
                            },
                            extendedWarranties: {
                                heading: "Produktbeskyttelse",
                                text: "Mod fejl på grund af normal slitage og defekter efter producentens garanti udløber."
                            },
                            carbonOffsets: {
                                heading: "Kulstofneutral forsendelse",
                                text: "Vi kompenserer for CO2-udledningen fra denne forsendelse."
                            },
                            productGuarantees: {
                                heading: "Tilfredshedsgaranti",
                                text: "Hvis du har kvalitetsproblemer inden for {{days}} dage, ordner vi det."
                            },
                            returnsAndExchanges: {
                                heading: "Gratis returneringer og ombytninger",
                                text: "Gratis returforsendelse på alle amerikanske ordrer for returneringer og ombytninger."
                            },
                            freeReturns: {
                                heading: "Gratis returneringer",
                                text: "Gratis returforsendelse på alle amerikanske ordrer."
                            },
                            subscriptions: {
                                text: "For abonnementsordrer vil Onward Package Protection blive tilføjet til hver tilbagevendende ordre og kan annulleres når som helst."
                            },
                            prioritySupport: {
                                heading: "Prioriteret support",
                                text: "Spring køen over og få hurtig kundesupport."
                            }
                        }
                    },
                    de: {
                        modal: {
                            headline: "Erleben Sie VIP-Schutz und garantierte Zufriedenheit mit Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Der Belohnungscode wird 30 Tage nach dem Kauf per E-Mail zugesandt."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% CashBack verdienen",
                                text: "Erhalten Sie {{rewardsPercentage}}% als Online-Shop-Guthaben für zukünftige Einkäufe zurück.*"
                            },
                            protect: {
                                heading: "Versandschutz",
                                text: "Vor Diebstahl, Verlust, Beschädigung und mehr — Onward schützt Sie."
                            },
                            extendedWarranties: {
                                heading: "Produktschutz",
                                text: "Vor Ausfall durch normale Abnutzung und Defekte nach Ablauf der Herstellergarantie."
                            },
                            carbonOffsets: {
                                heading: "Klimaneutraler Versand",
                                text: "Wir kompensieren die CO2-Emissionen dieser Sendung."
                            },
                            productGuarantees: {
                                heading: "Zufriedenheitsgarantie",
                                text: "Wenn Sie innerhalb von {{days}} Tagen Qualitätsprobleme haben, beheben wir das."
                            },
                            returnsAndExchanges: {
                                heading: "Kostenlose Rückgaben und Umtausch",
                                text: "Kostenloser Rückversand bei allen US-Bestellungen für Rückgaben und Umtausch."
                            },
                            freeReturns: {
                                heading: "Kostenlose Rückgaben",
                                text: "Kostenloser Rückversand bei allen US-Bestellungen."
                            },
                            subscriptions: {
                                text: "Bei Abo-Bestellungen wird Onward Package Protection zu jeder wiederkehrenden Bestellung hinzugefügt und kann jederzeit gekündigt werden."
                            },
                            prioritySupport: {
                                heading: "Prioritäts-Support",
                                text: "Überspringen Sie die Warteschlange und erhalten Sie beschleunigten Kundensupport."
                            }
                        }
                    },
                    el: {
                        modal: {
                            headline: "Ζήστε την VIP προστασία και την εγγυημένη ικανοποίηση με το Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Ο κωδικός ανταμοιβής θα σταλεί με email 30 ημέρες μετά την αγορά."
                            },
                            rewards: {
                                heading: "Κερδίστε {{rewardsPercentage}}% CashBack",
                                text: "Λάβετε {{rewardsPercentage}}% πίσω ως πίστωση online καταστήματος για μελλοντικές αγορές.*"
                            },
                            protect: {
                                heading: "Προστασία Αποστολής",
                                text: "Από κλοπή, απώλεια, ζημιά και άλλα — το Onward σας καλύπτει."
                            },
                            extendedWarranties: {
                                heading: "Προστασία Προϊόντος",
                                text: "Από βλάβη λόγω φυσιολογικής φθοράς και ελαττώματα μετά τη λήξη της εγγύησης του κατασκευαστή."
                            },
                            carbonOffsets: {
                                heading: "Ουδέτερη Αποστολή Άνθρακα",
                                text: "Θα αντισταθμίσουμε τις εκπομπές CO2 αυτής της αποστολής."
                            },
                            productGuarantees: {
                                heading: "Εγγύηση Ικανοποίησης",
                                text: "Αν έχετε οποιαδήποτε προβλήματα ποιότητας εντός {{days}} ημερών, θα το διορθώσουμε."
                            },
                            returnsAndExchanges: {
                                heading: "Δωρεάν Επιστροφές και Ανταλλαγές",
                                text: "Δωρεάν αποστολή επιστροφής σε όλες τις παραγγελίες ΗΠΑ για επιστροφές και ανταλλαγές."
                            },
                            freeReturns: {
                                heading: "Δωρεάν Επιστροφές",
                                text: "Δωρεάν αποστολή επιστροφής σε όλες τις παραγγελίες ΗΠΑ."
                            },
                            subscriptions: {
                                text: "Για παραγγελίες συνδρομής, το Onward Package Protection θα προστεθεί σε κάθε επαναλαμβανόμενη παραγγελία και μπορεί να ακυρωθεί ανά πάσα στιγμή."
                            },
                            prioritySupport: {
                                heading: "Προτεραιότητα Υποστήριξης",
                                text: "Παρακάμψτε την ουρά και λάβετε επιταχυμένη υποστήριξη πελατών."
                            }
                        }
                    },
                    en: _,
                    "en-GB": {
                        modal: {
                            headline: "Experience VIP protection & guaranteed satisfaction with Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Reward code will be emailed 30 days after purchase."
                            },
                            rewards: {
                                heading: "Earn {{rewardsPercentage}}% CashBack",
                                text: "Get {{rewardsPercentage}}% back in online store credit to be used on future purchases.*"
                            },
                            protect: {
                                heading: "Shipping Protection",
                                text: "From theft, loss, damage, & more — Onward has you covered."
                            },
                            extendedWarranties: {
                                heading: "Product Protection",
                                text: "From failure due to normal wear and tear and defects after the manufacturer's warranty expires."
                            },
                            carbonOffsets: {
                                heading: "Carbon Neutral Shipping",
                                text: "We'll offset the CO2 emissions of this shipment."
                            },
                            productGuarantees: {
                                heading: "Satisfaction Guarantee",
                                text: "If you have any quality issues within {{days}} days, we'll make it right."
                            },
                            returnsAndExchanges: {
                                heading: "Free Returns & Exchanges",
                                text: "Free return shipping on all UK orders for returns & exchanges."
                            },
                            freeReturns: {
                                heading: "Free Returns",
                                text: "Free return shipping on all UK orders."
                            },
                            subscriptions: {
                                text: "For subscription orders, Onward Package Protection will be added to each recurring order and may be cancelled at any time."
                            },
                            prioritySupport: {
                                heading: "Priority Support",
                                text: "Skip the queue and get expedited customer support."
                            }
                        }
                    },
                    es: {
                        modal: {
                            headline: "Experimenta protección VIP y satisfacción garantizada con Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*El código de recompensa se enviará por correo electrónico 30 días después de la compra."
                            },
                            rewards: {
                                heading: "Gana {{rewardsPercentage}}% CashBack",
                                text: "Obtén {{rewardsPercentage}}% de vuelta en crédito de tienda en línea para usar en compras futuras.*"
                            },
                            protect: {
                                heading: "Protección de Envío",
                                text: "Contra robo, pérdida, daños y más — Onward te cubre."
                            },
                            extendedWarranties: {
                                heading: "Protección del Producto",
                                text: "Contra fallas por desgaste normal y defectos después de que expire la garantía del fabricante."
                            },
                            carbonOffsets: {
                                heading: "Envío Carbono Neutral",
                                text: "Compensaremos las emisiones de CO2 de este envío."
                            },
                            productGuarantees: {
                                heading: "Garantía de Satisfacción",
                                text: "Si tienes problemas de calidad dentro de {{days}} días, lo solucionaremos."
                            },
                            returnsAndExchanges: {
                                heading: "Devoluciones y Cambios Gratis",
                                text: "Envío de devolución gratis en todos los pedidos de EE.UU. para devoluciones y cambios."
                            },
                            freeReturns: {
                                heading: "Devoluciones Gratis",
                                text: "Envío de devolución gratis en todos los pedidos de EE.UU."
                            },
                            subscriptions: {
                                text: "Para pedidos de suscripción, Onward Package Protection se agregará a cada pedido recurrente y puede cancelarse en cualquier momento."
                            },
                            prioritySupport: {
                                heading: "Soporte Prioritario",
                                text: "Salta la fila y obtén soporte al cliente acelerado."
                            }
                        }
                    },
                    "es-MX": {
                        modal: {
                            headline: "Experimenta protección VIP y satisfacción garantizada con Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*El código de recompensa se enviará por correo electrónico 30 días después de la compra."
                            },
                            rewards: {
                                heading: "Gana {{rewardsPercentage}}% CashBack",
                                text: "Obtén {{rewardsPercentage}}% de vuelta en crédito de tienda en línea para usar en compras futuras.*"
                            },
                            protect: {
                                heading: "Protección de Envío",
                                text: "Contra robo, pérdida, daños y más — Onward te cubre."
                            },
                            extendedWarranties: {
                                heading: "Protección del Producto",
                                text: "Contra fallas por desgaste normal y defectos después de que expire la garantía del fabricante."
                            },
                            carbonOffsets: {
                                heading: "Envío Carbono Neutral",
                                text: "Compensaremos las emisiones de CO2 de este envío."
                            },
                            productGuarantees: {
                                heading: "Garantía de Satisfacción",
                                text: "Si tienes problemas de calidad dentro de {{days}} días, lo solucionaremos."
                            },
                            returnsAndExchanges: {
                                heading: "Devoluciones y Cambios Gratis",
                                text: "Envío de devolución gratis en todos los pedidos de EE.UU. para devoluciones y cambios."
                            },
                            freeReturns: {
                                heading: "Devoluciones Gratis",
                                text: "Envío de devolución gratis en todos los pedidos de EE.UU."
                            },
                            subscriptions: {
                                text: "Para pedidos de suscripción, Onward Package Protection se agregará a cada pedido recurrente y puede cancelarse en cualquier momento."
                            },
                            prioritySupport: {
                                heading: "Soporte Prioritario",
                                text: "Salta la fila y obtén soporte al cliente acelerado."
                            }
                        }
                    },
                    et: {
                        modal: {
                            headline: "Koge VIP-kaitset ja garanteeritud rahulolu Onward VIP Protection-iga.",
                            rewardsDisclaimer: {
                                text: "*Preemiakoodi saadetakse e-postiga 30 päeva pärast ostu."
                            },
                            rewards: {
                                heading: "Teeni {{rewardsPercentage}}% CashBack",
                                text: "Saa {{rewardsPercentage}}% tagasi veebipoe krediidina tulevaste ostude jaoks.*"
                            },
                            protect: {
                                heading: "Saatmiskaitse",
                                text: "Varguse, kaotuse, kahjustuse ja muu eest — Onward kaitseb sind."
                            },
                            extendedWarranties: {
                                heading: "Tootekaitse",
                                text: "Rikete eest normaalse kulumise ja defektide tõttu pärast tootja garantii lõppemist."
                            },
                            carbonOffsets: {
                                heading: "Süsinikuneutraalne Saatmine",
                                text: "Kompenseerime selle saadetise CO2 heitkogused."
                            },
                            productGuarantees: {
                                heading: "Rahulolugarantii",
                                text: "Kui sul on kvaliteediprobleeme {{days}} päeva jooksul, teeme selle korda."
                            },
                            returnsAndExchanges: {
                                heading: "Tasuta Tagastused ja Vahetused",
                                text: "Tasuta tagastussaatmine kõikidele USA tellimustele tagastuste ja vahetuste jaoks."
                            },
                            freeReturns: {
                                heading: "Tasuta Tagastused",
                                text: "Tasuta tagastussaatmine kõikidele USA tellimustele."
                            },
                            subscriptions: {
                                text: "Tellimuse tellimuste puhul lisatakse Onward Package Protection igale korduvale tellimusele ja seda saab igal ajal tühistada."
                            },
                            prioritySupport: {
                                heading: "Prioriteetne Tugi",
                                text: "Jäta järjekord vahele ja saa kiirendatud kliendituge."
                            }
                        }
                    },
                    fa: {
                        modal: {
                            headline: "حفاظت VIP و رضایت تضمینی را با Onward VIP Protection تجربه کنید.",
                            rewardsDisclaimer: {
                                text: "*کد پاداش ۳۰ روز پس از خرید ایمیل خواهد شد."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% بازگشت نقدی کسب کنید",
                                text: "{{rewardsPercentage}}% به عنوان اعتبار فروشگاه آنلاین برای خریدهای آینده دریافت کنید.*"
                            },
                            protect: {
                                heading: "حفاظت ارسال",
                                text: "از سرقت، گم شدن، آسیب و موارد دیگر — Onward شما را پوشش می‌دهد."
                            },
                            extendedWarranties: {
                                heading: "حفاظت محصول",
                                text: "از خرابی ناشی از فرسودگی عادی و نقص‌ها پس از پایان گارانتی سازنده."
                            },
                            carbonOffsets: {
                                heading: "ارسال خنثی کربن",
                                text: "ما انتشار CO2 این محموله را جبران خواهیم کرد."
                            },
                            productGuarantees: {
                                heading: "ضمانت رضایت",
                                text: "اگر در {{days}} روز مشکل کیفیتی داشتید، آن را درست می‌کنیم."
                            },
                            returnsAndExchanges: {
                                heading: "بازگشت و تعویض رایگان",
                                text: "ارسال بازگشت رایگان برای همه سفارشات آمریکا برای بازگشت و تعویض."
                            },
                            freeReturns: {
                                heading: "بازگشت رایگان",
                                text: "ارسال بازگشت رایگان برای همه سفارشات آمریکا."
                            },
                            subscriptions: {
                                text: "برای سفارشات اشتراک، Onward Package Protection به هر سفارش تکراری اضافه می‌شود و می‌تواند در هر زمان لغو شود."
                            },
                            prioritySupport: {
                                heading: "پشتیبانی اولویت‌دار",
                                text: "از صف رد شوید و پشتیبانی سریع مشتری دریافت کنید."
                            }
                        }
                    },
                    fi: {
                        modal: {
                            headline: "Koe VIP-suoja ja taattu tyytyväisyys Onward VIP Protection -palvelulla.",
                            rewardsDisclaimer: {
                                text: "*Palkintokoodin saat sähköpostitse 30 päivää oston jälkeen."
                            },
                            rewards: {
                                heading: "Ansaitse {{rewardsPercentage}}% CashBack",
                                text: "Saat {{rewardsPercentage}}% takaisin verkkokaupan krediittinä tulevia ostoksia varten.*"
                            },
                            protect: {
                                heading: "Toimitussuoja",
                                text: "Varkaudelta, katoamiselta, vaurioilta ja muilta — Onward suojaa sinut."
                            },
                            extendedWarranties: {
                                heading: "Tuotesuoja",
                                text: "Vikoihin normaalin kulumisen ja virheiden vuoksi valmistajan takuun päättymisen jälkeen."
                            },
                            carbonOffsets: {
                                heading: "Hiilineutraali Toimitus",
                                text: "Kompensoimme tämän lähetyksen CO2-päästöt."
                            },
                            productGuarantees: {
                                heading: "Tyytyväisyystakuu",
                                text: "Jos sinulla on laatuongelmia {{days}} päivän sisällä, korjaamme sen."
                            },
                            returnsAndExchanges: {
                                heading: "Ilmaiset Palautukset ja Vaihdot",
                                text: "Ilmainen palautustoimitus kaikille USA:n tilauksille palautuksiin ja vaihtoihin."
                            },
                            freeReturns: {
                                heading: "Ilmaiset Palautukset",
                                text: "Ilmainen palautustoimitus kaikille USA:n tilauksille."
                            },
                            subscriptions: {
                                text: "Tilaustilauksille Onward Package Protection lisätään jokaiseen toistuvaan tilaukseen ja se voidaan peruuttaa milloin tahansa."
                            },
                            prioritySupport: {
                                heading: "Prioriteettituki",
                                text: "Ohita jono ja saat nopeutettua asiakastukea."
                            }
                        }
                    },
                    fr: {
                        modal: {
                            headline: "Découvrez la protection VIP et la satisfaction garantie avec Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Le code de récompense sera envoyé par e-mail 30 jours après l'achat."
                            },
                            rewards: {
                                heading: "Gagnez {{rewardsPercentage}}% de CashBack",
                                text: "Obtenez {{rewardsPercentage}}% en crédit boutique en ligne pour vos futurs achats.*"
                            },
                            protect: {
                                heading: "Protection d'Expédition",
                                text: "Contre le vol, la perte, les dommages et plus — Onward vous couvre."
                            },
                            extendedWarranties: {
                                heading: "Protection du Produit",
                                text: "Contre les pannes dues à l'usure normale et aux défauts après l'expiration de la garantie du fabricant."
                            },
                            carbonOffsets: {
                                heading: "Expédition Neutre en Carbone",
                                text: "Nous compenserons les émissions de CO2 de cette expédition."
                            },
                            productGuarantees: {
                                heading: "Garantie de Satisfaction",
                                text: "Si vous avez des problèmes de qualité dans les {{days}} jours, nous le corrigerons."
                            },
                            returnsAndExchanges: {
                                heading: "Retours et Échanges Gratuits",
                                text: "Livraison de retour gratuite sur toutes les commandes américaines pour les retours et échanges."
                            },
                            freeReturns: {
                                heading: "Retours Gratuits",
                                text: "Livraison de retour gratuite sur toutes les commandes américaines."
                            },
                            subscriptions: {
                                text: "Pour les commandes d'abonnement, Onward Package Protection sera ajoutée à chaque commande récurrente et peut être annulée à tout moment."
                            },
                            prioritySupport: {
                                heading: "Support Prioritaire",
                                text: "Passez devant et obtenez un support client accéléré."
                            }
                        }
                    },
                    "fr-CA": {
                        modal: {
                            headline: "Découvrez la protection VIP et la satisfaction garantie avec Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Le code de récompense sera envoyé par courriel 30 jours après l'achat."
                            },
                            rewards: {
                                heading: "Gagnez {{rewardsPercentage}}% de CashBack",
                                text: "Obtenez {{rewardsPercentage}}% en crédit boutique en ligne pour vos futurs achats.*"
                            },
                            protect: {
                                heading: "Protection d'Expédition",
                                text: "Contre le vol, la perte, les dommages et plus — Onward vous couvre."
                            },
                            extendedWarranties: {
                                heading: "Protection du Produit",
                                text: "Contre les pannes dues à l'usure normale et aux défauts après l'expiration de la garantie du fabricant."
                            },
                            carbonOffsets: {
                                heading: "Expédition Neutre en Carbone",
                                text: "Nous compenserons les émissions de CO2 de cette expédition."
                            },
                            productGuarantees: {
                                heading: "Garantie de Satisfaction",
                                text: "Si vous avez des problèmes de qualité dans les {{days}} jours, nous le corrigerons."
                            },
                            returnsAndExchanges: {
                                heading: "Retours et Échanges Gratuits",
                                text: "Livraison de retour gratuite sur toutes les commandes américaines pour les retours et échanges."
                            },
                            freeReturns: {
                                heading: "Retours Gratuits",
                                text: "Livraison de retour gratuite sur toutes les commandes américaines."
                            },
                            subscriptions: {
                                text: "Pour les commandes d'abonnement, Onward Package Protection sera ajoutée à chaque commande récurrente et peut être annulée à tout moment."
                            },
                            prioritySupport: {
                                heading: "Support Prioritaire",
                                text: "Passez devant et obtenez un support client accéléré."
                            }
                        }
                    },
                    ga: {
                        modal: {
                            headline: "Bain triail as cosaint VIP agus sástacht ráthaithe le Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Seolfar an cód luacha saothair trí ríomhphost 30 lá tar éis an cheannaithe."
                            },
                            rewards: {
                                heading: "Tuill {{rewardsPercentage}}% Airgead Ar Ais",
                                text: "Faigh {{rewardsPercentage}}% ar ais mar chreidmheas siopa ar líne le húsáid ar cheannacháin amach anseo.*"
                            },
                            protect: {
                                heading: "Cosaint Loingseoireachta",
                                text: "Ó ghoid, caillteanas, damáiste, agus níos mó — clúdaíonn Onward thú."
                            },
                            extendedWarranties: {
                                heading: "Cosaint Táirge",
                                text: "Ó theip mar gheall ar ghnáthchaitheamh agus lochtanna tar éis don bharántas déantóra dul in éag."
                            },
                            carbonOffsets: {
                                heading: "Loingseoireacht Neodrach Carbóin",
                                text: "Fritháireoimid astuithe CO2 an tseoladh seo."
                            },
                            productGuarantees: {
                                heading: "Ráthaíocht Sástachta",
                                text: "Má bhíonn aon fhadhbanna cáilíochta agat laistigh de {{days}} lá, déanfaimid é a chur ina cheart."
                            },
                            returnsAndExchanges: {
                                heading: "Aischuir agus Malartuithe Saor in Aisce",
                                text: "Loingseoireacht aischuir saor in aisce ar gach ordú SAM le haghaidh aischuir agus malartuithe."
                            },
                            freeReturns: {
                                heading: "Aischuir Saor in Aisce",
                                text: "Loingseoireacht aischuir saor in aisce ar gach ordú SAM."
                            },
                            subscriptions: {
                                text: "Le haghaidh orduithe síntiúis, cuirfear Onward Package Protection le gach ordú athfhillteach agus is féidir é a chealú am ar bith."
                            },
                            prioritySupport: {
                                heading: "Tacaíocht Tosaíochta",
                                text: "Léim thar an scuaine agus faigh tacaíocht custaiméirí luathaithe."
                            }
                        }
                    },
                    ha: {
                        modal: {
                            headline: "Gwada kariyar VIP da gamsuwar da aka tabbatar tare da Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Za a aika lambar lada ta imel kwanaki 30 bayan siye."
                            },
                            rewards: {
                                heading: "Sami {{rewardsPercentage}}% CashBack",
                                text: "Sami {{rewardsPercentage}}% a matsayin kudin shago na kan layi don amfani da shi wajen saye na gaba.*"
                            },
                            protect: {
                                heading: "Kariyar Aikawa",
                                text: "Daga sata, asara, lalacewa, da ƙari — Onward yana kare ka."
                            },
                            extendedWarranties: {
                                heading: "Kariyar Kaya",
                                text: "Daga gazawa saboda lalacewa ta yau da kullum da lahani bayan garantin masana'anta ya ƙare."
                            },
                            carbonOffsets: {
                                heading: "Aikawa Marar Carbon",
                                text: "Za mu daidaita hayaƙin CO2 na wannan aikawa."
                            },
                            productGuarantees: {
                                heading: "Garantin Gamsuwa",
                                text: "Idan kuna da matsalolin inganci a cikin kwanaki {{days}}, za mu gyara shi."
                            },
                            returnsAndExchanges: {
                                heading: "Dawowa da Musanya Kyauta",
                                text: "Aikawa kyauta don dawowa akan duk odar Amurka don dawowa da musanya."
                            },
                            freeReturns: {
                                heading: "Dawowa Kyauta",
                                text: "Aikawa kyauta don dawowa akan duk odar Amurka."
                            },
                            subscriptions: {
                                text: "Don odar biyan kuɗi, za a ƙara Onward Package Protection zuwa kowane oda mai maimaitawa kuma ana iya soke shi a kowane lokaci."
                            },
                            prioritySupport: {
                                heading: "Goyon Bayan Fifiko",
                                text: "Tsallake layi kuma sami goyon bayan abokan ciniki cikin sauri."
                            }
                        }
                    },
                    he: {
                        modal: {
                            headline: "חווה הגנת VIP ושביעות רצון מובטחת עם Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*קוד הפרס יישלח באימייל 30 יום לאחר הרכישה."
                            },
                            rewards: {
                                heading: "הרוויח {{rewardsPercentage}}% CashBack",
                                text: "קבל {{rewardsPercentage}}% בחזרה כקרדיט בחנות המקוונת לרכישות עתידיות.*"
                            },
                            protect: {
                                heading: "הגנת משלוח",
                                text: "מגניבה, אובדן, נזק ועוד — Onward מכסה אותך."
                            },
                            extendedWarranties: {
                                heading: "הגנת מוצר",
                                text: "מתקלות עקב בלאי רגיל ופגמים לאחר פקיעת אחריות היצרן."
                            },
                            carbonOffsets: {
                                heading: "משלוח ניטרלי פחמן",
                                text: "נקזז את פליטות ה-CO2 של משלוח זה."
                            },
                            productGuarantees: {
                                heading: "אחריות שביעות רצון",
                                text: "אם יש לך בעיות איכות תוך {{days}} ימים, נתקן את זה."
                            },
                            returnsAndExchanges: {
                                heading: "החזרות והחלפות חינם",
                                text: 'משלוח החזרה חינם על כל ההזמנות בארה"ב להחזרות והחלפות.'
                            },
                            freeReturns: {
                                heading: "החזרות חינם",
                                text: 'משלוח החזרה חינם על כל ההזמנות בארה"ב.'
                            },
                            subscriptions: {
                                text: "להזמנות מנוי, Onward Package Protection יתווסף לכל הזמנה חוזרת וניתן לבטל בכל עת."
                            },
                            prioritySupport: {
                                heading: "תמיכה עדיפה",
                                text: "דלג על התור וקבל תמיכת לקוחות מזורזת."
                            }
                        }
                    },
                    hi: {
                        modal: {
                            headline: "Onward VIP Protection के साथ VIP सुरक्षा और गारंटीड संतुष्टि का अनुभव करें।",
                            rewardsDisclaimer: {
                                text: "*इनाम कोड खरीद के 30 दिन बाद ईमेल किया जाएगा।"
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% कैशबैक कमाएं",
                                text: "भविष्य की खरीदारी के लिए ऑनलाइन स्टोर क्रेडिट के रूप में {{rewardsPercentage}}% वापस पाएं।*"
                            },
                            protect: {
                                heading: "शिपिंग सुरक्षा",
                                text: "चोरी, नुकसान, क्षति और अधिक से — Onward आपको कवर करता है।"
                            },
                            extendedWarranties: {
                                heading: "उत्पाद सुरक्षा",
                                text: "निर्माता की वारंटी समाप्त होने के बाद सामान्य टूट-फूट और दोषों के कारण खराबी से।"
                            },
                            carbonOffsets: {
                                heading: "कार्बन न्यूट्रल शिपिंग",
                                text: "हम इस शिपमेंट के CO2 उत्सर्जन को ऑफसेट करेंगे।"
                            },
                            productGuarantees: {
                                heading: "संतुष्टि गारंटी",
                                text: "यदि आपको {{days}} दिनों के भीतर कोई गुणवत्ता समस्या है, तो हम इसे ठीक कर देंगे।"
                            },
                            returnsAndExchanges: {
                                heading: "मुफ्त रिटर्न और एक्सचेंज",
                                text: "रिटर्न और एक्सचेंज के लिए सभी US ऑर्डर पर मुफ्त रिटर्न शिपिंग।"
                            },
                            freeReturns: {
                                heading: "मुफ्त रिटर्न",
                                text: "सभी US ऑर्डर पर मुफ्त रिटर्न शिपिंग।"
                            },
                            subscriptions: {
                                text: "सब्सक्रिप्शन ऑर्डर के लिए, Onward Package Protection प्रत्येक आवर्ती ऑर्डर में जोड़ा जाएगा और किसी भी समय रद्द किया जा सकता है।"
                            },
                            prioritySupport: {
                                heading: "प्राथमिकता सहायता",
                                text: "लाइन छोड़ें और त्वरित ग्राहक सहायता प्राप्त करें।"
                            }
                        }
                    },
                    hr: {
                        modal: {
                            headline: "Doživite VIP zaštitu i zajamčeno zadovoljstvo s Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Kod nagrade bit će poslan e-poštom 30 dana nakon kupnje."
                            },
                            rewards: {
                                heading: "Zaradite {{rewardsPercentage}}% CashBack",
                                text: "Dobijte {{rewardsPercentage}}% natrag kao kredit u online trgovini za buduće kupnje.*"
                            },
                            protect: {
                                heading: "Zaštita Dostave",
                                text: "Od krađe, gubitka, oštećenja i više — Onward vas pokriva."
                            },
                            extendedWarranties: {
                                heading: "Zaštita Proizvoda",
                                text: "Od kvara zbog normalnog trošenja i nedostataka nakon isteka jamstva proizvođača."
                            },
                            carbonOffsets: {
                                heading: "Ugljično Neutralna Dostava",
                                text: "Kompenzirat ćemo emisije CO2 ove pošiljke."
                            },
                            productGuarantees: {
                                heading: "Jamstvo Zadovoljstva",
                                text: "Ako imate bilo kakvih problema s kvalitetom unutar {{days}} dana, ispravit ćemo to."
                            },
                            returnsAndExchanges: {
                                heading: "Besplatni Povrati i Zamjene",
                                text: "Besplatna povratna dostava na sve narudžbe u SAD-u za povrate i zamjene."
                            },
                            freeReturns: {
                                heading: "Besplatni Povrati",
                                text: "Besplatna povratna dostava na sve narudžbe u SAD-u."
                            },
                            subscriptions: {
                                text: "Za pretplatničke narudžbe, Onward Package Protection bit će dodan svakoj ponavljajućoj narudžbi i može se otkazati u bilo kojem trenutku."
                            },
                            prioritySupport: {
                                heading: "Prioritetna Podrška",
                                text: "Preskočite red i dobijte ubrzanu korisničku podršku."
                            }
                        }
                    },
                    hu: {
                        modal: {
                            headline: "Tapasztalja meg a VIP védelmet és a garantált elégedettséget az Onward VIP Protection-nel.",
                            rewardsDisclaimer: {
                                text: "*A jutalom kódot e-mailben küldjük el a vásárlás után 30 nappal."
                            },
                            rewards: {
                                heading: "Szerezzen {{rewardsPercentage}}% CashBack-et",
                                text: "Kapjon vissza {{rewardsPercentage}}%-ot online bolti kreditként a jövőbeli vásárlásokhoz.*"
                            },
                            protect: {
                                heading: "Szállítási Védelem",
                                text: "Lopás, elvesztés, sérülés és egyebek ellen — az Onward véd téged."
                            },
                            extendedWarranties: {
                                heading: "Termékvédelem",
                                text: "A normál kopás és hibák miatti meghibásodás ellen a gyártói garancia lejárta után."
                            },
                            carbonOffsets: {
                                heading: "Karbonsemleges Szállítás",
                                text: "Kompenzáljuk ennek a szállítmánynak a CO2 kibocsátását."
                            },
                            productGuarantees: {
                                heading: "Elégedettségi Garancia",
                                text: "Ha {{days}} napon belül bármilyen minőségi problémája van, megoldjuk."
                            },
                            returnsAndExchanges: {
                                heading: "Ingyenes Visszaküldés és Csere",
                                text: "Ingyenes visszaküldési szállítás minden amerikai rendelésre visszaküldéshez és cseréhez."
                            },
                            freeReturns: {
                                heading: "Ingyenes Visszaküldés",
                                text: "Ingyenes visszaküldési szállítás minden amerikai rendelésre."
                            },
                            subscriptions: {
                                text: "Előfizetési rendelések esetén az Onward Package Protection minden ismétlődő rendeléshez hozzáadódik, és bármikor lemondható."
                            },
                            prioritySupport: {
                                heading: "Prioritásos Támogatás",
                                text: "Hagyja ki a sort és kapjon gyorsított ügyfélszolgálatot."
                            }
                        }
                    },
                    id: {
                        modal: {
                            headline: "Rasakan perlindungan VIP dan kepuasan terjamin dengan Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Kode hadiah akan dikirim melalui email 30 hari setelah pembelian."
                            },
                            rewards: {
                                heading: "Dapatkan {{rewardsPercentage}}% CashBack",
                                text: "Dapatkan kembali {{rewardsPercentage}}% sebagai kredit toko online untuk pembelian di masa depan.*"
                            },
                            protect: {
                                heading: "Perlindungan Pengiriman",
                                text: "Dari pencurian, kehilangan, kerusakan, dan lainnya — Onward melindungi Anda."
                            },
                            extendedWarranties: {
                                heading: "Perlindungan Produk",
                                text: "Dari kerusakan karena keausan normal dan cacat setelah garansi produsen berakhir."
                            },
                            carbonOffsets: {
                                heading: "Pengiriman Netral Karbon",
                                text: "Kami akan mengimbangi emisi CO2 dari pengiriman ini."
                            },
                            productGuarantees: {
                                heading: "Jaminan Kepuasan",
                                text: "Jika Anda memiliki masalah kualitas dalam {{days}} hari, kami akan memperbaikinya."
                            },
                            returnsAndExchanges: {
                                heading: "Pengembalian dan Penukaran Gratis",
                                text: "Pengiriman pengembalian gratis untuk semua pesanan AS untuk pengembalian dan penukaran."
                            },
                            freeReturns: {
                                heading: "Pengembalian Gratis",
                                text: "Pengiriman pengembalian gratis untuk semua pesanan AS."
                            },
                            subscriptions: {
                                text: "Untuk pesanan langganan, Onward Package Protection akan ditambahkan ke setiap pesanan berulang dan dapat dibatalkan kapan saja."
                            },
                            prioritySupport: {
                                heading: "Dukungan Prioritas",
                                text: "Lewati antrean dan dapatkan dukungan pelanggan yang dipercepat."
                            }
                        }
                    },
                    ig: {
                        modal: {
                            headline: "Nwee ahụmịhe nchedo VIP na afọ ojuju e kwadoro site na Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*A ga-eziga koodu ụgwọ ọrụ n'ozi email ụbọchị 30 mgbe ị zụtara."
                            },
                            rewards: {
                                heading: "Nweta {{rewardsPercentage}}% CashBack",
                                text: "Nweta {{rewardsPercentage}}% azụ dị ka ego ụlọ ahịa n'ịntanetị maka azụmahịa n'ọdịnihu.*"
                            },
                            protect: {
                                heading: "Nchedo Nzipu",
                                text: "Site na ohi, ịla n'iyi, mmebi, na ndị ọzọ — Onward na-echekwa gị."
                            },
                            extendedWarranties: {
                                heading: "Nchedo Ngwaahịa",
                                text: "Site na ịda n'ihu n'ihi ịdị ike nkịtị na ntụpọ mgbe nkwa nke onye mmepụta gbasara."
                            },
                            carbonOffsets: {
                                heading: "Nzipu Enweghị Carbon",
                                text: "Anyị ga-akwụ ụgwọ CO2 nke nzipu a."
                            },
                            productGuarantees: {
                                heading: "Nkwa Afọ Ojuju",
                                text: "Ọ bụrụ na ị nwere nsogbu ịdị mma n'ime ụbọchị {{days}}, anyị ga-edozi ya."
                            },
                            returnsAndExchanges: {
                                heading: "Nloghachi na Mgbanwe Efu",
                                text: "Nzipu nloghachi efu na iwu US niile maka nloghachi na mgbanwe."
                            },
                            freeReturns: {
                                heading: "Nloghachi Efu",
                                text: "Nzipu nloghachi efu na iwu US niile."
                            },
                            subscriptions: {
                                text: "Maka iwu ndenye aha, a ga-agbakwụnye Onward Package Protection na iwu ọ bụla na-emegharị ugboro ugboro ma nwee ike kagbuo ya n'oge ọ bụla."
                            },
                            prioritySupport: {
                                heading: "Nkwado Nke Mbu",
                                text: "Wụfee ahịrị ma nweta nkwado ndị ahịa ngwa ngwa."
                            }
                        }
                    },
                    it: {
                        modal: {
                            headline: "Sperimenta la protezione VIP e la soddisfazione garantita con Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Il codice premio verrà inviato via email 30 giorni dopo l'acquisto."
                            },
                            rewards: {
                                heading: "Guadagna {{rewardsPercentage}}% CashBack",
                                text: "Ottieni {{rewardsPercentage}}% indietro come credito negozio online da utilizzare per acquisti futuri.*"
                            },
                            protect: {
                                heading: "Protezione Spedizione",
                                text: "Da furto, smarrimento, danni e altro — Onward ti copre."
                            },
                            extendedWarranties: {
                                heading: "Protezione Prodotto",
                                text: "Da guasti dovuti a normale usura e difetti dopo la scadenza della garanzia del produttore."
                            },
                            carbonOffsets: {
                                heading: "Spedizione Carbon Neutral",
                                text: "Compenseremo le emissioni di CO2 di questa spedizione."
                            },
                            productGuarantees: {
                                heading: "Garanzia di Soddisfazione",
                                text: "Se hai problemi di qualità entro {{days}} giorni, lo sistemeremo."
                            },
                            returnsAndExchanges: {
                                heading: "Resi e Cambi Gratuiti",
                                text: "Spedizione di reso gratuita su tutti gli ordini USA per resi e cambi."
                            },
                            freeReturns: {
                                heading: "Resi Gratuiti",
                                text: "Spedizione di reso gratuita su tutti gli ordini USA."
                            },
                            subscriptions: {
                                text: "Per gli ordini in abbonamento, Onward Package Protection verrà aggiunto a ogni ordine ricorrente e può essere annullato in qualsiasi momento."
                            },
                            prioritySupport: {
                                heading: "Supporto Prioritario",
                                text: "Salta la fila e ottieni supporto clienti accelerato."
                            }
                        }
                    },
                    ja: {
                        modal: {
                            headline: "Onward VIP Protectionで、VIP保護と満足保証を体験してください。",
                            rewardsDisclaimer: {
                                text: "*リワードコードは購入後30日以内にメールで送信されます。"
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}%キャッシュバックを獲得",
                                text: "将来の購入に使用できるオンラインストアクレジットとして{{rewardsPercentage}}%を取り戻しましょう。*"
                            },
                            protect: {
                                heading: "配送保護",
                                text: "盗難、紛失、損傷などから — Onwardがあなたをカバーします。"
                            },
                            extendedWarranties: {
                                heading: "製品保護",
                                text: "メーカー保証期間終了後の通常の摩耗や欠陥による故障から保護します。"
                            },
                            carbonOffsets: {
                                heading: "カーボンニュートラル配送",
                                text: "この配送のCO2排出量を相殺します。"
                            },
                            productGuarantees: {
                                heading: "満足保証",
                                text: "{{days}}日以内に品質問題があれば、対応いたします。"
                            },
                            returnsAndExchanges: {
                                heading: "無料返品・交換",
                                text: "返品・交換のため、米国内全注文で返品送料無料。"
                            },
                            freeReturns: {
                                heading: "無料返品",
                                text: "米国内全注文で返品送料無料。"
                            },
                            subscriptions: {
                                text: "サブスクリプション注文の場合、Onward Package Protectionは各定期注文に追加され、いつでもキャンセルできます。"
                            },
                            prioritySupport: {
                                heading: "優先サポート",
                                text: "列をスキップして、迅速なカスタマーサポートを受けましょう。"
                            }
                        }
                    },
                    kk: {
                        modal: {
                            headline: "Onward VIP Protection арқылы VIP қорғау мен кепілдендірілген қанағаттануды сезініңіз.",
                            rewardsDisclaimer: {
                                text: "*Марапат коды сатып алғаннан кейін 30 күнде электрондық поштаға жіберіледі."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% CashBack табыңыз",
                                text: "Болашақ сатып алулар үшін онлайн дүкен кредиті ретінде {{rewardsPercentage}}% қайтарып алыңыз.*"
                            },
                            protect: {
                                heading: "Жеткізу қорғауы",
                                text: "Ұрлық, жоғалу, зақымдану және т.б. — Onward сізді қорғайды."
                            },
                            extendedWarranties: {
                                heading: "Өнім қорғауы",
                                text: "Өндіруші кепілдігі аяқталғаннан кейін қалыпты тозу мен ақаулардан болған істен шығудан."
                            },
                            carbonOffsets: {
                                heading: "Көміртегі бейтарап жеткізу",
                                text: "Біз бұл жөнелтілімнің CO2 шығарындыларын өтейміз."
                            },
                            productGuarantees: {
                                heading: "Қанағаттану кепілдігі",
                                text: "{{days}} күн ішінде сапа мәселелері болса, біз оны түзетеміз."
                            },
                            returnsAndExchanges: {
                                heading: "Тегін қайтару және айырбастау",
                                text: "Қайтару және айырбастау үшін барлық АҚШ тапсырыстарына тегін қайтару жеткізу."
                            },
                            freeReturns: {
                                heading: "Тегін қайтару",
                                text: "Барлық АҚШ тапсырыстарына тегін қайтару жеткізу."
                            },
                            subscriptions: {
                                text: "Жазылым тапсырыстары үшін Onward Package Protection әрбір қайталанатын тапсырысқа қосылады және кез келген уақытта тоқтатылуы мүмкін."
                            },
                            prioritySupport: {
                                heading: "Басым қолдау",
                                text: "Кезекті өткізіп жіберіңіз және жеделдетілген тұтынушылар қолдауын алыңыз."
                            }
                        }
                    },
                    km: {
                        modal: {
                            headline: "ទទួលបានការការពារ VIP និងការពេញចិត្តដែលធានា ជាមួយ Onward VIP Protection។",
                            rewardsDisclaimer: {
                                text: "*លេខកូដរង្វាន់នឹងត្រូវបានផ្ញើតាមអ៊ីមែល 30 ថ្ងៃបន្ទាប់ពីការទិញ។"
                            },
                            rewards: {
                                heading: "រកប្រាក់សង្គ្រោះ {{rewardsPercentage}}%",
                                text: "ទទួលបាន {{rewardsPercentage}}% ត្រឡប់មកវិញជាឥណទានហាងអនឡាញសម្រាប់ការទិញនាពេលអនាគត។*"
                            },
                            protect: {
                                heading: "ការការពារការដឹកជញ្ជូន",
                                text: "ពីការលួច ការបាត់បង់ ការខូចខាត និងច្រើនទៀត — Onward គ្របដណ្តប់អ្នក។"
                            },
                            extendedWarranties: {
                                heading: "ការការពារផលិតផល",
                                text: "ពីការបរាជ័យដោយសារការពាក់និងការហែកធម្មតា និងកំហុសបន្ទាប់ពីការធានារបស់អ្នកផលិតផុតកំណត់។"
                            },
                            carbonOffsets: {
                                heading: "ការដឹកជញ្ជូនអព្យាក្រឹតកាបូន",
                                text: "យើងនឹងបង់សំណងការបំភាយ CO2 នៃការដឹកជញ្ជូននេះ។"
                            },
                            productGuarantees: {
                                heading: "ការធានាពេញចិត្ត",
                                text: "ប្រសិនបើអ្នកមានបញ្ហាគុណភាពក្នុងរយៈពេល {{days}} ថ្ងៃ យើងនឹងដោះស្រាយវា។"
                            },
                            returnsAndExchanges: {
                                heading: "ការត្រឡប់និងប្តូរដោយឥតគិតថ្លៃ",
                                text: "ការដឹកជញ្ជូនត្រឡប់ដោយឥតគិតថ្លៃលើការបញ្ជាទិញអាមេរិកទាំងអស់សម្រាប់ការត្រឡប់និងការប្តូរ។"
                            },
                            freeReturns: {
                                heading: "ការត្រឡប់ដោយឥតគិតថ្លៃ",
                                text: "ការដឹកជញ្ជូនត្រឡប់ដោយឥតគិតថ្លៃលើការបញ្ជាទិញអាមេរិកទាំងអស់។"
                            },
                            subscriptions: {
                                text: "សម្រាប់ការបញ្ជាទិញជាវ Onward Package Protection នឹងត្រូវបានបន្ថែមទៅការបញ្ជាទិញម្តងហើយម្តងទៀត និងអាចលុបចោលបានគ្រប់ពេល។"
                            },
                            prioritySupport: {
                                heading: "ការគាំទ្រអាទិភាព",
                                text: "រំលងជួរ និងទទួលបានការគាំទ្រអតិថិជនរហ័ស។"
                            }
                        }
                    },
                    kn: {
                        modal: {
                            headline: "Onward VIP Protection ನೊಂದಿಗೆ VIP ರಕ್ಷಣೆ ಮತ್ತು ಖಾತರಿಯ ತೃಪ್ತಿಯನ್ನು ಅನುಭವಿಸಿ.",
                            rewardsDisclaimer: {
                                text: "*ಬಹುಮಾನ ಕೋಡ್ ಅನ್ನು ಖರೀದಿಯ 30 ದಿನಗಳ ನಂತರ ಇಮೇಲ್ ಮಾಡಲಾಗುವುದು."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% ಕ್ಯಾಶ್‌ಬ್ಯಾಕ್ ಗಳಿಸಿ",
                                text: "ಭವಿಷ್ಯದ ಖರೀದಿಗಳಿಗಾಗಿ ಆನ್‌ಲೈನ್ ಸ್ಟೋರ್ ಕ್ರೆಡಿಟ್ ಆಗಿ {{rewardsPercentage}}% ಹಿಂತಿರುಗಿ ಪಡೆಯಿರಿ.*"
                            },
                            protect: {
                                heading: "ಶಿಪ್ಪಿಂಗ್ ರಕ್ಷಣೆ",
                                text: "ಕಳ್ಳತನ, ನಷ್ಟ, ಹಾನಿ ಮತ್ತು ಹೆಚ್ಚಿನವುಗಳಿಂದ — Onward ನಿಮ್ಮನ್ನು ರಕ್ಷಿಸುತ್ತದೆ."
                            },
                            extendedWarranties: {
                                heading: "ಉತ್ಪನ್ನ ರಕ್ಷಣೆ",
                                text: "ತಯಾರಕರ ವಾರಂಟಿ ಮುಗಿದ ನಂತರ ಸಾಮಾನ್ಯ ಸವೆತ ಮತ್ತು ದೋಷಗಳಿಂದ ವೈಫಲ್ಯದಿಂದ."
                            },
                            carbonOffsets: {
                                heading: "ಕಾರ್ಬನ್ ತಟಸ್ಥ ಶಿಪ್ಪಿಂಗ್",
                                text: "ನಾವು ಈ ಶಿಪ್‌ಮೆಂಟ್‌ನ CO2 ಹೊರಸೂಸುವಿಕೆಯನ್ನು ಸರಿದೂಗಿಸುತ್ತೇವೆ."
                            },
                            productGuarantees: {
                                heading: "ತೃಪ್ತಿ ಖಾತರಿ",
                                text: "{{days}} ದಿನಗಳಲ್ಲಿ ನಿಮಗೆ ಯಾವುದೇ ಗುಣಮಟ್ಟದ ಸಮಸ್ಯೆಗಳಿದ್ದರೆ, ನಾವು ಅದನ್ನು ಸರಿಪಡಿಸುತ್ತೇವೆ."
                            },
                            returnsAndExchanges: {
                                heading: "ಉಚಿತ ಹಿಂತಿರುಗಿಕೆ ಮತ್ತು ವಿನಿಮಯಗಳು",
                                text: "ಹಿಂತಿರುಗಿಕೆ ಮತ್ತು ವಿನಿಮಯಗಳಿಗಾಗಿ ಎಲ್ಲಾ US ಆರ್ಡರ್‌ಗಳಲ್ಲಿ ಉಚಿತ ಹಿಂತಿರುಗಿ ಶಿಪ್ಪಿಂಗ್."
                            },
                            freeReturns: {
                                heading: "ಉಚಿತ ಹಿಂತಿರುಗಿಕೆಗಳು",
                                text: "ಎಲ್ಲಾ US ಆರ್ಡರ್‌ಗಳಲ್ಲಿ ಉಚಿತ ಹಿಂತಿರುಗಿ ಶಿಪ್ಪಿಂಗ್."
                            },
                            subscriptions: {
                                text: "ಸಬ್‌ಸ್ಕ್ರಿಪ್ಷನ್ ಆರ್ಡರ್‌ಗಳಿಗೆ, Onward Package Protection ಪ್ರತಿ ಪುನರಾವರ್ತಿತ ಆರ್ಡರ್‌ಗೆ ಸೇರಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಯಾವುದೇ ಸಮಯದಲ್ಲಿ ರದ್ದುಗೊಳಿಸಬಹುದು."
                            },
                            prioritySupport: {
                                heading: "ಆದ್ಯತೆ ಬೆಂಬಲ",
                                text: "ಸಾಲನ್ನು ಬಿಟ್ಟುಬಿಡಿ ಮತ್ತು ತ್ವರಿತ ಗ್ರಾಹಕ ಬೆಂಬಲವನ್ನು ಪಡೆಯಿರಿ."
                            }
                        }
                    },
                    ko: {
                        modal: {
                            headline: "Onward VIP Protection으로 VIP 보호와 보장된 만족을 경험하세요.",
                            rewardsDisclaimer: {
                                text: "*보상 코드는 구매 후 30일 이내에 이메일로 전송됩니다."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% 캐시백 적립",
                                text: "향후 구매에 사용할 온라인 스토어 크레딧으로 {{rewardsPercentage}}%를 돌려받으세요.*"
                            },
                            protect: {
                                heading: "배송 보호",
                                text: "도난, 분실, 손상 등으로부터 — Onward가 보호해 드립니다."
                            },
                            extendedWarranties: {
                                heading: "제품 보호",
                                text: "제조사 보증 만료 후 정상적인 마모 및 결함으로 인한 고장으로부터 보호합니다."
                            },
                            carbonOffsets: {
                                heading: "탄소 중립 배송",
                                text: "이 배송의 CO2 배출량을 상쇄합니다."
                            },
                            productGuarantees: {
                                heading: "만족 보장",
                                text: "{{days}}일 이내에 품질 문제가 있으면 해결해 드리겠습니다."
                            },
                            returnsAndExchanges: {
                                heading: "무료 반품 및 교환",
                                text: "반품 및 교환을 위해 모든 미국 주문에 무료 반품 배송."
                            },
                            freeReturns: {
                                heading: "무료 반품",
                                text: "모든 미국 주문에 무료 반품 배송."
                            },
                            subscriptions: {
                                text: "구독 주문의 경우 Onward Package Protection이 각 반복 주문에 추가되며 언제든지 취소할 수 있습니다."
                            },
                            prioritySupport: {
                                heading: "우선 지원",
                                text: "대기열을 건너뛰고 신속한 고객 지원을 받으세요."
                            }
                        }
                    },
                    ku: {
                        modal: {
                            headline: "Bi Onward VIP Protection re parastina VIP û razîbûna garantîkirî biceribîne.",
                            rewardsDisclaimer: {
                                text: "*Koda xelatê dê 30 roj piştî kirînê bi e-nameyê were şandin."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% CashBack Bistîne",
                                text: "{{rewardsPercentage}}% wekî krediya firotgehê online ji bo kirînên pêşerojê vegerîne.*"
                            },
                            protect: {
                                heading: "Parastina Şandina",
                                text: "Ji dizî, windabûn, zirar û bêtir — Onward te diparêze."
                            },
                            extendedWarranties: {
                                heading: "Parastina Hilberê",
                                text: "Ji têkçûna ji ber karsaziya normal û kêmasiyên piştî garantiya çêker diqede."
                            },
                            carbonOffsets: {
                                heading: "Şandina Karbonê Bêalî",
                                text: "Em ê avêtina CO2 ya vê şandiyê bersiv bidin."
                            },
                            productGuarantees: {
                                heading: "Garantiya Razîbûnê",
                                text: "Heke di nav {{days}} rojan de pirsgirêkên kalîteyê hebin, em ê wê rast bikin."
                            },
                            returnsAndExchanges: {
                                heading: "Vegerandin û Guherandinên Belaş",
                                text: "Şandina vegerandinê ya belaş li ser hemî siparişên Amerîkayê ji bo vegerandin û guherandinan."
                            },
                            freeReturns: {
                                heading: "Vegerandinên Belaş",
                                text: "Şandina vegerandinê ya belaş li ser hemî siparişên Amerîkayê."
                            },
                            subscriptions: {
                                text: "Ji bo siparişên abonetiyê, Onward Package Protection dê li her siparişa dubare were zêdekirin û dikare her dem were betal kirin."
                            },
                            prioritySupport: {
                                heading: "Piştgiriya Pêşîn",
                                text: "Rêza derbas bike û piştgiriya xerîdar a bilez bistîne."
                            }
                        }
                    },
                    ky: {
                        modal: {
                            headline: "Onward VIP Protection менен VIP коргоону жана кепилдиктүү канааттанууну сезиңиз.",
                            rewardsDisclaimer: {
                                text: "*Сыйлык коду сатып алгандан 30 күндөн кийин электрондук почта аркылуу жөнөтүлөт."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% CashBack табыңыз",
                                text: "Келечектеги сатып алуулар үчүн онлайн дүкөн кредити катары {{rewardsPercentage}}% кайтарып алыңыз.*"
                            },
                            protect: {
                                heading: "Жеткирүү коргоосу",
                                text: "Уурдоодон, жоготуудан, зыяндан жана башкалардан — Onward сизди коргойт."
                            },
                            extendedWarranties: {
                                heading: "Продукт коргоосу",
                                text: "Өндүрүүчүнүн кепилдиги аяктагандан кийин кадимки эскирүүдөн жана кемчиликтерден улам иштен чыгуудан."
                            },
                            carbonOffsets: {
                                heading: "Көмүртек нейтралдуу жеткирүү",
                                text: "Биз бул жөнөтүүнүн CO2 чыгарындыларын компенсациялайбыз."
                            },
                            productGuarantees: {
                                heading: "Канааттануу кепилдиги",
                                text: "{{days}} күндүн ичинде сапат көйгөйлөрү болсо, биз аны оңдойбуз."
                            },
                            returnsAndExchanges: {
                                heading: "Бекер кайтаруу жана алмаштыруу",
                                text: "Кайтаруу жана алмаштыруу үчүн бардык АКШ буйруктарына бекер кайтаруу жеткирүүсү."
                            },
                            freeReturns: {
                                heading: "Бекер кайтаруу",
                                text: "Бардык АКШ буйруктарына бекер кайтаруу жеткирүүсү."
                            },
                            subscriptions: {
                                text: "Жазылуу буйруктары үчүн Onward Package Protection ар бир кайталануучу буйрукка кошулат жана каалаган убакта жокко чыгарылышы мүмкүн."
                            },
                            prioritySupport: {
                                heading: "Артыкчылыктуу колдоо",
                                text: "Кезекти өткөрүп жиберип, тездетилген кардар колдоосун алыңыз."
                            }
                        }
                    },
                    lo: {
                        modal: {
                            headline: "ສໍາຜັດການປົກປ້ອງ VIP ແລະ ຄວາມພໍໃຈທີ່ຮັບປະກັນດ້ວຍ Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*ລະຫັດລາງວັນຈະຖືກສົ່ງທາງອີເມວ 30 ມື້ຫຼັງຈາກການຊື້."
                            },
                            rewards: {
                                heading: "ຮັບ {{rewardsPercentage}}% CashBack",
                                text: "ຮັບ {{rewardsPercentage}}% ກັບຄືນເປັນເຄຣດິດຮ້ານອອນໄລນ໌ເພື່ອໃຊ້ສໍາລັບການຊື້ໃນອະນາຄົດ.*"
                            },
                            protect: {
                                heading: "ການປົກປ້ອງການຂົນສົ່ງ",
                                text: "ຈາກການລັກ, ການສູນເສຍ, ຄວາມເສຍຫາຍ, ແລະອື່ນໆ — Onward ປົກປ້ອງທ່ານ."
                            },
                            extendedWarranties: {
                                heading: "ການປົກປ້ອງຜະລິດຕະພັນ",
                                text: "ຈາກຄວາມລົ້ມເຫຼວເນື່ອງຈາກການສຶກຫຼໍ່ປົກກະຕິ ແລະ ຂໍ້ບົກພ່ອງຫຼັງຈາກການຮັບປະກັນຂອງຜູ້ຜະລິດໝົດອາຍຸ."
                            },
                            carbonOffsets: {
                                heading: "ການຂົນສົ່ງທີ່ເປັນກາງຄາບອນ",
                                text: "ພວກເຮົາຈະຊົດເຊີຍການປ່ອຍ CO2 ຂອງການຂົນສົ່ງນີ້."
                            },
                            productGuarantees: {
                                heading: "ການຮັບປະກັນຄວາມພໍໃຈ",
                                text: "ຖ້າທ່ານມີບັນຫາຄຸນນະພາບພາຍໃນ {{days}} ມື້, ພວກເຮົາຈະແກ້ໄຂມັນ."
                            },
                            returnsAndExchanges: {
                                heading: "ການສົ່ງຄືນ ແລະ ການແລກປ່ຽນຟຣີ",
                                text: "ການຂົນສົ່ງຄືນຟຣີສໍາລັບຄໍາສັ່ງຊື້ອາເມລິກາທັງໝົດ ສໍາລັບການສົ່ງຄືນ ແລະ ການແລກປ່ຽນ."
                            },
                            freeReturns: {
                                heading: "ການສົ່ງຄືນຟຣີ",
                                text: "ການຂົນສົ່ງຄືນຟຣີສໍາລັບຄໍາສັ່ງຊື້ອາເມລິກາທັງໝົດ."
                            },
                            subscriptions: {
                                text: "ສໍາລັບຄໍາສັ່ງຊື້ການສະໝັກສະມາຊິກ, Onward Package Protection ຈະຖືກເພີ່ມໃສ່ທຸກໆຄໍາສັ່ງຊື້ທີ່ເກີດຂຶ້ນຊ້ໍາໆ ແລະ ສາມາດຍົກເລີກໄດ້ທຸກເວລາ."
                            },
                            prioritySupport: {
                                heading: "ການສະໜັບສະໜູນບຸລິມະສິດ",
                                text: "ຂ້າມແຖວ ແລະ ຮັບການສະໜັບສະໜູນລູກຄ້າທີ່ໄວ."
                            }
                        }
                    },
                    lt: {
                        modal: {
                            headline: "Patirkite VIP apsaugą ir garantuotą pasitenkinimą su Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Atlygio kodas bus išsiųstas el. paštu praėjus 30 dienų nuo pirkimo."
                            },
                            rewards: {
                                heading: "Uždirbkite {{rewardsPercentage}}% CashBack",
                                text: "Gaukite {{rewardsPercentage}}% atgal kaip internetinės parduotuvės kreditą būsimiems pirkiniams.*"
                            },
                            protect: {
                                heading: "Siuntimo Apsauga",
                                text: "Nuo vagystės, praradimo, žalos ir daugiau — Onward jus apsaugo."
                            },
                            extendedWarranties: {
                                heading: "Produkto Apsauga",
                                text: "Nuo gedimų dėl normalaus nusidėvėjimo ir defektų pasibaigus gamintojo garantijai."
                            },
                            carbonOffsets: {
                                heading: "Anglies Neutralus Siuntimas",
                                text: "Kompensuosime šio siuntinio CO2 išmetimus."
                            },
                            productGuarantees: {
                                heading: "Pasitenkinimo Garantija",
                                text: "Jei per {{days}} dienų turėsite kokybės problemų, mes tai sutvarkysime."
                            },
                            returnsAndExchanges: {
                                heading: "Nemokamas Grąžinimas ir Keitimas",
                                text: "Nemokamas grąžinimo siuntimas visiems JAV užsakymams grąžinimui ir keitimui."
                            },
                            freeReturns: {
                                heading: "Nemokamas Grąžinimas",
                                text: "Nemokamas grąžinimo siuntimas visiems JAV užsakymams."
                            },
                            subscriptions: {
                                text: "Prenumeratos užsakymams Onward Package Protection bus pridėta prie kiekvieno pasikartojančio užsakymo ir gali būti atšaukta bet kuriuo metu."
                            },
                            prioritySupport: {
                                heading: "Prioritetinis Palaikymas",
                                text: "Praleiskite eilę ir gaukite pagreitintą klientų aptarnavimą."
                            }
                        }
                    },
                    lv: {
                        modal: {
                            headline: "Izbaudiet VIP aizsardzību un garantētu apmierinātību ar Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Atlīdzības kods tiks nosūtīts pa e-pastu 30 dienas pēc pirkuma."
                            },
                            rewards: {
                                heading: "Nopelniet {{rewardsPercentage}}% CashBack",
                                text: "Saņemiet {{rewardsPercentage}}% atpakaļ kā tiešsaistes veikala kredītu turpmākajiem pirkumiem.*"
                            },
                            protect: {
                                heading: "Piegādes Aizsardzība",
                                text: "No zādzības, pazušanas, bojājumiem un vairāk — Onward jūs aizsargā."
                            },
                            extendedWarranties: {
                                heading: "Produkta Aizsardzība",
                                text: "No bojājumiem normāla nolietojuma un defektu dēļ pēc ražotāja garantijas beigām."
                            },
                            carbonOffsets: {
                                heading: "Oglekļa Neitrāla Piegāde",
                                text: "Mēs kompensēsim šī sūtījuma CO2 emisijas."
                            },
                            productGuarantees: {
                                heading: "Apmierinātības Garantija",
                                text: "Ja jums ir kādas kvalitātes problēmas {{days}} dienu laikā, mēs to izlabosim."
                            },
                            returnsAndExchanges: {
                                heading: "Bezmaksas Atgriešana un Apmaiņa",
                                text: "Bezmaksas atgriešanas piegāde visiem ASV pasūtījumiem atgriešanai un apmaiņai."
                            },
                            freeReturns: {
                                heading: "Bezmaksas Atgriešana",
                                text: "Bezmaksas atgriešanas piegāde visiem ASV pasūtījumiem."
                            },
                            subscriptions: {
                                text: "Abonēšanas pasūtījumiem Onward Package Protection tiks pievienota katram atkārtotam pasūtījumam un var tikt atcelta jebkurā laikā."
                            },
                            prioritySupport: {
                                heading: "Prioritārais Atbalsts",
                                text: "Izlaidiet rindu un saņemiet paātrinātu klientu atbalstu."
                            }
                        }
                    },
                    mi: {
                        modal: {
                            headline: "Wheako te tiaki VIP me te ngākau pai kua whakatauhia me Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Ka tukuna te waehere utu mā te īmēra i muri i te 30 rā mai i te hoko."
                            },
                            rewards: {
                                heading: "Whiwhia {{rewardsPercentage}}% CashBack",
                                text: "Whiwhia {{rewardsPercentage}}% hei nama toa ipurangi mō ngā hoko ā muri ake.*"
                            },
                            protect: {
                                heading: "Tiaki Tuku",
                                text: "Mai i te tahae, te ngaro, te pakaru, me ētahi atu — ka tiakina koe e Onward."
                            },
                            extendedWarranties: {
                                heading: "Tiaki Hua",
                                text: "Mai i te hapa nā te paunga noa me ngā hapa i muri i te mutunga o te tiwhikete a te kaihanga."
                            },
                            carbonOffsets: {
                                heading: "Tuku Waro-kore",
                                text: "Ka utu mātou i ngā tukunga CO2 o tēnei kawenga."
                            },
                            productGuarantees: {
                                heading: "Tiwhikete Ngākau Pai",
                                text: "Mēnā he raruraru kounga i roto i ngā rā {{days}}, ka whakatikahia e mātou."
                            },
                            returnsAndExchanges: {
                                heading: "Whakahoki me ngā Whakawhiti Kore Utu",
                                text: "Tuku whakahoki kore utu mō ngā ōta US katoa mō ngā whakahoki me ngā whakawhiti."
                            },
                            freeReturns: {
                                heading: "Whakahoki Kore Utu",
                                text: "Tuku whakahoki kore utu mō ngā ōta US katoa."
                            },
                            subscriptions: {
                                text: "Mō ngā ōta ohaurunga, ka tāpiritia te Onward Package Protection ki ia ōta tuarua ā ka taea te whakakore i ngā wā katoa."
                            },
                            prioritySupport: {
                                heading: "Tautoko Tuatahi",
                                text: "Pekehia te rārangi me te whiwhi tautoko kiritaki tere."
                            }
                        }
                    },
                    mk: {
                        modal: {
                            headline: "Искусете VIP заштита и гарантирано задоволство со Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Кодот за награда ќе биде испратен по е-пошта 30 дена по купувањето."
                            },
                            rewards: {
                                heading: "Заработете {{rewardsPercentage}}% CashBack",
                                text: "Добијте {{rewardsPercentage}}% назад како кредит во онлајн продавница за идни купувања.*"
                            },
                            protect: {
                                heading: "Заштита на Испорака",
                                text: "Од кражба, загуба, оштетување и повеќе — Onward ве покрива."
                            },
                            extendedWarranties: {
                                heading: "Заштита на Производ",
                                text: "Од дефект поради нормална употреба и недостатоци по истекот на гаранцијата на производителот."
                            },
                            carbonOffsets: {
                                heading: "Јаглеродно Неутрална Испорака",
                                text: "Ќе ги компензираме CO2 емисиите на оваа пратка."
                            },
                            productGuarantees: {
                                heading: "Гаранција за Задоволство",
                                text: "Ако имате проблеми со квалитетот во рок од {{days}} дена, ќе го поправиме."
                            },
                            returnsAndExchanges: {
                                heading: "Бесплатни Враќања и Замени",
                                text: "Бесплатна испорака за враќање на сите нарачки од САД за враќања и замени."
                            },
                            freeReturns: {
                                heading: "Бесплатни Враќања",
                                text: "Бесплатна испорака за враќање на сите нарачки од САД."
                            },
                            subscriptions: {
                                text: "За нарачки со претплата, Onward Package Protection ќе биде додадена на секоја повторувачка нарачка и може да се откаже во секое време."
                            },
                            prioritySupport: {
                                heading: "Приоритетна Поддршка",
                                text: "Прескокнете ја редицата и добијте забрзана корисничка поддршка."
                            }
                        }
                    },
                    ml: {
                        modal: {
                            headline: "Onward VIP Protection ഉപയോഗിച്ച് VIP സംരക്ഷണവും ഉറപ്പായ സംതൃപ്തിയും അനുഭവിക്കുക.",
                            rewardsDisclaimer: {
                                text: "*റിവാർഡ് കോഡ് വാങ്ങലിന് 30 ദിവസത്തിന് ശേഷം ഇമെയിൽ ചെയ്യും."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% ക്യാഷ്‌ബാക്ക് നേടുക",
                                text: "ഭാവി വാങ്ങലുകൾക്കായി ഓൺലൈൻ സ്റ്റോർ ക്രെഡിറ്റായി {{rewardsPercentage}}% തിരികെ നേടുക.*"
                            },
                            protect: {
                                heading: "ഷിപ്പിംഗ് സംരക്ഷണം",
                                text: "മോഷണം, നഷ്ടം, കേടുപാട് എന്നിവയിൽ നിന്നും കൂടുതലിൽ നിന്നും — Onward നിങ്ങളെ സംരക്ഷിക്കുന്നു."
                            },
                            extendedWarranties: {
                                heading: "ഉൽപ്പന്ന സംരക്ഷണം",
                                text: "നിർമ്മാതാവിന്റെ വാറണ്ടി കാലാവധി കഴിഞ്ഞതിന് ശേഷം സാധാരണ തേയ്മാനവും കുറവുകളും മൂലമുള്ള പരാജയത്തിൽ നിന്ന്."
                            },
                            carbonOffsets: {
                                heading: "കാർബൺ ന്യൂട്രൽ ഷിപ്പിംഗ്",
                                text: "ഈ ഷിപ്മെന്റിന്റെ CO2 ഉദ്‌വമനം ഞങ്ങൾ ഓഫ്‌സെറ്റ് ചെയ്യും."
                            },
                            productGuarantees: {
                                heading: "സംതൃപ്തി ഗ്യാരണ്ടി",
                                text: "{{days}} ദിവസത്തിനുള്ളിൽ നിങ്ങൾക്ക് ഗുണനിലവാര പ്രശ്‌നങ്ങളുണ്ടെങ്കിൽ, ഞങ്ങൾ അത് ശരിയാക്കും."
                            },
                            returnsAndExchanges: {
                                heading: "സൗജന്യ റിട്ടേണുകളും എക്സ്ചേഞ്ചുകളും",
                                text: "റിട്ടേണുകൾക്കും എക്സ്ചേഞ്ചുകൾക്കുമായി എല്ലാ US ഓർഡറുകളിലും സൗജന്യ റിട്ടേൺ ഷിപ്പിംഗ്."
                            },
                            freeReturns: {
                                heading: "സൗജന്യ റിട്ടേണുകൾ",
                                text: "എല്ലാ US ഓർഡറുകളിലും സൗജന്യ റിട്ടേൺ ഷിപ്പിംഗ്."
                            },
                            subscriptions: {
                                text: "സബ്‌സ്‌ക്രിപ്ഷൻ ഓർഡറുകൾക്ക്, Onward Package Protection ഓരോ ആവർത്തിച്ചുള്ള ഓർഡറിലും ചേർക്കും, ഏത് സമയത്തും റദ്ദാക്കാവുന്നതാണ്."
                            },
                            prioritySupport: {
                                heading: "മുൻഗണനാ പിന്തുണ",
                                text: "ക്യൂ ഒഴിവാക്കി വേഗത്തിലുള്ള ഉപഭോക്തൃ പിന്തുണ നേടുക."
                            }
                        }
                    },
                    mn: {
                        modal: {
                            headline: "Onward VIP Protection-тай VIP хамгаалалт болон баталгаат сэтгэл ханамжийг мэдрээрэй.",
                            rewardsDisclaimer: {
                                text: "*Шагналын код худалдан авалтаас 30 хоногийн дараа имэйлээр илгээгдэнэ."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% CashBack ав",
                                text: "Ирээдүйн худалдан авалтад ашиглах онлайн дэлгүүрийн кредит болгон {{rewardsPercentage}}% буцаан аваарай.*"
                            },
                            protect: {
                                heading: "Хүргэлтийн Хамгаалалт",
                                text: "Хулгай, алдагдал, гэмтлээс болон бусдаас — Onward таныг хамгаална."
                            },
                            extendedWarranties: {
                                heading: "Бүтээгдэхүүний Хамгаалалт",
                                text: "Үйлдвэрлэгчийн баталгаа дууссаны дараа хэвийн элэгдэл болон гэмтлээс үүссэн эвдрэлээс."
                            },
                            carbonOffsets: {
                                heading: "Нүүрстөрөгчийн Саармаг Хүргэлт",
                                text: "Бид энэ ачааны CO2 ялгарлыг нөхөн төлнө."
                            },
                            productGuarantees: {
                                heading: "Сэтгэл Ханамжийн Баталгаа",
                                text: "{{days}} хоногийн дотор чанарын асуудал гарвал бид засна."
                            },
                            returnsAndExchanges: {
                                heading: "Үнэгүй Буцаалт ба Солилцоо",
                                text: "Буцаалт ба солилцоонд зориулж бүх АНУ-ын захиалгад үнэгүй буцаалтын хүргэлт."
                            },
                            freeReturns: {
                                heading: "Үнэгүй Буцаалт",
                                text: "Бүх АНУ-ын захиалгад үнэгүй буцаалтын хүргэлт."
                            },
                            subscriptions: {
                                text: "Захиалгын захиалгуудын хувьд Onward Package Protection давтагдах захиалга бүрт нэмэгдэх бөгөөд хүссэн үедээ цуцлах боломжтой."
                            },
                            prioritySupport: {
                                heading: "Тэргүүлэх Дэмжлэг",
                                text: "Дарааллаас алгасаж, хурдан хэрэглэгчийн дэмжлэг аваарай."
                            }
                        }
                    },
                    ms: {
                        modal: {
                            headline: "Alami perlindungan VIP dan kepuasan terjamin dengan Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Kod ganjaran akan dihantar melalui e-mel 30 hari selepas pembelian."
                            },
                            rewards: {
                                heading: "Dapatkan {{rewardsPercentage}}% CashBack",
                                text: "Dapatkan kembali {{rewardsPercentage}}% sebagai kredit kedai dalam talian untuk pembelian masa hadapan.*"
                            },
                            protect: {
                                heading: "Perlindungan Penghantaran",
                                text: "Daripada kecurian, kehilangan, kerosakan dan banyak lagi — Onward melindungi anda."
                            },
                            extendedWarranties: {
                                heading: "Perlindungan Produk",
                                text: "Daripada kegagalan akibat haus dan lusuh biasa serta kecacatan selepas waranti pengeluar tamat."
                            },
                            carbonOffsets: {
                                heading: "Penghantaran Neutral Karbon",
                                text: "Kami akan mengimbangi pelepasan CO2 penghantaran ini."
                            },
                            productGuarantees: {
                                heading: "Jaminan Kepuasan",
                                text: "Jika anda mempunyai masalah kualiti dalam {{days}} hari, kami akan membetulkannya."
                            },
                            returnsAndExchanges: {
                                heading: "Pemulangan dan Pertukaran Percuma",
                                text: "Penghantaran pemulangan percuma untuk semua pesanan AS untuk pemulangan dan pertukaran."
                            },
                            freeReturns: {
                                heading: "Pemulangan Percuma",
                                text: "Penghantaran pemulangan percuma untuk semua pesanan AS."
                            },
                            subscriptions: {
                                text: "Untuk pesanan langganan, Onward Package Protection akan ditambah ke setiap pesanan berulang dan boleh dibatalkan pada bila-bila masa."
                            },
                            prioritySupport: {
                                heading: "Sokongan Keutamaan",
                                text: "Langkau barisan dan dapatkan sokongan pelanggan yang dipercepatkan."
                            }
                        }
                    },
                    mt: {
                        modal: {
                            headline: "Esperjenza l-protezzjoni VIP u sodisfazzjon garantit ma' Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Il-kodiċi tal-premju se jintbagħat bl-email 30 jum wara x-xiri."
                            },
                            rewards: {
                                heading: "Ikseb {{rewardsPercentage}}% CashBack",
                                text: "Ikseb {{rewardsPercentage}}% lura bħala kreditu tal-ħanut online għax-xirjiet futuri.*"
                            },
                            protect: {
                                heading: "Protezzjoni tat-Tbaħħir",
                                text: "Mis-serq, telf, ħsara, u aktar — Onward jipproteġik."
                            },
                            extendedWarranties: {
                                heading: "Protezzjoni tal-Prodott",
                                text: "Minn falliment minħabba konsum normali u difetti wara li l-garanzija tal-manifattur tiskadi."
                            },
                            carbonOffsets: {
                                heading: "Tbaħħir Newtrali għall-Karbonju",
                                text: "Se nikkumpensaw l-emissjonijiet ta' CO2 ta' din il-konsenja."
                            },
                            productGuarantees: {
                                heading: "Garanzija ta' Sodisfazzjon",
                                text: "Jekk għandek xi problemi tal-kwalità fi żmien {{days}} jum, se nirranġawha."
                            },
                            returnsAndExchanges: {
                                heading: "Ritorn u Bdil B'xejn",
                                text: "Tbaħħir tar-ritorn b'xejn fuq l-ordnijiet kollha tal-US għar-ritorn u l-bdil."
                            },
                            freeReturns: {
                                heading: "Ritorn B'xejn",
                                text: "Tbaħħir tar-ritorn b'xejn fuq l-ordnijiet kollha tal-US."
                            },
                            subscriptions: {
                                text: "Għall-ordnijiet ta' abbonament, Onward Package Protection se tiżdied ma' kull ordni li tirrepeti u tista' tiġi kkanċellata fi kwalunkwe ħin."
                            },
                            prioritySupport: {
                                heading: "Appoġġ ta' Prijorità",
                                text: "Aqbeż il-kju u ikseb appoġġ tal-klijent mgħaġġel."
                            }
                        }
                    },
                    my: {
                        modal: {
                            headline: "Onward VIP Protection ဖြင့် VIP အကာအကွယ်နှင့် အာမခံချက်ပေးသော စိတ်ကျေနပ်မှုကို ခံစားပါ။",
                            rewardsDisclaimer: {
                                text: "*ဆုလက်ဆောင်ကုဒ်ကို ဝယ်ယူပြီး ရက် ၃၀ အကြာတွင် အီးမေးလ်ပို့ပေးပါမည်။"
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% CashBack ရယူပါ",
                                text: "နောင်ဝယ်ယူမှုများအတွက် အွန်လိုင်းစတိုးခရက်ဒစ်အဖြစ် {{rewardsPercentage}}% ပြန်ရယူပါ။*"
                            },
                            protect: {
                                heading: "ပို့ဆောင်ရေး အကာအကွယ်",
                                text: "ခိုးယူခြင်း၊ ပျောက်ဆုံးခြင်း၊ ပျက်စီးခြင်းနှင့် အခြားအရာများမှ — Onward က သင့်ကို ကာကွယ်ပေးသည်။"
                            },
                            extendedWarranties: {
                                heading: "ထုတ်ကုန် အကာအကွယ်",
                                text: "ထုတ်လုပ်သူ အာမခံ ကုန်ဆုံးပြီးနောက် ပုံမှန်ဟောင်းနွမ်းမှုနှင့် ချို့ယွင်းချက်များကြောင့် ပျက်ကွက်ခြင်းမှ။"
                            },
                            carbonOffsets: {
                                heading: "ကာဗွန်ကြားနေ ပို့ဆောင်ရေး",
                                text: "ဤတင်ပို့မှု၏ CO2 ထုတ်လွှတ်မှုကို ကျွန်ုပ်တို့ ပြန်လည်ဖြည့်ဆည်းပေးပါမည်။"
                            },
                            productGuarantees: {
                                heading: "စိတ်ကျေနပ်မှု အာမခံ",
                                text: "ရက် {{days}} အတွင်း အရည်အသွေးပြဿနာများရှိပါက ကျွန်ုပ်တို့ ပြုပြင်ပေးပါမည်။"
                            },
                            returnsAndExchanges: {
                                heading: "အခမဲ့ ပြန်ပို့ခြင်းနှင့် လဲလှယ်ခြင်း",
                                text: "ပြန်ပို့ခြင်းနှင့် လဲလှယ်ခြင်းအတွက် US အမှာစာအားလုံးတွင် အခမဲ့ ပြန်ပို့ခြင်း။"
                            },
                            freeReturns: {
                                heading: "အခမဲ့ ပြန်ပို့ခြင်း",
                                text: "US အမှာစာအားလုံးတွင် အခမဲ့ ပြန်ပို့ခြင်း။"
                            },
                            subscriptions: {
                                text: "စာရင်းသွင်း အမှာစာများအတွက်၊ Onward Package Protection ကို ထပ်ခါထပ်ခါ အမှာစာတိုင်းတွင် ထည့်သွင်းမည်ဖြစ်ပြီး အချိန်မရွေး ပယ်ဖျက်နိုင်သည်။"
                            },
                            prioritySupport: {
                                heading: "ဦးစားပေး ပံ့ပိုးမှု",
                                text: "တန်းစီခြင်းကို ကျော်ပြီး မြန်ဆန်သော ဖောက်သည်ပံ့ပိုးမှု ရယူပါ။"
                            }
                        }
                    },
                    ne: {
                        modal: {
                            headline: "Onward VIP Protection सँग VIP सुरक्षा र ग्यारेन्टी गरिएको सन्तुष्टि अनुभव गर्नुहोस्।",
                            rewardsDisclaimer: {
                                text: "*पुरस्कार कोड खरिदको 30 दिन पछि इमेल गरिनेछ।"
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% क्यासब्याक कमाउनुहोस्",
                                text: "भविष्यको खरिदहरूको लागि अनलाइन स्टोर क्रेडिटको रूपमा {{rewardsPercentage}}% फिर्ता पाउनुहोस्।*"
                            },
                            protect: {
                                heading: "शिपिङ सुरक्षा",
                                text: "चोरी, हराउने, क्षति र अरूबाट — Onward ले तपाईंलाई कभर गर्छ।"
                            },
                            extendedWarranties: {
                                heading: "उत्पादन सुरक्षा",
                                text: "निर्माताको वारेन्टी समाप्त भएपछि सामान्य पहिरन र दोषहरूको कारण विफलताबाट।"
                            },
                            carbonOffsets: {
                                heading: "कार्बन न्यूट्रल शिपिङ",
                                text: "हामी यस शिपमेन्टको CO2 उत्सर्जन अफसेट गर्नेछौं।"
                            },
                            productGuarantees: {
                                heading: "सन्तुष्टि ग्यारेन्टी",
                                text: "यदि तपाईंलाई {{days}} दिनभित्र कुनै गुणस्तर समस्या छ भने, हामी यसलाई ठीक गर्नेछौं।"
                            },
                            returnsAndExchanges: {
                                heading: "निःशुल्क फिर्ता र एक्सचेन्ज",
                                text: "फिर्ता र एक्सचेन्जको लागि सबै US अर्डरहरूमा निःशुल्क फिर्ता शिपिङ।"
                            },
                            freeReturns: {
                                heading: "निःशुल्क फिर्ता",
                                text: "सबै US अर्डरहरूमा निःशुल्क फिर्ता शिपिङ।"
                            },
                            subscriptions: {
                                text: "सदस्यता अर्डरहरूको लागि, Onward Package Protection प्रत्येक दोहोरिने अर्डरमा थपिनेछ र कुनै पनि समयमा रद्द गर्न सकिन्छ।"
                            },
                            prioritySupport: {
                                heading: "प्राथमिकता समर्थन",
                                text: "लाइन छोड्नुहोस् र छिटो ग्राहक समर्थन प्राप्त गर्नुहोस्।"
                            }
                        }
                    },
                    nl: {
                        modal: {
                            headline: "Ervaar VIP-bescherming en gegarandeerde tevredenheid met Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*De beloningscode wordt 30 dagen na aankoop per e-mail verzonden."
                            },
                            rewards: {
                                heading: "Verdien {{rewardsPercentage}}% CashBack",
                                text: "Krijg {{rewardsPercentage}}% terug als online winkelkrediet voor toekomstige aankopen.*"
                            },
                            protect: {
                                heading: "Verzendbescherming",
                                text: "Tegen diefstal, verlies, schade en meer — Onward beschermt je."
                            },
                            extendedWarranties: {
                                heading: "Productbescherming",
                                text: "Tegen defecten door normale slijtage en gebreken na het verstrijken van de fabrieksgarantie."
                            },
                            carbonOffsets: {
                                heading: "Koolstofneutrale Verzending",
                                text: "We compenseren de CO2-uitstoot van deze zending."
                            },
                            productGuarantees: {
                                heading: "Tevredenheidsgarantie",
                                text: "Als je kwaliteitsproblemen hebt binnen {{days}} dagen, lossen we het op."
                            },
                            returnsAndExchanges: {
                                heading: "Gratis Retourneren en Omruilen",
                                text: "Gratis retourverzending op alle Amerikaanse bestellingen voor retourneren en omruilen."
                            },
                            freeReturns: {
                                heading: "Gratis Retourneren",
                                text: "Gratis retourverzending op alle Amerikaanse bestellingen."
                            },
                            subscriptions: {
                                text: "Voor abonnementsbestellingen wordt Onward Package Protection aan elke terugkerende bestelling toegevoegd en kan op elk moment worden geannuleerd."
                            },
                            prioritySupport: {
                                heading: "Prioritaire Ondersteuning",
                                text: "Sla de wachtrij over en krijg versnelde klantenondersteuning."
                            }
                        }
                    },
                    no: {
                        modal: {
                            headline: "Opplev VIP-beskyttelse og garantert tilfredshet med Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Belønningskoden sendes på e-post 30 dager etter kjøpet."
                            },
                            rewards: {
                                heading: "Tjen {{rewardsPercentage}}% CashBack",
                                text: "Få {{rewardsPercentage}}% tilbake som nettbutikkkreditt for fremtidige kjøp.*"
                            },
                            protect: {
                                heading: "Fraktbeskyttelse",
                                text: "Mot tyveri, tap, skade og mer — Onward dekker deg."
                            },
                            extendedWarranties: {
                                heading: "Produktbeskyttelse",
                                text: "Mot feil på grunn av normal slitasje og defekter etter at produsentens garanti utløper."
                            },
                            carbonOffsets: {
                                heading: "Karbonnøytral Frakt",
                                text: "Vi kompenserer for CO2-utslippene fra denne forsendelsen."
                            },
                            productGuarantees: {
                                heading: "Tilfredshetgaranti",
                                text: "Hvis du har kvalitetsproblemer innen {{days}} dager, ordner vi det."
                            },
                            returnsAndExchanges: {
                                heading: "Gratis Returer og Bytter",
                                text: "Gratis returfrakt på alle amerikanske bestillinger for returer og bytter."
                            },
                            freeReturns: {
                                heading: "Gratis Returer",
                                text: "Gratis returfrakt på alle amerikanske bestillinger."
                            },
                            subscriptions: {
                                text: "For abonnementsbestillinger vil Onward Package Protection legges til hver gjentagende bestilling og kan kanselleres når som helst."
                            },
                            prioritySupport: {
                                heading: "Prioritert Støtte",
                                text: "Hopp over køen og få rask kundestøtte."
                            }
                        }
                    },
                    pa: {
                        modal: {
                            headline: "Onward VIP Protection ਨਾਲ VIP ਸੁਰੱਖਿਆ ਅਤੇ ਗਰੰਟੀਸ਼ੁਦਾ ਸੰਤੁਸ਼ਟੀ ਦਾ ਅਨੁਭਵ ਕਰੋ।",
                            rewardsDisclaimer: {
                                text: "*ਇਨਾਮ ਕੋਡ ਖਰੀਦ ਤੋਂ 30 ਦਿਨਾਂ ਬਾਅਦ ਈਮੇਲ ਕੀਤਾ ਜਾਵੇਗਾ।"
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% ਕੈਸ਼ਬੈਕ ਕਮਾਓ",
                                text: "ਭਵਿੱਖ ਦੀਆਂ ਖਰੀਦਾਂ ਲਈ ਔਨਲਾਈਨ ਸਟੋਰ ਕ੍ਰੈਡਿਟ ਵਜੋਂ {{rewardsPercentage}}% ਵਾਪਸ ਪ੍ਰਾਪਤ ਕਰੋ।*"
                            },
                            protect: {
                                heading: "ਸ਼ਿਪਿੰਗ ਸੁਰੱਖਿਆ",
                                text: "ਚੋਰੀ, ਨੁਕਸਾਨ, ਨੁਕਸਾਨ ਅਤੇ ਹੋਰ ਤੋਂ — Onward ਤੁਹਾਨੂੰ ਕਵਰ ਕਰਦਾ ਹੈ।"
                            },
                            extendedWarranties: {
                                heading: "ਉਤਪਾਦ ਸੁਰੱਖਿਆ",
                                text: "ਨਿਰਮਾਤਾ ਦੀ ਵਾਰੰਟੀ ਖਤਮ ਹੋਣ ਤੋਂ ਬਾਅਦ ਆਮ ਖਰਾਬੀ ਅਤੇ ਨੁਕਸ ਕਾਰਨ ਅਸਫਲਤਾ ਤੋਂ।"
                            },
                            carbonOffsets: {
                                heading: "ਕਾਰਬਨ ਨਿਊਟਰਲ ਸ਼ਿਪਿੰਗ",
                                text: "ਅਸੀਂ ਇਸ ਸ਼ਿਪਮੈਂਟ ਦੇ CO2 ਨਿਕਾਸ ਨੂੰ ਆਫਸੈੱਟ ਕਰਾਂਗੇ।"
                            },
                            productGuarantees: {
                                heading: "ਸੰਤੁਸ਼ਟੀ ਗਰੰਟੀ",
                                text: "ਜੇਕਰ ਤੁਹਾਨੂੰ {{days}} ਦਿਨਾਂ ਦੇ ਅੰਦਰ ਕੋਈ ਗੁਣਵੱਤਾ ਸਮੱਸਿਆ ਹੈ, ਅਸੀਂ ਇਸਨੂੰ ਠੀਕ ਕਰਾਂਗੇ।"
                            },
                            returnsAndExchanges: {
                                heading: "ਮੁਫ਼ਤ ਵਾਪਸੀ ਅਤੇ ਬਦਲਾਅ",
                                text: "ਵਾਪਸੀ ਅਤੇ ਬਦਲਾਅ ਲਈ ਸਾਰੇ US ਆਰਡਰਾਂ 'ਤੇ ਮੁਫ਼ਤ ਵਾਪਸੀ ਸ਼ਿਪਿੰਗ।"
                            },
                            freeReturns: {
                                heading: "ਮੁਫ਼ਤ ਵਾਪਸੀ",
                                text: "ਸਾਰੇ US ਆਰਡਰਾਂ 'ਤੇ ਮੁਫ਼ਤ ਵਾਪਸੀ ਸ਼ਿਪਿੰਗ।"
                            },
                            subscriptions: {
                                text: "ਸਬਸਕ੍ਰਿਪਸ਼ਨ ਆਰਡਰਾਂ ਲਈ, Onward Package Protection ਹਰੇਕ ਦੁਹਰਾਏ ਜਾਣ ਵਾਲੇ ਆਰਡਰ ਵਿੱਚ ਸ਼ਾਮਲ ਕੀਤੀ ਜਾਵੇਗੀ ਅਤੇ ਕਿਸੇ ਵੀ ਸਮੇਂ ਰੱਦ ਕੀਤੀ ਜਾ ਸਕਦੀ ਹੈ।"
                            },
                            prioritySupport: {
                                heading: "ਤਰਜੀਹੀ ਸਹਾਇਤਾ",
                                text: "ਲਾਈਨ ਛੱਡੋ ਅਤੇ ਤੇਜ਼ ਗਾਹਕ ਸਹਾਇਤਾ ਪ੍ਰਾਪਤ ਕਰੋ।"
                            }
                        }
                    },
                    pl: {
                        modal: {
                            headline: "Doświadcz ochrony VIP i gwarantowanej satysfakcji z Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Kod nagrody zostanie wysłany e-mailem 30 dni po zakupie."
                            },
                            rewards: {
                                heading: "Zdobądź {{rewardsPercentage}}% CashBack",
                                text: "Otrzymaj {{rewardsPercentage}}% z powrotem jako kredyt sklepu online na przyszłe zakupy.*"
                            },
                            protect: {
                                heading: "Ochrona Wysyłki",
                                text: "Od kradzieży, utraty, uszkodzenia i więcej — Onward cię chroni."
                            },
                            extendedWarranties: {
                                heading: "Ochrona Produktu",
                                text: "Od awarii z powodu normalnego zużycia i wad po wygaśnięciu gwarancji producenta."
                            },
                            carbonOffsets: {
                                heading: "Wysyłka Neutralna Węglowo",
                                text: "Skompensujemy emisję CO2 z tej przesyłki."
                            },
                            productGuarantees: {
                                heading: "Gwarancja Satysfakcji",
                                text: "Jeśli masz jakiekolwiek problemy z jakością w ciągu {{days}} dni, naprawimy to."
                            },
                            returnsAndExchanges: {
                                heading: "Darmowe Zwroty i Wymiany",
                                text: "Darmowa wysyłka zwrotna na wszystkie zamówienia z USA dla zwrotów i wymian."
                            },
                            freeReturns: {
                                heading: "Darmowe Zwroty",
                                text: "Darmowa wysyłka zwrotna na wszystkie zamówienia z USA."
                            },
                            subscriptions: {
                                text: "W przypadku zamówień subskrypcyjnych, Onward Package Protection zostanie dodana do każdego powtarzającego się zamówienia i może być anulowana w dowolnym momencie."
                            },
                            prioritySupport: {
                                heading: "Priorytetowe Wsparcie",
                                text: "Omiń kolejkę i uzyskaj przyspieszone wsparcie klienta."
                            }
                        }
                    },
                    ps: {
                        modal: {
                            headline: "د Onward VIP Protection سره VIP ساتنه او تضمین شوې رضایت تجربه کړئ.",
                            rewardsDisclaimer: {
                                text: "*د انعام کوډ به د پیرود څخه 30 ورځې وروسته بریښنالیک شي."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% کیش بیک ترلاسه کړئ",
                                text: "د راتلونکو پیرودونو لپاره د آنلاین پلورنځي کریډیټ په توګه {{rewardsPercentage}}% بیرته ترلاسه کړئ.*"
                            },
                            protect: {
                                heading: "د لیږد ساتنه",
                                text: "د غلا، ورکیدو، زیان او نورو څخه — Onward تاسو پوښي."
                            },
                            extendedWarranties: {
                                heading: "د محصول ساتنه",
                                text: "د تولیدونکي تضمین پای ته رسیدو وروسته د نورمال خرابیدو او نیمګړتیاوو له امله له ناکامۍ څخه."
                            },
                            carbonOffsets: {
                                heading: "کاربن بې طرفه لیږد",
                                text: "موږ به د دې بار د CO2 انتشار جبران کړو."
                            },
                            productGuarantees: {
                                heading: "د رضایت تضمین",
                                text: "که تاسو د {{days}} ورځو دننه د کیفیت ستونزې لرئ، موږ به یې سم کړو."
                            },
                            returnsAndExchanges: {
                                heading: "وړیا بیرته راستنیدل او تبادله",
                                text: "د بیرته راستنیدو او تبادلې لپاره په ټولو امریکایي امرونو کې وړیا بیرته راستنیدل."
                            },
                            freeReturns: {
                                heading: "وړیا بیرته راستنیدل",
                                text: "په ټولو امریکایي امرونو کې وړیا بیرته راستنیدل."
                            },
                            subscriptions: {
                                text: "د ګډون امرونو لپاره، Onward Package Protection به هر تکراري امر ته اضافه شي او هر وخت لغوه کیدی شي."
                            },
                            prioritySupport: {
                                heading: "لومړیتوب ملاتړ",
                                text: "کتار پریږدئ او ګړندۍ پیرودونکي ملاتړ ترلاسه کړئ."
                            }
                        }
                    },
                    pt: {
                        modal: {
                            headline: "Experimente proteção VIP e satisfação garantida com Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*O código de recompensa será enviado por e-mail 30 dias após a compra."
                            },
                            rewards: {
                                heading: "Ganhe {{rewardsPercentage}}% CashBack",
                                text: "Receba {{rewardsPercentage}}% de volta como crédito na loja online para compras futuras.*"
                            },
                            protect: {
                                heading: "Proteção de Envio",
                                text: "Contra roubo, perda, danos e mais — Onward protege você."
                            },
                            extendedWarranties: {
                                heading: "Proteção do Produto",
                                text: "Contra falhas por desgaste normal e defeitos após o término da garantia do fabricante."
                            },
                            carbonOffsets: {
                                heading: "Envio Carbono Neutro",
                                text: "Compensaremos as emissões de CO2 desta remessa."
                            },
                            productGuarantees: {
                                heading: "Garantia de Satisfação",
                                text: "Se você tiver problemas de qualidade em {{days}} dias, resolveremos."
                            },
                            returnsAndExchanges: {
                                heading: "Devoluções e Trocas Grátis",
                                text: "Frete de devolução grátis em todos os pedidos dos EUA para devoluções e trocas."
                            },
                            freeReturns: {
                                heading: "Devoluções Grátis",
                                text: "Frete de devolução grátis em todos os pedidos dos EUA."
                            },
                            subscriptions: {
                                text: "Para pedidos de assinatura, Onward Package Protection será adicionado a cada pedido recorrente e pode ser cancelado a qualquer momento."
                            },
                            prioritySupport: {
                                heading: "Suporte Prioritário",
                                text: "Pule a fila e obtenha suporte ao cliente acelerado."
                            }
                        }
                    },
                    "pt-BR": {
                        modal: {
                            headline: "Experimente proteção VIP e satisfação garantida com Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*O código de recompensa será enviado por e-mail 30 dias após a compra."
                            },
                            rewards: {
                                heading: "Ganhe {{rewardsPercentage}}% CashBack",
                                text: "Receba {{rewardsPercentage}}% de volta como crédito na loja online para compras futuras.*"
                            },
                            protect: {
                                heading: "Proteção de Envio",
                                text: "Contra roubo, perda, danos e mais — Onward protege você."
                            },
                            extendedWarranties: {
                                heading: "Proteção do Produto",
                                text: "Contra falhas por desgaste normal e defeitos após o término da garantia do fabricante."
                            },
                            carbonOffsets: {
                                heading: "Envio Carbono Neutro",
                                text: "Compensaremos as emissões de CO2 desta remessa."
                            },
                            productGuarantees: {
                                heading: "Garantia de Satisfação",
                                text: "Se você tiver problemas de qualidade em {{days}} dias, resolveremos."
                            },
                            returnsAndExchanges: {
                                heading: "Devoluções e Trocas Grátis",
                                text: "Frete de devolução grátis em todos os pedidos dos EUA para devoluções e trocas."
                            },
                            freeReturns: {
                                heading: "Devoluções Grátis",
                                text: "Frete de devolução grátis em todos os pedidos dos EUA."
                            },
                            subscriptions: {
                                text: "Para pedidos de assinatura, Onward Package Protection será adicionado a cada pedido recorrente e pode ser cancelado a qualquer momento."
                            },
                            prioritySupport: {
                                heading: "Suporte Prioritário",
                                text: "Pule a fila e obtenha suporte ao cliente acelerado."
                            }
                        }
                    },
                    ro: {
                        modal: {
                            headline: "Experimentează protecția VIP și satisfacția garantată cu Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Codul de recompensă va fi trimis prin e-mail la 30 de zile după achiziție."
                            },
                            rewards: {
                                heading: "Câștigă {{rewardsPercentage}}% CashBack",
                                text: "Primește {{rewardsPercentage}}% înapoi ca credit magazin online pentru achiziții viitoare.*"
                            },
                            protect: {
                                heading: "Protecția Livrării",
                                text: "Împotriva furtului, pierderii, deteriorării și mai mult — Onward te acoperă."
                            },
                            extendedWarranties: {
                                heading: "Protecția Produsului",
                                text: "Împotriva defecțiunilor din cauza uzurii normale și a defectelor după expirarea garanției producătorului."
                            },
                            carbonOffsets: {
                                heading: "Livrare Neutră în Carbon",
                                text: "Vom compensa emisiile de CO2 ale acestei expedieri."
                            },
                            productGuarantees: {
                                heading: "Garanția Satisfacției",
                                text: "Dacă ai probleme de calitate în {{days}} zile, vom rezolva."
                            },
                            returnsAndExchanges: {
                                heading: "Returnări și Schimburi Gratuite",
                                text: "Livrare returnare gratuită pentru toate comenzile din SUA pentru returnări și schimburi."
                            },
                            freeReturns: {
                                heading: "Returnări Gratuite",
                                text: "Livrare returnare gratuită pentru toate comenzile din SUA."
                            },
                            subscriptions: {
                                text: "Pentru comenzile cu abonament, Onward Package Protection va fi adăugată la fiecare comandă recurentă și poate fi anulată oricând."
                            },
                            prioritySupport: {
                                heading: "Suport Prioritar",
                                text: "Sari peste coadă și obține suport clienți accelerat."
                            }
                        }
                    },
                    ru: {
                        modal: {
                            headline: "Испытайте VIP-защиту и гарантированное удовлетворение с Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Код вознаграждения будет отправлен по электронной почте через 30 дней после покупки."
                            },
                            rewards: {
                                heading: "Зарабатывайте {{rewardsPercentage}}% CashBack",
                                text: "Получите {{rewardsPercentage}}% обратно в виде кредита интернет-магазина для будущих покупок.*"
                            },
                            protect: {
                                heading: "Защита Доставки",
                                text: "От кражи, потери, повреждения и многого другого — Onward защищает вас."
                            },
                            extendedWarranties: {
                                heading: "Защита Продукта",
                                text: "От поломки из-за нормального износа и дефектов после истечения гарантии производителя."
                            },
                            carbonOffsets: {
                                heading: "Углеродно-нейтральная Доставка",
                                text: "Мы компенсируем выбросы CO2 этой отправки."
                            },
                            productGuarantees: {
                                heading: "Гарантия Удовлетворения",
                                text: "Если у вас возникнут проблемы с качеством в течение {{days}} дней, мы всё исправим."
                            },
                            returnsAndExchanges: {
                                heading: "Бесплатные Возвраты и Обмены",
                                text: "Бесплатная обратная доставка для всех заказов из США для возвратов и обменов."
                            },
                            freeReturns: {
                                heading: "Бесплатные Возвраты",
                                text: "Бесплатная обратная доставка для всех заказов из США."
                            },
                            subscriptions: {
                                text: "Для подписочных заказов Onward Package Protection будет добавлена к каждому повторяющемуся заказу и может быть отменена в любое время."
                            },
                            prioritySupport: {
                                heading: "Приоритетная Поддержка",
                                text: "Пропустите очередь и получите ускоренную поддержку клиентов."
                            }
                        }
                    },
                    si: {
                        modal: {
                            headline: "Onward VIP Protection සමඟ VIP ආරක්ෂාව සහ සහතික කළ තෘප්තිය අත්විඳින්න.",
                            rewardsDisclaimer: {
                                text: "*ත්‍යාග කේතය මිලදී ගැනීමෙන් දින 30කට පසුව ඊමේල් කරනු ලැබේ."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% CashBack උපයන්න",
                                text: "අනාගත මිලදී ගැනීම් සඳහා ඔන්ලයින් ස්ටෝර් ක්‍රෙඩිට් ලෙස {{rewardsPercentage}}% ආපසු ලබා ගන්න.*"
                            },
                            protect: {
                                heading: "ප්‍රවාහන ආරක්ෂාව",
                                text: "සොරකම, අහිමිවීම, හානිය සහ තවත් බොහෝ දේවලින් — Onward ඔබව ආවරණය කරයි."
                            },
                            extendedWarranties: {
                                heading: "නිෂ්පාදන ආරක්ෂාව",
                                text: "නිෂ්පාදකයාගේ වගකීම් කාලය අවසන් වූ පසු සාමාන්‍ය ඇඳුම් පැළඳුම් සහ දෝෂ නිසා ඇති වන අසමත්වීමෙන්."
                            },
                            carbonOffsets: {
                                heading: "කාබන් උදාසීන ප්‍රවාහනය",
                                text: "අපි මෙම නැව්ගත කිරීමේ CO2 විමෝචනය හරස් කරන්නෙමු."
                            },
                            productGuarantees: {
                                heading: "තෘප්තිය සහතිකය",
                                text: "දින {{days}} ඇතුළත ඔබට ගුණාත්මක ගැටළු තිබේ නම්, අපි එය නිවැරදි කරන්නෙමු."
                            },
                            returnsAndExchanges: {
                                heading: "නොමිලේ ආපසු සහ හුවමාරු",
                                text: "ආපසු සහ හුවමාරු සඳහා සියලුම US ඇණවුම් සඳහා නොමිලේ ආපසු ප්‍රවාහනය."
                            },
                            freeReturns: {
                                heading: "නොමිලේ ආපසු",
                                text: "සියලුම US ඇණවුම් සඳහා නොමිලේ ආපසු ප්‍රවාහනය."
                            },
                            subscriptions: {
                                text: "දායක ඇණවුම් සඳහා, Onward Package Protection සෑම පුනරාවර්තන ඇණවුමකටම එකතු කරනු ඇති අතර ඕනෑම වේලාවක අවලංගු කළ හැකිය."
                            },
                            prioritySupport: {
                                heading: "ප්‍රමුඛතා සහාය",
                                text: "පෝලිම මඟ හැර වේගවත් පාරිභෝගික සහාය ලබා ගන්න."
                            }
                        }
                    },
                    sk: {
                        modal: {
                            headline: "Zažite VIP ochranu a zaručenú spokojnosť s Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Kód odmeny bude zaslaný e-mailom 30 dní po nákupe."
                            },
                            rewards: {
                                heading: "Získajte {{rewardsPercentage}}% CashBack",
                                text: "Získajte {{rewardsPercentage}}% späť ako kredit v online obchode pre budúce nákupy.*"
                            },
                            protect: {
                                heading: "Ochrana Zásielky",
                                text: "Pred krádežou, stratou, poškodením a viac — Onward vás chráni."
                            },
                            extendedWarranties: {
                                heading: "Ochrana Produktu",
                                text: "Pred zlyhaním v dôsledku bežného opotrebenia a chýb po vypršaní záruky výrobcu."
                            },
                            carbonOffsets: {
                                heading: "Uhlíkovo Neutrálna Doprava",
                                text: "Kompenzujeme emisie CO2 z tejto zásielky."
                            },
                            productGuarantees: {
                                heading: "Záruka Spokojnosti",
                                text: "Ak máte akékoľvek problémy s kvalitou do {{days}} dní, napravíme to."
                            },
                            returnsAndExchanges: {
                                heading: "Bezplatné Vrátenie a Výmeny",
                                text: "Bezplatná doprava pri vrátení na všetky objednávky v USA pre vrátenie a výmeny."
                            },
                            freeReturns: {
                                heading: "Bezplatné Vrátenie",
                                text: "Bezplatná doprava pri vrátení na všetky objednávky v USA."
                            },
                            subscriptions: {
                                text: "Pri predplatných objednávkach bude Onward Package Protection pridaná ku každej opakujúcej sa objednávke a môže byť kedykoľvek zrušená."
                            },
                            prioritySupport: {
                                heading: "Prioritná Podpora",
                                text: "Preskočte rad a získajte urýchlenú zákaznícku podporu."
                            }
                        }
                    },
                    sl: {
                        modal: {
                            headline: "Doživite VIP zaščito in zagotovljeno zadovoljstvo z Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Koda za nagrado bo poslana po e-pošti 30 dni po nakupu."
                            },
                            rewards: {
                                heading: "Zaslužite {{rewardsPercentage}}% CashBack",
                                text: "Prejmite {{rewardsPercentage}}% nazaj kot dobropis v spletni trgovini za prihodnje nakupe.*"
                            },
                            protect: {
                                heading: "Zaščita Pošiljke",
                                text: "Pred krajo, izgubo, poškodbo in več — Onward vas ščiti."
                            },
                            extendedWarranties: {
                                heading: "Zaščita Izdelka",
                                text: "Pred okvaro zaradi normalne obrabe in napak po izteku garancije proizvajalca."
                            },
                            carbonOffsets: {
                                heading: "Ogljično Nevtralna Dostava",
                                text: "Izravnali bomo izpuste CO2 te pošiljke."
                            },
                            productGuarantees: {
                                heading: "Garancija Zadovoljstva",
                                text: "Če imate kakršne koli težave s kakovostjo v {{days}} dneh, bomo to popravili."
                            },
                            returnsAndExchanges: {
                                heading: "Brezplačne Vračila in Zamenjave",
                                text: "Brezplačna povratna dostava za vsa naročila iz ZDA za vračila in zamenjave."
                            },
                            freeReturns: {
                                heading: "Brezplačna Vračila",
                                text: "Brezplačna povratna dostava za vsa naročila iz ZDA."
                            },
                            subscriptions: {
                                text: "Za naročniška naročila bo Onward Package Protection dodana vsakemu ponavljajočemu se naročilu in jo je mogoče kadar koli preklicati."
                            },
                            prioritySupport: {
                                heading: "Prednostna Podpora",
                                text: "Preskočite vrsto in dobite pospešeno podporo strankam."
                            }
                        }
                    },
                    sm: {
                        modal: {
                            headline: "Fa'aaoao le puipuiga VIP ma le fiafia fa'amautinoatia ma Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*O le a fa'amailina le code totogi i aso e 30 pe a mae'a le fa'atauaina."
                            },
                            rewards: {
                                heading: "Maua {{rewardsPercentage}}% CashBack",
                                text: "Maua {{rewardsPercentage}}% toe foi mai o se aitalafu faleoloa i luga o le initoneti mo fa'atauga i le lumana'i.*"
                            },
                            protect: {
                                heading: "Puipuiga Lafo",
                                text: "Mai le gaoi, le leiloa, le fa'aleagaina, ma isi — e ufiufi oe e Onward."
                            },
                            extendedWarranties: {
                                heading: "Puipuiga Oloa",
                                text: "Mai le le'i manuia ona o le fa'aaogaina masani ma fa'aletonu pe a mae'a le fa'amautinoaga a le gaosi."
                            },
                            carbonOffsets: {
                                heading: "Lafo Neutral Carbon",
                                text: "O le a matou fa'aaopoopo le fa'aosoina o le CO2 o lenei uta."
                            },
                            productGuarantees: {
                                heading: "Fa'amautinoaga Fiafia",
                                text: "Afai e iai ni fa'afitauli lelei i totonu o aso {{days}}, o le a matou toe fa'aleleia."
                            },
                            returnsAndExchanges: {
                                heading: "Toe Fa'afo'i ma Sui Fua",
                                text: "Lafo toe fo'i fua i ota US uma mo toe fo'i ma sui."
                            },
                            freeReturns: {
                                heading: "Toe Fa'afo'i Fua",
                                text: "Lafo toe fo'i fua i ota US uma."
                            },
                            subscriptions: {
                                text: "Mo ota lesitala, Onward Package Protection o le a fa'aopoopoina i ota ta'itasi toe fai ma e mafai ona fa'aleaogaina i so'o se taimi."
                            },
                            prioritySupport: {
                                heading: "Lagolago Muamua",
                                text: "Oso i le laina ma maua le lagolago vave o tagata fa'atau."
                            }
                        }
                    },
                    sr: {
                        modal: {
                            headline: "Доживите VIP заштиту и гарантовано задовољство са Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Код награде биће послат е-поштом 30 дана након куповине."
                            },
                            rewards: {
                                heading: "Зарадите {{rewardsPercentage}}% CashBack",
                                text: "Добијте {{rewardsPercentage}}% назад као кредит у онлајн продавници за будуће куповине.*"
                            },
                            protect: {
                                heading: "Заштита Испоруке",
                                text: "Од крађе, губитка, оштећења и више — Onward вас покрива."
                            },
                            extendedWarranties: {
                                heading: "Заштита Производа",
                                text: "Од квара због нормалног хабања и недостатака након истека гаранције произвођача."
                            },
                            carbonOffsets: {
                                heading: "Угљенично Неутрална Испорука",
                                text: "Компензоваћемо CO2 емисије ове пошиљке."
                            },
                            productGuarantees: {
                                heading: "Гаранција Задовољства",
                                text: "Ако имате проблема са квалитетом у року од {{days}} дана, средићемо то."
                            },
                            returnsAndExchanges: {
                                heading: "Бесплатни Поврати и Замене",
                                text: "Бесплатна повратна достава на све наруџбине из САД за поврате и замене."
                            },
                            freeReturns: {
                                heading: "Бесплатни Поврати",
                                text: "Бесплатна повратна достава на све наруџбине из САД."
                            },
                            subscriptions: {
                                text: "За наруџбине претплате, Onward Package Protection биће додата свакој понављајућој наруџбини и може се отказати у било ком тренутку."
                            },
                            prioritySupport: {
                                heading: "Приоритетна Подршка",
                                text: "Прескочите ред и добијте убрзану корисничку подршку."
                            }
                        }
                    },
                    sv: {
                        modal: {
                            headline: "Upplev VIP-skydd och garanterad tillfredsställelse med Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Belöningskoden skickas via e-post 30 dagar efter köpet."
                            },
                            rewards: {
                                heading: "Tjäna {{rewardsPercentage}}% CashBack",
                                text: "Få {{rewardsPercentage}}% tillbaka som onlinebutikskredit för framtida köp.*"
                            },
                            protect: {
                                heading: "Fraktskydd",
                                text: "Mot stöld, förlust, skada och mer — Onward skyddar dig."
                            },
                            extendedWarranties: {
                                heading: "Produktskydd",
                                text: "Mot fel på grund av normalt slitage och defekter efter tillverkarens garanti löper ut."
                            },
                            carbonOffsets: {
                                heading: "Koldioxidneutral Frakt",
                                text: "Vi kompenserar för CO2-utsläppen från denna leverans."
                            },
                            productGuarantees: {
                                heading: "Nöjdhetsgaranti",
                                text: "Om du har några kvalitetsproblem inom {{days}} dagar fixar vi det."
                            },
                            returnsAndExchanges: {
                                heading: "Gratis Returer och Byten",
                                text: "Gratis returfrakt på alla amerikanska beställningar för returer och byten."
                            },
                            freeReturns: {
                                heading: "Gratis Returer",
                                text: "Gratis returfrakt på alla amerikanska beställningar."
                            },
                            subscriptions: {
                                text: "För prenumerationsbeställningar läggs Onward Package Protection till varje återkommande beställning och kan avbrytas när som helst."
                            },
                            prioritySupport: {
                                heading: "Prioriterad Support",
                                text: "Hoppa över kön och få snabb kundsupport."
                            }
                        }
                    },
                    sw: {
                        modal: {
                            headline: "Pata ulinzi wa VIP na kuridhika kwa uhakika na Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Msimbo wa zawadi utatumwa kwa barua pepe siku 30 baada ya ununuzi."
                            },
                            rewards: {
                                heading: "Pata {{rewardsPercentage}}% CashBack",
                                text: "Pata {{rewardsPercentage}}% nyuma kama mkopo wa duka la mtandaoni kwa ununuzi ujao.*"
                            },
                            protect: {
                                heading: "Ulinzi wa Usafirishaji",
                                text: "Kutoka kwa wizi, kupoteza, uharibifu, na zaidi — Onward inakufunika."
                            },
                            extendedWarranties: {
                                heading: "Ulinzi wa Bidhaa",
                                text: "Kutoka kwa kushindwa kwa sababu ya kuchakaa kawaida na kasoro baada ya dhamana ya mtengenezaji kuisha."
                            },
                            carbonOffsets: {
                                heading: "Usafirishaji wa Carbon Neutral",
                                text: "Tutafidia uzalishaji wa CO2 wa usafirishaji huu."
                            },
                            productGuarantees: {
                                heading: "Dhamana ya Kuridhika",
                                text: "Ikiwa una matatizo yoyote ya ubora ndani ya siku {{days}}, tutaisawazisha."
                            },
                            returnsAndExchanges: {
                                heading: "Kurudisha na Kubadilishana Bure",
                                text: "Usafirishaji wa kurudisha bure kwa maagizo yote ya US kwa kurudisha na kubadilishana."
                            },
                            freeReturns: {
                                heading: "Kurudisha Bure",
                                text: "Usafirishaji wa kurudisha bure kwa maagizo yote ya US."
                            },
                            subscriptions: {
                                text: "Kwa maagizo ya usajili, Onward Package Protection itaongezwa kwa kila agizo linalojirudia na inaweza kufutwa wakati wowote."
                            },
                            prioritySupport: {
                                heading: "Msaada wa Kipaumbele",
                                text: "Ruka foleni na upate msaada wa haraka wa wateja."
                            }
                        }
                    },
                    ta: {
                        modal: {
                            headline: "Onward VIP Protection உடன் VIP பாதுகாப்பு மற்றும் உத்தரவாத திருப்தியை அனுபவிக்கவும்.",
                            rewardsDisclaimer: {
                                text: "*வெகுமதி குறியீடு வாங்கிய 30 நாட்களுக்குப் பிறகு மின்னஞ்சல் செய்யப்படும்."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% கேஷ்பேக் சம்பாதிக்கவும்",
                                text: "எதிர்கால வாங்குதல்களுக்கு ஆன்லைன் ஸ்டோர் கிரெடிட்டாக {{rewardsPercentage}}% திரும்பப் பெறுங்கள்.*"
                            },
                            protect: {
                                heading: "ஷிப்பிங் பாதுகாப்பு",
                                text: "திருட்டு, இழப்பு, சேதம் மற்றும் பலவற்றிலிருந்து — Onward உங்களைப் பாதுகாக்கிறது."
                            },
                            extendedWarranties: {
                                heading: "தயாரிப்பு பாதுகாப்பு",
                                text: "உற்பத்தியாளரின் உத்தரவாதம் காலாவதியான பிறகு சாதாரண தேய்மானம் மற்றும் குறைபாடுகளால் ஏற்படும் தோல்வியிலிருந்து."
                            },
                            carbonOffsets: {
                                heading: "கார்பன் நடுநிலை ஷிப்பிங்",
                                text: "இந்த ஷிப்மென்ட்டின் CO2 உமிழ்வுகளை நாங்கள் ஈடுசெய்வோம்."
                            },
                            productGuarantees: {
                                heading: "திருப்தி உத்தரவாதம்",
                                text: "{{days}} நாட்களுக்குள் உங்களுக்கு தரச் சிக்கல்கள் இருந்தால், நாங்கள் அதைச் சரிசெய்வோம்."
                            },
                            returnsAndExchanges: {
                                heading: "இலவச திருப்பிகள் மற்றும் பரிமாற்றங்கள்",
                                text: "திருப்பி மற்றும் பரிமாற்றங்களுக்கு அனைத்து US ஆர்டர்களிலும் இலவச திருப்பி ஷிப்பிங்."
                            },
                            freeReturns: {
                                heading: "இலவச திருப்பிகள்",
                                text: "அனைத்து US ஆர்டர்களிலும் இலவச திருப்பி ஷிப்பிங்."
                            },
                            subscriptions: {
                                text: "சந்தா ஆர்டர்களுக்கு, Onward Package Protection ஒவ்வொரு மீண்டும் மீண்டும் வரும் ஆர்டரிலும் சேர்க்கப்படும் மற்றும் எந்த நேரத்திலும் ரத்து செய்யலாம்."
                            },
                            prioritySupport: {
                                heading: "முன்னுரிமை ஆதரவு",
                                text: "வரிசையைத் தவிர்த்து விரைவான வாடிக்கையாளர் ஆதரவைப் பெறுங்கள்."
                            }
                        }
                    },
                    te: {
                        modal: {
                            headline: "Onward VIP Protection తో VIP రక్షణ మరియు హామీ ఇచ్చిన సంతృప్తిని అనుభవించండి.",
                            rewardsDisclaimer: {
                                text: "*రివార్డ్ కోడ్ కొనుగోలు తర్వాత 30 రోజుల్లో ఇమెయిల్ చేయబడుతుంది."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% క్యాష్‌బ్యాక్ సంపాదించండి",
                                text: "భవిష్యత్ కొనుగోళ్లకు ఆన్‌లైన్ స్టోర్ క్రెడిట్‌గా {{rewardsPercentage}}% తిరిగి పొందండి.*"
                            },
                            protect: {
                                heading: "షిప్పింగ్ రక్షణ",
                                text: "దొంగతనం, నష్టం, నష్టం మరియు మరిన్నింటి నుండి — Onward మిమ్మల్ని కవర్ చేస్తుంది."
                            },
                            extendedWarranties: {
                                heading: "ఉత్పత్తి రక్షణ",
                                text: "తయారీదారు వారంటీ ముగిసిన తర్వాత సాధారణ అరుగుదల మరియు లోపాల వల్ల వైఫల్యం నుండి."
                            },
                            carbonOffsets: {
                                heading: "కార్బన్ న్యూట్రల్ షిప్పింగ్",
                                text: "ఈ షిప్‌మెంట్ యొక్క CO2 ఉద్గారాలను మేము భర్తీ చేస్తాము."
                            },
                            productGuarantees: {
                                heading: "సంతృప్తి హామీ",
                                text: "{{days}} రోజులలోపు మీకు ఏదైనా నాణ్యత సమస్యలు ఉంటే, మేము దాన్ని సరిచేస్తాము."
                            },
                            returnsAndExchanges: {
                                heading: "ఉచిత రిటర్న్‌లు మరియు ఎక్స్ఛేంజీలు",
                                text: "రిటర్న్‌లు మరియు ఎక్స్ఛేంజీల కోసం అన్ని US ఆర్డర్‌లపై ఉచిత రిటర్న్ షిప్పింగ్."
                            },
                            freeReturns: {
                                heading: "ఉచిత రిటర్న్‌లు",
                                text: "అన్ని US ఆర్డర్‌లపై ఉచిత రిటర్న్ షిప్పింగ్."
                            },
                            subscriptions: {
                                text: "సబ్‌స్క్రిప్షన్ ఆర్డర్‌ల కోసం, Onward Package Protection ప్రతి పునరావృత ఆర్డర్‌కు జోడించబడుతుంది మరియు ఎప్పుడైనా రద్దు చేయవచ్చు."
                            },
                            prioritySupport: {
                                heading: "ప్రాధాన్యత మద్దతు",
                                text: "క్యూను దాటి వేగవంతమైన కస్టమర్ సపోర్ట్ పొందండి."
                            }
                        }
                    },
                    tg: {
                        modal: {
                            headline: "Ҳифзи VIP ва қаноатмандии кафолатдоро бо Onward VIP Protection таҷриба кунед.",
                            rewardsDisclaimer: {
                                text: "*Рамзи мукофот 30 рӯз пас аз харид тавассути почтаи электронӣ фиристода мешавад."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% CashBack гиред",
                                text: "{{rewardsPercentage}}%-ро ҳамчун кредити мағозаи онлайн барои харидҳои оянда баргардонед.*"
                            },
                            protect: {
                                heading: "Ҳифзи Интиқол",
                                text: "Аз дуздӣ, гум шудан, зарар ва ғайра — Onward шуморо ҳифз мекунад."
                            },
                            extendedWarranties: {
                                heading: "Ҳифзи Маҳсулот",
                                text: "Аз хароб шудан аз сабаби фарсудашавии муқаррарӣ ва нуқсонҳо пас аз анҷоми кафолати истеҳсолкунанда."
                            },
                            carbonOffsets: {
                                heading: "Интиқоли Бетараф Карбон",
                                text: "Мо партовҳои CO2-и ин интиқолро ҷуброн мекунем."
                            },
                            productGuarantees: {
                                heading: "Кафолати Қаноатмандӣ",
                                text: "Агар дар давоми {{days}} рӯз масъалаҳои сифат дошта бошед, мо онро ислоҳ мекунем."
                            },
                            returnsAndExchanges: {
                                heading: "Баргардонидан ва Иваз кардани Ройгон",
                                text: "Интиқоли ройгони баргардонидан дар ҳамаи фармоишҳои ИМА барои баргардонидан ва иваз кардан."
                            },
                            freeReturns: {
                                heading: "Баргардонидани Ройгон",
                                text: "Интиқоли ройгони баргардонидан дар ҳамаи фармоишҳои ИМА."
                            },
                            subscriptions: {
                                text: "Барои фармоишҳои обуна, Onward Package Protection ба ҳар як фармоиши такроршаванда илова карда мешавад ва дар ҳар вақт бекор карда мешавад."
                            },
                            prioritySupport: {
                                heading: "Дастгирии Афзалиятнок",
                                text: "Аз навбат гузаред ва дастгирии зуди муштариёнро гиред."
                            }
                        }
                    },
                    th: {
                        modal: {
                            headline: "สัมผัสการคุ้มครอง VIP และความพึงพอใจที่รับประกันด้วย Onward VIP Protection",
                            rewardsDisclaimer: {
                                text: "*รหัสรางวัลจะถูกส่งทางอีเมลภายใน 30 วันหลังจากการซื้อ"
                            },
                            rewards: {
                                heading: "รับเงินคืน {{rewardsPercentage}}%",
                                text: "รับ {{rewardsPercentage}}% คืนเป็นเครดิตร้านค้าออนไลน์สำหรับการซื้อในอนาคต*"
                            },
                            protect: {
                                heading: "การคุ้มครองการจัดส่ง",
                                text: "จากการโจรกรรม, การสูญหาย, ความเสียหาย และอื่นๆ — Onward คุ้มครองคุณ"
                            },
                            extendedWarranties: {
                                heading: "การคุ้มครองผลิตภัณฑ์",
                                text: "จากความล้มเหลวเนื่องจากการสึกหรอปกติและข้อบกพร่องหลังจากการรับประกันของผู้ผลิตหมดอายุ"
                            },
                            carbonOffsets: {
                                heading: "การจัดส่งที่เป็นกลางทางคาร์บอน",
                                text: "เราจะชดเชยการปล่อย CO2 ของการจัดส่งนี้"
                            },
                            productGuarantees: {
                                heading: "การรับประกันความพึงพอใจ",
                                text: "หากคุณมีปัญหาด้านคุณภาพภายใน {{days}} วัน เราจะแก้ไขให้"
                            },
                            returnsAndExchanges: {
                                heading: "การคืนสินค้าและการแลกเปลี่ยนฟรี",
                                text: "ค่าจัดส่งคืนฟรีสำหรับคำสั่งซื้อทั้งหมดในสหรัฐฯ สำหรับการคืนสินค้าและการแลกเปลี่ยน"
                            },
                            freeReturns: {
                                heading: "การคืนสินค้าฟรี",
                                text: "ค่าจัดส่งคืนฟรีสำหรับคำสั่งซื้อทั้งหมดในสหรัฐฯ"
                            },
                            subscriptions: {
                                text: "สำหรับคำสั่งซื้อแบบสมัครสมาชิก Onward Package Protection จะถูกเพิ่มในทุกคำสั่งซื้อที่เกิดขึ้นซ้ำและสามารถยกเลิกได้ตลอดเวลา"
                            },
                            prioritySupport: {
                                heading: "การสนับสนุนลำดับความสำคัญ",
                                text: "ข้ามคิวและรับการสนับสนุนลูกค้าที่รวดเร็ว"
                            }
                        }
                    },
                    tk: {
                        modal: {
                            headline: "Onward VIP Protection bilen VIP goragyny we kepillendirilen kanagatlanmany başdan geçiriň.",
                            rewardsDisclaimer: {
                                text: "*Sylag kody satyn alynandan 30 gün soň e-poçta bilen iberiler."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% CashBack gazanyň",
                                text: "Geljekdäki satyn almalar üçin onlaýn dükan krediti hökmünde {{rewardsPercentage}}% yzyna alyň.*"
                            },
                            protect: {
                                heading: "Eltip Bermek Goragy",
                                text: "Ogurlykdan, ýitgiden, zyýandan we başga zatlardan — Onward sizi goraýar."
                            },
                            extendedWarranties: {
                                heading: "Önüm Goragy",
                                text: "Öndürijiniň kepilligi gutarandan soň adaty könelmek we kemçilikler sebäpli şowsuzlykdan."
                            },
                            carbonOffsets: {
                                heading: "Uglerod Bitarap Eltip Bermek",
                                text: "Bu ýüküň CO2 zyňyndylaryny öwezini doldrarys."
                            },
                            productGuarantees: {
                                heading: "Kanagatlanma Kepilligi",
                                text: "{{days}} günüň dowamynda hil meseleleriňiz bolsa, ony düzederis."
                            },
                            returnsAndExchanges: {
                                heading: "Mugt Gaýtarmak we Çalyşmak",
                                text: "Gaýtarmak we çalyşmak üçin ABŞ-nyň ähli sargytlarynda mugt gaýtaryş eltip bermek."
                            },
                            freeReturns: {
                                heading: "Mugt Gaýtarmak",
                                text: "ABŞ-nyň ähli sargytlarynda mugt gaýtaryş eltip bermek."
                            },
                            subscriptions: {
                                text: "Ýazylma sargytlary üçin Onward Package Protection her gaýtalanýan sargyda goşular we islendik wagt ýatyrylyp bilner."
                            },
                            prioritySupport: {
                                heading: "Ileri Tutulýan Goldaw",
                                text: "Nobaty geçiň we çalt müşderi goldawyny alyň."
                            }
                        }
                    },
                    to: {
                        modal: {
                            headline: "Sio ki he malu'i VIP mo e fiemālie fakapapau'i mo Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Ko e kouti totongi 'e 'īmeili 'i he 'aho 'e 30 hili 'a e fakatau."
                            },
                            rewards: {
                                heading: "Ma'u {{rewardsPercentage}}% CashBack",
                                text: "Ma'u {{rewardsPercentage}}% foki mai ko ha keleti falekoloa 'i he 'initaneti ki he fakatau 'i he kaha'u.*"
                            },
                            protect: {
                                heading: "Malu'i Fetu'utaki",
                                text: "Mei he kaiha'a, mole, maumau, mo hono toe — 'oku malu'i koe 'e Onward."
                            },
                            extendedWarranties: {
                                heading: "Malu'i Koloa",
                                text: "Mei he 'ikai ke lava koe'uhi ko e fakamole angamaheni mo e faingata'a hili hono 'osi 'a e fakapapau'i 'a e ngaohi."
                            },
                            carbonOffsets: {
                                heading: "Fetu'utaki Carbon Neutral",
                                text: "Te mau fakamahino 'a e ueveinga CO2 'o e fetu'utaki ni."
                            },
                            productGuarantees: {
                                heading: "Fakapapau'i Fiemālie",
                                text: "Kapau 'oku 'i ai ha'o palopalema lelei 'i he 'aho 'e {{days}}, te mau fakalelei'i."
                            },
                            returnsAndExchanges: {
                                heading: "Foki mo Fetongi Ta'etotongi",
                                text: "Fetu'utaki foki ta'etotongi 'i he ngaahi 'ota US kotoa ki he foki mo fetongi."
                            },
                            freeReturns: {
                                heading: "Foki Ta'etotongi",
                                text: "Fetu'utaki foki ta'etotongi 'i he ngaahi 'ota US kotoa."
                            },
                            subscriptions: {
                                text: "Ki he ngaahi 'ota fakatohi, ko e Onward Package Protection 'e tānaki ki he 'ota kotoa pē 'oku toe fai pea 'e lava ke kaniseli 'i ha taimi pē."
                            },
                            prioritySupport: {
                                heading: "Poupou Mu'omu'a",
                                text: "Lue hake 'i he laine pea ma'u 'a e tokoni fakatokolahi ki he kau fakatau."
                            }
                        }
                    },
                    tr: {
                        modal: {
                            headline: "Onward VIP Protection ile VIP koruma ve garantili memnuniyeti deneyimleyin.",
                            rewardsDisclaimer: {
                                text: "*Ödül kodu satın alma işleminden 30 gün sonra e-posta ile gönderilecektir."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% CashBack Kazanın",
                                text: "Gelecekteki alışverişlerde kullanmak üzere {{rewardsPercentage}}% online mağaza kredisi olarak geri alın.*"
                            },
                            protect: {
                                heading: "Kargo Koruması",
                                text: "Hırsızlık, kayıp, hasar ve dahası — Onward sizi korur."
                            },
                            extendedWarranties: {
                                heading: "Ürün Koruması",
                                text: "Üretici garantisi sona erdikten sonra normal aşınma ve yıpranma ile kusurlardan kaynaklanan arızalardan."
                            },
                            carbonOffsets: {
                                heading: "Karbon Nötr Kargo",
                                text: "Bu gönderinin CO2 emisyonlarını dengeleyeceğiz."
                            },
                            productGuarantees: {
                                heading: "Memnuniyet Garantisi",
                                text: "{{days}} gün içinde herhangi bir kalite sorununuz varsa, düzelteceğiz."
                            },
                            returnsAndExchanges: {
                                heading: "Ücretsiz İade ve Değişim",
                                text: "İade ve değişim için tüm ABD siparişlerinde ücretsiz iade kargos."
                            },
                            freeReturns: {
                                heading: "Ücretsiz İade",
                                text: "Tüm ABD siparişlerinde ücretsiz iade kargosu."
                            },
                            subscriptions: {
                                text: "Abonelik siparişleri için Onward Package Protection her yinelenen siparişe eklenecek ve istediğiniz zaman iptal edilebilir."
                            },
                            prioritySupport: {
                                heading: "Öncelikli Destek",
                                text: "Sırayı atlayın ve hızlandırılmış müşteri desteği alın."
                            }
                        }
                    },
                    uk: {
                        modal: {
                            headline: "Відчуйте VIP-захист та гарантоване задоволення з Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Код винагороди буде надіслано на електронну пошту через 30 днів після покупки."
                            },
                            rewards: {
                                heading: "Отримайте {{rewardsPercentage}}% CashBack",
                                text: "Отримайте {{rewardsPercentage}}% назад як кредит онлайн-магазину для майбутніх покупок.*"
                            },
                            protect: {
                                heading: "Захист Доставки",
                                text: "Від крадіжки, втрати, пошкодження та іншого — Onward захищає вас."
                            },
                            extendedWarranties: {
                                heading: "Захист Продукту",
                                text: "Від поломки через нормальний знос та дефекти після закінчення гарантії виробника."
                            },
                            carbonOffsets: {
                                heading: "Вуглецево-нейтральна Доставка",
                                text: "Ми компенсуємо викиди CO2 цієї відправки."
                            },
                            productGuarantees: {
                                heading: "Гарантія Задоволення",
                                text: "Якщо у вас виникнуть проблеми з якістю протягом {{days}} днів, ми все виправимо."
                            },
                            returnsAndExchanges: {
                                heading: "Безкоштовні Повернення та Обміни",
                                text: "Безкоштовна зворотна доставка для всіх замовлень із США для повернень та обмінів."
                            },
                            freeReturns: {
                                heading: "Безкоштовні Повернення",
                                text: "Безкоштовна зворотна доставка для всіх замовлень із США."
                            },
                            subscriptions: {
                                text: "Для замовлень за підпискою Onward Package Protection буде додано до кожного повторюваного замовлення і може бути скасовано в будь-який час."
                            },
                            prioritySupport: {
                                heading: "Пріоритетна Підтримка",
                                text: "Пропустіть чергу та отримайте прискорену підтримку клієнтів."
                            }
                        }
                    },
                    ur: {
                        modal: {
                            headline: "Onward VIP Protection کے ساتھ VIP تحفظ اور یقینی اطمینان کا تجربہ کریں۔",
                            rewardsDisclaimer: {
                                text: "*انعام کا کوڈ خریداری کے 30 دن بعد ای میل کیا جائے گا۔"
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% کیش بیک کمائیں",
                                text: "مستقبل کی خریداریوں کے لیے آن لائن اسٹور کریڈٹ کے طور پر {{rewardsPercentage}}% واپس حاصل کریں۔*"
                            },
                            protect: {
                                heading: "شپنگ تحفظ",
                                text: "چوری، نقصان، خرابی اور مزید سے — Onward آپ کی حفاظت کرتا ہے۔"
                            },
                            extendedWarranties: {
                                heading: "پروڈکٹ تحفظ",
                                text: "مینوفیکچرر کی وارنٹی ختم ہونے کے بعد عام ٹوٹ پھوٹ اور خرابیوں کی وجہ سے ناکامی سے۔"
                            },
                            carbonOffsets: {
                                heading: "کاربن نیوٹرل شپنگ",
                                text: "ہم اس شپمنٹ کے CO2 اخراج کی تلافی کریں گے۔"
                            },
                            productGuarantees: {
                                heading: "اطمینان کی گارنٹی",
                                text: "اگر آپ کو {{days}} دنوں کے اندر معیار کے مسائل ہیں، تو ہم اسے ٹھیک کر دیں گے۔"
                            },
                            returnsAndExchanges: {
                                heading: "مفت واپسی اور تبادلہ",
                                text: "واپسی اور تبادلے کے لیے تمام امریکی آرڈرز پر مفت واپسی شپنگ۔"
                            },
                            freeReturns: {
                                heading: "مفت واپسی",
                                text: "تمام امریکی آرڈرز پر مفت واپسی شپنگ۔"
                            },
                            subscriptions: {
                                text: "سبسکرپشن آرڈرز کے لیے، Onward Package Protection ہر بار بار آرڈر میں شامل کی جائے گی اور کسی بھی وقت منسوخ کی جا سکتی ہے۔"
                            },
                            prioritySupport: {
                                heading: "ترجیحی معاونت",
                                text: "قطار چھوڑیں اور تیز کسٹمر سپورٹ حاصل کریں۔"
                            }
                        }
                    },
                    uz: {
                        modal: {
                            headline: "Onward VIP Protection bilan VIP himoya va kafolatlangan mamnuniyatni his qiling.",
                            rewardsDisclaimer: {
                                text: "*Mukofot kodi xariddan 30 kun o'tgach elektron pochta orqali yuboriladi."
                            },
                            rewards: {
                                heading: "{{rewardsPercentage}}% CashBack oling",
                                text: "Kelajakdagi xaridlar uchun onlayn do'kon krediti sifatida {{rewardsPercentage}}% qaytarib oling.*"
                            },
                            protect: {
                                heading: "Yetkazib Berish Himoyasi",
                                text: "O'g'irlik, yo'qotish, shikastlanish va boshqalardan — Onward sizni himoya qiladi."
                            },
                            extendedWarranties: {
                                heading: "Mahsulot Himoyasi",
                                text: "Ishlab chiqaruvchi kafolati tugaganidan keyin oddiy eskirish va nuqsonlar sababli nosozlikdan."
                            },
                            carbonOffsets: {
                                heading: "Uglerod Neytral Yetkazib Berish",
                                text: "Biz ushbu jo'natmaning CO2 chiqindilarini qoplaymiz."
                            },
                            productGuarantees: {
                                heading: "Mamnuniyat Kafolati",
                                text: "Agar {{days}} kun ichida sifat muammolaringiz bo'lsa, biz uni tuzatamiz."
                            },
                            returnsAndExchanges: {
                                heading: "Bepul Qaytarish va Almashtirish",
                                text: "Qaytarish va almashtirish uchun barcha AQSh buyurtmalarida bepul qaytarish yetkazib berish."
                            },
                            freeReturns: {
                                heading: "Bepul Qaytarish",
                                text: "Barcha AQSh buyurtmalarida bepul qaytarish yetkazib berish."
                            },
                            subscriptions: {
                                text: "Obuna buyurtmalari uchun Onward Package Protection har bir takrorlanuvchi buyurtmaga qo'shiladi va istalgan vaqtda bekor qilinishi mumkin."
                            },
                            prioritySupport: {
                                heading: "Ustuvor Qo'llab-quvvatlash",
                                text: "Navbatni o'tkazib yuboring va tezlashtirilgan mijozlarni qo'llab-quvvatlang."
                            }
                        }
                    },
                    vi: {
                        modal: {
                            headline: "Trải nghiệm bảo vệ VIP và sự hài lòng được đảm bảo với Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Mã thưởng sẽ được gửi qua email 30 ngày sau khi mua hàng."
                            },
                            rewards: {
                                heading: "Nhận Hoàn Tiền {{rewardsPercentage}}%",
                                text: "Nhận lại {{rewardsPercentage}}% dưới dạng tín dụng cửa hàng trực tuyến để sử dụng cho các giao dịch mua hàng trong tương lai.*"
                            },
                            protect: {
                                heading: "Bảo Vệ Vận Chuyển",
                                text: "Khỏi trộm cắp, mất mát, hư hỏng và nhiều hơn nữa — Onward bảo vệ bạn."
                            },
                            extendedWarranties: {
                                heading: "Bảo Vệ Sản Phẩm",
                                text: "Khỏi hỏng hóc do hao mòn bình thường và lỗi sau khi bảo hành của nhà sản xuất hết hạn."
                            },
                            carbonOffsets: {
                                heading: "Vận Chuyển Trung Hòa Carbon",
                                text: "Chúng tôi sẽ bù đắp lượng khí thải CO2 của lô hàng này."
                            },
                            productGuarantees: {
                                heading: "Đảm Bảo Hài Lòng",
                                text: "Nếu bạn gặp bất kỳ vấn đề chất lượng nào trong vòng {{days}} ngày, chúng tôi sẽ khắc phục."
                            },
                            returnsAndExchanges: {
                                heading: "Đổi Trả Miễn Phí",
                                text: "Vận chuyển trả hàng miễn phí cho tất cả đơn hàng tại Hoa Kỳ để đổi trả."
                            },
                            freeReturns: {
                                heading: "Trả Hàng Miễn Phí",
                                text: "Vận chuyển trả hàng miễn phí cho tất cả đơn hàng tại Hoa Kỳ."
                            },
                            subscriptions: {
                                text: "Đối với đơn hàng đăng ký, Onward Package Protection sẽ được thêm vào mỗi đơn hàng định kỳ và có thể hủy bất cứ lúc nào."
                            },
                            prioritySupport: {
                                heading: "Hỗ Trợ Ưu Tiên",
                                text: "Bỏ qua hàng đợi và nhận hỗ trợ khách hàng nhanh chóng."
                            }
                        }
                    },
                    xh: {
                        modal: {
                            headline: "Fumana ukukhuselwa kwe-VIP kunye nokwaneliseka okuqinisekisiweyo nge-Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Ikhowudi yomvuzo iya kuthunyelwa nge-imeyile kwiintsuku ezingama-30 emva kokuthenga."
                            },
                            rewards: {
                                heading: "Fumana {{rewardsPercentage}}% i-CashBack",
                                text: "Fumana {{rewardsPercentage}}% ubuyele njengetyala levenkile ekwi-intanethi ukuze isetyenziswe kwizinto zokuthengwa kwixesha elizayo.*"
                            },
                            protect: {
                                heading: "Ukukhusela Ukuthunyelwa",
                                text: "Ekubeni, ekulahlekeni, umonakalo, kunye nokunye — i-Onward iyakugubungela."
                            },
                            extendedWarranties: {
                                heading: "Ukukhusela Imveliso",
                                text: "Ekuphukelweni ngenxa yokuqheleka kokuguga kunye neziphene emva kokuba isiqinisekiso somvelisi siphelile."
                            },
                            carbonOffsets: {
                                heading: "Ukuthunyelwa Okungathathi Cala Kwekhabhoni",
                                text: "Siya kulinganisa ukuphuma kwe-CO2 kolu thungelwano."
                            },
                            productGuarantees: {
                                heading: "Isiqinisekiso Sokwaneliseka",
                                text: "Ukuba unezingxaki zomgangatho kwiintsuku {{days}}, siya kukulungisa."
                            },
                            returnsAndExchanges: {
                                heading: "Ukubuyisela Kunye Nokutshintsha Simahla",
                                text: "Ukuthunyelwa kokubuyisela simahla kuzo zonke ii-odolo zase-US ukuze zibuyiswe kunye nokutshintsha."
                            },
                            freeReturns: {
                                heading: "Ukubuyisela Simahla",
                                text: "Ukuthunyelwa kokubuyisela simahla kuzo zonke ii-odolo zase-US."
                            },
                            subscriptions: {
                                text: "Kwii-odolo zobhaliso, i-Onward Package Protection iya kongezwa kwi-odolo nganye ephindaphindiweyo kwaye inokurhoxiswa nangaliphi na ixesha."
                            },
                            prioritySupport: {
                                heading: "Inkxaso Yokuqala",
                                text: "Tsiba umgca kwaye ufumane inkxaso yabathengi ekhawulezayo."
                            }
                        }
                    },
                    yo: {
                        modal: {
                            headline: "Ni iriri aabo VIP ati itẹlọrun ti a ṣe idaniloju pẹlu Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Koodu ẹbun yoo fi ranṣẹ si imeeli ni ọjọ 30 lẹhin rira."
                            },
                            rewards: {
                                heading: "Jẹ {{rewardsPercentage}}% CashBack",
                                text: "Gba {{rewardsPercentage}}% pada bi kirẹditi ile itaja ori ayelujara lati lo fun awọn rira ọjọ iwaju.*"
                            },
                            protect: {
                                heading: "Aabo Ifiranṣẹ",
                                text: "Lati ole, sonu, ibajẹ, ati diẹ sii — Onward bo ọ."
                            },
                            extendedWarranties: {
                                heading: "Aabo Ọja",
                                text: "Lati ikuna nitori wọọra deede ati awọn ailagbara lẹhin idaniloju olupese ti pari."
                            },
                            carbonOffsets: {
                                heading: "Ifiranṣẹ Carbon Neutral",
                                text: "A yoo ṣe idiwọ awọn itujade CO2 ti ifiranṣẹ yii."
                            },
                            productGuarantees: {
                                heading: "Idaniloju Itẹlọrun",
                                text: "Ti o ba ni awọn iṣoro didara laarin awọn ọjọ {{days}}, a yoo ṣatunṣe rẹ."
                            },
                            returnsAndExchanges: {
                                heading: "Awọn Ipadabọ ati Awọn Paṣipaarọ Ọfẹ",
                                text: "Ifiranṣẹ ipadabọ ọfẹ lori gbogbo awọn aṣẹ US fun awọn ipadabọ ati awọn paṣipaarọ."
                            },
                            freeReturns: {
                                heading: "Awọn Ipadabọ Ọfẹ",
                                text: "Ifiranṣẹ ipadabọ ọfẹ lori gbogbo awọn aṣẹ US."
                            },
                            subscriptions: {
                                text: "Fun awọn aṣẹ alabapin, Onward Package Protection yoo fi kun si aṣẹ atunwi kọọkan ati pe o le fagilee ni akoko eyikeyi."
                            },
                            prioritySupport: {
                                heading: "Atilẹyin Pataki",
                                text: "Fò laini naa ki o gba atilẹyin onibara ti o yara."
                            }
                        }
                    },
                    "zh-CN": {
                        modal: {
                            headline: "通过 Onward VIP Protection 体验 VIP 保护和保证满意。",
                            rewardsDisclaimer: {
                                text: "*奖励代码将在购买后 30 天内通过电子邮件发送。"
                            },
                            rewards: {
                                heading: "赚取 {{rewardsPercentage}}% 返现",
                                text: "获得 {{rewardsPercentage}}% 返还作为在线商店积分，用于未来购买。*"
                            },
                            protect: {
                                heading: "运输保护",
                                text: "防止盗窃、丢失、损坏等 — Onward 为您提供保障。"
                            },
                            extendedWarranties: {
                                heading: "产品保护",
                                text: "在制造商保修期满后，防止因正常磨损和缺陷导致的故障。"
                            },
                            carbonOffsets: {
                                heading: "碳中和运输",
                                text: "我们将抵消此次运输的二氧化碳排放。"
                            },
                            productGuarantees: {
                                heading: "满意保证",
                                text: "如果您在 {{days}} 天内有任何质量问题，我们将为您解决。"
                            },
                            returnsAndExchanges: {
                                heading: "免费退换货",
                                text: "所有美国订单的退货和换货均可免费退货运费。"
                            },
                            freeReturns: {
                                heading: "免费退货",
                                text: "所有美国订单均可免费退货运费。"
                            },
                            subscriptions: {
                                text: "对于订阅订单，Onward Package Protection 将添加到每个定期订单中，可随时取消。"
                            },
                            prioritySupport: {
                                heading: "优先支持",
                                text: "跳过排队，获得加快的客户支持。"
                            }
                        }
                    },
                    "zh-HK": {
                        modal: {
                            headline: "透過 Onward VIP Protection 體驗 VIP 保護和保證滿意。",
                            rewardsDisclaimer: {
                                text: "*獎勵代碼將在購買後 30 天內通過電郵發送。"
                            },
                            rewards: {
                                heading: "賺取 {{rewardsPercentage}}% 回贈",
                                text: "獲得 {{rewardsPercentage}}% 返還作為網上商店積分，用於日後購物。*"
                            },
                            protect: {
                                heading: "運輸保護",
                                text: "防止盜竊、遺失、損壞等 — Onward 為您提供保障。"
                            },
                            extendedWarranties: {
                                heading: "產品保護",
                                text: "在製造商保養期滿後，防止因正常磨損和缺陷導致的故障。"
                            },
                            carbonOffsets: {
                                heading: "碳中和運輸",
                                text: "我們將抵消此次運輸的二氧化碳排放。"
                            },
                            productGuarantees: {
                                heading: "滿意保證",
                                text: "如果您在 {{days}} 天內有任何質量問題，我們將為您解決。"
                            },
                            returnsAndExchanges: {
                                heading: "免費退換貨",
                                text: "所有美國訂單的退貨和換貨均可免費退貨運費。"
                            },
                            freeReturns: {
                                heading: "免費退貨",
                                text: "所有美國訂單均可免費退貨運費。"
                            },
                            subscriptions: {
                                text: "對於訂閱訂單，Onward Package Protection 將添加到每個定期訂單中，可隨時取消。"
                            },
                            prioritySupport: {
                                heading: "優先支援",
                                text: "跳過排隊，獲得加快的客戶支援。"
                            }
                        }
                    },
                    "zh-TW": {
                        modal: {
                            headline: "透過 Onward VIP Protection 體驗 VIP 保護和保證滿意。",
                            rewardsDisclaimer: {
                                text: "*獎勵代碼將在購買後 30 天內透過電子郵件發送。"
                            },
                            rewards: {
                                heading: "賺取 {{rewardsPercentage}}% 回饋",
                                text: "獲得 {{rewardsPercentage}}% 返還作為線上商店積分，用於未來購物。*"
                            },
                            protect: {
                                heading: "運送保護",
                                text: "防止竊盜、遺失、損壞等 — Onward 為您提供保障。"
                            },
                            extendedWarranties: {
                                heading: "產品保護",
                                text: "在製造商保固期滿後，防止因正常磨損和缺陷導致的故障。"
                            },
                            carbonOffsets: {
                                heading: "碳中和運送",
                                text: "我們將抵消此次運送的二氧化碳排放。"
                            },
                            productGuarantees: {
                                heading: "滿意保證",
                                text: "如果您在 {{days}} 天內有任何品質問題，我們將為您解決。"
                            },
                            returnsAndExchanges: {
                                heading: "免費退換貨",
                                text: "所有美國訂單的退貨和換貨均可免費退貨運費。"
                            },
                            freeReturns: {
                                heading: "免費退貨",
                                text: "所有美國訂單均可免費退貨運費。"
                            },
                            subscriptions: {
                                text: "對於訂閱訂單，Onward Package Protection 將添加到每個定期訂單中，可隨時取消。"
                            },
                            prioritySupport: {
                                heading: "優先支援",
                                text: "跳過排隊，獲得加快的客戶支援。"
                            }
                        }
                    },
                    zu: {
                        modal: {
                            headline: "Zizwe ukuvikelwa kwe-VIP nokwaneliseka okuqinisekisiwe ne-Onward VIP Protection.",
                            rewardsDisclaimer: {
                                text: "*Ikhodi yomklomelo izothunyelwa nge-imeyili ezinsukwini ezingu-30 ngemva kokuthenga."
                            },
                            rewards: {
                                heading: "Thola {{rewardsPercentage}}% i-CashBack",
                                text: "Thola {{rewardsPercentage}}% ubuyele njengesikweletu sesitolo se-inthanethi ukuze usebenzise ukuthengwa kwesikhathi esizayo.*"
                            },
                            protect: {
                                heading: "Ukuvikelwa Kokuthumela",
                                text: "Ekwebeni, ekulahlekeni, ukulimala, nokunye okuningi — i-Onward ikuvikela."
                            },
                            extendedWarranties: {
                                heading: "Ukuvikelwa Komkhiqizo",
                                text: "Ekuhlulekeni ngenxa yokuguga okuvamile nezici ngemva kokuba isiqinisekiso somkhiqizi siphele."
                            },
                            carbonOffsets: {
                                heading: "Ukuthumela Okungathathi Hlangothi Kwekhabhoni",
                                text: "Sizohlawulisana nokukhishwa kwe-CO2 kwalokhu okuthunyelwayo."
                            },
                            productGuarantees: {
                                heading: "Isiqinisekiso Sokwaneliseka",
                                text: "Uma unezinkinga zekhwalithi phakathi kwezinsuku ezingu-{{days}}, sizokukulungisa."
                            },
                            returnsAndExchanges: {
                                heading: "Ukubuyisa Nokushintsha Mahhala",
                                text: "Ukuthumela kokubuyisa mahhala kuwo wonke ama-oda ase-US ukuze abuyiswe futhi ashintshwe."
                            },
                            freeReturns: {
                                heading: "Ukubuyisa Mahhala",
                                text: "Ukuthumela kokubuyisa mahhala kuwo wonke ama-oda ase-US."
                            },
                            subscriptions: {
                                text: "Ngama-oda okubhalisa, i-Onward Package Protection izongezwa ku-oda ngalinye eliphindaphindiwe futhi lingakhanselwa noma nini."
                            },
                            prioritySupport: {
                                heading: "Ukusekelwa Okuphambili",
                                text: "Yeqa umugqa futhi uthole ukusekelwa kwamakhasimende okusheshayo."
                            }
                        }
                    }
                };

            function A(e, t) {
                const n = Object.assign({}, e);
                for (const a in t) void 0 !== t[a] && ("object" != typeof e[a] || null === e[a] || "object" != typeof t[a] || null === t[a] || Array.isArray(e[a]) ? n[a] = t[a] : n[a] = A(e[a], t[a]));
                return n
            }
            const E = {
                    modal: {
                        headerImage: {
                            icon: "https://assets.useonward.com/assets/modal_rocket.svg",
                            logo: "https://assets.useonward.com/assets/email/onward-logo-scaled-dark.png",
                            dark_mode_logo: "https://assets.useonward.com/assets/email/onward-logo-scaled-light.png",
                            logo_full_black: "https://assets.useonward.com/assets/email/full-black-onward-logo.png",
                            logo_black: "https://assets.useonward.com/assets/email/light-colored-onward-logo-scaled-x6.png",
                            logo_white: "https://assets.useonward.com/assets/email/dark-colored-onward-logo-scaled-x6.png",
                            logo_gray: "https://assets.useonward.com/assets/email/onward-logo-gray.png"
                        },
                        headline: "",
                        rewardsDisclaimer: {
                            text: ""
                        },
                        rewards: {
                            icon: "https://assets.useonward.com/assets/email/cashback.png",
                            heading: "",
                            text: ""
                        },
                        protect: {
                            icon: "https://assets.useonward.com/assets/email/protection-solid.png",
                            heading: "",
                            text: ""
                        },
                        extendedWarranties: {
                            icon: "https://assets.useonward.com/assets/email/protection-solid.png",
                            heading: "",
                            text: ""
                        },
                        carbonOffsets: {
                            icon: "https://assets.useonward.com/assets/email/carbon-offset-solid.png",
                            heading: "",
                            text: ""
                        },
                        productGuarantees: {
                            icon: "https://assets.useonward.com/assets/email/satisfaction-guarantee-solid.png",
                            heading: "",
                            text: ""
                        },
                        returnsAndExchanges: {
                            icon: "https://assets.useonward.com/assets/email/free-returns-solid.png",
                            heading: "",
                            text: ""
                        },
                        freeReturns: {
                            icon: "https://assets.useonward.com/assets/email/free-returns-solid.png",
                            heading: "",
                            text: ""
                        },
                        subscriptions: {
                            text: ""
                        },
                        prioritySupport: {
                            icon: "https://assets.useonward.com/assets/email/priority-support-solid.png",
                            heading: "",
                            text: ""
                        }
                    }
                },
                z = "Checkout+ Protection",
                j = "from Damage, Loss & Theft.";
            var V, L;
            ! function(e) {
                e.cart = "cart", e.checkout = "checkout"
            }(V || (V = {})),
            function(e) {
                e.doNotInsure = "do_not_insure", e.insureAnywayWithClosestVariant = "insure_anyway_with_closest_variant"
            }(L || (L = {}));
            class T {
                constructor({
                    shopEnabled: e = !0,
                    orderEditingEnabled: t = !1,
                    selectedByDefault: n = !1,
                    insuranceFeePercentage: a = 3,
                    rewardsPercentage: r = 0,
                    rewardsEnabled: i = !1,
                    extendedWarrantiesEnabled: o = !1,
                    productGuaranteesEnabled: s = !1,
                    productGuaranteeDays: d = 30,
                    carbonOffsetPriceCents: l = 0,
                    carbonOffsetsEnabled: c = !1,
                    flatRateReturnEnabled: u = !1,
                    minimumInsurableCartAmountCents: p = 0,
                    minimumInsurancePriceCents: h = null,
                    minimumInsurancePriceVariantId: w = null,
                    maximumInsurancePriceCents: g = null,
                    maximumInsurancePriceVariantId: m = null,
                    insuranceProductImageUrl: f = null,
                    showSubscriptionWording: b = !1,
                    copyLine1: x = null,
                    copyLine2: y = null,
                    poweredByEnabled: k = !1,
                    inlinePoweredByEnabled: v = !1,
                    disclaimerEnabled: P = !1,
                    disclaimerText: C = "",
                    moneyFormat: O = null,
                    oneLine: S = !1,
                    largeMultiline: _ = !1,
                    displayToggle: I = !0,
                    cartSubtotalSelector: A = null,
                    cartItemCountSelector: E = null,
                    excludePriceInSubtotalDisplay: T = !0,
                    ctaTextColor: D = null,
                    themePrimaryColor: B = null,
                    checkoutButtonSelector: R = null,
                    nativeSubscriptionsEnabled: M = !1,
                    backgroundColor: U = "",
                    walletsEnabled: W = !1,
                    analyticsEnabled: F = !1,
                    shopId: N = null,
                    shopCurrencyCode: G = null,
                    category: q = null,
                    isDev: H = !1,
                    shopSupportContact: K = null,
                    featuresEnabled: $ = [],
                    returnsAppEnabled: Z = !1,
                    autoRemoveInsuranceFromCart: J = !0,
                    checkoutPlusEnabled: Y = !1,
                    checkoutPlusButtonLabel: Q = null,
                    checkoutPlusOptOutLabel: X = null,
                    checkoutPlusCopyLine1: ee = null,
                    checkoutPlusCopyLine2: te = null,
                    checkoutPlusVariant: ne = V.cart,
                    checkoutPlusOptOutContainerSelector: ae = null,
                    pdpMorePaymentsSelectors: re = null,
                    headlessClient: ie = !1,
                    modalContent: oe = null,
                    checkoutModalContent: se = null,
                    customModalEnabled: de = !1,
                    overrideCheckoutButtonNameAttribute: le = !0,
                    overrideOptOutButtonNameAttribute: ce = !0,
                    shoppersUrl: ue = null,
                    checkoutExtensionHidden: pe = !1,
                    checkoutOneLine: he = !1,
                    legacyAutoInsertCheckoutPlus: we = !1,
                    customerSponsoredReturnLabel: ge = !0,
                    exchangesEnabled: me = !1,
                    orderEditingAddInsuranceCopyLine1: fe = null,
                    orderEditingAddInsuranceCopyLine2: be = null,
                    orderEditingDeadlineMinutes: xe = 60,
                    subtotalLabel: ye = null,
                    subtotalLabelSelector: ke = null,
                    poweredByLogoColor: ve = !0,
                    insuranceFallback: Pe = L.doNotInsure,
                    onwardLineitemProperties: Ce = null,
                    cashbackIssueImmediately: Oe = !1,
                    locale: Se = {
                        currency_iso_code: "USD",
                        currency_rate: "1.0",
                        request_locale: "en"
                    }
                } = {}) {
                    this.shopEnabled = e, this.orderEditingEnabled = t, this.selectedByDefault = n, this.insuranceFeePercentage = a, this.rewardsPercentage = r, this.rewardsEnabled = i, this.extendedWarrantiesEnabled = o, this.productGuaranteesEnabled = s, this.productGuaranteeDays = d, this.carbonOffsetPriceCents = l, this.carbonOffsetsEnabled = c, this.flatRateReturnEnabled = u, this.minimumInsurableCartAmountCents = p, this.minimumInsurancePriceCents = h, this.minimumInsurancePriceVariantId = w, this.maximumInsurancePriceCents = g, this.maximumInsurancePriceVariantId = m, this.insuranceProductImageUrl = f, this.showSubscriptionWording = b, this.copyLine1 = x || z, this.copyLine2 = y || j, this.poweredByEnabled = k, this.inlinePoweredByEnabled = v, this.disclaimerEnabled = P, this.disclaimerText = C, this.moneyFormat = O, this.oneLine = S, this.largeMultiline = _, this.displayToggle = I, this.cartSubtotalSelector = A, this.cartItemCountSelector = E, this.excludePriceInSubtotalDisplay = T, this.ctaTextColor = D, this.themePrimaryColor = B, this.checkoutButtonSelector = R, this.nativeSubscriptionsEnabled = M, this.backgroundColor = U, this.walletsEnabled = W, this.analyticsEnabled = F, this.shopId = N, this.shopCurrencyCode = G, this.category = q, this.isDev = H, this.shopSupportContact = K, this.featuresEnabled = $, this.returnsAppEnabled = Z, this.autoRemoveInsuranceFromCart = J, this.checkoutPlusEnabled = Y, this.checkoutPlusButtonLabel = Q, this.checkoutPlusOptOutLabel = X, this.checkoutPlusCopyLine1 = ee || x || z, this.checkoutPlusCopyLine2 = te || y || j, this.checkoutPlusVariant = ne, this.checkoutPlusOptOutContainerSelector = ae, this.pdpMorePaymentsSelectors = re, this.headlessClient = ie, this.modalContent = oe, this.checkoutModalContent = se, this.customModalEnabled = de, this.overrideCheckoutButtonNameAttribute = le, this.overrideOptOutButtonNameAttribute = ce, this.shoppersUrl = ue || "https://useonward.com/for-shoppers", this.checkoutExtensionHidden = pe, this.checkoutOneLine = he, this.legacyAutoInsertCheckoutPlus = we, this.customerSponsoredReturnLabel = ge, this.exchangesEnabled = me, this.orderEditingAddInsuranceCopyLine1 = fe || z, this.orderEditingAddInsuranceCopyLine2 = be, this.orderEditingDeadlineMinutes = xe, this.subtotalLabel = ye, this.subtotalLabelSelector = ke, this.poweredByLogoColor = ve, this.insuranceFallback = Pe, this.onwardLineitemProperties = Ce, this.cashbackIssueImmediately = Oe, this._locale = Se
                }
                get locale() {
                    return this._locale
                }
                setLocale(e) {
                    const t = ["currency_iso_code", "currency_rate", "request_locale"],
                        n = Object.keys(e).filter(e => !t.includes(e));
                    n.length > 0 && console.warn(`Invalid locale properties ignored: ${n.join(", ")}`), this._locale = Object.assign(Object.assign(Object.assign(Object.assign({}, this._locale), void 0 !== e.currency_iso_code && {
                        currency_iso_code: e.currency_iso_code
                    }), void 0 !== e.currency_rate && {
                        currency_rate: e.currency_rate
                    }), void 0 !== e.request_locale && {
                        request_locale: e.request_locale
                    })
                }
                get translations() {
                    return function(e = "en") {
                        const t = function(e) {
                            return I[e] || I[e.substring(0, 2)]
                        }(e);
                        return t ? A(E, t) : (console.warn(`Locale '${e}' not found, falling back to default`), A(E, _))
                    }(this._locale.request_locale)
                }
                get showReturnsAndExchangesWording() {
                    return this.returnsAppEnabled && !this.customerSponsoredReturnLabel && this.exchangesEnabled
                }
                get showReturnsAppWording() {
                    return this.flatRateReturnEnabled || this.returnsAppEnabled && !this.customerSponsoredReturnLabel && !this.exchangesEnabled
                }
                get showCarbonOffsetWording() {
                    return this.carbonOffsetsEnabled || this.carbonOffsetPriceCents > 0
                }
                get showRewardsWording() {
                    return this.rewardsEnabled && this.rewardsPercentage > 0
                }
                get showRewardsDisclaimer() {
                    return this.showRewardsWording && !this.cashbackIssueImmediately
                }
                get showExtendedWarrantiesWording() {
                    return this.extendedWarrantiesEnabled
                }
                get showProductGuaranteesWording() {
                    return this.productGuaranteesEnabled
                }
                get showCustomModal() {
                    return this.customModalEnabled
                }
                get productGuaranteesTextFormatted() {
                    return C(this.translations.modal.productGuarantees.text, {
                        days: this.productGuaranteeDays
                    })
                }
                get rewardsPercentageFormatted() {
                    return this.rewardsPercentage.toString().replace(/\.([^0]+)0+$/, ".$1")
                }
                get poweredByFooterEnabled() {
                    return this.poweredByEnabled && !this.inlinePoweredByEnabled
                }
                get poweredByHeaderEnabled() {
                    return this.poweredByEnabled && this.inlinePoweredByEnabled
                }
                get maximumInsurancePriceVariantGid() {
                    return this.maximumInsurancePriceVariantId ? `gid://shopify/ProductVariant/${this.maximumInsurancePriceVariantId}` : null
                }
                get minimumInsurancePriceVariantGid() {
                    return this.minimumInsurancePriceVariantId ? `gid://shopify/ProductVariant/${this.minimumInsurancePriceVariantId}` : null
                }
                get onwardSupportContact() {
                    return "help@useonward.com"
                }
                get modalContentFormatted() {
                    return this.modalContent && "" !== this.modalContent ? this.modalContent.toString() : null
                }
                get checkoutModalContentFormatted() {
                    return this.checkoutModalContent && "" !== this.checkoutModalContent ? this.checkoutModalContent.toString() : null
                }
                get isCheckoutPlusCheckoutVariant() {
                    return this.checkoutPlusEnabled && this.checkoutPlusVariant === V.checkout
                }
                get isInsuranceAttemptTrackingEnabled() {
                    return this.featuresEnabled.includes("widget:insurance_attempt_tracking")
                }
                get notCheckoutPlusCheckoutVariant() {
                    return !this.checkoutPlusEnabled || this.checkoutPlusVariant !== V.checkout
                }
                get isOnwardMultiProductDebugEnabled() {
                    return this.featuresEnabled.includes("widget:checkout:multi_product_debug")
                }
                shouldInsureWithClosestVariant() {
                    return this.insuranceFallback === L.insureAnywayWithClosestVariant
                }
                static load() {
                    return T.parse(JSON.stringify(window.OnwardSettingsJson))
                }
                static parse(e) {
                    try {
                        const {
                            shopEnabled: t,
                            orderEditingEnabledAt: n,
                            selectedByDefault: a,
                            carbonOffsetPriceCents: r,
                            carbonOffsetsEnabled: i,
                            flatRateReturnEnabled: o,
                            minimumInsurableCartAmountCents: s,
                            minimumInsurancePriceCents: d,
                            minimumInsurancePriceVariantId: l,
                            maximumInsurancePriceCents: c,
                            maximumInsurancePriceVariantId: u,
                            insuranceFeePercentage: p,
                            rewardsEnabled: h,
                            extendedWarrantiesEnabled: w,
                            productGuaranteesEnabled: g,
                            productGuaranteeDays: m,
                            rewardsPercentage: f,
                            insuranceProductImageUrl: b,
                            showSubscriptionWording: x,
                            copyLine1: y,
                            copyLine2: k,
                            poweredByEnabled: v,
                            inlinePoweredByEnabled: P,
                            disclaimerEnabled: C,
                            disclaimerText: O,
                            moneyFormat: S,
                            oneLine: _,
                            largeMultiline: I,
                            displayToggle: A,
                            cartSubtotalSelector: E,
                            cartItemCountSelector: z,
                            excludePriceInSubtotalDisplay: j,
                            ctaTextColor: V,
                            themePrimaryColor: L,
                            checkoutButtonSelector: D,
                            nativeSubscriptionsEnabled: B,
                            backgroundColor: R,
                            walletsEnabled: M,
                            analyticsEnabled: U,
                            shopId: W,
                            shopCurrencyCode: F,
                            shopSupportContact: N,
                            featuresEnabled: G,
                            returnsAppEnabled: q,
                            autoRemoveInsuranceFromCart: H,
                            checkoutPlusEnabled: K,
                            checkoutPlusButtonLabel: $,
                            checkoutPlusOptOutLabel: Z,
                            checkoutPlusCopyLine1: J,
                            checkoutPlusCopyLine2: Y,
                            checkoutPlusVariant: Q,
                            checkoutPlusOptOutContainerSelector: X,
                            pdpMorePaymentsSelectors: ee,
                            headlessClient: te,
                            modalContent: ne,
                            checkoutModalContent: ae,
                            customModalEnabled: re,
                            overrideCheckoutButtonNameAttribute: ie,
                            overrideOptOutButtonNameAttribute: oe,
                            shoppersUrl: se,
                            checkoutExtensionHidden: de,
                            checkoutOneLine: le,
                            legacyAutoInsertCheckoutPlus: ce,
                            customerSponsoredReturnLabel: ue,
                            exchangesEnabled: pe,
                            orderEditingAddInsuranceCopyLine1: he,
                            orderEditingAddInsuranceCopyLine2: we,
                            orderEditingDeadlineMinutes: ge,
                            subtotalLabel: me,
                            subtotalLabelSelector: fe,
                            poweredByLogoColor: be,
                            insuranceFallback: xe,
                            onwardLineitemProperties: ye,
                            cashbackIssueImmediately: ke,
                            locale: ve
                        } = JSON.parse(e);
                        return new T(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({
                            shopEnabled: t,
                            rewardsEnabled: h,
                            extendedWarrantiesEnabled: w,
                            productGuaranteesEnabled: g,
                            carbonOffsetsEnabled: i,
                            flatRateReturnEnabled: o,
                            selectedByDefault: a,
                            insuranceProductImageUrl: b,
                            showSubscriptionWording: x,
                            minimumInsurancePriceVariantId: l,
                            maximumInsurancePriceVariantId: u,
                            copyLine1: y,
                            copyLine2: k,
                            poweredByEnabled: v,
                            inlinePoweredByEnabled: P,
                            disclaimerEnabled: C,
                            disclaimerText: O,
                            moneyFormat: S,
                            oneLine: _,
                            largeMultiline: I,
                            displayToggle: A,
                            cartSubtotalSelector: E,
                            cartItemCountSelector: z,
                            excludePriceInSubtotalDisplay: j,
                            ctaTextColor: V,
                            themePrimaryColor: L,
                            checkoutButtonSelector: D,
                            nativeSubscriptionsEnabled: B,
                            backgroundColor: R,
                            walletsEnabled: M,
                            analyticsEnabled: U,
                            shopId: W,
                            shopCurrencyCode: F,
                            shopSupportContact: N,
                            featuresEnabled: G,
                            returnsAppEnabled: q,
                            autoRemoveInsuranceFromCart: H,
                            checkoutPlusEnabled: K,
                            checkoutPlusButtonLabel: $,
                            checkoutPlusOptOutLabel: Z,
                            checkoutPlusCopyLine1: J,
                            checkoutPlusCopyLine2: Y,
                            checkoutPlusVariant: Q,
                            checkoutPlusOptOutContainerSelector: X,
                            pdpMorePaymentsSelectors: ee,
                            headlessClient: te,
                            modalContent: ne,
                            checkoutModalContent: ae,
                            customModalEnabled: re,
                            overrideCheckoutButtonNameAttribute: ie,
                            overrideOptOutButtonNameAttribute: oe,
                            shoppersUrl: se,
                            checkoutExtensionHidden: de,
                            checkoutOneLine: le,
                            legacyAutoInsertCheckoutPlus: ce,
                            customerSponsoredReturnLabel: ue,
                            exchangesEnabled: pe,
                            orderEditingAddInsuranceCopyLine1: he,
                            orderEditingAddInsuranceCopyLine2: we,
                            orderEditingDeadlineMinutes: ge,
                            subtotalLabel: me,
                            subtotalLabelSelector: fe,
                            poweredByLogoColor: be,
                            insuranceFallback: xe,
                            onwardLineitemProperties: ye,
                            cashbackIssueImmediately: ke,
                            locale: ve
                        }, {
                            orderEditingEnabled: !!n
                        }), m && {
                            productGuaranteeDays: parseInt(m)
                        }), s && {
                            minimumInsurableCartAmountCents: parseInt(s)
                        }), d && {
                            minimumInsurancePriceCents: parseInt(d)
                        }), c && {
                            maximumInsurancePriceCents: parseInt(c)
                        }), p && {
                            insuranceFeePercentage: parseFloat(p)
                        }), f && {
                            rewardsPercentage: parseFloat(f)
                        }), r && {
                            carbonOffsetPriceCents: parseFloat(r)
                        }))
                    } catch (e) {
                        return new T
                    }
                }
            }
            var D = class {
                getItem(e) {
                    return localStorage.getItem(e)
                }
                setItem(e, t) {
                    localStorage.setItem(e, t)
                }
            };

            function B(e) {
                const t = Object.create(null);
                for (const n of e.split(",")) t[n] = 1;
                return e => e in t
            }
            const R = {},
                M = [],
                U = () => {},
                W = () => !1,
                F = e => 111 === e.charCodeAt(0) && 110 === e.charCodeAt(1) && (e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97),
                N = e => e.startsWith("onUpdate:"),
                G = Object.assign,
                q = (e, t) => {
                    const n = e.indexOf(t);
                    n > -1 && e.splice(n, 1)
                },
                H = Object.prototype.hasOwnProperty,
                K = (e, t) => H.call(e, t),
                $ = Array.isArray,
                Z = e => "[object Map]" === ae(e),
                J = e => "[object Set]" === ae(e),
                Y = e => "function" == typeof e,
                Q = e => "string" == typeof e,
                X = e => "symbol" == typeof e,
                ee = e => null !== e && "object" == typeof e,
                te = e => (ee(e) || Y(e)) && Y(e.then) && Y(e.catch),
                ne = Object.prototype.toString,
                ae = e => ne.call(e),
                re = e => "[object Object]" === ae(e),
                ie = e => Q(e) && "NaN" !== e && "-" !== e[0] && "" + parseInt(e, 10) === e,
                oe = B(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),
                se = e => {
                    const t = Object.create(null);
                    return n => t[n] || (t[n] = e(n))
                },
                de = /-\w/g,
                le = se(e => e.replace(de, e => e.slice(1).toUpperCase())),
                ce = /\B([A-Z])/g,
                ue = se(e => e.replace(ce, "-$1").toLowerCase()),
                pe = se(e => e.charAt(0).toUpperCase() + e.slice(1)),
                he = se(e => e ? `on${pe(e)}` : ""),
                we = (e, t) => !Object.is(e, t),
                ge = (e, ...t) => {
                    for (let n = 0; n < e.length; n++) e[n](...t)
                },
                me = (e, t, n, a = !1) => {
                    Object.defineProperty(e, t, {
                        configurable: !0,
                        enumerable: !1,
                        writable: a,
                        value: n
                    })
                },
                fe = e => {
                    const t = parseFloat(e);
                    return isNaN(t) ? e : t
                };
            let be;
            const xe = () => be || (be = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : "undefined" != typeof window ? window : void 0 !== n.g ? n.g : {});

            function ye(e) {
                if ($(e)) {
                    const t = {};
                    for (let n = 0; n < e.length; n++) {
                        const a = e[n],
                            r = Q(a) ? Ce(a) : ye(a);
                        if (r)
                            for (const e in r) t[e] = r[e]
                    }
                    return t
                }
                if (Q(e) || ee(e)) return e
            }
            const ke = /;(?![^(]*\))/g,
                ve = /:([^]+)/,
                Pe = /\/\*[^]*?\*\//g;

            function Ce(e) {
                const t = {};
                return e.replace(Pe, "").split(ke).forEach(e => {
                    if (e) {
                        const n = e.split(ve);
                        n.length > 1 && (t[n[0].trim()] = n[1].trim())
                    }
                }), t
            }

            function Oe(e) {
                let t = "";
                if (Q(e)) t = e;
                else if ($(e))
                    for (let n = 0; n < e.length; n++) {
                        const a = Oe(e[n]);
                        a && (t += a + " ")
                    } else if (ee(e))
                        for (const n in e) e[n] && (t += n + " ");
                return t.trim()
            }
            const Se = B("itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly");

            function _e(e) {
                return !!e || "" === e
            }
            const Ie = e => !(!e || !0 !== e.__v_isRef),
                Ae = e => Q(e) ? e : null == e ? "" : $(e) || ee(e) && (e.toString === ne || !Y(e.toString)) ? Ie(e) ? Ae(e.value) : JSON.stringify(e, Ee, 2) : String(e),
                Ee = (e, t) => Ie(t) ? Ee(e, t.value) : Z(t) ? {
                    [`Map(${t.size})`]: [...t.entries()].reduce((e, [t, n], a) => (e[ze(t, a) + " =>"] = n, e), {})
                } : J(t) ? {
                    [`Set(${t.size})`]: [...t.values()].map(e => ze(e))
                } : X(t) ? ze(t) : !ee(t) || $(t) || re(t) ? t : String(t),
                ze = (e, t = "") => {
                    var n;
                    return X(e) ? `Symbol(${null!=(n=e.description)?n:t})` : e
                };
            let je, Ve;
            class Le {
                constructor(e = !1) {
                    this.detached = e, this._active = !0, this._on = 0, this.effects = [], this.cleanups = [], this._isPaused = !1, this.parent = je, !e && je && (this.index = (je.scopes || (je.scopes = [])).push(this) - 1)
                }
                get active() {
                    return this._active
                }
                pause() {
                    if (this._active) {
                        let e, t;
                        if (this._isPaused = !0, this.scopes)
                            for (e = 0, t = this.scopes.length; e < t; e++) this.scopes[e].pause();
                        for (e = 0, t = this.effects.length; e < t; e++) this.effects[e].pause()
                    }
                }
                resume() {
                    if (this._active && this._isPaused) {
                        let e, t;
                        if (this._isPaused = !1, this.scopes)
                            for (e = 0, t = this.scopes.length; e < t; e++) this.scopes[e].resume();
                        for (e = 0, t = this.effects.length; e < t; e++) this.effects[e].resume()
                    }
                }
                run(e) {
                    if (this._active) {
                        const t = je;
                        try {
                            return je = this, e()
                        } finally {
                            je = t
                        }
                    }
                }
                on() {
                    1 === ++this._on && (this.prevScope = je, je = this)
                }
                off() {
                    this._on > 0 && 0 === --this._on && (je = this.prevScope, this.prevScope = void 0)
                }
                stop(e) {
                    if (this._active) {
                        let t, n;
                        for (this._active = !1, t = 0, n = this.effects.length; t < n; t++) this.effects[t].stop();
                        for (this.effects.length = 0, t = 0, n = this.cleanups.length; t < n; t++) this.cleanups[t]();
                        if (this.cleanups.length = 0, this.scopes) {
                            for (t = 0, n = this.scopes.length; t < n; t++) this.scopes[t].stop(!0);
                            this.scopes.length = 0
                        }
                        if (!this.detached && this.parent && !e) {
                            const e = this.parent.scopes.pop();
                            e && e !== this && (this.parent.scopes[this.index] = e, e.index = this.index)
                        }
                        this.parent = void 0
                    }
                }
            }
            const Te = new WeakSet;
            class De {
                constructor(e) {
                    this.fn = e, this.deps = void 0, this.depsTail = void 0, this.flags = 5, this.next = void 0, this.cleanup = void 0, this.scheduler = void 0, je && je.active && je.effects.push(this)
                }
                pause() {
                    this.flags |= 64
                }
                resume() {
                    64 & this.flags && (this.flags &= -65, Te.has(this) && (Te.delete(this), this.trigger()))
                }
                notify() {
                    2 & this.flags && !(32 & this.flags) || 8 & this.flags || Ue(this)
                }
                run() {
                    if (!(1 & this.flags)) return this.fn();
                    this.flags |= 2, Xe(this), Ne(this);
                    const e = Ve,
                        t = Ze;
                    Ve = this, Ze = !0;
                    try {
                        return this.fn()
                    } finally {
                        Ge(this), Ve = e, Ze = t, this.flags &= -3
                    }
                }
                stop() {
                    if (1 & this.flags) {
                        for (let e = this.deps; e; e = e.nextDep) Ke(e);
                        this.deps = this.depsTail = void 0, Xe(this), this.onStop && this.onStop(), this.flags &= -2
                    }
                }
                trigger() {
                    64 & this.flags ? Te.add(this) : this.scheduler ? this.scheduler() : this.runIfDirty()
                }
                runIfDirty() {
                    qe(this) && this.run()
                }
                get dirty() {
                    return qe(this)
                }
            }
            let Be, Re, Me = 0;

            function Ue(e, t = !1) {
                if (e.flags |= 8, t) return e.next = Re, void(Re = e);
                e.next = Be, Be = e
            }

            function We() {
                Me++
            }

            function Fe() {
                if (--Me > 0) return;
                if (Re) {
                    let e = Re;
                    for (Re = void 0; e;) {
                        const t = e.next;
                        e.next = void 0, e.flags &= -9, e = t
                    }
                }
                let e;
                for (; Be;) {
                    let t = Be;
                    for (Be = void 0; t;) {
                        const n = t.next;
                        if (t.next = void 0, t.flags &= -9, 1 & t.flags) try {
                            t.trigger()
                        } catch (t) {
                            e || (e = t)
                        }
                        t = n
                    }
                }
                if (e) throw e
            }

            function Ne(e) {
                for (let t = e.deps; t; t = t.nextDep) t.version = -1, t.prevActiveLink = t.dep.activeLink, t.dep.activeLink = t
            }

            function Ge(e) {
                let t, n = e.depsTail,
                    a = n;
                for (; a;) {
                    const e = a.prevDep; - 1 === a.version ? (a === n && (n = e), Ke(a), $e(a)) : t = a, a.dep.activeLink = a.prevActiveLink, a.prevActiveLink = void 0, a = e
                }
                e.deps = t, e.depsTail = n
            }

            function qe(e) {
                for (let t = e.deps; t; t = t.nextDep)
                    if (t.dep.version !== t.version || t.dep.computed && (He(t.dep.computed) || t.dep.version !== t.version)) return !0;
                return !!e._dirty
            }

            function He(e) {
                if (4 & e.flags && !(16 & e.flags)) return;
                if (e.flags &= -17, e.globalVersion === et) return;
                if (e.globalVersion = et, !e.isSSR && 128 & e.flags && (!e.deps && !e._dirty || !qe(e))) return;
                e.flags |= 2;
                const t = e.dep,
                    n = Ve,
                    a = Ze;
                Ve = e, Ze = !0;
                try {
                    Ne(e);
                    const n = e.fn(e._value);
                    (0 === t.version || we(n, e._value)) && (e.flags |= 128, e._value = n, t.version++)
                } catch (e) {
                    throw t.version++, e
                } finally {
                    Ve = n, Ze = a, Ge(e), e.flags &= -3
                }
            }

            function Ke(e, t = !1) {
                const {
                    dep: n,
                    prevSub: a,
                    nextSub: r
                } = e;
                if (a && (a.nextSub = r, e.prevSub = void 0), r && (r.prevSub = a, e.nextSub = void 0), n.subs === e && (n.subs = a, !a && n.computed)) {
                    n.computed.flags &= -5;
                    for (let e = n.computed.deps; e; e = e.nextDep) Ke(e, !0)
                }
                t || --n.sc || !n.map || n.map.delete(n.key)
            }

            function $e(e) {
                const {
                    prevDep: t,
                    nextDep: n
                } = e;
                t && (t.nextDep = n, e.prevDep = void 0), n && (n.prevDep = t, e.nextDep = void 0)
            }
            let Ze = !0;
            const Je = [];

            function Ye() {
                Je.push(Ze), Ze = !1
            }

            function Qe() {
                const e = Je.pop();
                Ze = void 0 === e || e
            }

            function Xe(e) {
                const {
                    cleanup: t
                } = e;
                if (e.cleanup = void 0, t) {
                    const e = Ve;
                    Ve = void 0;
                    try {
                        t()
                    } finally {
                        Ve = e
                    }
                }
            }
            let et = 0;
            class tt {
                constructor(e, t) {
                    this.sub = e, this.dep = t, this.version = t.version, this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0
                }
            }
            class nt {
                constructor(e) {
                    this.computed = e, this.version = 0, this.activeLink = void 0, this.subs = void 0, this.map = void 0, this.key = void 0, this.sc = 0, this.__v_skip = !0
                }
                track(e) {
                    if (!Ve || !Ze || Ve === this.computed) return;
                    let t = this.activeLink;
                    if (void 0 === t || t.sub !== Ve) t = this.activeLink = new tt(Ve, this), Ve.deps ? (t.prevDep = Ve.depsTail, Ve.depsTail.nextDep = t, Ve.depsTail = t) : Ve.deps = Ve.depsTail = t, at(t);
                    else if (-1 === t.version && (t.version = this.version, t.nextDep)) {
                        const e = t.nextDep;
                        e.prevDep = t.prevDep, t.prevDep && (t.prevDep.nextDep = e), t.prevDep = Ve.depsTail, t.nextDep = void 0, Ve.depsTail.nextDep = t, Ve.depsTail = t, Ve.deps === t && (Ve.deps = e)
                    }
                    return t
                }
                trigger(e) {
                    this.version++, et++, this.notify(e)
                }
                notify(e) {
                    We();
                    try {
                        for (let e = this.subs; e; e = e.prevSub) e.sub.notify() && e.sub.dep.notify()
                    } finally {
                        Fe()
                    }
                }
            }

            function at(e) {
                if (e.dep.sc++, 4 & e.sub.flags) {
                    const t = e.dep.computed;
                    if (t && !e.dep.subs) {
                        t.flags |= 20;
                        for (let e = t.deps; e; e = e.nextDep) at(e)
                    }
                    const n = e.dep.subs;
                    n !== e && (e.prevSub = n, n && (n.nextSub = e)), e.dep.subs = e
                }
            }
            const rt = new WeakMap,
                it = Symbol(""),
                ot = Symbol(""),
                st = Symbol("");

            function dt(e, t, n) {
                if (Ze && Ve) {
                    let t = rt.get(e);
                    t || rt.set(e, t = new Map);
                    let a = t.get(n);
                    a || (t.set(n, a = new nt), a.map = t, a.key = n), a.track()
                }
            }

            function lt(e, t, n, a, r, i) {
                const o = rt.get(e);
                if (!o) return void et++;
                const s = e => {
                    e && e.trigger()
                };
                if (We(), "clear" === t) o.forEach(s);
                else {
                    const r = $(e),
                        i = r && ie(n);
                    if (r && "length" === n) {
                        const e = Number(a);
                        o.forEach((t, n) => {
                            ("length" === n || n === st || !X(n) && n >= e) && s(t)
                        })
                    } else switch ((void 0 !== n || o.has(void 0)) && s(o.get(n)), i && s(o.get(st)), t) {
                        case "add":
                            r ? i && s(o.get("length")) : (s(o.get(it)), Z(e) && s(o.get(ot)));
                            break;
                        case "delete":
                            r || (s(o.get(it)), Z(e) && s(o.get(ot)));
                            break;
                        case "set":
                            Z(e) && s(o.get(it))
                    }
                }
                Fe()
            }

            function ct(e) {
                const t = Ht(e);
                return t === e ? t : (dt(t, 0, st), Gt(e) ? t : t.map(Kt))
            }

            function ut(e) {
                return dt(e = Ht(e), 0, st), e
            }
            const pt = {
                __proto__: null,
                [Symbol.iterator]() {
                    return ht(this, Symbol.iterator, Kt)
                },
                concat(...e) {
                    return ct(this).concat(...e.map(e => $(e) ? ct(e) : e))
                },
                entries() {
                    return ht(this, "entries", e => (e[1] = Kt(e[1]), e))
                },
                every(e, t) {
                    return gt(this, "every", e, t, void 0, arguments)
                },
                filter(e, t) {
                    return gt(this, "filter", e, t, e => e.map(Kt), arguments)
                },
                find(e, t) {
                    return gt(this, "find", e, t, Kt, arguments)
                },
                findIndex(e, t) {
                    return gt(this, "findIndex", e, t, void 0, arguments)
                },
                findLast(e, t) {
                    return gt(this, "findLast", e, t, Kt, arguments)
                },
                findLastIndex(e, t) {
                    return gt(this, "findLastIndex", e, t, void 0, arguments)
                },
                forEach(e, t) {
                    return gt(this, "forEach", e, t, void 0, arguments)
                },
                includes(...e) {
                    return ft(this, "includes", e)
                },
                indexOf(...e) {
                    return ft(this, "indexOf", e)
                },
                join(e) {
                    return ct(this).join(e)
                },
                lastIndexOf(...e) {
                    return ft(this, "lastIndexOf", e)
                },
                map(e, t) {
                    return gt(this, "map", e, t, void 0, arguments)
                },
                pop() {
                    return bt(this, "pop")
                },
                push(...e) {
                    return bt(this, "push", e)
                },
                reduce(e, ...t) {
                    return mt(this, "reduce", e, t)
                },
                reduceRight(e, ...t) {
                    return mt(this, "reduceRight", e, t)
                },
                shift() {
                    return bt(this, "shift")
                },
                some(e, t) {
                    return gt(this, "some", e, t, void 0, arguments)
                },
                splice(...e) {
                    return bt(this, "splice", e)
                },
                toReversed() {
                    return ct(this).toReversed()
                },
                toSorted(e) {
                    return ct(this).toSorted(e)
                },
                toSpliced(...e) {
                    return ct(this).toSpliced(...e)
                },
                unshift(...e) {
                    return bt(this, "unshift", e)
                },
                values() {
                    return ht(this, "values", Kt)
                }
            };

            function ht(e, t, n) {
                const a = ut(e),
                    r = a[t]();
                return a === e || Gt(e) || (r._next = r.next, r.next = () => {
                    const e = r._next();
                    return e.done || (e.value = n(e.value)), e
                }), r
            }
            const wt = Array.prototype;

            function gt(e, t, n, a, r, i) {
                const o = ut(e),
                    s = o !== e && !Gt(e),
                    d = o[t];
                if (d !== wt[t]) {
                    const t = d.apply(e, i);
                    return s ? Kt(t) : t
                }
                let l = n;
                o !== e && (s ? l = function(t, a) {
                    return n.call(this, Kt(t), a, e)
                } : n.length > 2 && (l = function(t, a) {
                    return n.call(this, t, a, e)
                }));
                const c = d.call(o, l, a);
                return s && r ? r(c) : c
            }

            function mt(e, t, n, a) {
                const r = ut(e);
                let i = n;
                return r !== e && (Gt(e) ? n.length > 3 && (i = function(t, a, r) {
                    return n.call(this, t, a, r, e)
                }) : i = function(t, a, r) {
                    return n.call(this, t, Kt(a), r, e)
                }), r[t](i, ...a)
            }

            function ft(e, t, n) {
                const a = Ht(e);
                dt(a, 0, st);
                const r = a[t](...n);
                return -1 !== r && !1 !== r || !qt(n[0]) ? r : (n[0] = Ht(n[0]), a[t](...n))
            }

            function bt(e, t, n = []) {
                Ye(), We();
                const a = Ht(e)[t].apply(e, n);
                return Fe(), Qe(), a
            }
            const xt = B("__proto__,__v_isRef,__isVue"),
                yt = new Set(Object.getOwnPropertyNames(Symbol).filter(e => "arguments" !== e && "caller" !== e).map(e => Symbol[e]).filter(X));

            function kt(e) {
                X(e) || (e = String(e));
                const t = Ht(this);
                return dt(t, 0, e), t.hasOwnProperty(e)
            }
            class vt {
                constructor(e = !1, t = !1) {
                    this._isReadonly = e, this._isShallow = t
                }
                get(e, t, n) {
                    if ("__v_skip" === t) return e.__v_skip;
                    const a = this._isReadonly,
                        r = this._isShallow;
                    if ("__v_isReactive" === t) return !a;
                    if ("__v_isReadonly" === t) return a;
                    if ("__v_isShallow" === t) return r;
                    if ("__v_raw" === t) return n === (a ? r ? Rt : Bt : r ? Dt : Tt).get(e) || Object.getPrototypeOf(e) === Object.getPrototypeOf(n) ? e : void 0;
                    const i = $(e);
                    if (!a) {
                        let e;
                        if (i && (e = pt[t])) return e;
                        if ("hasOwnProperty" === t) return kt
                    }
                    const o = Reflect.get(e, t, Zt(e) ? e : n);
                    if (X(t) ? yt.has(t) : xt(t)) return o;
                    if (a || dt(e, 0, t), r) return o;
                    if (Zt(o)) {
                        const e = i && ie(t) ? o : o.value;
                        return a && ee(e) ? Ut(e) : e
                    }
                    return ee(o) ? a ? Ut(o) : Mt(o) : o
                }
            }
            class Pt extends vt {
                constructor(e = !1) {
                    super(!1, e)
                }
                set(e, t, n, a) {
                    let r = e[t];
                    if (!this._isShallow) {
                        const t = Nt(r);
                        if (Gt(n) || Nt(n) || (r = Ht(r), n = Ht(n)), !$(e) && Zt(r) && !Zt(n)) return t || (r.value = n), !0
                    }
                    const i = $(e) && ie(t) ? Number(t) < e.length : K(e, t),
                        o = Reflect.set(e, t, n, Zt(e) ? e : a);
                    return e === Ht(a) && (i ? we(n, r) && lt(e, "set", t, n) : lt(e, "add", t, n)), o
                }
                deleteProperty(e, t) {
                    const n = K(e, t),
                        a = (e[t], Reflect.deleteProperty(e, t));
                    return a && n && lt(e, "delete", t, void 0), a
                }
                has(e, t) {
                    const n = Reflect.has(e, t);
                    return X(t) && yt.has(t) || dt(e, 0, t), n
                }
                ownKeys(e) {
                    return dt(e, 0, $(e) ? "length" : it), Reflect.ownKeys(e)
                }
            }
            class Ct extends vt {
                constructor(e = !1) {
                    super(!0, e)
                }
                set(e, t) {
                    return !0
                }
                deleteProperty(e, t) {
                    return !0
                }
            }
            const Ot = new Pt,
                St = new Ct,
                _t = new Pt(!0),
                It = e => e,
                At = e => Reflect.getPrototypeOf(e);

            function Et(e) {
                return function(...t) {
                    return "delete" !== e && ("clear" === e ? void 0 : this)
                }
            }

            function zt(e, t) {
                const n = function(e, t) {
                    const n = {
                        get(n) {
                            const a = this.__v_raw,
                                r = Ht(a),
                                i = Ht(n);
                            e || (we(n, i) && dt(r, 0, n), dt(r, 0, i));
                            const {
                                has: o
                            } = At(r), s = t ? It : e ? $t : Kt;
                            return o.call(r, n) ? s(a.get(n)) : o.call(r, i) ? s(a.get(i)) : void(a !== r && a.get(n))
                        },
                        get size() {
                            const t = this.__v_raw;
                            return !e && dt(Ht(t), 0, it), t.size
                        },
                        has(t) {
                            const n = this.__v_raw,
                                a = Ht(n),
                                r = Ht(t);
                            return e || (we(t, r) && dt(a, 0, t), dt(a, 0, r)), t === r ? n.has(t) : n.has(t) || n.has(r)
                        },
                        forEach(n, a) {
                            const r = this,
                                i = r.__v_raw,
                                o = Ht(i),
                                s = t ? It : e ? $t : Kt;
                            return !e && dt(o, 0, it), i.forEach((e, t) => n.call(a, s(e), s(t), r))
                        }
                    };
                    return G(n, e ? {
                        add: Et("add"),
                        set: Et("set"),
                        delete: Et("delete"),
                        clear: Et("clear")
                    } : {
                        add(e) {
                            t || Gt(e) || Nt(e) || (e = Ht(e));
                            const n = Ht(this);
                            return At(n).has.call(n, e) || (n.add(e), lt(n, "add", e, e)), this
                        },
                        set(e, n) {
                            t || Gt(n) || Nt(n) || (n = Ht(n));
                            const a = Ht(this),
                                {
                                    has: r,
                                    get: i
                                } = At(a);
                            let o = r.call(a, e);
                            o || (e = Ht(e), o = r.call(a, e));
                            const s = i.call(a, e);
                            return a.set(e, n), o ? we(n, s) && lt(a, "set", e, n) : lt(a, "add", e, n), this
                        },
                        delete(e) {
                            const t = Ht(this),
                                {
                                    has: n,
                                    get: a
                                } = At(t);
                            let r = n.call(t, e);
                            r || (e = Ht(e), r = n.call(t, e)), a && a.call(t, e);
                            const i = t.delete(e);
                            return r && lt(t, "delete", e, void 0), i
                        },
                        clear() {
                            const e = Ht(this),
                                t = 0 !== e.size,
                                n = e.clear();
                            return t && lt(e, "clear", void 0, void 0), n
                        }
                    }), ["keys", "values", "entries", Symbol.iterator].forEach(a => {
                        n[a] = function(e, t, n) {
                            return function(...a) {
                                const r = this.__v_raw,
                                    i = Ht(r),
                                    o = Z(i),
                                    s = "entries" === e || e === Symbol.iterator && o,
                                    d = "keys" === e && o,
                                    l = r[e](...a),
                                    c = n ? It : t ? $t : Kt;
                                return !t && dt(i, 0, d ? ot : it), {
                                    next() {
                                        const {
                                            value: e,
                                            done: t
                                        } = l.next();
                                        return t ? {
                                            value: e,
                                            done: t
                                        } : {
                                            value: s ? [c(e[0]), c(e[1])] : c(e),
                                            done: t
                                        }
                                    },
                                    [Symbol.iterator]() {
                                        return this
                                    }
                                }
                            }
                        }(a, e, t)
                    }), n
                }(e, t);
                return (t, a, r) => "__v_isReactive" === a ? !e : "__v_isReadonly" === a ? e : "__v_raw" === a ? t : Reflect.get(K(n, a) && a in t ? n : t, a, r)
            }
            const jt = {
                    get: zt(!1, !1)
                },
                Vt = {
                    get: zt(!1, !0)
                },
                Lt = {
                    get: zt(!0, !1)
                },
                Tt = new WeakMap,
                Dt = new WeakMap,
                Bt = new WeakMap,
                Rt = new WeakMap;

            function Mt(e) {
                return Nt(e) ? e : Wt(e, !1, Ot, jt, Tt)
            }

            function Ut(e) {
                return Wt(e, !0, St, Lt, Bt)
            }

            function Wt(e, t, n, a, r) {
                if (!ee(e)) return e;
                if (e.__v_raw && (!t || !e.__v_isReactive)) return e;
                const i = (o = e).__v_skip || !Object.isExtensible(o) ? 0 : function(e) {
                    switch (e) {
                        case "Object":
                        case "Array":
                            return 1;
                        case "Map":
                        case "Set":
                        case "WeakMap":
                        case "WeakSet":
                            return 2;
                        default:
                            return 0
                    }
                }((e => ae(e).slice(8, -1))(o));
                var o;
                if (0 === i) return e;
                const s = r.get(e);
                if (s) return s;
                const d = new Proxy(e, 2 === i ? a : n);
                return r.set(e, d), d
            }

            function Ft(e) {
                return Nt(e) ? Ft(e.__v_raw) : !(!e || !e.__v_isReactive)
            }

            function Nt(e) {
                return !(!e || !e.__v_isReadonly)
            }

            function Gt(e) {
                return !(!e || !e.__v_isShallow)
            }

            function qt(e) {
                return !!e && !!e.__v_raw
            }

            function Ht(e) {
                const t = e && e.__v_raw;
                return t ? Ht(t) : e
            }
            const Kt = e => ee(e) ? Mt(e) : e,
                $t = e => ee(e) ? Ut(e) : e;

            function Zt(e) {
                return !!e && !0 === e.__v_isRef
            }

            function Jt(e) {
                return Yt(e, !1)
            }

            function Yt(e, t) {
                return Zt(e) ? e : new Qt(e, t)
            }
            class Qt {
                constructor(e, t) {
                    this.dep = new nt, this.__v_isRef = !0, this.__v_isShallow = !1, this._rawValue = t ? e : Ht(e), this._value = t ? e : Kt(e), this.__v_isShallow = t
                }
                get value() {
                    return this.dep.track(), this._value
                }
                set value(e) {
                    const t = this._rawValue,
                        n = this.__v_isShallow || Gt(e) || Nt(e);
                    e = n ? e : Ht(e), we(e, t) && (this._rawValue = e, this._value = n ? e : Kt(e), this.dep.trigger())
                }
            }

            function Xt(e) {
                return Zt(e) ? e.value : e
            }
            const en = {
                get: (e, t, n) => "__v_raw" === t ? e : Xt(Reflect.get(e, t, n)),
                set: (e, t, n, a) => {
                    const r = e[t];
                    return Zt(r) && !Zt(n) ? (r.value = n, !0) : Reflect.set(e, t, n, a)
                }
            };

            function tn(e) {
                return Ft(e) ? e : new Proxy(e, en)
            }
            class nn {
                constructor(e, t, n) {
                    this.fn = e, this.setter = t, this._value = void 0, this.dep = new nt(this), this.__v_isRef = !0, this.deps = void 0, this.depsTail = void 0, this.flags = 16, this.globalVersion = et - 1, this.next = void 0, this.effect = this, this.__v_isReadonly = !t, this.isSSR = n
                }
                notify() {
                    if (this.flags |= 16, !(8 & this.flags || Ve === this)) return Ue(this, !0), !0
                }
                get value() {
                    const e = this.dep.track();
                    return He(this), e && (e.version = this.dep.version), this._value
                }
                set value(e) {
                    this.setter && this.setter(e)
                }
            }
            const an = {},
                rn = new WeakMap;
            let on;

            function sn(e, t = 1 / 0, n) {
                if (t <= 0 || !ee(e) || e.__v_skip) return e;
                if (((n = n || new Map).get(e) || 0) >= t) return e;
                if (n.set(e, t), t--, Zt(e)) sn(e.value, t, n);
                else if ($(e))
                    for (let a = 0; a < e.length; a++) sn(e[a], t, n);
                else if (J(e) || Z(e)) e.forEach(e => {
                    sn(e, t, n)
                });
                else if (re(e)) {
                    for (const a in e) sn(e[a], t, n);
                    for (const a of Object.getOwnPropertySymbols(e)) Object.prototype.propertyIsEnumerable.call(e, a) && sn(e[a], t, n)
                }
                return e
            }

            function dn(e, t, n, a) {
                try {
                    return a ? e(...a) : e()
                } catch (e) {
                    cn(e, t, n)
                }
            }

            function ln(e, t, n, a) {
                if (Y(e)) {
                    const r = dn(e, t, n, a);
                    return r && te(r) && r.catch(e => {
                        cn(e, t, n)
                    }), r
                }
                if ($(e)) {
                    const r = [];
                    for (let i = 0; i < e.length; i++) r.push(ln(e[i], t, n, a));
                    return r
                }
            }

            function cn(e, t, n, a = !0) {
                t && t.vnode;
                const {
                    errorHandler: r,
                    throwUnhandledErrorInProduction: i
                } = t && t.appContext.config || R;
                if (t) {
                    let a = t.parent;
                    const i = t.proxy,
                        o = `https://vuejs.org/error-reference/#runtime-${n}`;
                    for (; a;) {
                        const t = a.ec;
                        if (t)
                            for (let n = 0; n < t.length; n++)
                                if (!1 === t[n](e, i, o)) return;
                        a = a.parent
                    }
                    if (r) return Ye(), dn(r, null, 10, [e, i, o]), void Qe()
                }! function(e, t, n, a = !0, r = !1) {
                    if (r) throw e;
                    console.error(e)
                }(e, 0, 0, a, i)
            }
            const un = [];
            let pn = -1;
            const hn = [];
            let wn = null,
                gn = 0;
            const mn = Promise.resolve();
            let fn = null;

            function bn(e) {
                const t = fn || mn;
                return e ? t.then(this ? e.bind(this) : e) : t
            }

            function xn(e) {
                if (!(1 & e.flags)) {
                    const t = Pn(e),
                        n = un[un.length - 1];
                    !n || !(2 & e.flags) && t >= Pn(n) ? un.push(e) : un.splice(function(e) {
                        let t = pn + 1,
                            n = un.length;
                        for (; t < n;) {
                            const a = t + n >>> 1,
                                r = un[a],
                                i = Pn(r);
                            i < e || i === e && 2 & r.flags ? t = a + 1 : n = a
                        }
                        return t
                    }(t), 0, e), e.flags |= 1, yn()
                }
            }

            function yn() {
                fn || (fn = mn.then(Cn))
            }

            function kn(e, t, n = pn + 1) {
                for (; n < un.length; n++) {
                    const t = un[n];
                    if (t && 2 & t.flags) {
                        if (e && t.id !== e.uid) continue;
                        un.splice(n, 1), n--, 4 & t.flags && (t.flags &= -2), t(), 4 & t.flags || (t.flags &= -2)
                    }
                }
            }

            function vn(e) {
                if (hn.length) {
                    const e = [...new Set(hn)].sort((e, t) => Pn(e) - Pn(t));
                    if (hn.length = 0, wn) return void wn.push(...e);
                    for (wn = e, gn = 0; gn < wn.length; gn++) {
                        const e = wn[gn];
                        4 & e.flags && (e.flags &= -2), 8 & e.flags || e(), e.flags &= -2
                    }
                    wn = null, gn = 0
                }
            }
            const Pn = e => null == e.id ? 2 & e.flags ? -1 : 1 / 0 : e.id;

            function Cn(e) {
                try {
                    for (pn = 0; pn < un.length; pn++) {
                        const e = un[pn];
                        !e || 8 & e.flags || (4 & e.flags && (e.flags &= -2), dn(e, e.i, e.i ? 15 : 14), 4 & e.flags || (e.flags &= -2))
                    }
                } finally {
                    for (; pn < un.length; pn++) {
                        const e = un[pn];
                        e && (e.flags &= -2)
                    }
                    pn = -1, un.length = 0, vn(), fn = null, (un.length || hn.length) && Cn(e)
                }
            }
            let On, Sn = [],
                _n = !1;

            function In(e, ...t) {
                On ? On.emit(e, ...t) : _n || Sn.push({
                    event: e,
                    args: t
                })
            }

            function An(e, t) {
                var n, a;
                On = e, On ? (On.enabled = !0, Sn.forEach(({
                    event: e,
                    args: t
                }) => On.emit(e, ...t)), Sn = []) : "undefined" != typeof window && window.HTMLElement && !(null == (a = null == (n = window.navigator) ? void 0 : n.userAgent) ? void 0 : a.includes("jsdom")) ? ((t.__VUE_DEVTOOLS_HOOK_REPLAY__ = t.__VUE_DEVTOOLS_HOOK_REPLAY__ || []).push(e => {
                    An(e, t)
                }), setTimeout(() => {
                    On || (t.__VUE_DEVTOOLS_HOOK_REPLAY__ = null, _n = !0, Sn = [])
                }, 3e3)) : (_n = !0, Sn = [])
            }
            const En = Vn("component:added"),
                zn = Vn("component:updated"),
                jn = Vn("component:removed");

            function Vn(e) {
                return t => {
                    In(e, t.appContext.app, t.uid, t.parent ? t.parent.uid : void 0, t)
                }
            }
            let Ln = null,
                Tn = null;

            function Dn(e) {
                const t = Ln;
                return Ln = e, Tn = e && e.type.__scopeId || null, t
            }

            function Bn(e, t) {
                if (null === Ln) return e;
                const n = si(Ln),
                    a = e.dirs || (e.dirs = []);
                for (let e = 0; e < t.length; e++) {
                    let [r, i, o, s = R] = t[e];
                    r && (Y(r) && (r = {
                        mounted: r,
                        updated: r
                    }), r.deep && sn(i), a.push({
                        dir: r,
                        instance: n,
                        value: i,
                        oldValue: void 0,
                        arg: o,
                        modifiers: s
                    }))
                }
                return e
            }

            function Rn(e, t, n, a) {
                const r = e.dirs,
                    i = t && t.dirs;
                for (let o = 0; o < r.length; o++) {
                    const s = r[o];
                    i && (s.oldValue = i[o].value);
                    let d = s.dir[a];
                    d && (Ye(), ln(d, n, 8, [e.el, s, e, t]), Qe())
                }
            }
            const Mn = Symbol("_vte"),
                Un = Symbol("_leaveCb");
            Symbol("_enterCb");

            function Wn(e, t) {
                6 & e.shapeFlag && e.component ? (e.transition = t, Wn(e.component.subTree, t)) : 128 & e.shapeFlag ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t
            }

            function Fn(e) {
                e.ids = [e.ids[0] + e.ids[2]++ + "-", 0, 0]
            }

            function Nn(e) {
                const t = Zr(),
                    n = Yt(null, !0);
                if (t) {
                    const a = t.refs === R ? t.refs = {} : t.refs;
                    Object.defineProperty(a, e, {
                        enumerable: !0,
                        get: () => n.value,
                        set: e => n.value = e
                    })
                }
                return n
            }
            Boolean, Boolean;
            const Gn = new WeakMap;

            function qn(e, t, n, a, r = !1) {
                if ($(e)) return void e.forEach((e, i) => qn(e, t && ($(t) ? t[i] : t), n, a, r));
                if (Kn(a) && !r) return void(512 & a.shapeFlag && a.type.__asyncResolved && a.component.subTree.component && qn(e, t, n, a.component.subTree));
                const i = 4 & a.shapeFlag ? si(a.component) : a.el,
                    o = r ? null : i,
                    {
                        i: s,
                        r: d
                    } = e,
                    l = t && t.r,
                    c = s.refs === R ? s.refs = {} : s.refs,
                    u = s.setupState,
                    p = Ht(u),
                    h = u === R ? W : e => K(p, e);
                if (null != l && l !== d)
                    if (Hn(t), Q(l)) c[l] = null, h(l) && (u[l] = null);
                    else if (Zt(l)) {
                    l.value = null;
                    const e = t;
                    e.k && (c[e.k] = null)
                }
                if (Y(d)) dn(d, s, 12, [o, c]);
                else {
                    const t = Q(d),
                        a = Zt(d);
                    if (t || a) {
                        const s = () => {
                            if (e.f) {
                                const n = t ? h(d) ? u[d] : c[d] : d.value;
                                if (r) $(n) && q(n, i);
                                else if ($(n)) n.includes(i) || n.push(i);
                                else if (t) c[d] = [i], h(d) && (u[d] = c[d]);
                                else {
                                    const t = [i];
                                    d.value = t, e.k && (c[e.k] = t)
                                }
                            } else t ? (c[d] = o, h(d) && (u[d] = o)) : a && (d.value = o, e.k && (c[e.k] = o))
                        };
                        if (o) {
                            const t = () => {
                                s(), Gn.delete(e)
                            };
                            t.id = -1, Gn.set(e, t), Ya(t, n)
                        } else Hn(e), s()
                    }
                }
            }

            function Hn(e) {
                const t = Gn.get(e);
                t && (t.flags |= 8, Gn.delete(e))
            }
            xe().requestIdleCallback, xe().cancelIdleCallback;
            const Kn = e => !!e.type.__asyncLoader,
                $n = e => e.type.__isKeepAlive;

            function Zn(e, t) {
                Yn(e, "a", t)
            }

            function Jn(e, t) {
                Yn(e, "da", t)
            }

            function Yn(e, t, n = $r) {
                const a = e.__wdc || (e.__wdc = () => {
                    let t = n;
                    for (; t;) {
                        if (t.isDeactivated) return;
                        t = t.parent
                    }
                    return e()
                });
                if (Xn(t, a, n), n) {
                    let e = n.parent;
                    for (; e && e.parent;) $n(e.parent.vnode) && Qn(a, t, n, e), e = e.parent
                }
            }

            function Qn(e, t, n, a) {
                const r = Xn(t, e, a, !0);
                oa(() => {
                    q(a[t], r)
                }, n)
            }

            function Xn(e, t, n = $r, a = !1) {
                if (n) {
                    const r = n[e] || (n[e] = []),
                        i = t.__weh || (t.__weh = (...a) => {
                            Ye();
                            const r = Qr(n),
                                i = ln(t, n, e, a);
                            return r(), Qe(), i
                        });
                    return a ? r.unshift(i) : r.push(i), i
                }
            }
            RegExp, RegExp;
            const ea = e => (t, n = $r) => {
                    ai && "sp" !== e || Xn(e, (...e) => t(...e), n)
                },
                ta = ea("bm"),
                na = ea("m"),
                aa = ea("bu"),
                ra = ea("u"),
                ia = ea("bum"),
                oa = ea("um"),
                sa = ea("sp"),
                da = ea("rtg"),
                la = ea("rtc");

            function ca(e, t = $r) {
                Xn("ec", e, t)
            }
            const ua = "components";

            function pa(e, t) {
                return function(e, t, n = !0, a = !1) {
                    const r = Ln || $r;
                    if (r) {
                        const n = r.type;
                        if (e === ua) {
                            const e = function(e, t = !0) {
                                return Y(e) ? e.displayName || e.name : e.name || t && e.__name
                            }(n, !1);
                            if (e && (e === t || e === le(t) || e === pe(le(t)))) return n
                        }
                        const i = wa(r[e] || n[e], t) || wa(r.appContext[e], t);
                        return !i && a ? n : i
                    }
                }(ua, e, !0, t) || e
            }
            const ha = Symbol.for("v-ndc");

            function wa(e, t) {
                return e && (e[t] || e[le(t)] || e[pe(le(t))])
            }

            function ga(e, t, n, a) {
                let r;
                const i = n && n[a],
                    o = $(e);
                if (o || Q(e)) {
                    let n = !1,
                        a = !1;
                    o && Ft(e) && (n = !Gt(e), a = Nt(e), e = ut(e)), r = new Array(e.length);
                    for (let o = 0, s = e.length; o < s; o++) r[o] = t(n ? a ? $t(Kt(e[o])) : Kt(e[o]) : e[o], o, void 0, i && i[o])
                } else if ("number" == typeof e) {
                    r = new Array(e);
                    for (let n = 0; n < e; n++) r[n] = t(n + 1, n, void 0, i && i[n])
                } else if (ee(e))
                    if (e[Symbol.iterator]) r = Array.from(e, (e, n) => t(e, n, void 0, i && i[n]));
                    else {
                        const n = Object.keys(e);
                        r = new Array(n.length);
                        for (let a = 0, o = n.length; a < o; a++) {
                            const o = n[a];
                            r[a] = t(e[o], o, a, i && i[a])
                        }
                    }
                else r = [];
                return n && (n[a] = r), r
            }
            const ma = e => e ? ei(e) ? si(e) : ma(e.parent) : null,
                fa = G(Object.create(null), {
                    $: e => e,
                    $el: e => e.vnode.el,
                    $data: e => e.data,
                    $props: e => e.props,
                    $attrs: e => e.attrs,
                    $slots: e => e.slots,
                    $refs: e => e.refs,
                    $parent: e => ma(e.parent),
                    $root: e => ma(e.root),
                    $host: e => e.ce,
                    $emit: e => e.emit,
                    $options: e => __VUE_OPTIONS_API__ ? Ca(e) : e.type,
                    $forceUpdate: e => e.f || (e.f = () => {
                        xn(e.update)
                    }),
                    $nextTick: e => e.n || (e.n = bn.bind(e.proxy)),
                    $watch: e => __VUE_OPTIONS_API__ ? dr.bind(e) : U
                }),
                ba = (e, t) => e !== R && !e.__isScriptSetup && K(e, t),
                xa = {
                    get({
                        _: e
                    }, t) {
                        if ("__v_skip" === t) return !0;
                        const {
                            ctx: n,
                            setupState: a,
                            data: r,
                            props: i,
                            accessCache: o,
                            type: s,
                            appContext: d
                        } = e;
                        let l;
                        if ("$" !== t[0]) {
                            const s = o[t];
                            if (void 0 !== s) switch (s) {
                                case 1:
                                    return a[t];
                                case 2:
                                    return r[t];
                                case 4:
                                    return n[t];
                                case 3:
                                    return i[t]
                            } else {
                                if (ba(a, t)) return o[t] = 1, a[t];
                                if (r !== R && K(r, t)) return o[t] = 2, r[t];
                                if ((l = e.propsOptions[0]) && K(l, t)) return o[t] = 3, i[t];
                                if (n !== R && K(n, t)) return o[t] = 4, n[t];
                                __VUE_OPTIONS_API__ && !ka || (o[t] = 0)
                            }
                        }
                        const c = fa[t];
                        let u, p;
                        return c ? ("$attrs" === t && dt(e.attrs, 0, ""), c(e)) : (u = s.__cssModules) && (u = u[t]) ? u : n !== R && K(n, t) ? (o[t] = 4, n[t]) : (p = d.config.globalProperties, K(p, t) ? p[t] : void 0)
                    },
                    set({
                        _: e
                    }, t, n) {
                        const {
                            data: a,
                            setupState: r,
                            ctx: i
                        } = e;
                        return ba(r, t) ? (r[t] = n, !0) : a !== R && K(a, t) ? (a[t] = n, !0) : !(K(e.props, t) || "$" === t[0] && t.slice(1) in e || (i[t] = n, 0))
                    },
                    has({
                        _: {
                            data: e,
                            setupState: t,
                            accessCache: n,
                            ctx: a,
                            appContext: r,
                            propsOptions: i,
                            type: o
                        }
                    }, s) {
                        let d, l;
                        return !!(n[s] || e !== R && "$" !== s[0] && K(e, s) || ba(t, s) || (d = i[0]) && K(d, s) || K(a, s) || K(fa, s) || K(r.config.globalProperties, s) || (l = o.__cssModules) && l[s])
                    },
                    defineProperty(e, t, n) {
                        return null != n.get ? e._.accessCache[t] = 0 : K(n, "value") && this.set(e, t, n.value, null), Reflect.defineProperty(e, t, n)
                    }
                };

            function ya(e) {
                return $(e) ? e.reduce((e, t) => (e[t] = null, e), {}) : e
            }
            let ka = !0;

            function va(e, t, n) {
                ln($(e) ? e.map(e => e.bind(t.proxy)) : e.bind(t.proxy), t, n)
            }

            function Pa(e, t, n, a) {
                let r = a.includes(".") ? lr(n, a) : () => n[a];
                if (Q(e)) {
                    const n = t[e];
                    Y(n) && or(r, n)
                } else if (Y(e)) or(r, e.bind(n));
                else if (ee(e))
                    if ($(e)) e.forEach(e => Pa(e, t, n, a));
                    else {
                        const a = Y(e.handler) ? e.handler.bind(n) : t[e.handler];
                        Y(a) && or(r, a, e)
                    }
            }

            function Ca(e) {
                const t = e.type,
                    {
                        mixins: n,
                        extends: a
                    } = t,
                    {
                        mixins: r,
                        optionsCache: i,
                        config: {
                            optionMergeStrategies: o
                        }
                    } = e.appContext,
                    s = i.get(t);
                let d;
                return s ? d = s : r.length || n || a ? (d = {}, r.length && r.forEach(e => Oa(d, e, o, !0)), Oa(d, t, o)) : d = t, ee(t) && i.set(t, d), d
            }

            function Oa(e, t, n, a = !1) {
                const {
                    mixins: r,
                    extends: i
                } = t;
                i && Oa(e, i, n, !0), r && r.forEach(t => Oa(e, t, n, !0));
                for (const r in t)
                    if (a && "expose" === r);
                    else {
                        const a = Sa[r] || n && n[r];
                        e[r] = a ? a(e[r], t[r]) : t[r]
                    }
                return e
            }
            const Sa = {
                data: _a,
                props: za,
                emits: za,
                methods: Ea,
                computed: Ea,
                beforeCreate: Aa,
                created: Aa,
                beforeMount: Aa,
                mounted: Aa,
                beforeUpdate: Aa,
                updated: Aa,
                beforeDestroy: Aa,
                beforeUnmount: Aa,
                destroyed: Aa,
                unmounted: Aa,
                activated: Aa,
                deactivated: Aa,
                errorCaptured: Aa,
                serverPrefetch: Aa,
                components: Ea,
                directives: Ea,
                watch: function(e, t) {
                    if (!e) return t;
                    if (!t) return e;
                    const n = G(Object.create(null), e);
                    for (const a in t) n[a] = Aa(e[a], t[a]);
                    return n
                },
                provide: _a,
                inject: function(e, t) {
                    return Ea(Ia(e), Ia(t))
                }
            };

            function _a(e, t) {
                return t ? e ? function() {
                    return G(Y(e) ? e.call(this, this) : e, Y(t) ? t.call(this, this) : t)
                } : t : e
            }

            function Ia(e) {
                if ($(e)) {
                    const t = {};
                    for (let n = 0; n < e.length; n++) t[e[n]] = e[n];
                    return t
                }
                return e
            }

            function Aa(e, t) {
                return e ? [...new Set([].concat(e, t))] : t
            }

            function Ea(e, t) {
                return e ? G(Object.create(null), e, t) : t
            }

            function za(e, t) {
                return e ? $(e) && $(t) ? [...new Set([...e, ...t])] : G(Object.create(null), ya(e), ya(null != t ? t : {})) : t
            }

            function ja() {
                return {
                    app: null,
                    config: {
                        isNativeTag: W,
                        performance: !1,
                        globalProperties: {},
                        optionMergeStrategies: {},
                        errorHandler: void 0,
                        warnHandler: void 0,
                        compilerOptions: {}
                    },
                    mixins: [],
                    components: {},
                    directives: {},
                    provides: Object.create(null),
                    optionsCache: new WeakMap,
                    propsCache: new WeakMap,
                    emitsCache: new WeakMap
                }
            }
            let Va = 0;

            function La(e, t) {
                return function(n, a = null) {
                    Y(n) || (n = G({}, n)), null == a || ee(a) || (a = null);
                    const r = ja(),
                        i = new WeakSet,
                        o = [];
                    let s = !1;
                    const d = r.app = {
                        _uid: Va++,
                        _component: n,
                        _props: a,
                        _container: null,
                        _context: r,
                        _instance: null,
                        version: li,
                        get config() {
                            return r.config
                        },
                        set config(e) {},
                        use(e, ...t) {
                            return i.has(e) || (e && Y(e.install) ? (i.add(e), e.install(d, ...t)) : Y(e) && (i.add(e), e(d, ...t))), d
                        },
                        mixin(e) {
                            return __VUE_OPTIONS_API__ && (r.mixins.includes(e) || r.mixins.push(e)), d
                        },
                        component(e, t) {
                            return t ? (r.components[e] = t, d) : r.components[e]
                        },
                        directive(e, t) {
                            return t ? (r.directives[e] = t, d) : r.directives[e]
                        },
                        mount(i, o, l) {
                            if (!s) {
                                const c = d._ceVNode || Br(n, a);
                                return c.appContext = r, !0 === l ? l = "svg" : !1 === l && (l = void 0), o && t ? t(c, i) : e(c, i, l), s = !0, d._container = i, i.__vue_app__ = d, __VUE_PROD_DEVTOOLS__ && (d._instance = c.component, function(e, t) {
                                    In("app:init", e, t, {
                                        Fragment: yr,
                                        Text: kr,
                                        Comment: vr,
                                        Static: Pr
                                    })
                                }(d, li)), si(c.component)
                            }
                        },
                        onUnmount(e) {
                            o.push(e)
                        },
                        unmount() {
                            s && (ln(o, d._instance, 16), e(null, d._container), __VUE_PROD_DEVTOOLS__ && (d._instance = null, function(e) {
                                In("app:unmount", e)
                            }(d)), delete d._container.__vue_app__)
                        },
                        provide(e, t) {
                            return r.provides[e] = t, d
                        },
                        runWithContext(e) {
                            const t = Ta;
                            Ta = d;
                            try {
                                return e()
                            } finally {
                                Ta = t
                            }
                        }
                    };
                    return d
                }
            }
            let Ta = null;

            function Da(e, t, n = !1) {
                const a = Zr();
                if (a || Ta) {
                    let r = Ta ? Ta._context.provides : a ? null == a.parent || a.ce ? a.vnode.appContext && a.vnode.appContext.provides : a.parent.provides : void 0;
                    if (r && e in r) return r[e];
                    if (arguments.length > 1) return n && Y(t) ? t.call(a && a.proxy) : t
                }
            }
            const Ba = {},
                Ra = () => Object.create(Ba),
                Ma = e => Object.getPrototypeOf(e) === Ba;

            function Ua(e, t, n, a) {
                const [r, i] = e.propsOptions;
                let o, s = !1;
                if (t)
                    for (let d in t) {
                        if (oe(d)) continue;
                        const l = t[d];
                        let c;
                        r && K(r, c = le(d)) ? i && i.includes(c) ? (o || (o = {}))[c] = l : n[c] = l : wr(e.emitsOptions, d) || d in a && l === a[d] || (a[d] = l, s = !0)
                    }
                if (i) {
                    const t = Ht(n),
                        a = o || R;
                    for (let o = 0; o < i.length; o++) {
                        const s = i[o];
                        n[s] = Wa(r, t, s, a[s], e, !K(a, s))
                    }
                }
                return s
            }

            function Wa(e, t, n, a, r, i) {
                const o = e[n];
                if (null != o) {
                    const e = K(o, "default");
                    if (e && void 0 === a) {
                        const e = o.default;
                        if (o.type !== Function && !o.skipFactory && Y(e)) {
                            const {
                                propsDefaults: i
                            } = r;
                            if (n in i) a = i[n];
                            else {
                                const o = Qr(r);
                                a = i[n] = e.call(null, t), o()
                            }
                        } else a = e;
                        r.ce && r.ce._setProp(n, a)
                    }
                    o[0] && (i && !e ? a = !1 : !o[1] || "" !== a && a !== ue(n) || (a = !0))
                }
                return a
            }
            const Fa = new WeakMap;

            function Na(e, t, n = !1) {
                const a = __VUE_OPTIONS_API__ && n ? Fa : t.propsCache,
                    r = a.get(e);
                if (r) return r;
                const i = e.props,
                    o = {},
                    s = [];
                let d = !1;
                if (__VUE_OPTIONS_API__ && !Y(e)) {
                    const a = e => {
                        d = !0;
                        const [n, a] = Na(e, t, !0);
                        G(o, n), a && s.push(...a)
                    };
                    !n && t.mixins.length && t.mixins.forEach(a), e.extends && a(e.extends), e.mixins && e.mixins.forEach(a)
                }
                if (!i && !d) return ee(e) && a.set(e, M), M;
                if ($(i))
                    for (let e = 0; e < i.length; e++) {
                        const t = le(i[e]);
                        Ga(t) && (o[t] = R)
                    } else if (i)
                        for (const e in i) {
                            const t = le(e);
                            if (Ga(t)) {
                                const n = i[e],
                                    a = o[t] = $(n) || Y(n) ? {
                                        type: n
                                    } : G({}, n),
                                    r = a.type;
                                let d = !1,
                                    l = !0;
                                if ($(r))
                                    for (let e = 0; e < r.length; ++e) {
                                        const t = r[e],
                                            n = Y(t) && t.name;
                                        if ("Boolean" === n) {
                                            d = !0;
                                            break
                                        }
                                        "String" === n && (l = !1)
                                    } else d = Y(r) && "Boolean" === r.name;
                                a[0] = d, a[1] = l, (d || K(a, "default")) && s.push(t)
                            }
                        }
                const l = [o, s];
                return ee(e) && a.set(e, l), l
            }

            function Ga(e) {
                return "$" !== e[0] && !oe(e)
            }
            const qa = e => "_" === e || "_ctx" === e || "$stable" === e,
                Ha = e => $(e) ? e.map(Fr) : [Fr(e)],
                Ka = (e, t, n) => {
                    if (t._n) return t;
                    const a = function(e, t = Ln) {
                        if (!t) return e;
                        if (e._n) return e;
                        const n = (...a) => {
                            n._d && Ir(-1);
                            const r = Dn(t);
                            let i;
                            try {
                                i = e(...a)
                            } finally {
                                Dn(r), n._d && Ir(1)
                            }
                            return __VUE_PROD_DEVTOOLS__ && zn(t), i
                        };
                        return n._n = !0, n._c = !0, n._d = !0, n
                    }((...e) => Ha(t(...e)), n);
                    return a._c = !1, a
                },
                $a = (e, t, n) => {
                    const a = e._ctx;
                    for (const n in e) {
                        if (qa(n)) continue;
                        const r = e[n];
                        if (Y(r)) t[n] = Ka(0, r, a);
                        else if (null != r) {
                            const e = Ha(r);
                            t[n] = () => e
                        }
                    }
                },
                Za = (e, t) => {
                    const n = Ha(t);
                    e.slots.default = () => n
                },
                Ja = (e, t, n) => {
                    for (const a in t) !n && qa(a) || (e[a] = t[a])
                },
                Ya = function(e, t) {
                    t && t.pendingBranch ? $(e) ? t.effects.push(...e) : t.effects.push(e) : (n = e, $(n) ? hn.push(...n) : wn && -1 === n.id ? wn.splice(gn + 1, 0, n) : 1 & n.flags || (hn.push(n), n.flags |= 1), yn());
                    var n
                };

            function Qa(e, t) {
                "boolean" != typeof __VUE_OPTIONS_API__ && (xe().__VUE_OPTIONS_API__ = !0), "boolean" != typeof __VUE_PROD_DEVTOOLS__ && (xe().__VUE_PROD_DEVTOOLS__ = !1), "boolean" != typeof __VUE_PROD_HYDRATION_MISMATCH_DETAILS__ && (xe().__VUE_PROD_HYDRATION_MISMATCH_DETAILS__ = !1);
                const n = xe();
                n.__VUE__ = !0, __VUE_PROD_DEVTOOLS__ && An(n.__VUE_DEVTOOLS_GLOBAL_HOOK__, n);
                const {
                    insert: a,
                    remove: r,
                    patchProp: i,
                    createElement: o,
                    createText: s,
                    createComment: d,
                    setText: l,
                    setElementText: c,
                    parentNode: u,
                    nextSibling: p,
                    setScopeId: h = U,
                    insertStaticContent: w
                } = e, g = (e, t, n, a = null, r = null, i = null, o = void 0, s = null, d = !!t.dynamicChildren) => {
                    if (e === t) return;
                    e && !Vr(e, t) && (a = G(e), D(e, r, i, !0), e = null), -2 === t.patchFlag && (d = !1, t.dynamicChildren = null);
                    const {
                        type: l,
                        ref: c,
                        shapeFlag: u
                    } = t;
                    switch (l) {
                        case kr:
                            m(e, t, n, a);
                            break;
                        case vr:
                            f(e, t, n, a);
                            break;
                        case Pr:
                            null == e && b(t, n, a, o);
                            break;
                        case yr:
                            S(e, t, n, a, r, i, o, s, d);
                            break;
                        default:
                            1 & u ? x(e, t, n, a, r, i, o, s, d) : 6 & u ? _(e, t, n, a, r, i, o, s, d) : (64 & u || 128 & u) && l.process(e, t, n, a, r, i, o, s, d, $)
                    }
                    null != c && r ? qn(c, e && e.ref, i, t || e, !t) : null == c && e && null != e.ref && qn(e.ref, null, i, e, !0)
                }, m = (e, t, n, r) => {
                    if (null == e) a(t.el = s(t.children), n, r);
                    else {
                        const n = t.el = e.el;
                        t.children !== e.children && l(n, t.children)
                    }
                }, f = (e, t, n, r) => {
                    null == e ? a(t.el = d(t.children || ""), n, r) : t.el = e.el
                }, b = (e, t, n, a) => {
                    [e.el, e.anchor] = w(e.children, t, n, a, e.el, e.anchor)
                }, x = (e, t, n, a, r, i, o, s, d) => {
                    "svg" === t.type ? o = "svg" : "math" === t.type && (o = "mathml"), null == e ? y(t, n, a, r, i, o, s, d) : P(e, t, r, i, o, s, d)
                }, y = (e, t, n, r, s, d, l, u) => {
                    let p, h;
                    const {
                        props: w,
                        shapeFlag: g,
                        transition: m,
                        dirs: f
                    } = e;
                    if (p = e.el = o(e.type, d, w && w.is, w), 8 & g ? c(p, e.children) : 16 & g && v(e.children, p, null, r, s, Xa(e, d), l, u), f && Rn(e, null, r, "created"), k(p, e, e.scopeId, l, r), w) {
                        for (const e in w) "value" === e || oe(e) || i(p, e, null, w[e], d, r);
                        "value" in w && i(p, "value", null, w.value, d), (h = w.onVnodeBeforeMount) && qr(h, r, e)
                    }
                    __VUE_PROD_DEVTOOLS__ && (me(p, "__vnode", e, !0), me(p, "__vueParentComponent", r, !0)), f && Rn(e, null, r, "beforeMount");
                    const b = function(e, t) {
                        return (!e || e && !e.pendingBranch) && t && !t.persisted
                    }(s, m);
                    b && m.beforeEnter(p), a(p, t, n), ((h = w && w.onVnodeMounted) || b || f) && Ya(() => {
                        h && qr(h, r, e), b && m.enter(p), f && Rn(e, null, r, "mounted")
                    }, s)
                }, k = (e, t, n, a, r) => {
                    if (n && h(e, n), a)
                        for (let t = 0; t < a.length; t++) h(e, a[t]);
                    if (r) {
                        let n = r.subTree;
                        if (t === n || xr(n.type) && (n.ssContent === t || n.ssFallback === t)) {
                            const t = r.vnode;
                            k(e, t, t.scopeId, t.slotScopeIds, r.parent)
                        }
                    }
                }, v = (e, t, n, a, r, i, o, s, d = 0) => {
                    for (let l = d; l < e.length; l++) {
                        const d = e[l] = s ? Nr(e[l]) : Fr(e[l]);
                        g(null, d, t, n, a, r, i, o, s)
                    }
                }, P = (e, t, n, a, r, o, s) => {
                    const d = t.el = e.el;
                    __VUE_PROD_DEVTOOLS__ && (d.__vnode = t);
                    let {
                        patchFlag: l,
                        dynamicChildren: u,
                        dirs: p
                    } = t;
                    l |= 16 & e.patchFlag;
                    const h = e.props || R,
                        w = t.props || R;
                    let g;
                    if (n && er(n, !1), (g = w.onVnodeBeforeUpdate) && qr(g, n, t, e), p && Rn(t, e, n, "beforeUpdate"), n && er(n, !0), (h.innerHTML && null == w.innerHTML || h.textContent && null == w.textContent) && c(d, ""), u ? C(e.dynamicChildren, u, d, n, a, Xa(t, r), o) : s || j(e, t, d, null, n, a, Xa(t, r), o, !1), l > 0) {
                        if (16 & l) O(d, h, w, n, r);
                        else if (2 & l && h.class !== w.class && i(d, "class", null, w.class, r), 4 & l && i(d, "style", h.style, w.style, r), 8 & l) {
                            const e = t.dynamicProps;
                            for (let t = 0; t < e.length; t++) {
                                const a = e[t],
                                    o = h[a],
                                    s = w[a];
                                s === o && "value" !== a || i(d, a, o, s, r, n)
                            }
                        }
                        1 & l && e.children !== t.children && c(d, t.children)
                    } else s || null != u || O(d, h, w, n, r);
                    ((g = w.onVnodeUpdated) || p) && Ya(() => {
                        g && qr(g, n, t, e), p && Rn(t, e, n, "updated")
                    }, a)
                }, C = (e, t, n, a, r, i, o) => {
                    for (let s = 0; s < t.length; s++) {
                        const d = e[s],
                            l = t[s],
                            c = d.el && (d.type === yr || !Vr(d, l) || 198 & d.shapeFlag) ? u(d.el) : n;
                        g(d, l, c, null, a, r, i, o, !0)
                    }
                }, O = (e, t, n, a, r) => {
                    if (t !== n) {
                        if (t !== R)
                            for (const o in t) oe(o) || o in n || i(e, o, t[o], null, r, a);
                        for (const o in n) {
                            if (oe(o)) continue;
                            const s = n[o],
                                d = t[o];
                            s !== d && "value" !== o && i(e, o, d, s, r, a)
                        }
                        "value" in n && i(e, "value", t.value, n.value, r)
                    }
                }, S = (e, t, n, r, i, o, d, l, c) => {
                    const u = t.el = e ? e.el : s(""),
                        p = t.anchor = e ? e.anchor : s("");
                    let {
                        patchFlag: h,
                        dynamicChildren: w,
                        slotScopeIds: g
                    } = t;
                    g && (l = l ? l.concat(g) : g), null == e ? (a(u, n, r), a(p, n, r), v(t.children || [], n, p, i, o, d, l, c)) : h > 0 && 64 & h && w && e.dynamicChildren ? (C(e.dynamicChildren, w, n, i, o, d, l), (null != t.key || i && t === i.subTree) && tr(e, t, !0)) : j(e, t, n, p, i, o, d, l, c)
                }, _ = (e, t, n, a, r, i, o, s, d) => {
                    t.slotScopeIds = s, null == e ? 512 & t.shapeFlag ? r.ctx.activate(t, n, a, o, d) : I(t, n, a, r, i, o, d) : A(e, t, d)
                }, I = (e, t, n, a, r, i, o) => {
                    const s = e.component = function(e, t, n) {
                        const a = e.type,
                            r = (t ? t.appContext : e.appContext) || Hr,
                            i = {
                                uid: Kr++,
                                vnode: e,
                                type: a,
                                parent: t,
                                appContext: r,
                                root: null,
                                next: null,
                                subTree: null,
                                effect: null,
                                update: null,
                                job: null,
                                scope: new Le(!0),
                                render: null,
                                proxy: null,
                                exposed: null,
                                exposeProxy: null,
                                withProxy: null,
                                provides: t ? t.provides : Object.create(r.provides),
                                ids: t ? t.ids : ["", 0, 0],
                                accessCache: null,
                                renderCache: [],
                                components: null,
                                directives: null,
                                propsOptions: Na(a, r),
                                emitsOptions: hr(a, r),
                                emit: null,
                                emitted: null,
                                propsDefaults: R,
                                inheritAttrs: a.inheritAttrs,
                                ctx: R,
                                data: R,
                                props: R,
                                attrs: R,
                                slots: R,
                                refs: R,
                                setupState: R,
                                setupContext: null,
                                suspense: n,
                                suspenseId: n ? n.pendingId : 0,
                                asyncDep: null,
                                asyncResolved: !1,
                                isMounted: !1,
                                isUnmounted: !1,
                                isDeactivated: !1,
                                bc: null,
                                c: null,
                                bm: null,
                                m: null,
                                bu: null,
                                u: null,
                                um: null,
                                bum: null,
                                da: null,
                                a: null,
                                rtg: null,
                                rtc: null,
                                ec: null,
                                sp: null
                            };
                        return i.ctx = {
                            _: i
                        }, i.root = t ? t.root : i, i.emit = ur.bind(null, i), e.ce && e.ce(i), i
                    }(e, a, r);
                    if ($n(e) && (s.ctx.renderer = $), function(e, t = !1, n = !1) {
                            t && Yr(t);
                            const {
                                props: a,
                                children: r
                            } = e.vnode, i = ei(e);
                            (function(e, t, n, a = !1) {
                                const r = {},
                                    i = Ra();
                                e.propsDefaults = Object.create(null), Ua(e, t, r, i);
                                for (const t in e.propsOptions[0]) t in r || (r[t] = void 0);
                                n ? e.props = a ? r : Wt(r, !1, _t, Vt, Dt) : e.type.props ? e.props = r : e.props = i, e.attrs = i
                            })(e, a, i, t), ((e, t, n) => {
                                const a = e.slots = Ra();
                                if (32 & e.vnode.shapeFlag) {
                                    const e = t._;
                                    e ? (Ja(a, t, n), n && me(a, "_", e, !0)) : $a(t, a)
                                } else t && Za(e, t)
                            })(e, r, n || t);
                            const o = i ? function(e, t) {
                                const n = e.type;
                                e.accessCache = Object.create(null), e.proxy = new Proxy(e.ctx, xa);
                                const {
                                    setup: a
                                } = n;
                                if (a) {
                                    Ye();
                                    const n = e.setupContext = a.length > 1 ? function(e) {
                                            const t = t => {
                                                e.exposed = t || {}
                                            };
                                            return {
                                                attrs: new Proxy(e.attrs, oi),
                                                slots: e.slots,
                                                emit: e.emit,
                                                expose: t
                                            }
                                        }(e) : null,
                                        r = Qr(e),
                                        i = dn(a, e, 0, [e.props, n]),
                                        o = te(i);
                                    if (Qe(), r(), !o && !e.sp || Kn(e) || Fn(e), o) {
                                        if (i.then(Xr, Xr), t) return i.then(n => {
                                            ri(e, n, t)
                                        }).catch(t => {
                                            cn(t, e, 0)
                                        });
                                        e.asyncDep = i
                                    } else ri(e, i, t)
                                } else ii(e, t)
                            }(e, t) : void 0;
                            t && Yr(!1)
                        }(s, !1, o), s.asyncDep) {
                        if (r && r.registerDep(s, E, o), !e.el) {
                            const a = s.subTree = Br(vr);
                            f(null, a, t, n), e.placeholder = a.el
                        }
                    } else E(s, e, t, n, r, i, o)
                }, A = (e, t, n) => {
                    const a = t.component = e.component;
                    if (function(e, t, n) {
                            const {
                                props: a,
                                children: r,
                                component: i
                            } = e, {
                                props: o,
                                children: s,
                                patchFlag: d
                            } = t, l = i.emitsOptions;
                            if (t.dirs || t.transition) return !0;
                            if (!(n && d >= 0)) return !(!r && !s || s && s.$stable) || a !== o && (a ? !o || br(a, o, l) : !!o);
                            if (1024 & d) return !0;
                            if (16 & d) return a ? br(a, o, l) : !!o;
                            if (8 & d) {
                                const e = t.dynamicProps;
                                for (let t = 0; t < e.length; t++) {
                                    const n = e[t];
                                    if (o[n] !== a[n] && !wr(l, n)) return !0
                                }
                            }
                            return !1
                        }(e, t, n)) {
                        if (a.asyncDep && !a.asyncResolved) return void z(a, t, n);
                        a.next = t, a.update()
                    } else t.el = e.el, a.vnode = t
                }, E = (e, t, n, a, r, i, o) => {
                    const s = () => {
                        if (e.isMounted) {
                            let {
                                next: t,
                                bu: n,
                                u: a,
                                parent: d,
                                vnode: l
                            } = e; {
                                const n = nr(e);
                                if (n) return t && (t.el = l.el, z(e, t, o)), void n.asyncDep.then(() => {
                                    e.isUnmounted || s()
                                })
                            }
                            let c, p = t;
                            er(e, !1), t ? (t.el = l.el, z(e, t, o)) : t = l, n && ge(n), (c = t.props && t.props.onVnodeBeforeUpdate) && qr(c, d, t, l), er(e, !0);
                            const h = gr(e),
                                w = e.subTree;
                            e.subTree = h, g(w, h, u(w.el), G(w), e, r, i), t.el = h.el, null === p && function({
                                vnode: e,
                                parent: t
                            }, n) {
                                for (; t;) {
                                    const a = t.subTree;
                                    if (a.suspense && a.suspense.activeBranch === e && (a.el = e.el), a !== e) break;
                                    (e = t.vnode).el = n, t = t.parent
                                }
                            }(e, h.el), a && Ya(a, r), (c = t.props && t.props.onVnodeUpdated) && Ya(() => qr(c, d, t, l), r), __VUE_PROD_DEVTOOLS__ && zn(e)
                        } else {
                            let o;
                            const {
                                el: s,
                                props: d
                            } = t, {
                                bm: l,
                                m: c,
                                parent: u,
                                root: p,
                                type: h
                            } = e, w = Kn(t);
                            if (er(e, !1), l && ge(l), !w && (o = d && d.onVnodeBeforeMount) && qr(o, u, t), er(e, !0), s && J) {
                                const t = () => {
                                    e.subTree = gr(e), J(s, e.subTree, e, r, null)
                                };
                                w && h.__asyncHydrate ? h.__asyncHydrate(s, e, t) : t()
                            } else {
                                p.ce && !1 !== p.ce._def.shadowRoot && p.ce._injectChildStyle(h);
                                const o = e.subTree = gr(e);
                                g(null, o, n, a, e, r, i), t.el = o.el
                            }
                            if (c && Ya(c, r), !w && (o = d && d.onVnodeMounted)) {
                                const e = t;
                                Ya(() => qr(o, u, e), r)
                            }(256 & t.shapeFlag || u && Kn(u.vnode) && 256 & u.vnode.shapeFlag) && e.a && Ya(e.a, r), e.isMounted = !0, __VUE_PROD_DEVTOOLS__ && En(e), t = n = a = null
                        }
                    };
                    e.scope.on();
                    const d = e.effect = new De(s);
                    e.scope.off();
                    const l = e.update = d.run.bind(d),
                        c = e.job = d.runIfDirty.bind(d);
                    c.i = e, c.id = e.uid, d.scheduler = () => xn(c), er(e, !0), l()
                }, z = (e, t, n) => {
                    t.component = e;
                    const a = e.vnode.props;
                    e.vnode = t, e.next = null,
                        function(e, t, n, a) {
                            const {
                                props: r,
                                attrs: i,
                                vnode: {
                                    patchFlag: o
                                }
                            } = e, s = Ht(r), [d] = e.propsOptions;
                            let l = !1;
                            if (!(a || o > 0) || 16 & o) {
                                let a;
                                Ua(e, t, r, i) && (l = !0);
                                for (const i in s) t && (K(t, i) || (a = ue(i)) !== i && K(t, a)) || (d ? !n || void 0 === n[i] && void 0 === n[a] || (r[i] = Wa(d, s, i, void 0, e, !0)) : delete r[i]);
                                if (i !== s)
                                    for (const e in i) t && K(t, e) || (delete i[e], l = !0)
                            } else if (8 & o) {
                                const n = e.vnode.dynamicProps;
                                for (let a = 0; a < n.length; a++) {
                                    let o = n[a];
                                    if (wr(e.emitsOptions, o)) continue;
                                    const c = t[o];
                                    if (d)
                                        if (K(i, o)) c !== i[o] && (i[o] = c, l = !0);
                                        else {
                                            const t = le(o);
                                            r[t] = Wa(d, s, t, c, e, !1)
                                        }
                                    else c !== i[o] && (i[o] = c, l = !0)
                                }
                            }
                            l && lt(e.attrs, "set", "")
                        }(e, t.props, a, n), ((e, t, n) => {
                            const {
                                vnode: a,
                                slots: r
                            } = e;
                            let i = !0,
                                o = R;
                            if (32 & a.shapeFlag) {
                                const e = t._;
                                e ? n && 1 === e ? i = !1 : Ja(r, t, n) : (i = !t.$stable, $a(t, r)), o = t
                            } else t && (Za(e, t), o = {
                                default: 1
                            });
                            if (i)
                                for (const e in r) qa(e) || null != o[e] || delete r[e]
                        })(e, t.children, n), Ye(), kn(e), Qe()
                }, j = (e, t, n, a, r, i, o, s, d = !1) => {
                    const l = e && e.children,
                        u = e ? e.shapeFlag : 0,
                        p = t.children,
                        {
                            patchFlag: h,
                            shapeFlag: w
                        } = t;
                    if (h > 0) {
                        if (128 & h) return void L(l, p, n, a, r, i, o, s, d);
                        if (256 & h) return void V(l, p, n, a, r, i, o, s, d)
                    }
                    8 & w ? (16 & u && N(l, r, i), p !== l && c(n, p)) : 16 & u ? 16 & w ? L(l, p, n, a, r, i, o, s, d) : N(l, r, i, !0) : (8 & u && c(n, ""), 16 & w && v(p, n, a, r, i, o, s, d))
                }, V = (e, t, n, a, r, i, o, s, d) => {
                    t = t || M;
                    const l = (e = e || M).length,
                        c = t.length,
                        u = Math.min(l, c);
                    let p;
                    for (p = 0; p < u; p++) {
                        const a = t[p] = d ? Nr(t[p]) : Fr(t[p]);
                        g(e[p], a, n, null, r, i, o, s, d)
                    }
                    l > c ? N(e, r, i, !0, !1, u) : v(t, n, a, r, i, o, s, d, u)
                }, L = (e, t, n, a, r, i, o, s, d) => {
                    let l = 0;
                    const c = t.length;
                    let u = e.length - 1,
                        p = c - 1;
                    for (; l <= u && l <= p;) {
                        const a = e[l],
                            c = t[l] = d ? Nr(t[l]) : Fr(t[l]);
                        if (!Vr(a, c)) break;
                        g(a, c, n, null, r, i, o, s, d), l++
                    }
                    for (; l <= u && l <= p;) {
                        const a = e[u],
                            l = t[p] = d ? Nr(t[p]) : Fr(t[p]);
                        if (!Vr(a, l)) break;
                        g(a, l, n, null, r, i, o, s, d), u--, p--
                    }
                    if (l > u) {
                        if (l <= p) {
                            const e = p + 1,
                                u = e < c ? t[e].el : a;
                            for (; l <= p;) g(null, t[l] = d ? Nr(t[l]) : Fr(t[l]), n, u, r, i, o, s, d), l++
                        }
                    } else if (l > p)
                        for (; l <= u;) D(e[l], r, i, !0), l++;
                    else {
                        const h = l,
                            w = l,
                            m = new Map;
                        for (l = w; l <= p; l++) {
                            const e = t[l] = d ? Nr(t[l]) : Fr(t[l]);
                            null != e.key && m.set(e.key, l)
                        }
                        let f, b = 0;
                        const x = p - w + 1;
                        let y = !1,
                            k = 0;
                        const v = new Array(x);
                        for (l = 0; l < x; l++) v[l] = 0;
                        for (l = h; l <= u; l++) {
                            const a = e[l];
                            if (b >= x) {
                                D(a, r, i, !0);
                                continue
                            }
                            let c;
                            if (null != a.key) c = m.get(a.key);
                            else
                                for (f = w; f <= p; f++)
                                    if (0 === v[f - w] && Vr(a, t[f])) {
                                        c = f;
                                        break
                                    }
                            void 0 === c ? D(a, r, i, !0) : (v[c - w] = l + 1, c >= k ? k = c : y = !0, g(a, t[c], n, null, r, i, o, s, d), b++)
                        }
                        const P = y ? function(e) {
                            const t = e.slice(),
                                n = [0];
                            let a, r, i, o, s;
                            const d = e.length;
                            for (a = 0; a < d; a++) {
                                const d = e[a];
                                if (0 !== d) {
                                    if (r = n[n.length - 1], e[r] < d) {
                                        t[a] = r, n.push(a);
                                        continue
                                    }
                                    for (i = 0, o = n.length - 1; i < o;) s = i + o >> 1, e[n[s]] < d ? i = s + 1 : o = s;
                                    d < e[n[i]] && (i > 0 && (t[a] = n[i - 1]), n[i] = a)
                                }
                            }
                            for (i = n.length, o = n[i - 1]; i-- > 0;) n[i] = o, o = t[o];
                            return n
                        }(v) : M;
                        for (f = P.length - 1, l = x - 1; l >= 0; l--) {
                            const e = w + l,
                                u = t[e],
                                p = t[e + 1],
                                h = e + 1 < c ? p.el || p.placeholder : a;
                            0 === v[l] ? g(null, u, n, h, r, i, o, s, d) : y && (f < 0 || l !== P[f] ? T(u, n, h, 2) : f--)
                        }
                    }
                }, T = (e, t, n, i, o = null) => {
                    const {
                        el: s,
                        type: d,
                        transition: l,
                        children: c,
                        shapeFlag: u
                    } = e;
                    if (6 & u) T(e.component.subTree, t, n, i);
                    else if (128 & u) e.suspense.move(t, n, i);
                    else if (64 & u) d.move(e, t, n, $);
                    else if (d !== yr)
                        if (d !== Pr)
                            if (2 !== i && 1 & u && l)
                                if (0 === i) l.beforeEnter(s), a(s, t, n), Ya(() => l.enter(s), o);
                                else {
                                    const {
                                        leave: i,
                                        delayLeave: o,
                                        afterLeave: d
                                    } = l, c = () => {
                                        e.ctx.isUnmounted ? r(s) : a(s, t, n)
                                    }, u = () => {
                                        s._isLeaving && s[Un](!0), i(s, () => {
                                            c(), d && d()
                                        })
                                    };
                                    o ? o(s, c, u) : u()
                                }
                    else a(s, t, n);
                    else(({
                        el: e,
                        anchor: t
                    }, n, r) => {
                        let i;
                        for (; e && e !== t;) i = p(e), a(e, n, r), e = i;
                        a(t, n, r)
                    })(e, t, n);
                    else {
                        a(s, t, n);
                        for (let e = 0; e < c.length; e++) T(c[e], t, n, i);
                        a(e.anchor, t, n)
                    }
                }, D = (e, t, n, a = !1, r = !1) => {
                    const {
                        type: i,
                        props: o,
                        ref: s,
                        children: d,
                        dynamicChildren: l,
                        shapeFlag: c,
                        patchFlag: u,
                        dirs: p,
                        cacheIndex: h
                    } = e;
                    if (-2 === u && (r = !1), null != s && (Ye(), qn(s, null, n, e, !0), Qe()), null != h && (t.renderCache[h] = void 0), 256 & c) return void t.ctx.deactivate(e);
                    const w = 1 & c && p,
                        g = !Kn(e);
                    let m;
                    if (g && (m = o && o.onVnodeBeforeUnmount) && qr(m, t, e), 6 & c) F(e.component, n, a);
                    else {
                        if (128 & c) return void e.suspense.unmount(n, a);
                        w && Rn(e, null, t, "beforeUnmount"), 64 & c ? e.type.remove(e, t, n, $, a) : l && !l.hasOnce && (i !== yr || u > 0 && 64 & u) ? N(l, t, n, !1, !0) : (i === yr && 384 & u || !r && 16 & c) && N(d, t, n), a && B(e)
                    }(g && (m = o && o.onVnodeUnmounted) || w) && Ya(() => {
                        m && qr(m, t, e), w && Rn(e, null, t, "unmounted")
                    }, n)
                }, B = e => {
                    const {
                        type: t,
                        el: n,
                        anchor: a,
                        transition: i
                    } = e;
                    if (t === yr) return void W(n, a);
                    if (t === Pr) return void(({
                        el: e,
                        anchor: t
                    }) => {
                        let n;
                        for (; e && e !== t;) n = p(e), r(e), e = n;
                        r(t)
                    })(e);
                    const o = () => {
                        r(n), i && !i.persisted && i.afterLeave && i.afterLeave()
                    };
                    if (1 & e.shapeFlag && i && !i.persisted) {
                        const {
                            leave: t,
                            delayLeave: a
                        } = i, r = () => t(n, o);
                        a ? a(e.el, o, r) : r()
                    } else o()
                }, W = (e, t) => {
                    let n;
                    for (; e !== t;) n = p(e), r(e), e = n;
                    r(t)
                }, F = (e, t, n) => {
                    const {
                        bum: a,
                        scope: r,
                        job: i,
                        subTree: o,
                        um: s,
                        m: d,
                        a: l
                    } = e;
                    var c;
                    ar(d), ar(l), a && ge(a), r.stop(), i && (i.flags |= 8, D(o, e, t, n)), s && Ya(s, t), Ya(() => {
                        e.isUnmounted = !0
                    }, t), __VUE_PROD_DEVTOOLS__ && (c = e, On && "function" == typeof On.cleanupBuffer && !On.cleanupBuffer(c) && jn(c))
                }, N = (e, t, n, a = !1, r = !1, i = 0) => {
                    for (let o = i; o < e.length; o++) D(e[o], t, n, a, r)
                }, G = e => {
                    if (6 & e.shapeFlag) return G(e.component.subTree);
                    if (128 & e.shapeFlag) return e.suspense.next();
                    const t = p(e.anchor || e.el),
                        n = t && t[Mn];
                    return n ? p(n) : t
                };
                let q = !1;
                const H = (e, t, n) => {
                        null == e ? t._vnode && D(t._vnode, null, null, !0) : g(t._vnode || null, e, t, null, null, null, n), t._vnode = e, q || (q = !0, kn(), vn(), q = !1)
                    },
                    $ = {
                        p: g,
                        um: D,
                        m: T,
                        r: B,
                        mt: I,
                        mc: v,
                        pc: j,
                        pbc: C,
                        n: G,
                        o: e
                    };
                let Z, J;
                return t && ([Z, J] = t($)), {
                    render: H,
                    hydrate: Z,
                    createApp: La(H, Z)
                }
            }

            function Xa({
                type: e,
                props: t
            }, n) {
                return "svg" === n && "foreignObject" === e || "mathml" === n && "annotation-xml" === e && t && t.encoding && t.encoding.includes("html") ? void 0 : n
            }

            function er({
                effect: e,
                job: t
            }, n) {
                n ? (e.flags |= 32, t.flags |= 4) : (e.flags &= -33, t.flags &= -5)
            }

            function tr(e, t, n = !1) {
                const a = e.children,
                    r = t.children;
                if ($(a) && $(r))
                    for (let e = 0; e < a.length; e++) {
                        const t = a[e];
                        let i = r[e];
                        1 & i.shapeFlag && !i.dynamicChildren && ((i.patchFlag <= 0 || 32 === i.patchFlag) && (i = r[e] = Nr(r[e]), i.el = t.el), n || -2 === i.patchFlag || tr(t, i)), i.type === kr && -1 !== i.patchFlag && (i.el = t.el), i.type !== vr || i.el || (i.el = t.el)
                    }
            }

            function nr(e) {
                const t = e.subTree.component;
                if (t) return t.asyncDep && !t.asyncResolved ? t : nr(t)
            }

            function ar(e) {
                if (e)
                    for (let t = 0; t < e.length; t++) e[t].flags |= 8
            }
            const rr = Symbol.for("v-scx"),
                ir = () => Da(rr);

            function or(e, t, n) {
                return sr(e, t, n)
            }

            function sr(e, t, n = R) {
                const {
                    immediate: a,
                    deep: r,
                    flush: i,
                    once: o
                } = n, s = G({}, n), d = t && a || !t && "post" !== i;
                let l;
                if (ai)
                    if ("sync" === i) {
                        const e = ir();
                        l = e.__watcherHandles || (e.__watcherHandles = [])
                    } else if (!d) {
                    const e = () => {};
                    return e.stop = U, e.resume = U, e.pause = U, e
                }
                const c = $r;
                s.call = (e, t, n) => ln(e, c, t, n);
                let u = !1;
                "post" === i ? s.scheduler = e => {
                    Ya(e, c && c.suspense)
                } : "sync" !== i && (u = !0, s.scheduler = (e, t) => {
                    t ? e() : xn(e)
                }), s.augmentJob = e => {
                    t && (e.flags |= 4), u && (e.flags |= 2, c && (e.id = c.uid, e.i = c))
                };
                const p = function(e, t, n = R) {
                    const {
                        immediate: a,
                        deep: r,
                        once: i,
                        scheduler: o,
                        augmentJob: s,
                        call: d
                    } = n, l = e => r ? e : Gt(e) || !1 === r || 0 === r ? sn(e, 1) : sn(e);
                    let c, u, p, h, w = !1,
                        g = !1;
                    if (Zt(e) ? (u = () => e.value, w = Gt(e)) : Ft(e) ? (u = () => l(e), w = !0) : $(e) ? (g = !0, w = e.some(e => Ft(e) || Gt(e)), u = () => e.map(e => Zt(e) ? e.value : Ft(e) ? l(e) : Y(e) ? d ? d(e, 2) : e() : void 0)) : u = Y(e) ? t ? d ? () => d(e, 2) : e : () => {
                            if (p) {
                                Ye();
                                try {
                                    p()
                                } finally {
                                    Qe()
                                }
                            }
                            const t = on;
                            on = c;
                            try {
                                return d ? d(e, 3, [h]) : e(h)
                            } finally {
                                on = t
                            }
                        } : U, t && r) {
                        const e = u,
                            t = !0 === r ? 1 / 0 : r;
                        u = () => sn(e(), t)
                    }
                    const m = je,
                        f = () => {
                            c.stop(), m && m.active && q(m.effects, c)
                        };
                    if (i && t) {
                        const e = t;
                        t = (...t) => {
                            e(...t), f()
                        }
                    }
                    let b = g ? new Array(e.length).fill(an) : an;
                    const x = e => {
                        if (1 & c.flags && (c.dirty || e))
                            if (t) {
                                const e = c.run();
                                if (r || w || (g ? e.some((e, t) => we(e, b[t])) : we(e, b))) {
                                    p && p();
                                    const n = on;
                                    on = c;
                                    try {
                                        const n = [e, b === an ? void 0 : g && b[0] === an ? [] : b, h];
                                        b = e, d ? d(t, 3, n) : t(...n)
                                    } finally {
                                        on = n
                                    }
                                }
                            } else c.run()
                    };
                    return s && s(x), c = new De(u), c.scheduler = o ? () => o(x, !1) : x, h = e => function(e, t = !1, n = on) {
                        if (n) {
                            let t = rn.get(n);
                            t || rn.set(n, t = []), t.push(e)
                        }
                    }(e, !1, c), p = c.onStop = () => {
                        const e = rn.get(c);
                        if (e) {
                            if (d) d(e, 4);
                            else
                                for (const t of e) t();
                            rn.delete(c)
                        }
                    }, t ? a ? x(!0) : b = c.run() : o ? o(x.bind(null, !0), !0) : c.run(), f.pause = c.pause.bind(c), f.resume = c.resume.bind(c), f.stop = f, f
                }(e, t, s);
                return ai && (l ? l.push(p) : d && p()), p
            }

            function dr(e, t, n) {
                const a = this.proxy,
                    r = Q(e) ? e.includes(".") ? lr(a, e) : () => a[e] : e.bind(a, a);
                let i;
                Y(t) ? i = t : (i = t.handler, n = t);
                const o = Qr(this),
                    s = sr(r, i.bind(a), n);
                return o(), s
            }

            function lr(e, t) {
                const n = t.split(".");
                return () => {
                    let t = e;
                    for (let e = 0; e < n.length && t; e++) t = t[n[e]];
                    return t
                }
            }
            const cr = (e, t) => "modelValue" === t || "model-value" === t ? e.modelModifiers : e[`${t}Modifiers`] || e[`${le(t)}Modifiers`] || e[`${ue(t)}Modifiers`];

            function ur(e, t, ...n) {
                if (e.isUnmounted) return;
                const a = e.vnode.props || R;
                let r = n;
                const i = t.startsWith("update:"),
                    o = i && cr(a, t.slice(7));
                let s;
                o && (o.trim && (r = n.map(e => Q(e) ? e.trim() : e)), o.number && (r = n.map(fe))), __VUE_PROD_DEVTOOLS__ && function(e, t, n) {
                    In("component:emit", e.appContext.app, e, t, n)
                }(e, t, r);
                let d = a[s = he(t)] || a[s = he(le(t))];
                !d && i && (d = a[s = he(ue(t))]), d && ln(d, e, 6, r);
                const l = a[s + "Once"];
                if (l) {
                    if (e.emitted) {
                        if (e.emitted[s]) return
                    } else e.emitted = {};
                    e.emitted[s] = !0, ln(l, e, 6, r)
                }
            }
            const pr = new WeakMap;

            function hr(e, t, n = !1) {
                const a = __VUE_OPTIONS_API__ && n ? pr : t.emitsCache,
                    r = a.get(e);
                if (void 0 !== r) return r;
                const i = e.emits;
                let o = {},
                    s = !1;
                if (__VUE_OPTIONS_API__ && !Y(e)) {
                    const a = e => {
                        const n = hr(e, t, !0);
                        n && (s = !0, G(o, n))
                    };
                    !n && t.mixins.length && t.mixins.forEach(a), e.extends && a(e.extends), e.mixins && e.mixins.forEach(a)
                }
                return i || s ? ($(i) ? i.forEach(e => o[e] = null) : G(o, i), ee(e) && a.set(e, o), o) : (ee(e) && a.set(e, null), null)
            }

            function wr(e, t) {
                return !(!e || !F(t)) && (t = t.slice(2).replace(/Once$/, ""), K(e, t[0].toLowerCase() + t.slice(1)) || K(e, ue(t)) || K(e, t))
            }

            function gr(e) {
                const {
                    type: t,
                    vnode: n,
                    proxy: a,
                    withProxy: r,
                    propsOptions: [i],
                    slots: o,
                    attrs: s,
                    emit: d,
                    render: l,
                    renderCache: c,
                    props: u,
                    data: p,
                    setupState: h,
                    ctx: w,
                    inheritAttrs: g
                } = e, m = Dn(e);
                let f, b;
                try {
                    if (4 & n.shapeFlag) {
                        const e = r || a,
                            t = e;
                        f = Fr(l.call(t, e, c, u, h, p, w)), b = s
                    } else {
                        const e = t;
                        f = Fr(e.length > 1 ? e(u, {
                            attrs: s,
                            slots: o,
                            emit: d
                        }) : e(u, null)), b = t.props ? s : mr(s)
                    }
                } catch (t) {
                    Cr.length = 0, cn(t, e, 1), f = Br(vr)
                }
                let x = f;
                if (b && !1 !== g) {
                    const e = Object.keys(b),
                        {
                            shapeFlag: t
                        } = x;
                    e.length && 7 & t && (i && e.some(N) && (b = fr(b, i)), x = Rr(x, b, !1, !0))
                }
                return n.dirs && (x = Rr(x, null, !1, !0), x.dirs = x.dirs ? x.dirs.concat(n.dirs) : n.dirs), n.transition && Wn(x, n.transition), f = x, Dn(m), f
            }
            const mr = e => {
                    let t;
                    for (const n in e)("class" === n || "style" === n || F(n)) && ((t || (t = {}))[n] = e[n]);
                    return t
                },
                fr = (e, t) => {
                    const n = {};
                    for (const a in e) N(a) && a.slice(9) in t || (n[a] = e[a]);
                    return n
                };

            function br(e, t, n) {
                const a = Object.keys(t);
                if (a.length !== Object.keys(e).length) return !0;
                for (let r = 0; r < a.length; r++) {
                    const i = a[r];
                    if (t[i] !== e[i] && !wr(n, i)) return !0
                }
                return !1
            }
            const xr = e => e.__isSuspense;
            const yr = Symbol.for("v-fgt"),
                kr = Symbol.for("v-txt"),
                vr = Symbol.for("v-cmt"),
                Pr = Symbol.for("v-stc"),
                Cr = [];
            let Or = null;

            function Sr(e = !1) {
                Cr.push(Or = e ? null : [])
            }
            let _r = 1;

            function Ir(e, t = !1) {
                _r += e, e < 0 && Or && t && (Or.hasOnce = !0)
            }

            function Ar(e) {
                return e.dynamicChildren = _r > 0 ? Or || M : null, Cr.pop(), Or = Cr[Cr.length - 1] || null, _r > 0 && Or && Or.push(e), e
            }

            function Er(e, t, n, a, r, i) {
                return Ar(Dr(e, t, n, a, r, i, !0))
            }

            function zr(e, t, n, a, r) {
                return Ar(Br(e, t, n, a, r, !0))
            }

            function jr(e) {
                return !!e && !0 === e.__v_isVNode
            }

            function Vr(e, t) {
                return e.type === t.type && e.key === t.key
            }
            const Lr = ({
                    key: e
                }) => null != e ? e : null,
                Tr = ({
                    ref: e,
                    ref_key: t,
                    ref_for: n
                }) => ("number" == typeof e && (e = "" + e), null != e ? Q(e) || Zt(e) || Y(e) ? {
                    i: Ln,
                    r: e,
                    k: t,
                    f: !!n
                } : e : null);

            function Dr(e, t = null, n = null, a = 0, r = null, i = (e === yr ? 0 : 1), o = !1, s = !1) {
                const d = {
                    __v_isVNode: !0,
                    __v_skip: !0,
                    type: e,
                    props: t,
                    key: t && Lr(t),
                    ref: t && Tr(t),
                    scopeId: Tn,
                    slotScopeIds: null,
                    children: n,
                    component: null,
                    suspense: null,
                    ssContent: null,
                    ssFallback: null,
                    dirs: null,
                    transition: null,
                    el: null,
                    anchor: null,
                    target: null,
                    targetStart: null,
                    targetAnchor: null,
                    staticCount: 0,
                    shapeFlag: i,
                    patchFlag: a,
                    dynamicProps: r,
                    dynamicChildren: null,
                    appContext: null,
                    ctx: Ln
                };
                return s ? (Gr(d, n), 128 & i && e.normalize(d)) : n && (d.shapeFlag |= Q(n) ? 8 : 16), _r > 0 && !o && Or && (d.patchFlag > 0 || 6 & i) && 32 !== d.patchFlag && Or.push(d), d
            }
            const Br = function(e, t = null, n = null, a = 0, r = null, i = !1) {
                if (e && e !== ha || (e = vr), jr(e)) {
                    const a = Rr(e, t, !0);
                    return n && Gr(a, n), _r > 0 && !i && Or && (6 & a.shapeFlag ? Or[Or.indexOf(e)] = a : Or.push(a)), a.patchFlag = -2, a
                }
                if (o = e, Y(o) && "__vccOpts" in o && (e = e.__vccOpts), t) {
                    t = function(e) {
                        return e ? qt(e) || Ma(e) ? G({}, e) : e : null
                    }(t);
                    let {
                        class: e,
                        style: n
                    } = t;
                    e && !Q(e) && (t.class = Oe(e)), ee(n) && (qt(n) && !$(n) && (n = G({}, n)), t.style = ye(n))
                }
                var o;
                return Dr(e, t, n, a, r, Q(e) ? 1 : xr(e) ? 128 : (e => e.__isTeleport)(e) ? 64 : ee(e) ? 4 : Y(e) ? 2 : 0, i, !0)
            };

            function Rr(e, t, n = !1, a = !1) {
                const {
                    props: r,
                    ref: i,
                    patchFlag: o,
                    children: s,
                    transition: d
                } = e, l = t ? function(...e) {
                    const t = {};
                    for (let n = 0; n < e.length; n++) {
                        const a = e[n];
                        for (const e in a)
                            if ("class" === e) t.class !== a.class && (t.class = Oe([t.class, a.class]));
                            else if ("style" === e) t.style = ye([t.style, a.style]);
                        else if (F(e)) {
                            const n = t[e],
                                r = a[e];
                            !r || n === r || $(n) && n.includes(r) || (t[e] = n ? [].concat(n, r) : r)
                        } else "" !== e && (t[e] = a[e])
                    }
                    return t
                }(r || {}, t) : r, c = {
                    __v_isVNode: !0,
                    __v_skip: !0,
                    type: e.type,
                    props: l,
                    key: l && Lr(l),
                    ref: t && t.ref ? n && i ? $(i) ? i.concat(Tr(t)) : [i, Tr(t)] : Tr(t) : i,
                    scopeId: e.scopeId,
                    slotScopeIds: e.slotScopeIds,
                    children: s,
                    target: e.target,
                    targetStart: e.targetStart,
                    targetAnchor: e.targetAnchor,
                    staticCount: e.staticCount,
                    shapeFlag: e.shapeFlag,
                    patchFlag: t && e.type !== yr ? -1 === o ? 16 : 16 | o : o,
                    dynamicProps: e.dynamicProps,
                    dynamicChildren: e.dynamicChildren,
                    appContext: e.appContext,
                    dirs: e.dirs,
                    transition: d,
                    component: e.component,
                    suspense: e.suspense,
                    ssContent: e.ssContent && Rr(e.ssContent),
                    ssFallback: e.ssFallback && Rr(e.ssFallback),
                    placeholder: e.placeholder,
                    el: e.el,
                    anchor: e.anchor,
                    ctx: e.ctx,
                    ce: e.ce
                };
                return d && a && Wn(c, d.clone(c)), c
            }

            function Mr(e = " ", t = 0) {
                return Br(kr, null, e, t)
            }

            function Ur(e, t) {
                const n = Br(Pr, null, e);
                return n.staticCount = t, n
            }

            function Wr(e = "", t = !1) {
                return t ? (Sr(), zr(vr, null, e)) : Br(vr, null, e)
            }

            function Fr(e) {
                return null == e || "boolean" == typeof e ? Br(vr) : $(e) ? Br(yr, null, e.slice()) : jr(e) ? Nr(e) : Br(kr, null, String(e))
            }

            function Nr(e) {
                return null === e.el && -1 !== e.patchFlag || e.memo ? e : Rr(e)
            }

            function Gr(e, t) {
                let n = 0;
                const {
                    shapeFlag: a
                } = e;
                if (null == t) t = null;
                else if ($(t)) n = 16;
                else if ("object" == typeof t) {
                    if (65 & a) {
                        const n = t.default;
                        return void(n && (n._c && (n._d = !1), Gr(e, n()), n._c && (n._d = !0)))
                    } {
                        n = 32;
                        const a = t._;
                        a || Ma(t) ? 3 === a && Ln && (1 === Ln.slots._ ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024)) : t._ctx = Ln
                    }
                } else Y(t) ? (t = {
                    default: t,
                    _ctx: Ln
                }, n = 32) : (t = String(t), 64 & a ? (n = 16, t = [Mr(t)]) : n = 8);
                e.children = t, e.shapeFlag |= n
            }

            function qr(e, t, n, a = null) {
                ln(e, t, 7, [n, a])
            }
            const Hr = ja();
            let Kr = 0;
            let $r = null;
            const Zr = () => $r || Ln;
            let Jr, Yr; {
                const e = xe(),
                    t = (t, n) => {
                        let a;
                        return (a = e[t]) || (a = e[t] = []), a.push(n), e => {
                            a.length > 1 ? a.forEach(t => t(e)) : a[0](e)
                        }
                    };
                Jr = t("__VUE_INSTANCE_SETTERS__", e => $r = e), Yr = t("__VUE_SSR_SETTERS__", e => ai = e)
            }
            const Qr = e => {
                    const t = $r;
                    return Jr(e), e.scope.on(), () => {
                        e.scope.off(), Jr(t)
                    }
                },
                Xr = () => {
                    $r && $r.scope.off(), Jr(null)
                };

            function ei(e) {
                return 4 & e.vnode.shapeFlag
            }
            let ti, ni, ai = !1;

            function ri(e, t, n) {
                Y(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : ee(t) && (__VUE_PROD_DEVTOOLS__ && (e.devtoolsRawSetupState = t), e.setupState = tn(t)), ii(e, n)
            }

            function ii(e, t, n) {
                const a = e.type;
                if (!e.render) {
                    if (!t && ti && !a.render) {
                        const t = a.template || __VUE_OPTIONS_API__ && Ca(e).template;
                        if (t) {
                            const {
                                isCustomElement: n,
                                compilerOptions: r
                            } = e.appContext.config, {
                                delimiters: i,
                                compilerOptions: o
                            } = a, s = G(G({
                                isCustomElement: n,
                                delimiters: i
                            }, r), o);
                            a.render = ti(t, s)
                        }
                    }
                    e.render = a.render || U, ni && ni(e)
                }
                if (__VUE_OPTIONS_API__) {
                    const t = Qr(e);
                    Ye();
                    try {
                        ! function(e) {
                            const t = Ca(e),
                                n = e.proxy,
                                a = e.ctx;
                            ka = !1, t.beforeCreate && va(t.beforeCreate, e, "bc");
                            const {
                                data: r,
                                computed: i,
                                methods: o,
                                watch: s,
                                provide: d,
                                inject: l,
                                created: c,
                                beforeMount: u,
                                mounted: p,
                                beforeUpdate: h,
                                updated: w,
                                activated: g,
                                deactivated: m,
                                beforeDestroy: f,
                                beforeUnmount: b,
                                destroyed: x,
                                unmounted: y,
                                render: k,
                                renderTracked: v,
                                renderTriggered: P,
                                errorCaptured: C,
                                serverPrefetch: O,
                                expose: S,
                                inheritAttrs: _,
                                components: I,
                                directives: A,
                                filters: E
                            } = t;
                            if (l && function(e, t) {
                                    $(e) && (e = Ia(e));
                                    for (const n in e) {
                                        const a = e[n];
                                        let r;
                                        r = ee(a) ? "default" in a ? Da(a.from || n, a.default, !0) : Da(a.from || n) : Da(a), Zt(r) ? Object.defineProperty(t, n, {
                                            enumerable: !0,
                                            configurable: !0,
                                            get: () => r.value,
                                            set: e => r.value = e
                                        }) : t[n] = r
                                    }
                                }(l, a), o)
                                for (const e in o) {
                                    const t = o[e];
                                    Y(t) && (a[e] = t.bind(n))
                                }
                            if (r) {
                                const t = r.call(n, n);
                                ee(t) && (e.data = Mt(t))
                            }
                            if (ka = !0, i)
                                for (const e in i) {
                                    const t = i[e],
                                        r = Y(t) ? t.bind(n, n) : Y(t.get) ? t.get.bind(n, n) : U,
                                        o = !Y(t) && Y(t.set) ? t.set.bind(n) : U,
                                        s = di({
                                            get: r,
                                            set: o
                                        });
                                    Object.defineProperty(a, e, {
                                        enumerable: !0,
                                        configurable: !0,
                                        get: () => s.value,
                                        set: e => s.value = e
                                    })
                                }
                            if (s)
                                for (const e in s) Pa(s[e], a, n, e);
                            if (d) {
                                const e = Y(d) ? d.call(n) : d;
                                Reflect.ownKeys(e).forEach(t => {
                                    ! function(e, t) {
                                        if ($r) {
                                            let n = $r.provides;
                                            const a = $r.parent && $r.parent.provides;
                                            a === n && (n = $r.provides = Object.create(a)), n[e] = t
                                        }
                                    }(t, e[t])
                                })
                            }

                            function z(e, t) {
                                $(t) ? t.forEach(t => e(t.bind(n))) : t && e(t.bind(n))
                            }
                            if (c && va(c, e, "c"), z(ta, u), z(na, p), z(aa, h), z(ra, w), z(Zn, g), z(Jn, m), z(ca, C), z(la, v), z(da, P), z(ia, b), z(oa, y), z(sa, O), $(S))
                                if (S.length) {
                                    const t = e.exposed || (e.exposed = {});
                                    S.forEach(e => {
                                        Object.defineProperty(t, e, {
                                            get: () => n[e],
                                            set: t => n[e] = t,
                                            enumerable: !0
                                        })
                                    })
                                } else e.exposed || (e.exposed = {});
                            k && e.render === U && (e.render = k), null != _ && (e.inheritAttrs = _), I && (e.components = I), A && (e.directives = A), O && Fn(e)
                        }(e)
                    } finally {
                        Qe(), t()
                    }
                }
            }
            const oi = {
                get(e, t) {
                    return dt(e, 0, ""), e[t]
                }
            };

            function si(e) {
                return e.exposed ? e.exposeProxy || (e.exposeProxy = new Proxy(tn((t = e.exposed, !K(t, "__v_skip") && Object.isExtensible(t) && me(t, "__v_skip", !0), t)), {
                    get(t, n) {
                        return n in t ? t[n] : n in fa ? fa[n](e) : void 0
                    },
                    has(e, t) {
                        return t in e || t in fa
                    }
                })) : e.proxy;
                var t
            }
            const di = (e, t) => {
                    const n = function(e, t, n = !1) {
                        let a, r;
                        return Y(e) ? a = e : (a = e.get, r = e.set), new nn(a, r, n)
                    }(e, 0, ai);
                    return n
                },
                li = "3.5.22";
            let ci;
            const ui = "undefined" != typeof window && window.trustedTypes;
            if (ui) try {
                ci = ui.createPolicy("vue", {
                    createHTML: e => e
                })
            } catch (e) {}
            const pi = ci ? e => ci.createHTML(e) : e => e,
                hi = "undefined" != typeof document ? document : null,
                wi = hi && hi.createElement("template"),
                gi = {
                    insert: (e, t, n) => {
                        t.insertBefore(e, n || null)
                    },
                    remove: e => {
                        const t = e.parentNode;
                        t && t.removeChild(e)
                    },
                    createElement: (e, t, n, a) => {
                        const r = "svg" === t ? hi.createElementNS("http://www.w3.org/2000/svg", e) : "mathml" === t ? hi.createElementNS("http://www.w3.org/1998/Math/MathML", e) : n ? hi.createElement(e, {
                            is: n
                        }) : hi.createElement(e);
                        return "select" === e && a && null != a.multiple && r.setAttribute("multiple", a.multiple), r
                    },
                    createText: e => hi.createTextNode(e),
                    createComment: e => hi.createComment(e),
                    setText: (e, t) => {
                        e.nodeValue = t
                    },
                    setElementText: (e, t) => {
                        e.textContent = t
                    },
                    parentNode: e => e.parentNode,
                    nextSibling: e => e.nextSibling,
                    querySelector: e => hi.querySelector(e),
                    setScopeId(e, t) {
                        e.setAttribute(t, "")
                    },
                    insertStaticContent(e, t, n, a, r, i) {
                        const o = n ? n.previousSibling : t.lastChild;
                        if (r && (r === i || r.nextSibling))
                            for (; t.insertBefore(r.cloneNode(!0), n), r !== i && (r = r.nextSibling););
                        else {
                            wi.innerHTML = pi("svg" === a ? `<svg>${e}</svg>` : "mathml" === a ? `<math>${e}</math>` : e);
                            const r = wi.content;
                            if ("svg" === a || "mathml" === a) {
                                const e = r.firstChild;
                                for (; e.firstChild;) r.appendChild(e.firstChild);
                                r.removeChild(e)
                            }
                            t.insertBefore(r, n)
                        }
                        return [o ? o.nextSibling : t.firstChild, n ? n.previousSibling : t.lastChild]
                    }
                },
                mi = Symbol("_vtc");
            Boolean;
            const fi = Symbol("_vod"),
                bi = Symbol("_vsh"),
                xi = {
                    name: "show",
                    beforeMount(e, {
                        value: t
                    }, {
                        transition: n
                    }) {
                        e[fi] = "none" === e.style.display ? "" : e.style.display, n && t ? n.beforeEnter(e) : yi(e, t)
                    },
                    mounted(e, {
                        value: t
                    }, {
                        transition: n
                    }) {
                        n && t && n.enter(e)
                    },
                    updated(e, {
                        value: t,
                        oldValue: n
                    }, {
                        transition: a
                    }) {
                        !t != !n && (a ? t ? (a.beforeEnter(e), yi(e, !0), a.enter(e)) : a.leave(e, () => {
                            yi(e, !1)
                        }) : yi(e, t))
                    },
                    beforeUnmount(e, {
                        value: t
                    }) {
                        yi(e, t)
                    }
                };

            function yi(e, t) {
                e.style.display = t ? e[fi] : "none", e[bi] = !t
            }
            const ki = Symbol(""),
                vi = /(?:^|;)\s*display\s*:/,
                Pi = /\s*!important$/;

            function Ci(e, t, n) {
                if ($(n)) n.forEach(n => Ci(e, t, n));
                else if (null == n && (n = ""), t.startsWith("--")) e.setProperty(t, n);
                else {
                    const a = function(e, t) {
                        const n = Si[t];
                        if (n) return n;
                        let a = le(t);
                        if ("filter" !== a && a in e) return Si[t] = a;
                        a = pe(a);
                        for (let n = 0; n < Oi.length; n++) {
                            const r = Oi[n] + a;
                            if (r in e) return Si[t] = r
                        }
                        return t
                    }(e, t);
                    Pi.test(n) ? e.setProperty(ue(a), n.replace(Pi, ""), "important") : e[a] = n
                }
            }
            const Oi = ["Webkit", "Moz", "ms"],
                Si = {},
                _i = "http://www.w3.org/1999/xlink";

            function Ii(e, t, n, a, r, i = Se(t)) {
                a && t.startsWith("xlink:") ? null == n ? e.removeAttributeNS(_i, t.slice(6, t.length)) : e.setAttributeNS(_i, t, n) : null == n || i && !_e(n) ? e.removeAttribute(t) : e.setAttribute(t, i ? "" : X(n) ? String(n) : n)
            }

            function Ai(e, t, n, a, r) {
                if ("innerHTML" === t || "textContent" === t) return void(null != n && (e[t] = "innerHTML" === t ? pi(n) : n));
                const i = e.tagName;
                if ("value" === t && "PROGRESS" !== i && !i.includes("-")) {
                    const a = "OPTION" === i ? e.getAttribute("value") || "" : e.value,
                        r = null == n ? "checkbox" === e.type ? "on" : "" : String(n);
                    return a === r && "_value" in e || (e.value = r), null == n && e.removeAttribute(t), void(e._value = n)
                }
                let o = !1;
                if ("" === n || null == n) {
                    const a = typeof e[t];
                    "boolean" === a ? n = _e(n) : null == n && "string" === a ? (n = "", o = !0) : "number" === a && (n = 0, o = !0)
                }
                try {
                    e[t] = n
                } catch (e) {}
                o && e.removeAttribute(r || t)
            }
            const Ei = Symbol("_vei");
            const zi = /(?:Once|Passive|Capture)$/;
            let ji = 0;
            const Vi = Promise.resolve(),
                Li = () => ji || (Vi.then(() => ji = 0), ji = Date.now()),
                Ti = e => 111 === e.charCodeAt(0) && 110 === e.charCodeAt(1) && e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123;
            "undefined" != typeof HTMLElement && HTMLElement, Symbol("_moveCb"), Symbol("_enterCb"), Symbol("_assign");
            const Di = G({
                patchProp: (e, t, n, a, r, i) => {
                    const o = "svg" === r;
                    "class" === t ? function(e, t, n) {
                        const a = e[mi];
                        a && (t = (t ? [t, ...a] : [...a]).join(" ")), null == t ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t
                    }(e, a, o) : "style" === t ? function(e, t, n) {
                        const a = e.style,
                            r = Q(n);
                        let i = !1;
                        if (n && !r) {
                            if (t)
                                if (Q(t))
                                    for (const e of t.split(";")) {
                                        const t = e.slice(0, e.indexOf(":")).trim();
                                        null == n[t] && Ci(a, t, "")
                                    } else
                                        for (const e in t) null == n[e] && Ci(a, e, "");
                            for (const e in n) "display" === e && (i = !0), Ci(a, e, n[e])
                        } else if (r) {
                            if (t !== n) {
                                const e = a[ki];
                                e && (n += ";" + e), a.cssText = n, i = vi.test(n)
                            }
                        } else t && e.removeAttribute("style");
                        fi in e && (e[fi] = i ? a.display : "", e[bi] && (a.display = "none"))
                    }(e, n, a) : F(t) ? N(t) || function(e, t, n, a, r = null) {
                        const i = e[Ei] || (e[Ei] = {}),
                            o = i[t];
                        if (a && o) o.value = a;
                        else {
                            const [n, s] = function(e) {
                                let t;
                                if (zi.test(e)) {
                                    let n;
                                    for (t = {}; n = e.match(zi);) e = e.slice(0, e.length - n[0].length), t[n[0].toLowerCase()] = !0
                                }
                                return [":" === e[2] ? e.slice(3) : ue(e.slice(2)), t]
                            }(t);
                            if (a) {
                                const o = i[t] = function(e, t) {
                                    const n = e => {
                                        if (e._vts) {
                                            if (e._vts <= n.attached) return
                                        } else e._vts = Date.now();
                                        ln(function(e, t) {
                                            if ($(t)) {
                                                const n = e.stopImmediatePropagation;
                                                return e.stopImmediatePropagation = () => {
                                                    n.call(e), e._stopped = !0
                                                }, t.map(e => t => !t._stopped && e && e(t))
                                            }
                                            return t
                                        }(e, n.value), t, 5, [e])
                                    };
                                    return n.value = e, n.attached = Li(), n
                                }(a, r);
                                ! function(e, t, n, a) {
                                    e.addEventListener(t, n, a)
                                }(e, n, o, s)
                            } else o && (function(e, t, n, a) {
                                e.removeEventListener(t, n, a)
                            }(e, n, o, s), i[t] = void 0)
                        }
                    }(e, t, 0, a, i) : ("." === t[0] ? (t = t.slice(1), 1) : "^" === t[0] ? (t = t.slice(1), 0) : function(e, t, n, a) {
                        if (a) return "innerHTML" === t || "textContent" === t || !!(t in e && Ti(t) && Y(n));
                        if ("spellcheck" === t || "draggable" === t || "translate" === t || "autocorrect" === t) return !1;
                        if ("form" === t) return !1;
                        if ("list" === t && "INPUT" === e.tagName) return !1;
                        if ("type" === t && "TEXTAREA" === e.tagName) return !1;
                        if ("width" === t || "height" === t) {
                            const t = e.tagName;
                            if ("IMG" === t || "VIDEO" === t || "CANVAS" === t || "SOURCE" === t) return !1
                        }
                        return (!Ti(t) || !Q(n)) && t in e
                    }(e, t, a, o)) ? (Ai(e, t, a), e.tagName.includes("-") || "value" !== t && "checked" !== t && "selected" !== t || Ii(e, t, a, o, 0, "value" !== t)) : !e._isVueCE || !/[A-Z]/.test(t) && Q(a) ? ("true-value" === t ? e._trueValue = a : "false-value" === t && (e._falseValue = a), Ii(e, t, a, o)) : Ai(e, le(t), a, 0, t)
                }
            }, gi);
            let Bi;
            const Ri = (...e) => {
                const t = (Bi || (Bi = Qa(Di))).createApp(...e),
                    {
                        mount: n
                    } = t;
                return t.mount = e => {
                    const a = function(e) {
                        if (Q(e)) return document.querySelector(e);
                        return e
                    }(e);
                    if (!a) return;
                    const r = t._component;
                    Y(r) || r.render || r.template || (r.template = a.innerHTML), 1 === a.nodeType && (a.textContent = "");
                    const i = n(a, !1, function(e) {
                        return e instanceof SVGElement ? "svg" : "function" == typeof MathMLElement && e instanceof MathMLElement ? "mathml" : void 0
                    }(a));
                    return a instanceof Element && (a.removeAttribute("v-cloak"), a.setAttribute("data-v-app", "")), i
                }, t
            };
            const Mi = ["aria-label"],
                Ui = {
                    key: 0,
                    class: "checkout-plus"
                },
                Wi = {
                    class: "onward-flex"
                },
                Fi = {
                    id: "onward-content",
                    class: "onward-multi-line-container onward-flex onward-flex-1 onward-my-auto onward-flex-col"
                },
                Ni = {
                    class: "onward-flex onward-justify-between"
                },
                Gi = {
                    class: "onward-flex onward-items-center"
                },
                qi = {
                    key: 0,
                    class: "onward-inline-flex onward-gap-1 onward-items-center",
                    id: "powered-by"
                },
                Hi = {
                    key: 1,
                    class: "onward-inline-flex onward-gap-1 onward-ml-[4px] onward-items-center",
                    id: "powered-by"
                },
                Ki = {
                    key: 1
                },
                $i = {
                    class: "onward-flex"
                },
                Zi = {
                    id: "onward-toggle",
                    for: "insuranceToggle",
                    class: "onward-flex onward-items-center onward-cursor-pointer onward-mb-0"
                },
                Ji = ["aria-pressed"],
                Yi = {
                    key: 0,
                    class: "onward-flex onward-flex-col onward-flex-1",
                    id: "onward-widget-footer"
                },
                Qi = {
                    key: 0,
                    id: "powered-by",
                    class: "onward-flex onward-text-left onward-mt-[10px] onward-leading-normal onward-w-[fit-content]"
                },
                Xi = ["shopId", "analyticsEnabled", "selectedByDefault", "rewardsEnabled", "rewardsPercentage", "productGuaranteesEnabled", "carbonOffsetsEnabled", "flatRateReturnEnabled", "oneLine", "insuranceFeePercentage", "category"],
                eo = {
                    publish: function(e, t = {}) {
                        var n;
                        if (null === (n = window.Shopify) || void 0 === n ? void 0 : n.analytics) return window.Shopify.analytics.publish(e, t);
                        !async function(e, t) {
                            const n = e => "true" === e || !0 === e,
                                a = n(e.isDev) ? "dev-widget.useonward.com" : "widget.useonward.com";
                            if (n(e.analyticsEnabled)) {
                                let r = {
                                    name: t.name,
                                    domain: a,
                                    url: t.context.document.location.href,
                                    props: {
                                        shopId: parseInt(e.shopId),
                                        shopDomain: t.context.document.location.host,
                                        fullUrl: t.context.document.location.href,
                                        selectedByDefault: n(e.selectedByDefault),
                                        rewardsEnabled: n(e.rewardsEnabled),
                                        rewardsPercentage: e.rewardsPercentage,
                                        productGuaranteesEnabled: n(e.productGuaranteesEnabled),
                                        oneLine: n(e.oneLine),
                                        insuranceFeePercentage: e.insuranceFeePercentage,
                                        flatRateReturnEnabled: n(e.flatRateReturnEnabled),
                                        category: e.category,
                                        quantity: e.quantity,
                                        linesToAdd: e.linesToAdd,
                                        linesToRemove: e.linesToRemove,
                                        widgetUuid: e.widgetUuid
                                    }
                                };
                                fetch("https://analytics.useonward.com/api/event", {
                                    method: "POST",
                                    body: JSON.stringify(r),
                                    keepalive: !0
                                })
                            }
                        }(t, {
                            name: e,
                            context: {
                                document: window
                            }
                        })
                    }
                };
            class to {
                constructor(e, t = null) {
                    this.onwardSettings = e, this.engine = null != t ? t : eo
                }
                publish(e, t = {}) {
                    const n = Object.fromEntries(Xi.map(e => [e, this.onwardSettings[e]]));
                    this.engine.publish(e, Object.assign(Object.assign({}, t), n))
                }
            }
            let no = null;

            function ao(e, t = null) {
                return no || (no = new to(e, t)), no
            }
            const ro = {
                    class: "onward-modal-feature-icon onward-relative after:onward-content-[''] after:onward-bg-[#D4587D] after:onward-absolute after:onward-w-px after:onward-h-[130%] after:onward-top-[25px] after:onward-z-[-1] after:onward-left-2/4 after:onward-translate-x-2/4"
                },
                io = ["src"],
                oo = {
                    class: "onward-flex onward-flex-col"
                },
                so = {
                    class: "onward-text-[13px] onward-font-inherit onward-leading-none onward-tracking-normal onward-m-0 onward-font-bold onward-gradient-text"
                },
                lo = {
                    class: "onward-text-[10px] onward-font-normal onward-leading-normal onward-tracking-normal onward-m-0 onward-text-black onward-mt-1"
                };
            var co = {
                __name: "FeatureModalItem",
                props: ["title", "description", "icon", "type"],
                setup(e) {
                    const t = e;
                    return (e, n) => (Sr(), Er("div", {
                        class: Oe(`onward-modal-feature onward-modal-feature__${t.type} onward-flex onward-space-x-4`)
                    }, [Dr("div", ro, [Dr("img", {
                        src: t.icon,
                        width: "25",
                        alt: "Onward benefit icon",
                        role: "presentation",
                        border: "0",
                        class: "onward-max-w-none onward-max-h-none onward-w-[30px]"
                    }, null, 8, io)]), Dr("div", oo, [Dr("div", so, Ae(t.title), 1), Dr("div", lo, Ae(t.description), 1)])], 2))
                }
            };
            const uo = ["href"],
                po = ["color"],
                ho = ["id"],
                wo = ["id", "xlink:href"],
                go = ["id", "xlink:href"],
                mo = ["fill"],
                fo = ["fill"],
                bo = ["fill"];
            var xo = {
                __name: "OnwardLogo",
                setup(e) {
                    const t = {
                            black: "#000000",
                            white: "#FFFFFF"
                        },
                        n = T.load(),
                        a = t[n.poweredByLogoColor],
                        r = Jt(`onward-radial-gradient-${O()}`),
                        i = Jt(a || t.black),
                        o = Jt(a ? "currentColor" : `url(#${r.value})`),
                        s = Jt(a ? "currentColor" : `url(#${r.value}-2)`),
                        d = Jt(a ? "currentColor" : `url(#${r.value}-3)`);
                    return (e, t) => (Sr(), Er("a", {
                        href: Xt(n).shoppersUrl + "?utm_source=widget",
                        target: "_blank",
                        "aria-label": "Powered by Onward",
                        class: "onward-mr-1 onward-mb-0 onward-no-underline onward-cursor-pointer onward-shrink-0 onward-inline-flex"
                    }, [(Sr(), Er("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        "xmlns:xlink": "http://www.w3.org/1999/xlink",
                        viewBox: "0 0 1095 196",
                        color: i.value,
                        class: "onward-h-[12px] onward-w-[initial]"
                    }, [Dr("defs", null, [Dr("radialGradient", {
                        id: `${r.value}`,
                        cx: "-62.07",
                        cy: "-601.09",
                        fx: "-62.07",
                        fy: "-601.09",
                        r: "1",
                        gradientTransform: "translate(-94010.21 -118144.57) rotate(-45) scale(277.19 -249.8)",
                        gradientUnits: "userSpaceOnUse"
                    }, [...t[0] || (t[0] = [Dr("stop", {
                        offset: "0",
                        "stop-color": "#ff7943"
                    }, null, -1), Dr("stop", {
                        offset: ".25",
                        "stop-color": "#ec595b"
                    }, null, -1), Dr("stop", {
                        offset: ".59",
                        "stop-color": "#da3daf"
                    }, null, -1), Dr("stop", {
                        offset: "1",
                        "stop-color": "#9c95dc"
                    }, null, -1)])], 8, ho), Dr("radialGradient", {
                        id: `${r.value}-2`,
                        cy: "-601.09",
                        fy: "-601.09",
                        r: "1",
                        "xlink:href": `#${r.value}`
                    }, null, 8, wo), Dr("radialGradient", {
                        id: `${r.value}-3`,
                        cx: "-62.07",
                        cy: "-601.09",
                        fx: "-62.07",
                        fy: "-601.09",
                        r: "1",
                        "xlink:href": `#${r.value}`
                    }, null, 8, go)]), t[1] || (t[1] = Ur('<path fill="currentColor" d="m320.45,196c50.81,0,84.69-36.4,84.69-86.55s-33.88-87.04-84.69-87.04-84.45,36.65-84.45,87.04,33.88,86.55,84.45,86.55Zm.23-32.55c-29.93,0-49.88-19.77-49.88-54s19.95-54.49,49.88-54.49,49.65,19.77,49.65,54.49-19.95,54-49.65,54Z"></path><path fill="currentColor" d="m494.15,70.87c-18.79,0-33.88,10.13-41.07,28.45v-26.04h-32.25v120.31h33.87v-61.72c0-20.73,10.9-30.62,25.75-30.62,13.22,0,23.67,6.99,23.67,26.52v65.82h33.64v-75.95c0-29.65-18.1-46.77-43.62-46.77Z"></path><path fill="currentColor" d="m690.5,153.09l-23.2-79.8h-41.07l-23.43,79.56-22.74-79.56h-35.5l36.66,120.31h37.82l26.91-86.55,26.68,86.55h39.44l36.89-120.31h-35.5l-22.97,79.8Z"></path><path fill="currentColor" d="m804.53,70.87c-17.63,0-35.03,5.3-47.8,14.47v30.38c12.3-9.64,27.61-15.19,41.3-15.19,17.17,0,27.84,8.68,27.84,24.59v5.06c-7.42-5.3-17.4-8.2-29.93-8.2-26.22,0-45.01,14.47-45.01,37.13s16.71,36.89,42.69,36.89c15.78,0,28.07-6.27,34.8-16.88v14.47h30.86v-68.47c0-34.48-19.95-54.25-54.76-54.25Zm.93,101.98c-12.76,0-20.42-6.03-20.42-15.67s8.12-15.91,21.35-15.91c12.07,0,20.88,6.75,20.88,15.91,0,9.64-8.82,15.67-21.81,15.67Z"></path><path fill="currentColor" d="m946.91,70.87c-18.1,0-29.7,10.61-35.5,32.07v-29.65h-31.79v120.31h33.41v-53.28c0-27,12.3-37.61,31.79-37.61,6.96,0,13.69,2.41,17.63,4.82v-33.03c-3.48-2.17-9.75-3.62-15.55-3.62Z"></path><path fill="currentColor" d="m1056.59,97.15c-7.66-16.64-21.81-26.28-41.76-26.28-30.63,0-48.96,24.59-48.96,62.68s18.33,62.44,49.19,62.44c19.95,0,33.87-9.64,41.53-26.28v23.87h33.41V20h-33.41v77.15Zm-28.07,68.23c-17.87,0-29.24-12.54-29.24-31.82s11.37-32.07,29.24-32.07,29,12.54,29,32.07-11.37,31.82-29,31.82Z"></path>', 6)), Dr("path", {
                        fill: o.value,
                        d: "m43.92,152.09L0,164.79v31.2h31.26l12.66-43.91Z"
                    }, null, 8, mo), Dr("path", {
                        fill: s.value,
                        d: "m0,111.42v31.09l74.83-21.45-21.45,74.94h31.46l34.09-118.6L0,111.42Z"
                    }, null, 8, fo), Dr("path", {
                        fill: d.value,
                        d: "m0,55.86v33.29l150.19-42.96-43.05,149.81h33.37L196,0,0,55.86Z"
                    }, null, 8, bo)], 8, po))], 8, uo))
                }
            };
            const yo = ["data-open"],
                ko = {
                    key: 0,
                    class: "custom-modal onward-max-w-[380px] onward-w-full onward-flex-col onward-rounded-2 onward-bg-white onward-z-[2147483647] onward-overflow-auto onward-max-h-full onward-px-4"
                },
                vo = {
                    class: "onward-z-10 onward-relative"
                },
                Po = ["innerHTML"],
                Co = {
                    class: "onward-flex onward-flex-col onward-items-center onward-mt-8"
                },
                Oo = {
                    class: "onward-flex onward-items-center onward-space-x-[4px]"
                },
                So = {
                    class: "onward-w-[55px]"
                },
                _o = ["href"],
                Io = {
                    key: 1,
                    class: "onward-max-w-[380px] onward-w-full onward-flex-col onward-rounded-2 onward-bg-white onward-z-[2147483647] onward-overflow-auto onward-max-h-full onward-px-4"
                },
                Ao = {
                    class: "onward-modal-header onward-relative onward-max-w-[285px] onward-m-auto onward-flex onward-flex-row onward-pt-[35px] onward-flex-row-reverse onward-justify-between"
                },
                Eo = {
                    class: "onward-z-10"
                },
                zo = {
                    class: "onward-flex onward-flex-col onward-items-center"
                },
                jo = {
                    class: "onward-flex onward-items-center onward-space-x-4"
                },
                Vo = {
                    class: "onward-w-[82px]"
                },
                Lo = {
                    class: "onward-modal-body onward-max-w-[285px] onward-m-auto"
                },
                To = {
                    class: "onward-modal-feature-list onward-flex onward-flex-col onward-space-y-8 onward-mt-8 onward-mb-5"
                },
                Do = {
                    class: "onward-flex onward-flex-col"
                },
                Bo = {
                    class: "onward-text-[36px] onward-font-inherit onward-leading-none onward-tracking-normal onward-m-0 onward-font-bold onward-mb-2 onward-gradient-text"
                },
                Ro = {
                    class: "onward-text-[12px] onward-font-normal onward-leading-normal onward-tracking-normal onward-m-0 onward-text-[#270F2F] onward-mt-1"
                },
                Mo = {
                    class: "onward-flex onward-flex-col onward-space-y-8"
                },
                Uo = {
                    key: 0,
                    class: "onward-space-y-4"
                },
                Wo = {
                    key: 0,
                    class: "onward-modal-subscription-line onward-flex onward-justify-center onward-text-[9px] onward-font-inherit onward-text-left onward-leading-tight onward-tracking-normal onward-m-0 onward-text-gray-500"
                },
                Fo = {
                    class: ""
                },
                No = {
                    key: 1,
                    class: "onward-modal-subscription-line onward-italic onward-flex onward-text-[9px] onward-font-inherit onward-text-left onward-leading-tight onward-tracking-normal onward-m-0 onward-text-gray-500"
                },
                Go = {
                    class: ""
                },
                qo = {
                    class: "onward-modal-footer onward-flex onward-items-center onward-justify-around onward-mt-4 onward-border-t onward-border-l-0 onward-border-r-0 onward-border-b-0 onward-border-solid onward-border-border onward-pt-3 onward-pb-8 onward-gap-2"
                },
                Ho = ["href"];
            var Ko = {
                __name: "FeaturesModal",
                props: ["isOpen", "setIsOpen"],
                setup(e, {
                    expose: t
                }) {
                    t({
                        dialogRef: Nn("dialog-ref")
                    });
                    const n = Jt(T.load()),
                        {
                            leadFeature: a,
                            featureList: r
                        } = function(e) {
                            const t = [{
                                    type: "extended_warranties",
                                    description: e.translations.modal.extendedWarranties.text,
                                    title: e.translations.modal.extendedWarranties.heading,
                                    icon: e.translations.modal.extendedWarranties.icon,
                                    visible: e.showExtendedWarrantiesWording
                                }, {
                                    type: "cashback",
                                    description: C(e.translations.modal.rewards.text, {
                                        rewardsPercentage: e.rewardsPercentageFormatted
                                    }),
                                    title: C(e.translations.modal.rewards.heading, {
                                        rewardsPercentage: e.rewardsPercentageFormatted
                                    }),
                                    icon: e.translations.modal.rewards.icon,
                                    visible: e.showRewardsWording
                                }, {
                                    type: "product_guarantees",
                                    description: e.productGuaranteesTextFormatted,
                                    title: e.translations.modal.productGuarantees.heading,
                                    icon: e.translations.modal.productGuarantees.icon,
                                    visible: e.showProductGuaranteesWording
                                }, {
                                    type: "free_returns",
                                    description: e.translations.modal.freeReturns.text,
                                    title: e.translations.modal.freeReturns.heading,
                                    icon: e.translations.modal.freeReturns.icon,
                                    visible: e.showReturnsAppWording
                                }, {
                                    type: "returns_and_exchanges",
                                    description: e.translations.modal.returnsAndExchanges.text,
                                    title: e.translations.modal.returnsAndExchanges.heading,
                                    icon: e.translations.modal.returnsAndExchanges.icon,
                                    visible: e.showReturnsAndExchangesWording
                                }, {
                                    type: "protect",
                                    description: e.translations.modal.protect.text,
                                    title: e.translations.modal.protect.heading,
                                    icon: e.translations.modal.protect.icon,
                                    visible: !0
                                }, {
                                    type: "carbon_offsets",
                                    description: e.translations.modal.carbonOffsets.text,
                                    title: e.translations.modal.carbonOffsets.heading,
                                    icon: e.translations.modal.carbonOffsets.icon,
                                    visible: e.showCarbonOffsetWording
                                }, {
                                    type: "priority_support",
                                    description: e.translations.modal.prioritySupport.text,
                                    title: e.translations.modal.prioritySupport.heading,
                                    icon: e.translations.modal.prioritySupport.icon,
                                    visible: !0
                                }],
                                [n, ...a] = t.filter(e => e.visible);
                            return {
                                leadFeature: n,
                                featureList: a
                            }
                        }(n.value),
                        i = n.value.modalContentFormatted,
                        o = n.value.showCustomModal && i,
                        s = e => (e.composedPath().some(e => "A" === e.nodeName) || e.preventDefault(), e.stopPropagation(), !1);
                    return (t, d) => (Sr(), Er("dialog", {
                        id: "onward-modal",
                        ref: "dialog-ref",
                        "data-open": e.isOpen,
                        "aria-label": "Onward Features Information Modal",
                        class: "onward-flex onward-items-center onward-justify-center onward-rounded-2xl onward-px-4 onward-font-inter onward-text-left onward-m-auto onward-top-0 onward-bottom-0 onward-right-0 onward-left-0",
                        onClick: d[2] || (d[2] = t => e.setIsOpen(!1))
                    }, [Dr("div", {
                        id: "onward-modal-container",
                        onClick: s
                    }, [Xt(o) ? (Sr(), Er("div", ko, [Dr("div", vo, [Dr("button", {
                        type: "button",
                        "aria-label": "Close information modal",
                        onClick: d[0] || (d[0] = t => e.setIsOpen(!1)),
                        id: "onward-modal-close",
                        class: "onward-inline-flex onward-items-center onward-justify-center onward-cursor-pointer onward-bg-transparent onward-border-0 onward-p-0 onward-absolute onward-top-4 onward-right-0"
                    }, [...d[3] || (d[3] = [Dr("div", {
                        class: "onward-w-[20px] onward-h-[20px] onward-items-center"
                    }, [Dr("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "20",
                        height: "20",
                        viewBox: "0 0 20 20",
                        fill: "none",
                        "aria-label": "Onward Logo"
                    }, [Dr("path", {
                        d: "M14.8492 14.8501C14.6489 15.0505 14.4132 15.1504 14.1421 15.15C13.8711 15.1504 13.6354 15.0505 13.435 14.8501L9.89949 11.3146L6.36396 14.8501C6.16361 15.0505 5.92768 15.1507 5.65615 15.1507C5.38556 15.1507 5.15009 15.0505 4.94975 14.8501C4.7494 14.6498 4.64899 14.4141 4.64852 14.143C4.64899 13.872 4.7494 13.6363 4.94975 13.4359L8.48528 9.90039L4.94975 6.36486C4.7494 6.16451 4.64923 5.92857 4.64923 5.65704C4.64923 5.38646 4.7494 5.15099 4.94975 4.95064C5.15009 4.7503 5.3858 4.64989 5.65685 4.64942C5.92791 4.64989 6.16361 4.7503 6.36396 4.95064L9.89949 8.48618L13.435 4.95064C13.6354 4.7503 13.8708 4.65012 14.1414 4.65012C14.413 4.65012 14.6489 4.7503 14.8492 4.95064C15.0496 5.15099 15.1495 5.38669 15.1491 5.65775C15.1495 5.92881 15.0496 6.16451 14.8492 6.36486L11.3137 9.90039L14.8492 13.4359C15.0496 13.6363 15.1498 13.8717 15.1498 14.1423C15.1498 14.4139 15.0496 14.6498 14.8492 14.8501Z",
                        fill: "black",
                        "fill-opacity": "0.3"
                    })])], -1)])])]), Dr("div", {
                        id: "onward-modal-body",
                        class: "onward-modal-body__custom",
                        innerHTML: Xt(i)
                    }, null, 8, Po), Dr("div", Co, [Dr("div", Oo, [d[5] || (d[5] = Dr("div", {
                        class: "onward-text-[10px] onward-text-[#B3B3B3] onward-font-[Inter]"
                    }, "Powered by", -1)), Dr("div", So, [Dr("a", {
                        href: n.value.shoppersUrl + "?utm_source=widget_modal",
                        target: "_blank",
                        "aria-label": "Link to Onward will open in a new tab",
                        id: "onward-modal-for-shoppers-link",
                        class: "onward-text-[9px] onward-font-inherit onward-leading-none onward-text-gray-500 onward-underline hover:onward-text-gray-900 onward-cursor-pointer onward-text-center"
                    }, [...d[4] || (d[4] = [Ur('<svg xmlns="http://www.w3.org/2000/svg" width="55" height="16" viewBox="0 0 82 16" fill="#ccc"><path d="M24.1074 15.221C27.9299 15.221 30.4783 12.5012 30.4783 8.75468C30.4783 4.99019 27.9299 2.25238 24.1074 2.25238C20.3023 2.25238 17.7539 4.99019 17.7539 8.75468C17.7539 12.5012 20.3023 15.221 24.1074 15.221ZM24.1248 12.7893C21.8732 12.7893 20.3721 11.3124 20.3721 8.75468C20.3721 6.16097 21.8732 4.68399 24.1248 4.68399C26.359 4.68399 27.8601 6.16097 27.8601 8.75468C27.8601 11.3124 26.359 12.7893 24.1248 12.7893Z"></path><path d="M37.1745 5.87278C35.7607 5.87278 34.6262 6.62928 34.0851 7.99818V6.0529H31.6589V15.0408H34.2072V10.4298C34.2072 8.88076 35.0276 8.14228 36.1447 8.14228C37.1396 8.14228 37.9251 8.66462 37.9251 10.1236V15.0408H40.456V9.36709C40.456 7.15162 39.0945 5.87278 37.1745 5.87278Z"></path><path d="M51.946 12.0148L50.2005 6.0529H47.111L45.3481 11.9968L43.6376 6.0529H40.9671L43.7249 15.0408H46.57L48.5947 8.57456L50.6019 15.0408H53.5692L56.3445 6.0529H53.6739L51.946 12.0148Z"></path><path d="M60.5242 5.87278C59.1976 5.87278 57.8885 6.26904 56.9285 6.95349V9.22299C57.8536 8.50251 59.0056 8.08824 60.0354 8.08824C61.3271 8.08824 62.13 8.73667 62.13 9.92545V10.3037C61.5714 9.90744 60.8209 9.6913 59.8783 9.6913C57.906 9.6913 56.4922 10.772 56.4922 12.4651C56.4922 14.1402 57.7489 15.221 59.7038 15.221C60.8907 15.221 61.8158 14.7526 62.322 13.9601V15.0408H64.6434V9.92545C64.6434 7.34975 63.1423 5.87278 60.5242 5.87278ZM60.594 13.4918C59.634 13.4918 59.058 13.0415 59.058 12.321C59.058 11.6006 59.6689 11.1323 60.6638 11.1323C61.5714 11.1323 62.2347 11.6366 62.2347 12.321C62.2347 13.0415 61.5714 13.4918 60.594 13.4918Z"></path><path d="M71.235 5.87278C69.8735 5.87278 69.0008 6.6653 68.5644 8.26836V6.0529H66.1732V15.0408H68.6866V11.0602C68.6866 9.04287 69.6117 8.25035 71.0779 8.25035C71.6015 8.25035 72.1077 8.43047 72.4044 8.61059V6.14296C72.1426 5.98085 71.6713 5.87278 71.235 5.87278Z"></path><path d="M79.4863 7.83607C78.9103 6.59325 77.8456 5.87278 76.3445 5.87278C74.0405 5.87278 72.6616 7.70999 72.6616 10.5559C72.6616 13.3657 74.0405 15.221 76.362 15.221C77.863 15.221 78.9103 14.5005 79.4863 13.2577V15.0408H81.9998V2.07227H79.4863V7.83607ZM77.3743 12.9334C76.0303 12.9334 75.175 11.9968 75.175 10.5559C75.175 9.09691 76.0303 8.16029 77.3743 8.16029C78.7009 8.16029 79.5561 9.09691 79.5561 10.5559C79.5561 11.9968 78.7009 12.9334 77.3743 12.9334Z"></path><path d="M3.30372 11.9404L0 12.8897V15.2209H2.35142L3.30372 11.9404Z"></path><path d="M0 8.90214V11.2245L5.62934 9.62199L4.01565 15.2209H6.38242L8.94678 6.36046L0 8.90214Z"></path><path d="M0 4.75126V7.23831L11.2987 4.02856L8.05976 15.2209H10.5698L14.745 0.578125L0 4.75126Z"></path></svg>', 1)])], 8, _o)])])])])) : (Sr(), Er("div", Io, [Dr("header", Ao, [Dr("div", Eo, [Dr("button", {
                        type: "button",
                        "aria-label": "Close information modal",
                        onClick: d[1] || (d[1] = t => e.setIsOpen(!1)),
                        id: "onward-modal-close",
                        class: "onward-inline-flex onward-items-center onward-justify-center onward-cursor-pointer onward-bg-transparent onward-border-0 onward-p-0"
                    }, [...d[6] || (d[6] = [Dr("div", {
                        class: "onward-w-[20px] onward-h-[20px] onward-items-center"
                    }, [Dr("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "20",
                        height: "20",
                        viewBox: "0 0 20 20",
                        fill: "none",
                        "aria-label": "Onward Logo"
                    }, [Dr("path", {
                        d: "M14.8492 14.8501C14.6489 15.0505 14.4132 15.1504 14.1421 15.15C13.8711 15.1504 13.6354 15.0505 13.435 14.8501L9.89949 11.3146L6.36396 14.8501C6.16361 15.0505 5.92768 15.1507 5.65615 15.1507C5.38556 15.1507 5.15009 15.0505 4.94975 14.8501C4.7494 14.6498 4.64899 14.4141 4.64852 14.143C4.64899 13.872 4.7494 13.6363 4.94975 13.4359L8.48528 9.90039L4.94975 6.36486C4.7494 6.16451 4.64923 5.92857 4.64923 5.65704C4.64923 5.38646 4.7494 5.15099 4.94975 4.95064C5.15009 4.7503 5.3858 4.64989 5.65685 4.64942C5.92791 4.64989 6.16361 4.7503 6.36396 4.95064L9.89949 8.48618L13.435 4.95064C13.6354 4.7503 13.8708 4.65012 14.1414 4.65012C14.413 4.65012 14.6489 4.7503 14.8492 4.95064C15.0496 5.15099 15.1495 5.38669 15.1491 5.65775C15.1495 5.92881 15.0496 6.16451 14.8492 6.36486L11.3137 9.90039L14.8492 13.4359C15.0496 13.6363 15.1498 13.8717 15.1498 14.1423C15.1498 14.4139 15.0496 14.6498 14.8492 14.8501Z",
                        fill: "black",
                        "fill-opacity": "0.3"
                    })])], -1)])])]), Dr("div", zo, [Dr("div", jo, [Dr("div", Vo, [Br(xo)])])])]), Dr("main", Lo, [Dr("div", To, [Dr("section", {
                        class: Oe(`onward-modal-feature onward-modal-feature-lead onward-modal-feature__${Xt(a).type} onward-flex onward-space-x-4`)
                    }, [Dr("div", Do, [Dr("h1", Bo, Ae(Xt(a).title), 1), Dr("p", Ro, Ae(Xt(a).description), 1)])], 2), Dr("div", Mo, [(Sr(!0), Er(yr, null, ga(Xt(r), e => (Sr(), zr(co, {
                        title: e.title,
                        description: e.description,
                        icon: e.icon,
                        type: e.type
                    }, null, 8, ["title", "description", "icon", "type"]))), 256))]), n.value.showSubscriptionWording || n.value.showRewardsWording ? (Sr(), Er("div", Uo, [n.value.showSubscriptionWording ? (Sr(), Er("div", Wo, [Dr("div", Fo, Ae(n.value.translations.modal.subscriptions.text), 1)])) : Wr("v-if", !0), n.value.showRewardsDisclaimer ? (Sr(), Er("div", No, [Dr("div", Go, Ae(n.value.translations.modal.rewardsDisclaimer.text), 1)])) : Wr("v-if", !0)])) : Wr("v-if", !0)])]), Dr("footer", qo, [Dr("a", {
                        href: n.value.shoppersUrl + "?utm_source=widget_modal",
                        target: "_blank",
                        "aria-label": "Link to onward FAQ will open in a new tab",
                        id: "onward-modal-faq-link",
                        class: "onward-text-[9px] onward-font-inherit onward-leading-none onward-text-gray-500 onward-underline hover:onward-text-gray-900 onward-cursor-pointer onward-text-center"
                    }, " FAQ ", 8, Ho), d[7] || (d[7] = Dr("a", {
                        href: "https://useonward.com/privacy-and-data-security-statement?utm_source=widget_modal",
                        target: "_blank",
                        "aria-label": "Link to onward Privacy Policy will open in a new tab",
                        id: "onward-modal-policy-link",
                        class: "onward-text-[9px] onward-font-inherit onward-leading-none onward-text-gray-500 onward-underline hover:onward-text-gray-900 onward-cursor-pointer onward-text-center"
                    }, " Privacy Policy ", -1)), d[8] || (d[8] = Dr("a", {
                        href: "https://useonward.com/terms-and-conditions?utm_source=widget_modal",
                        target: "_blank",
                        "aria-label": "Link to onward Terms of Service will open in a new tab",
                        id: "onward-modal-terms-link",
                        class: "onward-text-[9px] onward-font-inherit onward-leading-none onward-text-gray-500 onward-underline hover:onward-text-gray-900 onward-cursor-pointer onward-text-center"
                    }, " Terms of Service ", -1))])]))])], 8, yo))
                }
            };
            n(771);
            var $o = Ko,
                Zo = {
                    __name: "InfoIcon",
                    props: ["setIsOpen", "customStyles"],
                    setup(e) {
                        return (t, n) => (Sr(), Er("button", {
                            id: "onward-info-button",
                            type: "button",
                            onClick: n[0] || (n[0] = t => e.setIsOpen(!0)),
                            "aria-label": "Open onward more information modal",
                            class: Oe(["onward-bg-transparent onward-border-0 onward-p-0", [e.customStyles]])
                        }, [...n[1] || (n[1] = [Dr("svg", {
                            id: "onward-info-icon",
                            xmlns: "http://www.w3.org/2000/svg",
                            fill: "currentColor",
                            class: "onward-w-[13px] onward-h-[13px] onward-cursor-pointer",
                            viewBox: "0 0 16 16"
                        }, [Dr("path", {
                            d: "M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"
                        }), Dr("path", {
                            d: "m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"
                        })], -1)])], 2))
                    }
                };
            const Jo = {
                    key: 0,
                    id: "onward-content",
                    class: "onward-one-line-container onward-one-line-container__cashback onward-flex onward-flex-1 onward-my-auto onward-mr-2"
                },
                Yo = {
                    key: 1,
                    id: "onward-content",
                    class: "onward-one-line-container onward-flex onward-flex-1 onward-my-auto onward-mr-2"
                },
                Qo = {
                    id: "onward-content",
                    class: "onward-multi-line-container onward-flex onward-flex-1 onward-my-auto onward-mr-2 onward-flex-col"
                },
                Xo = {
                    key: 0,
                    class: "onward-inline-flex onward-ml-[1px] onward-gap-1",
                    id: "powered-by"
                };
            var es = {
                    props: ["containerDivForAttributes", "onwardApp"],
                    components: {
                        FeaturesModal: $o,
                        OnwardLogo: xo,
                        InfoIcon: Zo,
                        OneLineDisplay: {
                            __name: "OneLineDisplay",
                            props: ["copyLine1", "copyLine2", "setModalIsOpen", "insurancePrice", "widgetStyles", "labelToggle"],
                            setup(e) {
                                const t = Jt(T.load());
                                return (n, a) => (Sr(), Er(yr, null, [Wr(" Verify for oneLine directly from the settings to exclude PDP widgets from using new layout, otherwise the layout will break "), t.value.rewardsEnabled && t.value.oneLine ? (Sr(), Er("div", Jo, [Dr("div", {
                                    id: "onward-copy-line-1",
                                    class: Oe(["onward-text-left onward-text-xs onward-leading-tight onward-m-0 onward-font-inherit onward-font-medium onward-w-[fit-content] onward-pr-1 onward-cursor-pointer", [e.widgetStyles.textColorClass]])
                                }, [Dr("span", {
                                    class: "onward-underline onward-underline-offset-2 onward-font-bold",
                                    onClick: a[0] || (a[0] = t => e.setModalIsOpen(!0))
                                }, Ae(e.copyLine1), 1), a[5] || (a[5] = Mr(" + ", -1))], 2), Br(xo), Dr("div", {
                                    id: "onward-copy-line-2",
                                    class: Oe(["onward-text-left onward-text-xs onward-leading-tight onward-m-0 onward-font-inherit onward-font-medium onward-w-[fit-content] onward-pr-1 onward-cursor-pointer", [e.widgetStyles.textColorClass]])
                                }, [Dr("span", {
                                    onClick: a[1] || (a[1] = t => e.setModalIsOpen(!0))
                                }, Ae(e.copyLine2), 1)], 2), Dr("span", {
                                    id: "onward-price",
                                    class: Oe(["onward-text-[12px] onward-leading-tight onward-m-0 onward-font-inherit onward-text-right onward-pr-[2px]", [e.widgetStyles.textColorClass]]),
                                    onClick: a[2] || (a[2] = (...t) => e.labelToggle && e.labelToggle(...t))
                                }, [a[6] || (a[6] = Dr("span", {
                                    id: "onward-for-copy"
                                }, "for", -1)), Mr(" " + Ae(e.insurancePrice), 1)], 2)])) : (Sr(), Er("div", Yo, [Br(xo), Dr("div", {
                                    id: "onward-copy-line-1",
                                    class: Oe(["onward-text-left onward-text-xs onward-leading-tight onward-m-0 onward-font-inherit onward-font-medium onward-w-[fit-content] onward-pr-1 onward-cursor-pointer", [e.widgetStyles.textColorClass]])
                                }, [Dr("span", {
                                    onClick: a[3] || (a[3] = t => e.setModalIsOpen(!0))
                                }, Ae(e.copyLine1), 1)], 2), Dr("span", {
                                    id: "onward-price",
                                    class: Oe(["onward-text-[12px] onward-leading-tight onward-m-0 onward-font-inherit onward-text-right onward-pr-[2px]", [e.widgetStyles.textColorClass]]),
                                    onClick: a[4] || (a[4] = (...t) => e.labelToggle && e.labelToggle(...t))
                                }, [a[7] || (a[7] = Dr("span", {
                                    id: "onward-for-copy"
                                }, "for", -1)), Mr(" " + Ae(e.insurancePrice), 1)], 2), Dr("div", {
                                    class: Oe(["onward-ml-1 onward-flex", [e.widgetStyles.textColorClass]])
                                }, [Br(Zo, {
                                    setIsOpen: e.setModalIsOpen
                                }, null, 8, ["setIsOpen"])], 2)]))], 2112))
                            }
                        },
                        MultipleLineDisplay: {
                            __name: "MultipleLineDisplay",
                            props: ["copyLine1", "copyLine2", "setModalIsOpen", "insureOrder", "widgetStyles"],
                            setup(e) {
                                const t = Jt(T.load());
                                return (n, a) => (Sr(), Er("div", Qo, [Dr("div", {
                                    id: "onward-copy-line-1",
                                    class: Oe(["onward-text-left onward-text-xs onward-leading-tight onward-m-0 onward-font-inherit onward-font-medium onward-w-[fit-content] onward-pr-1 onward-cursor-pointer", [e.widgetStyles.textColorClass]])
                                }, [Dr("span", {
                                    onClick: a[0] || (a[0] = t => e.setModalIsOpen(!0))
                                }, Ae(e.copyLine1), 1), t.value.poweredByHeaderEnabled ? (Sr(), Er("div", Xo, [a[2] || (a[2] = Mr(" by ", -1)), Br(xo), Dr("div", {
                                    class: Oe(["onward-ml-1 onward-inline-flex onward-items-center", [e.widgetStyles.textColorClass]])
                                }, [Br(Zo, {
                                    setIsOpen: e.setModalIsOpen
                                }, null, 8, ["setIsOpen"])], 2)])) : Wr("v-if", !0)], 2), Dr("div", {
                                    id: "onward-copy-line-2",
                                    class: "onward-flex onward-text-left onward-mt-2 onward-leading-normal onward-w-[fit-content] onward-pr-1 onward-cursor-pointer",
                                    onClick: a[1] || (a[1] = t => e.setModalIsOpen(!0))
                                }, [!e.insureOrder && t.value.disclaimerEnabled ? (Sr(), Er("span", {
                                    key: 0,
                                    class: Oe([
                                        [e.widgetStyles.textColorClass], "onward-text-[11px] onward-leading-tight onward-ml-0 mw-ml-1 onward-mb-0 onward-font-light onward-whitespace-pre-line onward-disclaimer"
                                    ])
                                }, Ae(t.value.disclaimerText), 3)) : (Sr(), Er("span", {
                                    key: 1,
                                    class: Oe([
                                        [e.widgetStyles.textColorClass], "onward-text-[11px] onward-leading-tight onward-ml-0 mw-ml-1 onward-mb-0 onward-font-light onward-whitespace-pre-line"
                                    ])
                                }, Ae(e.copyLine2), 3))])]))
                            }
                        }
                    },
                    methods: {},
                    data() {
                        return {}
                    },
                    setup(e) {
                        let t = e.containerDivForAttributes,
                            n = e.onwardApp;
                        const r = T.load();
                        let i = t.getAttribute("data-wallets-variant-id"),
                            o = Jt(null),
                            s = Jt(null),
                            d = Jt(null),
                            l = Jt(null),
                            c = Jt(n.insureOrder),
                            u = Jt(!1),
                            p = Jt(!1),
                            h = Jt(!1),
                            w = Jt(t.hasAttribute("data-one-line") || r.oneLine),
                            g = Jt(t.hasAttribute("data-toggle-widget") || !r.checkoutPlusEnabled),
                            m = Jt(t.hasAttribute("data-hide-widget")),
                            f = Jt(t.hasAttribute("data-invert-colors")),
                            b = O();
                        const x = Nn("modal-ref");
                        a.log("Generated app instance", b);
                        let y = Jt({
                            textColorClass: r.ctaTextColor ? "onward-cta-text" : "onward-text-gray-700",
                            textSecondaryColorClass: "onward-text-gray-700",
                            svgFill: r.ctaTextColor || "#022342",
                            activeToggleClass: r.themePrimaryColor ? "onward-active-toggle" : "onward-bg-primary",
                            inactiveToggleClass: "onward-bg-gray-200",
                            switchOnTextColor: "onward-text-white",
                            switchOffTextColor: "onward-text-gray-500",
                            innerToggleNubClass: "onward-bg-white",
                            buttonLabelTextOn: "onward-text-white",
                            buttonLabelTextOff: "onward-text-gray-500",
                            switchNubOn: "onward-bg-white",
                            switchNubOff: "onward-bg-white",
                            sectionClasses: (k = r, w.value ? "onward-pt-[14px]" : k.backgroundColor ? "onward-py-[14px] onward-px-[24px] onward-rounded-[10px]" : "onward-py-[14px]"),
                            backgroundColor: r.backgroundColor
                        });
                        var k;
                        f.value && (y = Jt({
                            textColorClass: "onward-text-white",
                            textSecondaryColorClass: "text-white",
                            svgFill: "white",
                            activeToggleClass: "onward-bg-white",
                            inactiveToggleClass: "onward-bg-gray-400",
                            switchOnTextColor: "onward-text-black",
                            switchOffTextColor: "onward-text-black",
                            innerToggleNubClass: "onward-bg-gray-400",
                            buttonLabelTextOn: "onward-text-black",
                            buttonLabelTextOff: "onward-text-white",
                            switchNubOn: "onward-bg-gray-700",
                            switchNubOff: "onward-bg-white"
                        })), y.value.switchTranslateOn = "onward-translate-x-[15.5px]", y.value.switchTranslateOff = "onward-translate-x-0.5", ta(async () => {
                            p.value = !0
                        });
                        const v = di(function() {
                                return r.shopEnabled
                            }),
                            P = di(function() {
                                return o.value && !m.value
                            });
                        or(o, () => {
                            !h.value && P.value && (ao(r).publish("onward:visible"), h.value = !0)
                        });
                        const S = di(function() {
                                return C(g.value ? r.copyLine1 : r.checkoutPlusCopyLine1, {
                                    reward_amount: s.value,
                                    subtotal_with_onward: d.value,
                                    subtotal_without_onward: l.value
                                })
                            }),
                            _ = di(function() {
                                return C(g.value ? r.copyLine2 : i ? "ShopPay includes Checkout+ upgrade" : r.checkoutPlusCopyLine2, {
                                    reward_amount: s.value,
                                    subtotal_with_onward: d.value,
                                    subtotal_without_onward: l.value
                                })
                            });
                        return {
                            renderTemplateString: C,
                            insureOrder: c,
                            insurancePrice: o,
                            estimatedRewardsAmount: s,
                            subtotalWithOnward: d,
                            subtotalWithoutOnward: l,
                            renderWidget: v,
                            instanceUUID: b,
                            modalIsOpen: u,
                            labelToggle: function() {
                                a.log(`labelToggle start, insureOrder: ${c.value}`), n.toggleInsureOrder(), a.log("performToggleWork"), n.earlyUpdateUICartOnToggleTotalAndCount({}), a.log("end of toggle callled"), a.log(`labelToggle end, insureOrder: ${c.value}`)
                            },
                            showWidget: P,
                            finishedMounting: p,
                            onwardSettings: r,
                            widgetStyles: y,
                            copyLine1: S,
                            copyLine2: _,
                            oneLine: w,
                            toggleWidget: g,
                            hideWidget: m,
                            walletsVariantId: i,
                            setModalIsOpen(e) {
                                1 == e && window.onwardModalShown && window.onwardModalShown(), 0 == e && window.onwardModalHidden && window.onwardModalHidden(), ao(r).publish(e ? "onward:modal_open" : "onward:modal_close"), e ? x.value ? .dialogRef ? .showModal && x.value.dialogRef.showModal() : x.value ? .dialogRef ? .close && x.value.dialogRef.close(), u.value = e
                            }
                        }
                    }
                },
                ts = (0, n(262).A)(es, [
                    ["render", function(e, t, n, a, r, i) {
                        const o = pa("OnwardLogo"),
                            s = pa("InfoIcon"),
                            d = pa("OneLineDisplay"),
                            l = pa("MultipleLineDisplay"),
                            c = pa("FeaturesModal");
                        return a.renderWidget ? Bn((Sr(), Er("section", {
                            key: 0,
                            "aria-label": a.copyLine1,
                            class: Oe(["onward-font-inter onward-min-w-[300px] onward-max-w-[400px] onward-tracking-normal", a.widgetStyles.sectionClasses]),
                            style: ye([a.widgetStyles.backgroundColor && !a.onwardSettings.oneLine ? {
                                backgroundColor: a.widgetStyles.backgroundColor
                            } : {}])
                        }, [a.toggleWidget ? (Sr(), Er("div", Ki, [Dr("div", $i, [a.oneLine ? (Sr(), zr(d, {
                            key: 0,
                            copyLine1: a.copyLine1,
                            copyLine2: a.copyLine2,
                            setModalIsOpen: a.setModalIsOpen,
                            insurancePrice: a.insurancePrice,
                            widgetStyles: a.widgetStyles,
                            labelToggle: a.labelToggle
                        }, null, 8, ["copyLine1", "copyLine2", "setModalIsOpen", "insurancePrice", "widgetStyles", "labelToggle"])) : (Sr(), zr(l, {
                            key: 1,
                            copyLine1: a.copyLine1,
                            copyLine2: a.copyLine2,
                            insureOrder: a.insureOrder,
                            setModalIsOpen: a.setModalIsOpen,
                            widgetStyles: a.widgetStyles
                        }, null, 8, ["copyLine1", "copyLine2", "insureOrder", "setModalIsOpen", "widgetStyles"])), Dr("div", {
                            id: "onward-controls",
                            onClick: t[2] || (t[2] = (...e) => a.labelToggle && a.labelToggle(...e)),
                            class: Oe(["onward-flex onward-flex-col onward-space-y-1", a.oneLine ? "onward-space-y-0" : ""])
                        }, [a.oneLine ? Wr("v-if", !0) : (Sr(), Er("p", {
                            key: 0,
                            id: "onward-price",
                            class: Oe([
                                [a.widgetStyles.textSecondaryColorClass], "onward-text-[12px] onward-leading-tight onward-m-0 onward-font-inherit onward-text-right onward-pr-[2px]"
                            ])
                        }, Ae(a.insurancePrice), 3)), Bn(Dr("div", null, [Dr("label", Zi, [Dr("div", {
                            class: Oe(["onward-box-border onward-ml-auto onward-p-0 onward-relative onward-inline-flex onward-items-center onward-shrink-0 onward-cursor-pointer onward-border-solid onward-border-2 onward-border-transparent onward-rounded-full onward-transition-colors onward-ease-in-out onward-duration-200 onward-ring-0", ["onward-h-[16px] onward-w-8", a.insureOrder ? a.widgetStyles.activeToggleClass : "", a.insureOrder ? "" : a.widgetStyles.inactiveToggleClass]])
                        }, [Dr("button", {
                            type: "button",
                            "aria-label": "Add Onward insurance",
                            "aria-pressed": a.insureOrder,
                            class: Oe([
                                [a.insureOrder ? a.widgetStyles.switchTranslateOn : a.widgetStyles.switchTranslateOff, a.insureOrder ? a.widgetStyles.switchNubOn : a.widgetStyles.switchNubOff], "onward-pointer-events-none onward-inline-block onward-h-3 onward-w-3 onward-rounded-full onward-shadow onward-ring-0 onward-transition onward-ease-in-out onward-duration-200 onward-border-0 onward-p-0"
                            ])
                        }, " ", 10, Ji)], 2)])], 512), [
                            [xi, a.finishedMounting]
                        ])], 2)]), !a.oneLine && a.onwardSettings.poweredByFooterEnabled || a.onwardSettings.disclaimerEnabled ? (Sr(), Er("div", Yi, [!a.oneLine && a.onwardSettings.poweredByFooterEnabled ? (Sr(), Er("div", Qi, [Dr("div", {
                            class: Oe(["onward-text-[11px] onward-flex onward-leading-tight onward-ml-0 onward-mb-0 onward-shrink-0", [a.widgetStyles.textColorClass]])
                        }, [t[3] || (t[3] = Dr("span", {
                            id: "onward-power-by-copy",
                            class: "onward-mr-1"
                        }, "Powered by", -1)), Br(o)], 2), Dr("div", {
                            class: Oe(["onward-ml-1 onward-flex onward-items-center", [a.widgetStyles.textColorClass]])
                        }, [Br(s, {
                            setIsOpen: a.setModalIsOpen
                        }, null, 8, ["setIsOpen"])], 2)])) : Wr("v-if", !0)])) : Wr("v-if", !0)])) : (Sr(), Er("div", Ui, [Dr("div", Wi, [Dr("div", Fi, [Dr("div", Ni, [Dr("div", Gi, [Dr("div", {
                            id: "onward-copy-line-1",
                            class: Oe(["onward-flex onward-text-left onward-text-[13px] onward-leading-tight onward-m-0 onward-font-inherit onward-font-medium onward-w-[fit-content] onward-pr-1 onward-cursor-pointer", [a.widgetStyles.textColorClass]])
                        }, [a.onwardSettings.poweredByFooterEnabled ? (Sr(), Er("div", qi, [Br(o, {
                            class: "onward-pb-[2px]"
                        })])) : Wr("v-if", !0), Dr("span", {
                            onClick: t[0] || (t[0] = e => a.setModalIsOpen(!0))
                        }, Ae(a.copyLine1), 1), a.onwardSettings.poweredByHeaderEnabled ? (Sr(), Er("div", Hi, [Dr("span", {
                            class: Oe(["onward-text-[13px] onward-font-inherit onward-leading-tight", [a.widgetStyles.textColorClass]])
                        }, "by", 2), Br(o, {
                            class: "onward-pb-[2px]"
                        })])) : Wr("v-if", !0), Dr("div", {
                            id: "info-icon",
                            class: Oe(["onward-inline-flex onward-items-center onward-ml-1", [a.widgetStyles.textColorClass]])
                        }, [Br(s, {
                            setIsOpen: a.setModalIsOpen,
                            customStyles: "onward-flex"
                        }, null, 8, ["setIsOpen"])], 2)], 2)]), Dr("p", {
                            id: "onward-price",
                            class: Oe(["onward-text-[13px] onward-leading-tight onward-m-0 onward-font-inherit onward-text-right onward-pr-[2px]", [a.widgetStyles.textColorClass]])
                        }, Ae(a.insurancePrice), 3)]), a.walletsVariantId || !a.oneLine ? (Sr(), Er("div", {
                            key: 0,
                            id: "onward-copy-line-2",
                            class: "onward-flex onward-text-left onward-mt-2 onward-leading-normal onward-w-[fit-content] onward-pr-1 onward-cursor-pointer",
                            onClick: t[1] || (t[1] = e => a.setModalIsOpen(!0))
                        }, [Dr("span", {
                            class: Oe([
                                [a.widgetStyles.textColorClass], "onward-text-[11px] onward-leading-normal onward-ml-0 mw-ml-1 onward-mb-0 onward-font-light onward-whitespace-pre-line"
                            ])
                        }, Ae(a.copyLine2), 3)])) : Wr("v-if", !0)])])])), Br(c, {
                            isOpen: a.modalIsOpen,
                            setIsOpen: a.setModalIsOpen,
                            ref: "modal-ref"
                        }, null, 8, ["isOpen", "setIsOpen"])], 14, Mi)), [
                            [xi, a.showWidget]
                        ]) : Wr("v-if", !0)
                    }]
                ]),
                ns = n(844);
            const as = e => {
                    if ("a" === e.tagName.toLowerCase()) {
                        const t = new URL(e.href);
                        return ["/checkout", "/checkout/"].includes(t.pathname)
                    }
                    return !0
                },
                rs = (e, t) => {
                    "INPUT" === e.nodeName ? (e.dataset.onwardOriginalLabel || = e.value, e.value = t) : (e.dataset.onwardOriginalLabel || = e.innerHTML, e.textContent = t)
                },
                is = e => {
                    const t = e.dataset.onwardOriginalLabel;
                    t && ("INPUT" === e.nodeName ? e.value = t : e.innerHTML = t)
                };
            class os {
                vueApps = [];
                addedHandlers = [];
                locale = null;
                onwardSettings = null;
                storefrontClient = null;
                localStore = null;
                insureOrder = null;
                addedCheckoutButtonHandlers = [];
                proceedInitiated = !1;
                insideCheckout = !1;
                instanceUUID = null;
                nullified = !1;
                onwardClientInitializing = null;
                logger = null;
                domRoots = [];
                static CheckoutPlusBtnBaseClass = "onward-checkout-btn__plus";
                static CheckoutPlusOriginalBtnBaseClass = "onward-checkout-btn";
                static OptOutLinkBaseClass = "onward-opt-out-link";
                static OptOutLinkClasses = [this.OptOutLinkBaseClass, "onward-cursor-pointer", "onward-bg-transparent", "onward-underline", "onward-border-none", "onward-mt-2", "onward-mr-0", "onward-mb-0", "onward-ml-0", "onward-pt-2", "onward-pr-0", "onward-pb-0", "onward-pl-0", "onward-w-full", "onward-text-center", "!onward-text-[13px]", "onward-capitalize", "onward-block"].join(" ");
                static CheckoutButtonSelectors = '\n    form[action$="/cart"] button[type="submit"],\n    form[action$="/cart"] input[type="submit"],\n    button[form="cart"],\n    button[form="mini-cart-form"],\n    button.rebuy-cart__checkout-button,\n    a[href*="/checkout"]\n  ';
                static PDPMorePaymentsSelectors = "\n    #more-payment-options-link,\n    .shopify-payment-button__more-options\n  ";
                static computeOptOutClasses(e, t = !1) {
                    let n = t ? "!onward-text-white" : "!onward-text-black";
                    return e ? `${this.OptOutLinkBaseClass} ${e}` : `${this.OptOutLinkClasses} ${n}`
                }
                constructor(e, t, n) {
                    this.vueApps = [], this.optOutButtons = [], this.checkoutButtons = [], this.onwardSettings = T.parse(JSON.stringify(e)), this.storefrontClient = t, this.localStore = new D, n && this.onwardSettings.setLocale(n), this.addedCheckoutButtonHandlers = [], this.domRoots = [document], this.instanceUUID = O(), this.logger = new a(this.instanceUUID), this.sanitizedMoneyFormat = this._sanitizeMoneyFormat(), this.initializeOnwardClient(), this.hideInsuranceProduct()
                }
                _sanitizeMoneyFormat() {
                    let e = this.onwardSettings.moneyFormat || window.Currency ? .money_format || window.theme ? .moneyFormat || window.theme ? .settings ? .moneyFormat;
                    if (e) {
                        var t = document.createElement("div");
                        return t.innerHTML = e, t.textContent
                    }
                }
                async initializeOnwardClient() {
                    if (!this.onwardSettings.shopEnabled) return !1;
                    if (this.onwardClientInitializing) return await this.onwardClientInitializing, !0;
                    if (window.onwardClient) return this.logger.log("already initialized"), window.dispatchEvent(new Event("onward:initialized")), !0;
                    const e = new P(this.onwardSettings, this.storefrontClient);
                    return this.onwardClientInitializing = e.initialize(), await this.onwardClientInitializing, this.onwardClientInitializing = null, window.onwardClient = e, this.configureCartState(), window.dispatchEvent(new Event("onward:initialized")), !0
                }
                async mountWidgets(e, t = {}) {
                    this.nullified ? this.logger.log("nullified, not performing mount") : 0 != e.length ? await this.initializeOnwardClient() && (this.logger.log(`mounting ${e.length} widgets`), e.forEach(e => {
                        let t = Ri(ts, {
                            onwardApp: this,
                            containerDivForAttributes: e
                        }).mount(e);
                        this.vueApps.push(t)
                    }), this.assignPrices(), t.skipCheckoutPlus || this.insertCheckoutPlus(), this.logger.log(`finished mounting ${e.length} widgets`), ao(this.onwardSettings).publish("onward:loaded"), this.nullified || t.skipButtonHandlers || this.addButtonHandlers(), this.updateCheckoutPlusButtonsVisibilityAndCopy(), window.dispatchEvent(new Event("onward:widgets_mounted"))) : this.logger.log("no widgets to mount")
                }
                registerCheckoutPlusButton(e) {
                    e && !this.checkoutButtons.includes(e) && (this.checkoutButtons.push(e), this.updateCheckoutPlusButtonsVisibilityAndCopy())
                }
                assignPrices() {
                    this.vueApps.filter(e => {
                        if (e.walletsVariantId) e.insurancePrice = this.walletsInsurancePriceFor(e.walletsVariantId), e.estimatedRewardsAmount = this.walletsEstimatedRewardsAmountFor(e.walletsVariantId);
                        else {
                            const t = this.computePricesAndTotals();
                            e.insurancePrice = t.insurancePrice, e.estimatedRewardsAmount = t.estimatedRewardsAmount, e.subtotalWithOnward = t.subtotalWithOnward, e.subtotalWithoutOnward = t.subtotalWithoutOnward
                        }
                    })
                }
                computePricesAndTotals() {
                    const e = window.onwardClient ? .insuranceVariant();
                    return {
                        insurancePrice: this.insurancePriceFor(e),
                        estimatedRewardsAmount: this.rewardsAmountForVariant(e),
                        subtotalWithOnward: this.subtotalWithOnward(),
                        subtotalWithoutOnward: this.subtotalWithoutOnward()
                    }
                }
                insurancePriceFor(e) {
                    return this.nullified || !e ? null : this.formatPrice(e.price.amount)
                }
                rewardsAmountForVariant(e) {
                    if (this.nullified || !e || !this.onwardSettings.rewardsEnabled) return null;
                    let t = window.onwardClient.estimatedRewardsAmount();
                    return t > 0 ? this.formatPrice(t) : null
                }
                subtotalWithOnward() {
                    const e = window.onwardClient ? .cartPriceWithInsurance();
                    return e ? this.formatPrice(e) : null
                }
                subtotalWithoutOnward() {
                    const e = window.onwardClient ? .cartPriceWithoutInsurance();
                    return e ? this.formatPrice(e) : null
                }
                walletsInsurancePriceFor(e) {
                    if (this.nullified || !this.onwardSettings.walletsEnabled) return null;
                    let t = function(e, t, n) {
                        const r = c(t, window.OnwardWalletsCurrentProduct.variants);
                        if (!r) return null;
                        if (!r.requires_shipping) return a.log("Wallet variant does not require shipping, not calculating insurance price"), null;
                        const i = l(n, {
                                variant_id: t,
                                quantity: 1,
                                requires_shipping: r.requires_shipping
                            }, r.price / 100),
                            o = e.insuranceCartLinesToAdd([i]);
                        return o && 0 != o.length ? o[0].cost.amount : (a.log(`Could not find potentialCartLines for variant ${t}`), null)
                    }(window.onwardClient.insuranceCalculator(), e, window.onwardClient.cart.currency);
                    return t ? this.formatPrice(t) : t
                }
                walletsEstimatedRewardsAmountFor(e) {
                    if (this.nullified || !this.onwardSettings.walletsEnabled) return null;
                    let t = function(e, t, n) {
                        const a = c(t, window.OnwardWalletsCurrentProduct.variants);
                        if (!a) return 0;
                        const r = l(n, {
                            variant_id: t,
                            quantity: 1
                        }, a.price / 100);
                        return e.estimatedRewardAmount([r])
                    }(window.onwardClient.insuranceCalculator(), e, window.onwardClient.cart.currency);
                    return t ? this.formatPrice(t) : t
                }
                toggleInsureOrder() {
                    const e = !this.insureOrder;
                    ao(this.onwardSettings).publish(e ? "onward:toggle_on" : "onward:toggle_off"), this.assignInsureOrder(e)
                }
                assignInsureOrder(e) {
                    this.insureOrder = e, !0 === e ? this.localStore.setItem("insureOrder", "true") : !1 === e && this.localStore.setItem("insureOrder", "false"), this.vueApps.forEach(t => {
                        t.insureOrder = e
                    })
                }
                configureCartState() {
                    this.logger.log("configureCartState");
                    let e = null;
                    e = window.onwardClient.insuranceCartItems().length > 1 || (null === this.localStore.getItem("insureOrder") ? this.onwardSettings.selectedByDefault : "true" === this.localStore.getItem("insureOrder")), this.assignPrices(), this.assignInsureOrder(e);
                    const t = this,
                        n = this.onwardSettings.autoRemoveInsuranceFromCart;
                    !this.insideCheckout && n ? window.onwardClient.uninsureOrderIfRequired().then(function() {
                        t.logger.log("Fixed cart that does not match widget state, updating UI"), t.hideInsuranceProduct(), t.earlyUpdateUICartOnToggleTotalAndCount()
                    }) : this.insideCheckout || n || t.earlyUpdateUICartOnToggleTotalAndCount(), !this.insideCheckout && this.onwardSettings.isCheckoutPlusCheckoutVariant && this.updateCartForCheckoutWithInsurance()
                }
                findCheckoutButtons() {
                    return this.onwardSettings.headlessClient ? [] : this.onwardSettings.checkoutButtonSelector ? Array.from(document.querySelectorAll(this.onwardSettings.checkoutButtonSelector)) : Array.from(document.querySelectorAll(this.constructor.CheckoutButtonSelectors)).filter(as)
                }
                addButtonHandlers() {
                    this.removeAllAddedCheckoutButtonHandlers(), this.logger.log("overriding forms"), window.cartSubmit ? this.handleLegacyRechargeCartSubmit() : this.insideCheckout || this.allWidgetsHiddenViaDataAttributes() || this.findCheckoutButtons().forEach(e => this.watchCheckoutButtonLink(e))
                }
                addDomRoot(e) {
                    this.domRoots.includes(e) || this.domRoots.push(e)
                }
                handleLegacyRechargeCartSubmit() {
                    if (window.cartSubmit.toString().includes("runningRechargeCartFix")) return;
                    let e = !1,
                        t = this;
                    var n;
                    n = window.cartSubmit, window.cartSubmit = function(a, r) {
                        e || (e = !0, window.onwardClient.fixInsuranceInCartIfRequired(t.insureOrder).then(function() {
                            e = !1, n(a, r)
                        }))
                    }
                }
                hideInsuranceProduct() {
                    this.logger.log("hiding insurance from script"), window.onwardHideProductInCart && window.onwardHideProductInCart()
                }
                updatePDPOptOutText() {
                    if (!this.onwardSettings.walletsEnabled || !this.isPDP()) return;
                    const e = this.onwardSettings.pdpMorePaymentsSelectors ? ? this.constructor.PDPMorePaymentsSelectors;
                    document.querySelectorAll(e).forEach(this.updateOnePDPOptOutText)
                }
                updateOnePDPOptOutText = e => {
                    let t = {
                        subtotal_without_onward: ""
                    };
                    const n = window.OnwardWalletsCurrentProduct ? .selected_or_first_available_variant ? .id;
                    if (n) {
                        const e = c(n, window.OnwardWalletsCurrentProduct.variants);
                        e && (t.subtotal_without_onward = this.formatPrice(e.price / 100))
                    }
                    const a = C(this.onwardSettings.checkoutPlusOptOutLabel, { ...t
                    });
                    e.textContent = a.trim()
                };
                isPDP() {
                    return this.vueApps.some(e => e.walletsVariantId)
                }
                updateCheckoutPlusButtonsVisibilityAndCopy() {
                    const e = window.onwardClient ? .insuranceVariant();
                    if (e) {
                        this.optOutButtons.forEach(e => {
                            e.classList.remove("onward-hidden")
                        });
                        const e = this.computePricesAndTotals(),
                            t = {
                                insurance_price: e.insurancePrice,
                                reward_amount: e.estimatedRewardsAmount,
                                subtotal_with_onward: e.subtotalWithOnward,
                                subtotal_without_onward: e.subtotalWithoutOnward
                            };
                        if (this.onwardSettings.checkoutPlusOptOutLabel) {
                            const e = C(this.onwardSettings.checkoutPlusOptOutLabel, { ...t
                            });
                            this.optOutButtons.filter(Boolean).forEach(t => rs(t, e))
                        }
                        if (this.onwardSettings.checkoutPlusButtonLabel) {
                            const e = C(this.onwardSettings.checkoutPlusButtonLabel, { ...t
                            });
                            this.checkoutButtons.filter(Boolean).forEach(t => rs(t, e))
                        }
                        if (this.onwardSettings.subtotalLabel && this.onwardSettings.subtotalLabelSelector) {
                            const e = this.onwardSettings.subtotalLabel;
                            this.queryDocumentOnAllDoms(this.onwardSettings.subtotalLabelSelector).forEach(t => rs(t, e))
                        }
                    } else this.optOutButtons.forEach(e => {
                        e.classList.add("onward-hidden")
                    }), this.onwardSettings.checkoutPlusOptOutLabel && this.optOutButtons.filter(Boolean).forEach(is), this.onwardSettings.checkoutPlusButtonLabel && this.checkoutButtons.filter(Boolean).forEach(is), this.onwardSettings.subtotalLabel && this.onwardSettings.subtotalLabelSelector && this.queryDocumentOnAllDoms(this.onwardSettings.subtotalLabelSelector).forEach(is)
                }
                insertCheckoutPlus() {
                    !this.onwardSettings.headlessClient && this.onwardSettings.legacyAutoInsertCheckoutPlus && this.onwardSettings.checkoutPlusEnabled && this.onwardSettings.checkoutPlusVariant === V.cart && (this.isPDP() && this.updatePDPOptOutText(), window.onwardClient.insuranceVariant() && (window.onwardCheckoutPlus ? (this.logger.log("placing checkout plus with override"), window.onwardCheckoutPlus()) : (this.logger.log("placing checkout plus"), this.findCheckoutButtons().forEach(e => {
                        const t = this.onwardSettings.checkoutPlusOptOutContainerSelector && document.querySelector(this.onwardSettings.checkoutPlusOptOutContainerSelector) || e.parentNode;
                        this.checkoutPlusifyButton(e, t)
                    }))))
                }
                checkoutPlusifyButton(e, t, n = {}) {
                    if (e.classList.contains(this.constructor.CheckoutPlusOriginalBtnBaseClass) || e.classList.contains(this.constructor.OptOutLinkBaseClass)) return;
                    e.classList.add(this.constructor.CheckoutPlusOriginalBtnBaseClass);
                    const a = e.cloneNode(!0),
                        r = {
                            continueToCheckout: n.continueToCheckout
                        };
                    a.addEventListener("click", this.checkoutPlusEventHandler(!0, e, r), !0), a.classList.add(this.constructor.CheckoutPlusBtnBaseClass), this.onwardSettings.overrideCheckoutButtonNameAttribute && ["INPUT", "BUTTON"].includes(a.nodeName) && a.setAttribute("name", this.constructor.CheckoutPlusBtnBaseClass), e.parentNode.insertBefore(a, e);
                    const i = e.cloneNode(!0);
                    i.className = this.constructor.computeOptOutClasses(n.optOutCustomClasses, n.invertOptOutColors), this.onwardSettings.overrideOptOutButtonNameAttribute && ["INPUT", "BUTTON"].includes(i.nodeName) && i.setAttribute("name", this.constructor.OptOutLinkBaseClass), i.onclick = this.checkoutPlusEventHandler(!1, e, r);
                    const o = n.optOutPosition || "beforeend";
                    ("beforebegin" === o || "afterend" === o ? t.parentNode : t).querySelector(`.${this.constructor.OptOutLinkBaseClass}`) || (t.insertAdjacentElement(o, i), this.optOutButtons.push(i), this.checkoutButtons.push(a)), new MutationObserver(this.checkoutPlusOriginalButtonMutationHandler(e, a, i)).observe(e, {
                        childList: !0,
                        subtree: !0,
                        attributes: !0
                    }), e.classList.add("onward-hidden"), this.updateCheckoutPlusButtonsVisibilityAndCopy(), window.dispatchEvent(new Event("onward:checkout_plus_inserted"))
                }
                addCheckoutPlusCheckoutOptOutLink(e, t, n) {
                    const a = document.createElement("button");
                    if (a.href = "javascript:void(0)", a.className = this.constructor.computeOptOutClasses(n.optOutCustomClasses, n.invertOptOutColors), a.addEventListener("click", async e => {
                            if (this.logger.log("opt-out clicked"), e.preventDefault(), await this.updateCartForCheckoutWithoutInsurance(), n.continueToCheckout) n.continueToCheckout(a);
                            else {
                                const e = n.documentNode || document,
                                    t = n.buttonSelector ? e.querySelector(n.buttonSelector) : n.button;
                                t ? (this.logger.log("opt-out cart attribute set, clicking attached checkout button", t), t.dispatchEvent(new MouseEvent("click", {
                                    view: window,
                                    bubbles: !0,
                                    cancelable: !0
                                }))) : this.logger.error("opt-out cart attribute set, failed to find attached button", n)
                            }
                        }), e.insertAdjacentElement(t, a), n.staticStandaloneOptOut) {
                        const e = n.staticStandaloneOptOutLabel || this.onwardSettings.checkoutPlusOptOutLabel;
                        rs(a, e)
                    } else this.optOutButtons.push(a), this.updateCheckoutPlusButtonsVisibilityAndCopy();
                    window.dispatchEvent(new Event("onward:checkout_plus_inserted"))
                }
                checkoutPlusOriginalButtonMutationHandler(e, t, n) {
                    return a => {
                        a.some(e => "attributes" === e.type) && (t.disabled = e.disabled, t.style.pointerEvents = e.style.pointerEvents, n && (n.disabled = e.disabled, n.style.pointerEvents = e.style.pointerEvents), [this.constructor.CheckoutPlusOriginalBtnBaseClass, "onward-hidden"].forEach(t => {
                            e.classList.contains(t) || e.classList.add(t)
                        })), a.some(e => "childList" === e.type) && (this.onwardSettings.checkoutPlusButtonLabel ? t.dataset.onwardOriginalLabel = e.innerHTML : t.innerHTML = e.innerHTML)
                    }
                }
                checkoutPlusEventHandler(e, t, n = {}) {
                    const a = n.continueToCheckout ? ? this.defaultCheckoutPlusContinueToCheckout;
                    return async n => {
                        n.preventDefault(), n.stopImmediatePropagation();
                        try {
                            e ? await window.onwardApp.updateCartForCheckoutWithInsurance() : await window.onwardApp.updateCartForCheckoutWithoutInsurance()
                        } catch (e) {
                            this.logger.warn("Unable to fix insurance in cart, product might be unavailable")
                        }
                        a(t)
                    }
                }
                defaultCheckoutPlusContinueToCheckout(e) {
                    const t = new MouseEvent("click", {
                        view: window,
                        bubbles: !0,
                        cancelable: !0
                    });
                    e.dispatchEvent(t)
                }
                earlyUpdateUICartOnToggleTotalAndCount() {
                    let e;
                    e = !this.onwardSettings.excludePriceInSubtotalDisplay && this.insureOrder ? window.onwardClient.cartPriceWithInsurance() : window.onwardClient.cartPriceWithoutInsurance(), this.logger.log("Early updating price"), this.updateUICartTotalAndCount(e, window.onwardClient.quantityWithoutInsurance())
                }
                updateUICartTotalAndCount(e, t) {
                    let n = this.formatPrice(e);
                    window.onwardUpdateSubtotalAndCount ? window.onwardUpdateSubtotalAndCount(n, t) : (this.onwardSettings.cartSubtotalSelector && this.queryDocumentOnAllDoms(this.onwardSettings.cartSubtotalSelector).forEach(t => {
                        let n = this.formatPrice(e);
                        this.logger.log(`updating ui subtotal to ${n}`), t.innerText = n, t.textContent = n
                    }), t && this.onwardSettings.cartItemCountSelector && this.queryDocumentOnAllDoms(this.onwardSettings.cartItemCountSelector).forEach(e => {
                        const n = e.innerText;
                        if (n) {
                            const a = n.replace(/\d+/g, t.toString());
                            e.innerText = a, e.textContent = a
                        } else e.innerText = t.toString(), e.textContent = t.toString()
                    }))
                }
                formatPrice(e) {
                    return this.sanitizedMoneyFormat ? (0, ns.formatMoney)(e, this.sanitizedMoneyFormat) : this.formatIntlCurrency(e, this.onwardSettings.locale.currency_iso_code, this.onwardSettings.locale.request_locale)
                }
                formatIntlCurrency(e, t, n) {
                    var a = new Intl.NumberFormat(n, {
                        style: "currency",
                        currency: t
                    });
                    let r = isNaN(e) || null == e ? 0 : e.toFixed(2);
                    return a.format(r)
                }
                removeAllAddedCheckoutButtonHandlers() {
                    this.logger.log(`Removing ${this.addedHandlers.length} checkout button handlers`), this.addedHandlers.forEach(([e, t]) => {
                        e.removeEventListener("click", t)
                    })
                }
                destroy() {
                    this.unmountAllVueApps(), this.removeAllAddedCheckoutButtonHandlers(), this.nullified = !0
                }
                async fixInsuranceAndProceed() {
                    if (!this.onwardSettings.shopEnabled) return void this.logger.log("Onward disabled");
                    if (this.allWidgetsHiddenViaDataAttributes()) return void this.logger.log("Onward hidden");
                    if (this.proceedInitiated) return void this.logger.log("proceed already initiated");
                    this.proceedInitiated = !0;
                    let e = this;
                    return window.onwardClient.syncCart().then(function() {
                        return window.onwardClient.fixInsuranceInCartIfRequired(e.insureOrder).then(function() {
                            return !0
                        })
                    })
                }
                allWidgetsHiddenViaDataAttributes() {
                    return 0 == this.vueApps.length || this.vueApps.every(e => e.hideWidget)
                }
                updateCartForCheckout() {
                    if (this.onwardSettings.shopEnabled) try {
                        return window.onwardClient.fixInsuranceInCartIfRequired(this.insureOrder)
                    } catch (e) {
                        return this.logger.warn("Unable to fix insurance in cart, product might be unavailable"), Promise.resolve()
                    }
                }
                updateCartForCheckoutWithInsurance() {
                    if (this.onwardSettings.shopEnabled) return this.insureOrder = !0, this.onwardSettings.isCheckoutPlusCheckoutVariant ? (this.logger.log("Updating cart attributes for checkout with insurance, setting _onwardInsured=true"), window.onwardClient.updateCartAttributes({
                        _onwardInsured: !0
                    })) : window.onwardClient.fixInsuranceInCartIfRequired(!0)
                }
                updateCartForCheckoutWithoutInsurance() {
                    if (this.onwardSettings.shopEnabled) return this.insureOrder = !1, this.onwardSettings.isCheckoutPlusCheckoutVariant ? (this.logger.log("Updating cart attributes for checkout without insurance, setting _onwardInsured=false"), window.onwardClient.updateCartAttributes({
                        _onwardInsured: !1
                    })) : window.onwardClient.fixInsuranceInCartIfRequired(!1)
                }
                async cartChanged(e) {
                    this.logger.log("cartChanged"), this.proceedInitiated ? this.logger.log("proceed already initiated") : (this.hideInsuranceProduct(), await this.initializeOnwardClient(), window.onwardClient.setCurrentCart(e), this.assignPrices(), this.insertCheckoutPlus(), this.earlyUpdateUICartOnToggleTotalAndCount(), this.updateCheckoutPlusButtonsVisibilityAndCopy(), window.dispatchEvent(new Event("onward:cart_changed")))
                }
                get vueApps() {
                    return this.vueApps
                }
                unmountAllVueApps() {
                    this.logger.log(`Unmounting ${this.vueApps.length} vue apps`), this.vueApps.forEach(e => {
                        e._.appContext.app.unmount()
                    }), this.vueApps = []
                }
                get finishedMounting() {
                    return 0 != this.vueApps.length && 0 != this.onwardSettings.shopEnabled && this.vueApps.every(e => e.finishedMounting)
                }
                get instanceUUIDs() {
                    return this.vueApps.map(e => e._.appContext.app.instanceUUID).join(", ")
                }
                watchCheckoutButtonLink(e) {
                    if (this.onwardSettings.checkoutPlusEnabled) return;
                    let t = !1;
                    this.logger.log("Watching link click");
                    let n = this,
                        a = function(e) {
                            t ? n.logger.log("Checkout link triggered: already fixed") : (n.logger.log("Checkout link triggered: proceeding"), t = !0, e.preventDefault(), window.onwardClient.fixInsuranceInCartIfRequired(n.insureOrder).then(function() {
                                n.logger.log("Finished fixInsuranceInCartIfRequired");
                                const t = new MouseEvent("click", {
                                    view: window,
                                    bubbles: !0,
                                    cancelable: !0
                                });
                                e.target.dispatchEvent(t)
                            }))
                        };
                    e.addEventListener("click", a), this.addedHandlers.push([e, a]), window.addEventListener("beforeunload", () => {
                        t = !1
                    })
                }
                shouldInsureWalletsRequest() {
                    return (this.onwardSettings.checkoutPlusEnabled || this.insureOrder) && this.onwardSettings.walletsEnabled
                }
                updatedWalletsPayload(e) {
                    return this.shouldInsureWalletsRequest() ? (ao(this.onwardSettings).publish("onward:wallets:rest:updated"), window.onwardClient.updatedWalletsPayload(e, window.OnwardWalletsCurrentProduct ? .variants)) : e
                }
                updatedWalletsGraphQLPayload(e) {
                    if (!this.shouldInsureWalletsRequest()) return e;
                    const t = JSON.parse(e),
                        n = t ? .variables ? .input ? .lines ? .[0].merchandiseId;
                    if (!n) return e;
                    const a = {
                            line_items: [{
                                variant_id: n.split("/").pop(),
                                quantity: t ? .variables ? .input ? .lines ? .[0].quantity || 1
                            }]
                        },
                        r = window.onwardClient.calculateWalletsInsuranceVariant(a, window.OnwardWalletsCurrentProduct ? .variants);
                    return this.logger.log(r), r ? (ao(this.onwardSettings).publish("onward:wallets:graphql:updated"), t.variables.input.lines.push({
                        attributes: S(this.onwardSettings.onwardLineitemProperties) || [],
                        quantity: 1,
                        merchandiseId: `gid://shopify/ProductVariant/${r.variant.id}`
                    }), JSON.stringify(t)) : e
                }
                updatedCartAttributesGraphQLPayload(e) {
                    if (!this.onwardSettings.isCheckoutPlusCheckoutVariant) return e;
                    try {
                        const t = JSON.parse(e),
                            {
                                variables: {
                                    attributes: n
                                }
                            } = t;
                        if (!n.find(e => "_onwardInsured" === e.key)) return n.push({
                            key: "_onwardInsured",
                            value: "true"
                        }), t.variables.attributes = n, JSON.stringify(t)
                    } catch (t) {
                        return e
                    }
                    return e
                }
                queryDocumentOnAllDoms(e) {
                    return this.domRoots.flatMap(t => Array.from(t.querySelectorAll(e)))
                }
            }
            var ss, ds = os;

            function ls(e, t, n) {
                return function(a) {
                    window.onwardApp.logger.log("found Route-hijacked button", e, a, t), a.addEventListener("click", window.onwardApp.checkoutPlusEventHandler(e, t, n), !0)
                }
            }

            function cs(e, t, n) {
                return !!("beforebegin" === n || "afterend" === n ? t.parentNode : t).querySelector(e) && (window.onwardApp.logger.warn(`${e} already inserted`, t, n), !0)
            }! function(e) {
                e.Default = "default", e.Inverted = "inverted"
            }(ss || (ss = {}));
            class us {
                constructor(e = document, t = {}) {
                    var n;
                    this.routeObserverAdded = !1, this.onDomChanged = e => {
                        const t = [...e].flatMap(e => [...e.addedNodes]).filter(e => e.nodeType === Node.ELEMENT_NODE);
                        for (const e of t)
                            for (const t of this.observedSelectors) e.matches(t.selector) ? t.handler(e) : e.querySelectorAll(t.selector).forEach(t.handler)
                    }, window.onwardApp ? (this.documentNode = e, this.colorMode = null !== (n = t.colorMode) && void 0 !== n ? n : ss.Default, this.observedSelectors = [], this.domObserver = new MutationObserver(this.onDomChanged), this.domObserver.observe(this.documentNode, {
                        childList: !0,
                        subtree: !0
                    })) : a.error("Cannot be initialized before window.onwardApp is available")
                }
                addContainer(e, t = {}) {
                    window.onwardApp.onwardSettings.shopEnabled ? (t.position || (t.position = "beforeend"), this.onSelectorMatch(e, n => {
                        window.onwardApp.logger.log("addContainer->onSelectorMatch", e, t, n), this.mountContainer(n, t)
                    })) : window.onwardApp.logger.error("Enable the shop in settings before using Onward")
                }
                attachCheckoutButton(e, t) {
                    window.onwardApp.onwardSettings.shopEnabled ? window.onwardApp.onwardSettings.checkoutPlusEnabled ? window.onwardApp.onwardSettings.checkoutPlusVariant === V.cart ? this.addCheckoutButton(e, t) : window.onwardApp.onwardSettings.checkoutPlusVariant === V.checkout ? this.addOptOutLink(t.optOutSelector, {
                        lazilyAttachToButtonSelector: e,
                        position: t.optOutPosition,
                        optOutCustomClasses: t.optOutCustomClasses,
                        continueToCheckout: t.continueToCheckout
                    }) : window.onwardApp.logger.error("Unknown Checkout+ variant", window.onwardApp.onwardSettings.checkoutPlusVariant) : this.onSelectorMatch(e, n => {
                        window.onwardApp.logger.log("attachCheckoutButton->onSelectorMatch", e, t, n), window.onwardApp.watchCheckoutButtonLink(n)
                    }) : window.onwardApp.logger.error("Enable the shop in settings before using Onward")
                }
                addCheckoutPlus(e, t) {
                    this.attachCheckoutButton(e, t)
                }
                addShadowRoot(e, t) {
                    this.onSelectorMatch(e, e => {
                        const n = new us(e.shadowRoot, {
                            colorMode: this.colorMode
                        });
                        n.pushOnwardStyleSheetsToShadowRoot(), window.onwardApp.addDomRoot(e.shadowRoot), t(n)
                    })
                }
                addRebuy(e = {
                    optOutSelector: "#rebuy-cart .rebuy-cart__checkout-button"
                }) {
                    if (!window.onwardApp.onwardSettings.shopEnabled) return void window.onwardApp.logger.error("Enable the shop in settings before using Onward");
                    if (!window.onwardApp.onwardSettings.checkoutPlusEnabled) return void window.onwardApp.logger.error("Enable Checkout+ in settings before using Checkout+ methods");
                    if (!window.Rebuy || !window.Rebuy.SmartCart) return void window.onwardApp.logger.error("Rebuy App is not initialized");
                    const t = document.querySelectorAll(".rebuy-cart__flyout-actions").length > 0 ? "#rebuy-cart .rebuy-cart__flyout-actions" : '#rebuy-cart [data-rebuy-component="checkout-area"]',
                        n = e.optOutSelector;
                    this.addContainer(t, {
                        position: "afterbegin"
                    }), this.addOptOutLink(t, {
                        lazilyAttachToButtonSelector: n,
                        position: e.optOutPosition || "afterend",
                        optOutCustomClasses: e.optOutCustomClasses,
                        continueToCheckout: () => {
                            const e = document.querySelector(n);
                            window.onwardApp.insureOrder = !1, e && e.dispatchEvent(new MouseEvent("click", {
                                view: window,
                                bubbles: !0,
                                cancelable: !0
                            }))
                        }
                    }), this.setupRebuyHandles()
                }
                addPDP(e, t = {}) {
                    var n;
                    this.addPDPContainer(e), this.addPDPOptOut(null !== (n = t.optOutSelector) && void 0 !== n ? n : "#more-payment-options-link")
                }
                addPDPContainer(e, t = {}) {
                    var n, a, r;
                    window.onwardApp.onwardSettings.shopEnabled ? window.onwardApp.onwardSettings.walletsEnabled ? (null === (a = null === (n = window.OnwardWalletsCurrentProduct) || void 0 === n ? void 0 : n.selected_or_first_available_variant) || void 0 === a ? void 0 : a.id) ? (t.position || (t.position = "beforebegin"), t.attributes || (t.attributes = {}), (r = t.attributes)["data-wallets-variant-id"] || (r["data-wallets-variant-id"] = window.OnwardWalletsCurrentProduct.selected_or_first_available_variant.id), this.addContainer(e, t)) : window.onwardApp.logger.log("addPDPContainer exiting because window.OnwardWalletsCurrentProduct is not available") : window.onwardApp.logger.error("Enable wallets in settings before using PDP") : window.onwardApp.logger.error("Enable the shop in settings before using Onward")
                }
                addPDPOptOut(e) {
                    window.onwardApp.onwardSettings.walletsEnabled ? this.onSelectorMatch(e, t => {
                        window.onwardApp.logger.log("addPDPOptOut->onSelectorMatch", e, t), window.onwardApp.updateOnePDPOptOutText(t)
                    }) : window.onwardApp.logger.error("Enable wallets in settings before using PDP")
                }
                addCheckoutButton(e, t = {}) {
                    window.onwardApp.onwardSettings.checkoutPlusEnabled ? this.onSelectorMatch(e, n => {
                        window.onwardApp.logger.log("addCheckoutButton->onSelectorMatch", e, t, n);
                        const a = t.optOutSelector ? this.documentNode.querySelector(t.optOutSelector) : n.parentNode;
                        this.routeObserverAdded || (this.routeObserverAdded = !0, this.onSelectorMatch(`.${ds.CheckoutPlusBtnBaseClass}[data-route-copy]`, ls(!0, n, {
                            continueToCheckout: t.continueToCheckout
                        })), this.onSelectorMatch(`.${ds.OptOutLinkBaseClass}[data-route-copy]`, ls(!1, n, {
                            continueToCheckout: t.continueToCheckout
                        }))), window.onwardApp.checkoutPlusifyButton(n, a, {
                            optOutPosition: t.optOutPosition,
                            optOutCustomClasses: t.optOutCustomClasses,
                            invertOptOutColors: this.colorMode === ss.Inverted,
                            continueToCheckout: t.continueToCheckout
                        })
                    }) : window.onwardApp.logger.error("Enable Checkout+ in settings before using Checkout+ methods")
                }
                autoAddCheckoutButtons(e = {}) {
                    this.addCheckoutButton(ds.CheckoutButtonSelectors, e)
                }
                addShopPayCheckoutButton(e) {
                    this.onSelectorMatch(e, t => {
                        if (window.onwardApp.logger.log("addShopPayCheckoutButton->onSelectorMatch", e, t), "product" === t.getAttribute("page-type")) return void window.onwardApp.logger.error("addShopPayCheckoutButton cannot be used with PDP ShopPay buttons. Use addPDP instead.", t);
                        const n = window.onwardApp.checkoutPlusEventHandler(!0, t, {
                            continueToCheckout: e => {
                                const t = new MouseEvent("click", {
                                    view: window,
                                    bubbles: !0,
                                    cancelable: !0
                                });
                                ("SHOP-PAY-WALLET-BUTTON" === e.nodeName ? e.button : e).dispatchEvent(t)
                            }
                        });
                        t.addEventListener("click", n, {
                            once: !0,
                            capture: !0
                        })
                    })
                }
                autoAddShopPayCheckoutButtons() {
                    this.addShopPayCheckoutButton('shop-pay-wallet-button:not([page-type="product"])')
                }
                addOptOutLink(e, t) {
                    t.attachToButtonSelector || t.lazilyAttachToButtonSelector || t.continueToCheckout ? this.onSelectorMatch(e, n => {
                        if (window.onwardApp.logger.log("addOptOutLink->onSelectorMatch", e, t, n), cs(`.${ds.OptOutLinkBaseClass}`, n, t.position)) return;
                        let a = {
                            staticStandaloneOptOut: t.staticStandaloneOptOut,
                            staticStandaloneOptOutLabel: t.staticStandaloneOptOutLabel,
                            optOutCustomClasses: t.optOutCustomClasses
                        };
                        if (t.continueToCheckout) a = Object.assign({
                            continueToCheckout: t.continueToCheckout,
                            buttonSelector: t.attachToButtonSelector || t.lazilyAttachToButtonSelector,
                            documentNode: this.documentNode
                        }, a);
                        else if (t.attachToButtonSelector) {
                            const e = this.documentNode.querySelector(t.attachToButtonSelector);
                            if (!e) return void window.onwardApp.logger.error("attachToButtonSelector not found", t.attachToButtonSelector);
                            a = Object.assign({
                                button: e
                            }, a)
                        } else a = Object.assign({
                            buttonSelector: t.lazilyAttachToButtonSelector,
                            documentNode: this.documentNode
                        }, a);
                        t.staticStandaloneOptOut || this.registerCheckoutButtonFromOptOutLinkOptions(a), window.onwardApp.addCheckoutPlusCheckoutOptOutLink(n, t.position || "beforeend", Object.assign(Object.assign({}, a), {
                            invertOptOutColors: this.colorMode === ss.Inverted
                        }))
                    }) : window.onwardApp.logger.error("attachToButtonSelector, lazilyAttachToButtonSelector, or continueToCheckout must be provided")
                }
                onSelectorMatch(e, t) {
                    this.documentNode.querySelectorAll(e).forEach(t), this.observedSelectors.push({
                        selector: e,
                        handler: t
                    })
                }
                registerCheckoutButtonFromOptOutLinkOptions(e) {
                    if (!e.buttonSelector && !e.button) return void window.onwardApp.logger.error("attachToButtonSelector or lazilyAttachToButtonSelector must be provided");
                    const t = e.documentNode || document,
                        n = e.buttonSelector ? t.querySelector(e.buttonSelector) : e.button;
                    n ? window.onwardApp.registerCheckoutPlusButton(n) : this.onSelectorMatch(e.buttonSelector, e => {
                        window.onwardApp.registerCheckoutPlusButton(e)
                    })
                }
                pushOnwardStyleSheetsToShadowRoot() {
                    Array.from(document.querySelectorAll("style")).filter(e => {
                        var t;
                        return (null === (t = e.innerText) || void 0 === t ? void 0 : t.includes("#onward")) || "onward-styles-sheet" === e.id
                    }).forEach(e => {
                        const t = new CSSStyleSheet;
                        t.replaceSync(e.innerText), this.documentNode.adoptedStyleSheets.push(t)
                    })
                }
                disconnect() {
                    this.domObserver.disconnect()
                }
                setupRebuyHandles() {
                    function e(e) {
                        const t = e.bind(window.Rebuy.SmartCart);
                        return function() {
                            return e = this, n = void 0, r = function*() {
                                let e;
                                yield window.onwardApp.updateCartForCheckout(), window.onwardApp.insureOrder = !0, (e = function() {
                                    "ready" === window.Rebuy.SmartCart.status ? t.call() : setTimeout(e, 200)
                                })()
                            }, new((a = void 0) || (a = Promise))(function(t, i) {
                                function o(e) {
                                    try {
                                        d(r.next(e))
                                    } catch (e) {
                                        i(e)
                                    }
                                }

                                function s(e) {
                                    try {
                                        d(r.throw(e))
                                    } catch (e) {
                                        i(e)
                                    }
                                }

                                function d(e) {
                                    var n;
                                    e.done ? t(e.value) : (n = e.value, n instanceof a ? n : new a(function(e) {
                                        e(n)
                                    })).then(o, s)
                                }
                                d((r = r.apply(e, n || [])).next())
                            });
                            var e, n, a, r
                        }
                    }
                    window.Rebuy && window.Rebuy.SmartCart && (window.onwardApp.insureOrder = !0, window.Rebuy.SmartCart.checkout = e(window.Rebuy.SmartCart.checkout), window.Rebuy.SmartCart.shopPayCheckout = e(window.Rebuy.SmartCart.shopPayCheckout))
                }
                mountContainer(e, t) {
                    if (cs("#onward-container", e, t.position)) return;
                    const n = document.createElement("div");
                    n.id = "onward-container", this.colorMode === ss.Inverted && n.setAttribute("data-invert-colors", "");
                    for (const e in t.attributes) n.setAttribute(e, t.attributes[e]);
                    e.insertAdjacentElement(t.position, n), window.onwardApp.mountWidgets([n], {
                        skipCheckoutPlus: !0,
                        skipButtonHandlers: !0
                    })
                }
            }
            var ps, hs = us;

            function ws(e) {
                return fs(e, new RegExp(".*/cart/change", "g"))
            }

            function gs(e) {
                return fs(e, new RegExp(".*/cart/add", "g"))
            }

            function ms(e) {
                return fs(e, new RegExp(".*/cart/update", "g"))
            }

            function fs(e, t) {
                return "string" != typeof e ? null : e.match(t)
            }

            function bs(e) {
                return fs(e, new RegExp(".*/graphql.json", "g"))
            }
            window.dispatchEvent(new Event("onward:before-loaded")), window.OnwardSetup = hs, window.OnwardInsuranceCalculator = i, window.OnwardSettings = T, window.initializeOnward = function(e = !1, t = "#onward-container", n = new d) {
                    ! function(e) {
                        const t = e.storefrontClient,
                            n = e.containerSelector || "#onward-container",
                            r = document.querySelectorAll(n),
                            i = Array.from(r).filter(e => 0 == e.childNodes.length);
                        e.force && i.length > 0 && (window.onwardApp && (a.log("onwardApp already existed, nilling out", window.onwardApp.instanceUUID), window.onwardApp.destroy()), window.onwardApp = null), window.onwardApp ? a.log("initializeOnward: app already mounted", window.onwardApp.instanceUUID) : (window.onwardApp = new ds(window.OnwardSettingsJson, t, e.locale), window.onwardApp.onwardSettings.notCheckoutPlusCheckoutVariant && window.onwardApp.mountWidgets(r))
                    }({
                        storefrontClient: n,
                        containerSelector: t,
                        force: e
                    })
                }, window.dispatchEvent(new Event("onward:loaded")), window.initializeOnward(), setTimeout(() => {
                    window.initializeOnward()
                }, 1e3), window.addEventListener("pageshow", function(e) {
                    if (e.persisted && window.onwardApp && !window.onwardApp.insideCheckout && window.onwardApp.onwardSettings.isCheckoutPlusCheckoutVariant) try {
                        window.onwardApp.updateCartForCheckoutWithInsurance()
                    } catch (e) {
                        window.onwardApp.logger.warn(`${e.status}: Unable to fix insurance in cart, updateCartForCheckoutWithInsurance on pageshow`)
                    }
                }), ps = XMLHttpRequest.prototype.open, XMLHttpRequest.prototype.open = function() {
                    if (!window.onwardApp) return a.log("Not listening to ajax hooks"), ps.apply(this, arguments);
                    this.addEventListener("load", function() {
                        if (this && (ms(this._url) || gs(this._url))) fetch("/cart.js").then(e => {
                            e.json().then(function(e) {
                                window.onwardApp.cartChanged(e)
                            })
                        });
                        else if (this && ws(this._url) && this.status >= 200 && this.status < 300) try {
                            window.onwardApp.cartChanged(JSON.parse(this.responseText))
                        } catch {
                            a.log(`Handling legacy XHR cart request. Unable to parse response as cart. Re-fetching cart... ${this.status} ${this.responseType} "${this.responseText}"`), fetch("/cart.js").then(e => {
                                e.json().then(function(e) {
                                    window.onwardApp.cartChanged(e)
                                })
                            })
                        }
                    }), ps.apply(this, arguments)
                },
                function(e, t, n = {}) {
                    "function" == typeof t && (a.log("fetch called..."), e.fetch = function() {
                        if (n.hijackWallets) {
                            if (e = arguments[1], fs(arguments[0], new RegExp("^/wallets/checkouts(/\\w*)?.json", "g")) && "application/json" === e ? .headers ? .["Content-Type"] && e ? .body ? .includes('"wallet_name":"ShopifyPay"') && window.onwardApp && window.onwardApp.vueApps.length > 0) return arguments[1].body = window.onwardApp.updatedWalletsPayload(arguments[1].body), t.apply(this, arguments);
                            if (function(e, t) {
                                    return bs(e) && "portable-wallets" === t ? .headers ? .["X-SDK-Variant"] && "ShopPay" === t ? .headers ? .["X-Wallet-Name"]
                                }(arguments[0], arguments[1]) && window.onwardApp && window.onwardApp.vueApps.length > 0) return arguments[1].body = window.onwardApp.updatedWalletsGraphQLPayload(arguments[1].body), t.apply(this, arguments)
                        }
                        var e;
                        (function(e, t) {
                            return bs(e) && t ? .body ? .includes("cartAttributesUpdate")
                        })(arguments[0], arguments[1]) && window.onwardApp && window.onwardApp.vueApps.length > 0 && (arguments[1].body = window.onwardApp.updatedCartAttributesGraphQLPayload(arguments[1].body));
                        const r = t.apply(this, arguments);
                        return r.then(e => {
                            window.onwardApp ? window.onwardClient && window.onwardClient.onwardNetworkCallHappening ? a.log("window.onwardClient networkCallHappening, continue running fetch, this is probabaly onwards") : ms(e.url) || gs(e.url) || function(e, t) {
                                return bs(e) && t ? .body ? .includes("cartDiscountCodesUpdate")
                            }(arguments[0], arguments[1]) ? t("/cart.js").then(e => {
                                e.json().then(function(e) {
                                    window.onwardApp.cartChanged(e)
                                })
                            }) : ws(e.url) && e.clone().json().then(function(e) {
                                window.onwardApp.cartChanged(e)
                            }) : a.log("Not listening to fetch hooks")
                        }), r
                    })
                }(window, window.fetch, {
                    hijackWallets: window.onwardApp.onwardSettings.notCheckoutPlusCheckoutVariant
                })
        }()
}();