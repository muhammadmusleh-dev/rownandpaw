! function() {
    "use strict";
    try {
        window.snaptr.cfg('b24afcc9-6690-4d62-8a61-f26bad940c79', {
            "asc": [],
            "gw": null,
            "a": [],
            "ipg": "92",
            "b": [],
            "t": "",
            "v": "3.7.5-2401032347",
            "tpd": [],
            "ec": []
        })
    } catch (e) {}
}();