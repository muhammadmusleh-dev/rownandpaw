"use strict";
(self.webpackChunk_intelligems_shopify_plugin = self.webpackChunk_intelligems_shopify_plugin || []).push([
    [78], {
        22140: (e, i, t) => {
            t.r(i), t.d(i, {
                TestShippingConfig: () => _,
                TestShippingManagers: () => p,
                init: () => f
            });
            var n = {};
            t.r(n), t.d(n, {
                setShippingParams: () => E
            });
            var r = {};
            t.r(r), t.d(r, {
                interceptorShippingTestModifications: () => S
            });
            var a = {};
            t.r(a), t.d(a, {
                ShippingManager: () => l
            });
            var p = {};
            t.r(p), t.d(p, {
                AtcForm: () => n,
                Interceptor: () => r,
                ShippingManager: () => a
            });
            var s = t(56400),
                o = t(10755),
                c = t(64605),
                g = t(21617),
                d = t(6324);

            function E(e) {
                d.E.ifLoadedSync((i => {
                    let t = null;
                    const n = e,
                        r = i.ExperienceManagers.State.getShippingExperiences().sort(g.g);
                    for (const e of r) {
                        const r = c.t2.getVariation(e);
                        if (t = r, r) {
                            const e = i.ExperienceConfig._configFileShippingRateGroups.filter((e => e.variationId === r.id));
                            e ? .length && (s.GT.BH.updateOrAddLineItemInput(n, s.F1.pc.LINE_ITEM_TEST_GROUP, r.id), o.FF.Uw.isDebugState() && (n.elements[s.F1.pc.LINE_ITEM_PREVIEW] || s.GT.BH.addLineItemInput(n, s.F1.pc.LINE_ITEM_PREVIEW, "true")))
                        }
                    }
                    if (t) {
                        const e = i.ExperienceManagers.State.getAllVariationShortIds().join(",");
                        s.GT.BH.updateOrAddLineItemInput(n, s.F1.pc.LINE_ITEM_TEST_GROUPS, e)
                    }
                }))
            }
            var I = t(79781);

            function S(e, i) {
                const t = { ...e
                    },
                    n = d.E.ifLoadedSync();
                if (n) {
                    const e = n.ExperienceManagers.State.getShippingExperiences();
                    if (e && e.length > 0) {
                        const r = c.t2.getVariation(e[0]) ? .id;
                        if (r) {
                            const e = (0, I.g)(t, {
                                [s.F1.pc.LINE_ITEM_TEST_GROUP]: r,
                                [s.F1.pc.LINE_ITEM_TEST_GROUPS]: n.ExperienceManagers.State.getAllVariationShortIds().join(","),
                                ...o.FF.Uw.isDebugState() && {
                                    [s.F1.pc.LINE_ITEM_PREVIEW]: "true"
                                }
                            });
                            return t.properties = e.properties, {
                                item: t,
                                isModified: i || e.modified,
                                isRedirect: !1
                            }
                        }
                    }
                }
                return {
                    item: t,
                    isModified: i || !1,
                    isRedirect: !1
                }
            }
            class l {
                static handleWindowMessage(e, i = {}) {
                    const {
                        type: t,
                        payload: n
                    } = e.data;
                    Object.keys(i).includes(t) && i ? .[t] && i[t] ? .(n)
                }
            }
            let _;
            l.igShippingProgressBarRoot = void 0;
            const f = e => {
                _ = e
            }
        }
    }
]);
//# sourceMappingURL=https://cdn.intelligems.io/ig_1733952477486.7cc449a654c266dc7532c6b18283996f.js.map