(function(n) {
    typeof define == "function" && define.amd ? define(n) : n()
})(function() {
    "use strict";

    function n() {
        if (window.Shopify && window.Shopify.theme) {
            const e = window.Shopify.theme.role;
            return e === "unpublished" || e === "demo"
        }
        return !1
    }

    function u() {
        return /.*\.shopifypreview\.com\/products_preview/.test(window.location.href) || /\/products\/([A-Za-z0-9-_%]+)(\/)?/.test(window.location.href)
    }

    function d() {
        return /\/cart/.test(window.location.href)
    }
    var p = {
        VITE_SDK_URL: "https://sdk.teeinblue.com"
    };
    (function() {
        if (window.Shopify) {
            var e = !1;
            const i = window.teeinblueCampaign || window.TeeInBlueCampaign || {};
            if (d() ? e = !0 : u() ? (n() || i.isTeeInBlueProduct) && (e = !0) : i.config && i.config.enable_for_all_pages && (e = !0), !e) return !1;
            var a = p.VITE_SDK_URL,
                o = document.currentScript;
            if (!o) return !1;
            var l = o.getAttribute("src"),
                w = new RegExp(/async.js\?platform=(.*)&v=(.*)&token=(.*)&shop=(.*)/),
                t = l.match(w);
            if (!t) return !1;
            var f = t[1],
                c = t[2],
                v = t[3],
                m = t[4],
                g = `${a}/${f}/app-v${c}.js?token=${v}&shop=${m}`,
                h = `${a}/${f}/app-v${c}`,
                _ = document.querySelector(`script[src*="${h}"][defer]`);
            if (!_) {
                let s = function() {
                    let r = document.createElement("script");
                    r.setAttribute("src", g), document.head.appendChild(r)
                };
                switch (document.readyState) {
                    case "loading":
                        document.addEventListener("readystatechange", r => {
                            r.target.readyState === "interactive" && s()
                        });
                        break;
                    default:
                        s();
                        break
                }
            }
        }
        return !1
    })()
});