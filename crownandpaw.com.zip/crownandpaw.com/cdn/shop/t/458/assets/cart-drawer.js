// Cart drawer
var cartInterval, shippingInterval;
var digitalDownloadProduct = '29877512667222';
var skipArtworkProduct = '39593134162006';

// Rebuild cart using section rendering API
function reBuildCart() {
    handleButtonLoadingState(true);
    $.ajax({
        url: '/?section_id=cart-drawer',
        type: "GET"
    }).then((res) => {
        $(".vue-cart.slider_cart_holder").empty().append(res);
        handleButtonLoadingState(false);
    })
}

function handleGiftCard(checkbox) {
    handleButtonLoadingState(true);

    const selectElement = document.querySelector('.slider_cart_digital-download__price.gift_card');
    const selectedVariantId = selectElement ? selectElement.value : 39552042238038;

    if (!checkbox.checked) {
        $.post({
            url: "/cart/change.js",
            dataType: 'json',
            data: {
                id: selectedVariantId,
                quantity: 0
            },
            success: function() {
                reBuildCart();
            }
        });
    } else if (selectedVariantId) {
        $.post({
            url: '/cart/add.js',
            dataType: 'json',
            data: {
                items: [{
                    id: selectedVariantId,
                    quantity: 1
                }]
            },
            success: function() {
                reBuildCart();
            }
        });
    }
}

function handleDigitalDownload(checkbox) {
    var vt_id = checkbox.closest(".slider_cart_digital-download").getAttribute("data-excluded-product-id");
    handleButtonLoadingState(true);
    if (!checkbox.checked) {
        $.post({
            url: "/cart/change.js",
            dataType: 'json',
            data: {
                id: vt_id,
                quantity: 0
            },
            success: function() {
                reBuildCart();
            },
            error: function() {
                reBuildCart();
            }
        });
    } else {
        const quantity = checkbox.dataset.quantity;
        console.log(quantity);
        $.post({
            url: '/cart/add.js',
            dataType: 'json',
            data: {
                items: [{
                    id: vt_id,
                    quantity: quantity
                }]
            },
            success: function() {
                reBuildCart();
            },
            error: function() {
                reBuildCart();
            }
        });
    }
}

function handleSkipArtwork(checkbox) {
    var vt_id = checkbox.closest(".slider_cart_digital-download").getAttribute("data-excluded-product-id");
    handleButtonLoadingState(true);

    if (!checkbox.checked) {
        $.post({
            url: "/cart/change.js",
            dataType: 'json',
            data: {
                id: vt_id,
                quantity: 0
            },
            success: function() {
                reBuildCart();
            },
            error: function() {
                reBuildCart();
            }
        });
    } else {
        const quantity = checkbox.dataset.quantity;
        console.log(quantity);
        $.post({
            url: '/cart/add.js',
            dataType: 'json',
            data: {
                items: [{
                    id: vt_id,
                    quantity: quantity
                }]
            },
            success: function() {
                reBuildCart();
            },
            error: function() {
                reBuildCart();
            }
        });
    }
}

// Handle button load on product page (needs to be loaded here)
function handleButtonLoadingState(isLoading) {
    if (isLoading) {
        $('[data-add-to-cart]').attr('aria-disabled', true);
        $('[data-add-to-cart-text]').addClass('hide');
        $('[data-loader]').removeClass('hide');
        $('[data-loader]').attr('disabled', true);
        $('[data-loader-status]').attr('aria-hidden', false);
        $('.vue-cart__loading').addClass('active');
    } else {
        $('[data-add-to-cart]').removeAttr('aria-disabled');
        $('[data-add-to-cart-text]').removeClass('hide');
        $('[data-loader]').addClass('hide');
        $('[data-loader]').removeAttr('disabled');
        $('[data-loader-status]').attr('aria-hidden', true);
        $('.vue-cart__loading').removeClass('active');
    }
}

// Delivery Cutoff countdown
function startShippingCountDown() {
    const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];

    let artwork_production_time = parseInt("48");
    let shipping_time = parseInt("84");
    let countdownText_origin_custom = "YOUR ARTWORK will be ready by [DATE] if you order in the next [TIME]";
    let countdownText_origin_non_custom = "ARRIVES by [DATE] if you order in the next [TIME] in USA";

    const today = new Date();
    const nowHour = today.getUTCHours();
    const cutOff_time = new Date();
    let deliver_date;
    let left_time;
    if (nowHour < 14) {
        // Will delivery on next day
        cutOff_time.setUTCHours(14, 0, 0, 0);
        left_time = cutOff_time - today;
        artwork_date = today.setUTCHours(today.getUTCHours() + artwork_production_time)
        deliver_date = today.setUTCHours(today.getUTCHours() + shipping_time)
    } else {
        // Will delivery after 2 days
        cutOff_time.setUTCDate(new Date(today).getUTCDate() + 1);
        cutOff_time.setUTCHours(0, 0, 0, 0);
        left_time = cutOff_time - today;
        let tomorrow = today.setUTCDate(today.getUTCDate() + 1);
        artwork_date = tomorrow.setUTCHours(tomorrow.getUTCHours() + artwork_production_time)
        deliver_date = tomorrow.setUTCHours(tomorrow.getUTCHours() + shipping_time)
    }
    let has_custom_product = false;

    if (document.querySelector(".slider_cart_countdown__Shipping") != null) {
        if (document.querySelector(".slider_cart_countdown__Shipping").hasAttribute("data-has-canvas")) has_custom_product = true;
    }

    const countdownText_origin = has_custom_product ? countdownText_origin_custom : countdownText_origin_non_custom;
    const result_date = has_custom_product ? artwork_date : deliver_date;

    let day = new Date(result_date).getUTCDay();
    // if (day === 6) deliver_date = new Date(deliver_date).setUTCDate(new Date(deliver_date).getUTCDate() + 2);
    // if (day === 0) deliver_date = new Date(deliver_date).setUTCDate(new Date(deliver_date).getUTCDate() + 1);

    // day = new Date(deliver_date).getUTCDay();
    const date = new Date(result_date).getUTCDate();
    const month = new Date(result_date).getUTCMonth();
    const year = new Date(result_date).getUTCFullYear();

    const hours = Math.floor(left_time % (1000 * 60 * 60 * 24) / (1000 * 60 * 60));
    const minutes = Math.floor(left_time % (1000 * 60 * 60) / (1000 * 60));

    countdownText = countdownText_origin.replace("[DATE]", `<strong>${DAYS[day]}, ${date} ${MONTHS[month]} ${year}</strong>`);
    countdownText = countdownText.replace("[TIME]", `<strong>${("00" + hours).slice(2)}hours ${("00" + minutes).slice(2)}mins</strong>`);

    if (document.querySelector(".slider_cart_countdown__Shipping") != null) {
        document.querySelector(".slider_cart_countdown__Shipping").innerHTML = countdownText;

    }
}

// cart countdown
function startCartCountDown() {
    let countdownText_origin = "Your cart is reserved for [CART_COUNTDOWN]";
    var cart_reserved_time = 10 * 60; // 10 min countdown timer
    cartInterval = setInterval(() => {
        if (cart_reserved_time == 0) cart_reserved_time = 10 * 60;

        var min = Math.floor(cart_reserved_time / 60);
        var sec = cart_reserved_time - min * 60;
        countdownText = countdownText_origin.replace("[CART_COUNTDOWN]", `<span class="Cart__Countdown">${('0' + min).slice(-2)}:${('0' + sec).slice(-2)}s</span>`)
        document.querySelector(".slider_cart_countdown__Cart").innerHTML = countdownText;
        cart_reserved_time--;
    }, 1000);
}