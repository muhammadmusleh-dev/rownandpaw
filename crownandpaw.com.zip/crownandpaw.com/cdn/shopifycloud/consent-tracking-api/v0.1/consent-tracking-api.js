! function(n) {
    "use strict";
    const e = {
            TRACKING_ACCEPTED: "trackingConsentAccepted",
            TRACKING_DECLINED: "trackingConsentDeclined",
            MARKETING_ACCEPTED: "firstPartyMarketingConsentAccepted",
            SALE_OF_DATA_ACCEPTED: "thirdPartyMarketingConsentAccepted",
            ANALYTICS_ACCEPTED: "analyticsConsentAccepted",
            PREFERENCES_ACCEPTED: "preferencesConsentAccepted",
            MARKETING_DECLINED: "firstPartyMarketingConsentDeclined",
            SALE_OF_DATA_DECLINED: "thirdPartyMarketingConsentDeclined",
            ANALYTICS_DECLINED: "analyticsConsentDeclined",
            PREFERENCES_DECLINED: "preferencesConsentDeclined",
            CONSENT_COLLECTED: "visitorConsentCollected",
            CONSENT_TRACKING_API_LOADED: "consentTrackingApiLoaded"
        },
        t = "2.1",
        o = "3",
        r = {
            ACCEPTED: "yes",
            DECLINED: "no",
            NO_INTERACTION: "no_interaction",
            NO_VALUE: ""
        },
        i = {
            NO_VALUE: "",
            ACCEPTED: "1",
            DECLINED: "0"
        },
        c = {
            PREFERENCES: "p",
            ANALYTICS: "a",
            MARKETING: "m",
            SALE_OF_DATA: "t"
        },
        a = {
            MARKETING: "m",
            ANALYTICS: "a",
            PREFERENCES: "p",
            SALE_OF_DATA: "s"
        },
        s = {
            MARKETING: "marketing",
            ANALYTICS: "analytics",
            PREFERENCES: "preferences",
            SALE_OF_DATA: "sale_of_data",
            EMAIL: "email"
        },
        u = {
            HEADLESS_STOREFRONT: "headlessStorefront",
            ROOT_DOMAIN: "rootDomain",
            CHECKOUT_ROOT_DOMAIN: "checkoutRootDomain",
            STOREFRONT_ROOT_DOMAIN: "storefrontRootDomain",
            STOREFRONT_ACCESS_TOKEN: "storefrontAccessToken",
            IS_EXTENSION_TOKEN: "isExtensionToken",
            METAFIELDS: "metafields"
        };

    function l(n, e) {
        var t = Object.keys(n);
        if (Object.getOwnPropertySymbols) {
            var o = Object.getOwnPropertySymbols(n);
            e && (o = o.filter((function(e) {
                return Object.getOwnPropertyDescriptor(n, e).enumerable
            }))), t.push.apply(t, o)
        }
        return t
    }

    function d(n) {
        for (var e = 1; e < arguments.length; e++) {
            var t = null != arguments[e] ? arguments[e] : {};
            e % 2 ? l(Object(t), !0).forEach((function(e) {
                E(n, e, t[e])
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(t)) : l(Object(t)).forEach((function(e) {
                Object.defineProperty(n, e, Object.getOwnPropertyDescriptor(t, e))
            }))
        }
        return n
    }

    function E(n, e, t) {
        return e in n ? Object.defineProperty(n, e, {
            value: t,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : n[e] = t, n
    }

    function f() {
        try {
            return !1
        } catch (n) {
            if (n instanceof ReferenceError) return !0;
            throw n
        }
    }
    class A {}
    A.warn = n => {
        f() || console.warn(n)
    }, A.error = n => {
        f() || console.error(n)
    }, A.info = n => {
        f() || console.info(n)
    }, A.debug = n => {
        f() || console.debug(n)
    }, A.trace = n => {
        f() || console.trace(n)
    };
    const p = A;

    function C(n) {
        try {
            return decodeURIComponent(n)
        } catch (n) {
            return ""
        }
    }

    function g(n, e) {
        if (null === n) return "null";
        if (Array.isArray(n)) {
            const e = n.map((n => g(n, !0))).join(",");
            return "[".concat(e, "]")
        }
        if ("object" == typeof n) {
            let t = [];
            for (const e in n) n.hasOwnProperty(e) && void 0 !== n[e] && t.push("".concat(e, ":").concat(g(n[e], !0)));
            const o = t.join(",");
            return e ? "{".concat(o, "}") : o
        }
        return "string" == typeof n ? '"'.concat(n, '"') : "".concat(n)
    }

    function h(n) {
        let e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const t = function() {
            try {
                return document.cookie
            } catch (n) {
                return !1
            }
        }() ? document.cookie.split("; ") : [];
        for (let e = 0; e < t.length; e++) {
            const [o, r] = t[e].split("=");
            if (n === C(o)) {
                return C(r)
            }
        }
        if (e && "_tracking_consent" === n && !window.localStorage.getItem("tracking_consent_fetched")) {
            if (f()) return;
            return console.debug("_tracking_consent missing"),
                function() {
                    let n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "/";
                    const e = new XMLHttpRequest;
                    e.open("HEAD", n, !1), e.withCredentials = !0, e.send()
                }(), window.localStorage.setItem("tracking_consent_fetched", "true"), h(n, !1)
        }
    }

    function T(n) {
        return n === encodeURIComponent(C(n))
    }

    function _(n, e, t, o) {
        if (!T(o)) throw new TypeError("Cookie value is not correctly URI encoded.");
        if (!T(n)) throw new TypeError("Cookie name is not correctly URI encoded.");
        let r = "".concat(n, "=").concat(o);
        r += "; path=/", e && (r += "; domain=".concat(e)), r += "; expires=".concat(new Date((new Date).getTime() + t).toUTCString()), document.cookie = r
    }
    const y = "_cmp";
    const m = "_tracking_consent",
        N = 31536e6;

    function S() {
        const n = function() {
            var n, e;
            const t = null === (n = window.Shopify) || void 0 === n || null === (e = n.customerPrivacy) || void 0 === e ? void 0 : e.cachedConsent;
            return t ? C(t) : void 0
        }() || h(m) || function() {
            try {
                var n;
                const [e] = null === (n = performance) || void 0 === n ? void 0 : n.getEntriesByType("navigation"), t = null == e ? void 0 : e.serverTiming.find((n => n.name === y));
                let o = null == t ? void 0 : t.description;
                if (!o) return;
                try {
                    o = decodeURIComponent(o)
                } catch (n) {}
                return o
            } catch (n) {
                return
            }
        }();
        if (void 0 !== n) return function(n) {
            if ("%" == n.slice(0, 1)) try {
                n = decodeURIComponent(n)
            } catch (n) {}
            const e = n.slice(0, 1);
            if ("{" == e) return function(n) {
                var e;
                let o;
                try {
                    o = JSON.parse(n)
                } catch (n) {
                    return
                }
                if (o.v !== t) return;
                if (null === (e = o.con) || void 0 === e || !e.CMP) return;
                return o
            }(n);
            if ("3" == e) return function(n) {
                const e = n.slice(1).split("_"),
                    [t, r, s, u, l] = e;
                let d, E;
                try {
                    d = e[5] ? JSON.parse(e.slice(5).join("_")) : void 0
                } catch (n) {}
                if (l) {
                    const n = l.replace(/\*/g, "/").replace(/-/g, "+"),
                        e = Array.from(atob(n)).map((n => n.charCodeAt(0).toString(16).padStart(2, "0"))).join("");
                    E = [8, 13, 18, 23].reduce(((n, e) => n.slice(0, e) + "-" + n.slice(e)), e)
                }

                function f(n) {
                    const e = t.split(".")[0];
                    return e.includes(n.toLowerCase()) ? i.DECLINED : e.includes(n.toUpperCase()) ? i.ACCEPTED : i.NO_VALUE
                }

                function A(n) {
                    return t.includes(n.replace("t", "s").toUpperCase())
                }
                return {
                    v: o,
                    con: {
                        CMP: {
                            [a.ANALYTICS]: f(a.ANALYTICS),
                            [a.PREFERENCES]: f(a.PREFERENCES),
                            [a.MARKETING]: f(a.MARKETING),
                            [a.SALE_OF_DATA]: f(a.SALE_OF_DATA)
                        }
                    },
                    region: r || "",
                    cus: d,
                    purposes: {
                        [c.ANALYTICS]: A(c.ANALYTICS),
                        [c.PREFERENCES]: A(c.PREFERENCES),
                        [c.MARKETING]: A(c.MARKETING),
                        [c.SALE_OF_DATA]: A(c.SALE_OF_DATA)
                    },
                    sale_of_data_region: "t" == u,
                    display_banner: "t" == s,
                    consent_id: E
                }
            }(n);
            return
        }(n)
    }

    function w() {
        try {
            let n = S();
            if (!n) return;
            return n
        } catch (n) {
            return
        }
    }

    function D() {
        return {
            m: P(a.MARKETING),
            a: P(a.ANALYTICS),
            p: P(a.PREFERENCES),
            s: P(a.SALE_OF_DATA)
        }
    }

    function I() {
        return D()[a.SALE_OF_DATA]
    }

    function R() {
        let n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
        return null === n && (n = w()), void 0 === n
    }

    function O(n) {
        switch (n) {
            case i.ACCEPTED:
                return r.ACCEPTED;
            case i.DECLINED:
                return r.DECLINED;
            default:
                return r.NO_VALUE
        }
    }

    function v(n) {
        switch (n) {
            case a.ANALYTICS:
                return s.ANALYTICS;
            case a.MARKETING:
                return s.MARKETING;
            case a.PREFERENCES:
                return s.PREFERENCES;
            case a.SALE_OF_DATA:
                return s.SALE_OF_DATA
        }
    }

    function P(n) {
        const e = w();
        if (!e) return i.NO_VALUE;
        const t = e.con.CMP;
        return t ? t[n] : i.NO_VALUE
    }

    function L() {
        const n = w();
        return R(n) ? "" : n.region || ""
    }

    function k(n) {
        const e = S();
        if (!e || !e.purposes) return !0;
        const t = e.purposes[n];
        return "boolean" != typeof t || t
    }

    function b() {
        return k(c.PREFERENCES)
    }

    function M() {
        return k(c.ANALYTICS)
    }

    function F() {
        return k(c.MARKETING)
    }

    function K() {
        return k(c.SALE_OF_DATA)
    }

    function G() {
        const n = S();
        return !!n && ("boolean" == typeof n.display_banner && n.display_banner)
    }

    function j() {
        const n = S();
        return n && n.sale_of_data_region || !1
    }

    function U() {
        const n = S();
        return n && n.consent_id || ""
    }
    class Y {
        constructor() {
            let n = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            if (this.useInstrumentation = void 0, Y.instance) return Y.instance;
            Y.instance = this, this.useInstrumentation = n
        }
        instrumentationEnabled() {
            return this.useInstrumentation
        }
        setUseInstrumentation(n) {
            this.useInstrumentation = n
        }
        produce(n, e) {
            if (this.instrumentationEnabled() && M()) try {
                const t = {
                        schema_id: "customer_privacy_api_events/2.0",
                        payload: {
                            shop_domain: window.location.host,
                            method_name: n,
                            call_details: e || null
                        }
                    },
                    o = {
                        accept: "*/*",
                        "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
                        "content-type": "application/json; charset=utf-8",
                        "x-monorail-edge-event-created-at-ms": String(Date.now()),
                        "x-monorail-edge-event-sent-at-ms": String(Date.now())
                    };
                if (!window.location.host.endsWith("spin.dev")) return fetch("https://monorail-edge.shopifysvc.com/v1/produce", {
                    headers: o,
                    body: JSON.stringify(t),
                    method: "POST",
                    mode: "cors",
                    credentials: "omit"
                });
                console.log("Monorail event from consent API:", o, t)
            } catch (n) {}
        }
    }

    function B(n) {
        void 0 !== n.granular_consent && function(n) {
            const t = n[c.MARKETING],
                o = n[c.SALE_OF_DATA],
                r = n[c.ANALYTICS],
                i = n[c.PREFERENCES];
            !0 === t ? x(e.MARKETING_ACCEPTED) : !1 === t && x(e.MARKETING_DECLINED);
            !0 === o ? x(e.SALE_OF_DATA_ACCEPTED) : !1 === o && x(e.SALE_OF_DATA_DECLINED);
            !0 === r ? x(e.ANALYTICS_ACCEPTED) : !1 === r && x(e.ANALYTICS_DECLINED);
            !0 === i ? x(e.PREFERENCES_ACCEPTED) : !1 === i && x(e.PREFERENCES_DECLINED);
            const a = function(n) {
                const e = {
                    marketingAllowed: n[c.MARKETING],
                    saleOfDataAllowed: n[c.SALE_OF_DATA],
                    analyticsAllowed: n[c.ANALYTICS],
                    preferencesAllowed: n[c.PREFERENCES],
                    firstPartyMarketingAllowed: n[c.MARKETING],
                    thirdPartyMarketingAllowed: n[c.SALE_OF_DATA]
                };
                return e
            }(n);
            x(e.CONSENT_COLLECTED, a);
            const s = [r, i, t, o];
            s.every((n => !0 === n)) && x(e.TRACKING_ACCEPTED);
            s.every((n => !1 === n)) && x(e.TRACKING_DECLINED)
        }({
            [c.PREFERENCES]: b(),
            [c.ANALYTICS]: M(),
            [c.MARKETING]: F(),
            [c.SALE_OF_DATA]: K()
        })
    }

    function x(n, e) {
        document.dispatchEvent(new CustomEvent(n, {
            detail: e || {}
        }))
    }
    Y.instance = void 0;
    const V = "95ba910bcec4542ef2a0b64cd7ca666c";

    function q(n, e, t) {
        try {
            var o;
            ! function(n) {
                const e = new XMLHttpRequest;
                e.open("POST", "https://error-analytics-production.shopifysvc.com", !0), e.setRequestHeader("Content-Type", "application/json"), e.setRequestHeader("Bugsnag-Api-Key", V), e.setRequestHeader("Bugsnag-Payload-Version", "5");
                const t = function(n) {
                    const e = function(n) {
                            return n.stackTrace || n.stack || n.description || n.name
                        }(n.error),
                        [t, o] = (e || "unknown error").split("\n")[0].split(":");
                    return JSON.stringify({
                        payloadVersion: 5,
                        notifier: {
                            name: "ConsentTrackingAPI",
                            version: "latest",
                            url: "-"
                        },
                        events: [{
                            exceptions: [{
                                errorClass: (t || "").trim(),
                                message: (o || "").trim(),
                                stacktrace: [{
                                    file: "consent-tracking-api.js",
                                    lineNumber: "1",
                                    method: e
                                }],
                                type: "browserjs"
                            }],
                            context: n.context || "general",
                            app: {
                                id: "ConsentTrackingAPI",
                                version: "latest"
                            },
                            metaData: {
                                request: {
                                    shopId: n.shopId,
                                    shopUrl: window.location.href
                                },
                                device: {
                                    userAgent: window.navigator.userAgent
                                },
                                "Additional Notes": n.notes
                            },
                            unhandled: !1
                        }]
                    })
                }(n);
                e.send(t)
            }({
                error: n,
                context: e,
                shopId: J() || (null === (o = window.Shopify) || void 0 === o ? void 0 : o.shop),
                notes: t
            })
        } catch (n) {}
    }

    function H(n) {
        return function() {
            try {
                return n(...arguments)
            } catch (n) {
                throw n instanceof TypeError || q(n), n
            }
        }
    }

    function J() {
        try {
            const n = document.getElementById("shopify-features").textContent;
            return JSON.parse(n).shopId
        } catch (n) {
            return null
        }
    }

    function X() {
        return F()
    }

    function W() {
        return K()
    }

    function $() {
        const n = {},
            e = D();
        for (const t of Object.keys(e)) n[v(t)] = O(e[t]);
        return n
    }

    function Z(n, e) {
        const o = new Y;
        return o.produce("setTrackingConsent"), "object" == typeof n && n.headlessStorefront && !n.storefrontAccessToken ? (p.warn("Headless consent has been updated. Please read shopify.dev/docs/api/customer-privacy to integrate."), o.produce("setTrackingConsent-Headless"), function(n, e) {
            function o(n) {
                let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : i.NO_VALUE;
                return !0 === n ? i.ACCEPTED : !1 === n ? i.DECLINED : e
            }
            const r = {
                    [a.ANALYTICS]: o(n[s.ANALYTICS], i.DECLINED),
                    [a.MARKETING]: o(n[s.MARKETING], i.DECLINED),
                    [a.PREFERENCES]: o(n[s.PREFERENCES], i.DECLINED),
                    [a.SALE_OF_DATA]: o(n[s.SALE_OF_DATA])
                },
                c = {
                    v: t,
                    reg: "",
                    con: {
                        CMP: r
                    }
                },
                u = encodeURIComponent(JSON.stringify(c));
            return _(m, n.rootDomain, N, u), e(null), new Promise(((n, e) => {}))
        }(n, e || (() => {}))) : function(n, e) {
            if (function(n) {
                    if ("boolean" != typeof n && "object" != typeof n) throw TypeError("setTrackingConsent must be called with a boolean or object consent value");
                    if ("object" == typeof n) {
                        const e = Object.keys(n);
                        if (0 === e.length) throw TypeError("The submitted consent object is empty.");
                        const t = [s.MARKETING, s.ANALYTICS, s.PREFERENCES, s.SALE_OF_DATA, s.EMAIL, u.ROOT_DOMAIN, u.CHECKOUT_ROOT_DOMAIN, u.STOREFRONT_ROOT_DOMAIN, u.STOREFRONT_ACCESS_TOKEN, u.HEADLESS_STOREFRONT, u.IS_EXTENSION_TOKEN, u.METAFIELDS];
                        for (const n of e)
                            if (!t.includes(n)) throw TypeError("The submitted consent object should only contain the following keys: ".concat(t.join(", "), ". Extraneous key: ").concat(n, "."))
                    }
                }(n), void 0 !== e && "function" != typeof e) throw TypeError("setTrackingConsent must be called with a callback function if the callback argument is provided");
            let t;
            if (!0 === n || !1 === n) {
                p.warn("Binary consent is deprecated. Please update to granular consent (shopify.dev/docs/api/consent-tracking)");
                t = {
                    analytics: n,
                    preferences: n,
                    marketing: n
                }
            } else t = n;
            const o = function(n) {
                    if (!n) return null;
                    return An() ? document.referrer : ""
                }(t.analytics),
                r = function(n) {
                    if (!n) return null;
                    return An() ? window.location.pathname + window.location.search : "/"
                }(t.analytics);
            return sn(d(d({
                granular_consent: t
            }, null !== o && {
                referrer: o
            }), null !== r && {
                landing_page: r
            }), e)
        }(n, e)
    }
    const z = n => {
        let {
            useBugsnagReporting: e,
            useInstrumentation: t
        } = n;
        I() != i.DECLINED && !1 === gn() && un(!1, (() => !1));
        const o = {
            getTrackingConsent: ln,
            setTrackingConsent: Z,
            userCanBeTracked: Cn,
            getRegulation: dn,
            isRegulationEnforced: pn,
            getShopPrefs: En,
            shouldShowGDPRBanner: Tn,
            userDataCanBeSold: hn,
            setCCPAConsent: un,
            getCCPAConsent: _n,
            shouldShowCCPABanner: yn,
            doesMerchantSupportGranularConsent: mn,
            analyticsProcessingAllowed: M,
            preferencesProcessingAllowed: b,
            marketingAllowed: X,
            firstPartyMarketingAllowed: X,
            saleOfDataAllowed: W,
            thirdPartyMarketingAllowed: W,
            currentVisitorConsent: $,
            shouldShowBanner: G,
            saleOfDataRegion: j,
            getRegion: fn,
            getTrackingConsentMetafield: Nn,
            consentId: Sn,
            unstable: {
                analyticsProcessingAllowed: M,
                preferencesProcessingAllowed: b,
                marketingAllowed: X,
                saleOfDataAllowed: W,
                currentVisitorConsent: $,
                shouldShowBanner: G,
                saleOfDataRegion: j
            },
            __metadata__: {
                name: "@shopify/consent-tracking-api",
                version: "v0.1",
                description: "Shopify Consent Tracking API"
            }
        };
        if (new Y(t), !e) return o;
        const r = ["unstable", "__metadata__"];
        for (const n in o) o.hasOwnProperty(n) && (o[n] = r.includes(n) ? o[n] : H(o[n]));
        return o
    };

    function Q() {
        return z(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            useBugsnagReporting: !1,
            useInstrumentation: !1
        })
    }

    function nn(n) {
        if (!n) return;
        const e = function(n) {
            const e = new URL(n, window.location.origin),
                t = tn(n) ? en(e) : en(e).replace(window.location.origin, "");
            return document.querySelectorAll('a[href^="'.concat(t, '"]'))
        }(n);
        if (!e.length) return;
        const t = U(),
            o = function() {
                const n = $();
                if (!n) return null;
                if (!("analytics" in n && "marketing" in n && "preferences" in n)) return null;
                const e = on(n.analytics),
                    t = on(n.marketing),
                    o = on(n.preferences);
                return "" === e && "" === t && "" === o ? null : "a".concat(e, "m").concat(t, "p").concat(o)
            }();
        for (const r of Array.from(e)) {
            const e = r.getAttribute("href");
            if (!e) continue;
            const i = new URL(e, window.location.origin);
            if (t && i.searchParams.set("consent_id", t), o && i.searchParams.set("consent", o), t || o) {
                const e = tn(n) ? i.toString() : i.toString().replace(window.location.origin, "");
                r.setAttribute("href", e)
            }
        }
    }

    function en(n) {
        return "".concat(n.origin).concat(n.pathname.replace(/\/$/, ""))
    }

    function tn(n) {
        return n.startsWith("http://") || n.startsWith("https://")
    }

    function on(n) {
        switch (n) {
            case r.ACCEPTED:
                return "1";
            case r.DECLINED:
                return "0";
            default:
                return ""
        }
    }
    const rn = "_landing_page",
        cn = "_orig_referrer";

    function an(n) {
        const e = n.granular_consent,
            t = g(d(d({
                visitorConsent: d({
                    marketing: e.marketing,
                    analytics: e.analytics,
                    preferences: e.preferences,
                    saleOfData: e.sale_of_data
                }, e.metafields && {
                    metafields: e.metafields
                })
            }, e.email && {
                visitorEmail: e.email
            }), {}, {
                origReferrer: n.referrer,
                landingPage: n.landing_page
            }));
        return {
            query: "query { consentManagement { cookies(".concat(t, ") { trackingConsentCookie cookieDomain landingPageCookie origReferrerCookie } customerAccountUrl } }"),
            variables: {}
        }
    }

    function sn(n, e) {
        const t = n.granular_consent,
            o = t.storefrontAccessToken || function() {
                const n = document.documentElement.querySelector("#shopify-features"),
                    e = "Could not find liquid access token";
                if (!n) return void p.warn(e);
                const t = JSON.parse(n.textContent || "").accessToken;
                if (!t) return void p.warn(e);
                return t
            }(),
            r = t.checkoutRootDomain || window.location.host,
            i = t.isExtensionToken ? "Shopify-Storefront-Extension-Token" : "x-shopify-storefront-access-token",
            c = {
                headers: d({
                    "content-type": "application/json",
                    [i]: o
                }, !1),
                body: JSON.stringify(an(n)),
                method: "POST"
            };
        return fetch("https://".concat(r, "/api/unstable/graphql.json"), c).then((n => {
            if (n.ok) return n.json();
            throw new Error("Server error")
        })).then((o => {
            var r, i;
            const c = 31536e6,
                a = 12096e5,
                s = o.data.consentManagement.cookies.cookieDomain,
                u = s || t.checkoutRootDomain || window.location.hostname,
                l = t.storefrontRootDomain || s || window.location.hostname,
                d = o.data.consentManagement.cookies.trackingConsentCookie,
                E = o.data.consentManagement.cookies.landingPageCookie,
                f = o.data.consentManagement.cookies.origReferrerCookie,
                A = null !== (r = null === (i = o.data.consentManagement) || void 0 === i ? void 0 : i.customerAccountUrl) && void 0 !== r ? r : "";
            return d && function(n) {
                var e;
                null !== (e = window.Shopify) && void 0 !== e && e.customerPrivacy || (window.Shopify = window.Shopify || {}, window.Shopify.customerPrivacy = {}), window.Shopify.customerPrivacy.cachedConsent = n
            }(d), t.headlessStorefront && (_(m, u, c, d), E && f && (_(rn, u, a, E), _(cn, u, a, f)), l !== u && (_(m, l, c, d), E && f && (_(rn, l, a, E), _(cn, l, a, f)))), B(n), nn(A), void 0 !== e && e(null, o), o
        })).catch((n => {
            const t = "Error while setting storefront API consent: " + n.message;
            if (void 0 === e) throw {
                error: t
            };
            e({
                error: t
            })
        }))
    }

    function un(n, e) {
        if (p.warn("This method is deprecated. Please read shopify.dev/docs/api/customer-privacy for the latest information."), "boolean" != typeof n) throw TypeError("setCCPAConsent must be called with a boolean consent value");
        if ("function" != typeof e) throw TypeError("setCCPAConsent must be called with a callback function");
        return sn({
            granular_consent: {
                sale_of_data: n
            }
        }, e)
    }

    function ln() {
        if ((new Y).produce("getTrackingConsent"), R()) return r.NO_VALUE;
        const n = D();
        return n[a.MARKETING] === i.ACCEPTED && n[a.ANALYTICS] === i.ACCEPTED ? r.ACCEPTED : n[a.MARKETING] === i.DECLINED || n[a.ANALYTICS] === i.DECLINED ? r.DECLINED : r.NO_INTERACTION
    }

    function dn() {
        (new Y).produce("getRegulation"), p.warn("getRegulation is deprecated and will be removed.");
        const n = L();
        return "" === n ? "" : ["AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "GR", "HU", "IS", "IE", "IT", "LV", "LI", "LT", "LU", "MT", "NL", "NO", "PL", "PT", "RO", "SI", "SK", "ES", "SE", "GB"].includes(n.slice(0, 2)) ? "GDPR" : "US" === n.slice(0, 2) && ["CA", "VA"].includes(n.slice(2, 4)) ? "CCPA" : ""
    }

    function En() {
        return (new Y).produce("getShopPrefs"), p.warn("getShopPrefs is deprecated and will be removed."), {
            limit: []
        }
    }

    function fn() {
        return L()
    }

    function An() {
        if ("" === document.referrer) return !0;
        const n = document.createElement("a");
        return n.href = document.referrer, window.location.hostname != n.hostname
    }

    function pn() {
        return (new Y).produce("isRegulationEnforced"), p.warn("isRegulationEnforced is deprecated and will be removed."), !0
    }

    function Cn() {
        return !!R() || F() && M()
    }

    function gn() {
        return j() ? "string" == typeof navigator.globalPrivacyControl ? "1" !== navigator.globalPrivacyControl : "boolean" == typeof navigator.globalPrivacyControl ? !navigator.globalPrivacyControl : null : null
    }

    function hn() {
        return p.warn("userDataCanBeSold is deprecated and will be replaced with saleOfDataAllowed."), K()
    }

    function Tn() {
        return G() && ln() === r.NO_INTERACTION
    }

    function _n() {
        return !1 === gn() ? r.DECLINED : (n = I(), R() ? r.NO_VALUE : n === i.NO_VALUE ? r.NO_INTERACTION : O(n));
        var n
    }

    function yn() {
        return (new Y).produce("shouldShowCCPABanner"), p.warn("shouldShowCCPABanner is deprecated and will be removed."), j() && _n() === r.NO_INTERACTION
    }

    function mn() {
        return !0
    }

    function Nn(n) {
        return function(n) {
            const e = w();
            if (R(e) || !e.cus) return;
            const t = e.cus[encodeURIComponent(n)];
            return t ? C(t) : t
        }(n)
    }

    function Sn() {
        return U()
    }

    function wn() {
        var n, t, o, r;
        const i = Q({
            useBugsnagReporting: !0,
            useInstrumentation: !0
        });
        if ((null === (n = window.Shopify.trackingConsent) || void 0 === n ? void 0 : n.__metadata__) || (null === (t = window.Shopify.customerPrivacy) || void 0 === t ? void 0 : t.__metadata__)) {
            const n = null === (o = window.Shopify.customerPrivacy.__metadata__) || void 0 === o ? void 0 : o.version,
                e = null === (r = i.__metadata__) || void 0 === r ? void 0 : r.version,
                t = `Multiple versions of Shopify.trackingConsent or Shopify.customerPrivacy loaded -  Version '${n}' is already loaded but replacing with version '${e}'.\n\nThis could result in unexpected behavior. See documentation https://shopify.dev/docs/api/customer-privacy for more information.`,
                c = "Shopify.trackingConsent or Shopify.customerPrivacy already exists.\n\nLoading multiple versions could result in unexpected behavior. See documentation https://shopify.dev/docs/api/customer-privacy for more information.";
            try {
                console.warn(n && e ? t : c)
            } catch (n) {
                if (!(n instanceof ReferenceError)) throw n
            }
        }
        const c = Object.assign(Object.assign({}, window.Shopify.customerPrivacy), i);
        window.Shopify.customerPrivacy = window.Shopify.trackingConsent = c, x(e.CONSENT_TRACKING_API_LOADED)
    }
    window.Shopify = window.Shopify ? window.Shopify : {}, wn(), n.default = Q, n.setGlobalObject = wn, Object.defineProperty(n, "__esModule", {
        value: !0
    })
}({});
//# sourceMappingURL=consent-tracking-api.js.map