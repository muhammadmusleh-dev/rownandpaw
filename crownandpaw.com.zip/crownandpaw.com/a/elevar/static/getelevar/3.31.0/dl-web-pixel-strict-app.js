let e;
var t = {};
t.d = (e, a) => {
    for (var r in a) t.o(a, r) && !t.o(e, r) && Object.defineProperty(e, r, {
        enumerable: !0,
        get: a[r]
    })
}, t.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t);
var a = {};

function r(e) {
    for (var t = 1; t < arguments.length; t++) {
        var a = arguments[t];
        for (var r in a) e[r] = a[r]
    }
    return e
}
t.d(a, {
    R: () => ei
});
var n = function e(t, a) {
    function n(e, n, i) {
        if ("undefined" != typeof document) {
            "number" == typeof(i = r({}, a, i)).expires && (i.expires = new Date(Date.now() + 864e5 * i.expires)), i.expires && (i.expires = i.expires.toUTCString()), e = encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape);
            var o = "";
            for (var s in i) i[s] && (o += "; " + s, !0 !== i[s] && (o += "=" + i[s].split(";")[0]));
            return document.cookie = e + "=" + t.write(n, e) + o
        }
    }
    return Object.create({
        set: n,
        get: function(e) {
            if ("undefined" != typeof document && (!arguments.length || e)) {
                for (var a = document.cookie ? document.cookie.split("; ") : [], r = {}, n = 0; n < a.length; n++) {
                    var i = a[n].split("="),
                        o = i.slice(1).join("=");
                    try {
                        var s = decodeURIComponent(i[0]);
                        if (r[s] = t.read(o, s), e === s) break
                    } catch (e) {}
                }
                return e ? r[e] : r
            }
        },
        remove: function(e, t) {
            n(e, "", r({}, t, {
                expires: -1
            }))
        },
        withAttributes: function(t) {
            return e(this.converter, r({}, this.attributes, t))
        },
        withConverter: function(t) {
            return e(r({}, this.converter, t), this.attributes)
        }
    }, {
        attributes: {
            value: Object.freeze(a)
        },
        converter: {
            value: Object.freeze(t)
        }
    })
}({
    read: function(e) {
        return '"' === e[0] && (e = e.slice(1, -1)), e.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent)
    },
    write: function(e) {
        return encodeURIComponent(e).replace(/%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g, decodeURIComponent)
    }
}, {
    path: "/"
});

function i(e, t, a) {
    let r = e.length - t.length;
    if (0 === r) return e(...t);
    if (1 === r) {
        let r;
        return r = a => e(a, ...t), void 0 === a ? r : Object.assign(r, {
            lazy: a,
            lazyArgs: t
        })
    }
    throw Error("Wrong number of arguments")
}

function o(e, t) {
    let a = {};
    for (let r of t) r in e && (a[r] = e[r]);
    return a
}
let s = "___ELEVAR_GTM_SUITE--",
    l = {
        userId: `${s}userId`,
        sessionId: `${s}sessionId`,
        sessionCount: `${s}sessionCount`,
        lastCollectionPathname: `${s}lastCollectionPathname`,
        lastDlPushTimestamp: `${s}lastDlPushTimestamp`,
        userOnSignupPath: `${s}userOnSignupPath`,
        userLoggedIn: `${s}userLoggedIn`,
        cart: `${s}cart`,
        params: `${s}params`,
        cookies: `${s}cookies`,
        debug: `${s}debug`,
        shopifyPixelMode: "shopify-pixel-mode"
    },
    c = "_Elevar-apex",
    u = "___ELEVAR_GTM_SUITE--apexDomain",
    d = {
        get context() {
            if (void 0 !== e) return e;
            throw Error("`setExecution` has not been called")
        }
    },
    _ = (e, t) => {
        let a = (e => {
                switch (e) {
                    case "UNEXPECTED":
                    case "TRANSFORM_FN_BAD_RETURN":
                    case "TRANSFORM_FN_ERROR_THROWN":
                    case "USERID_FN_BAD_RETURN":
                    case "USERID_FN_ERROR_THROWN":
                    case "MARKETID_FN_BAD_RETURN":
                    case "MARKETID_FN_ERROR_THROWN":
                    case "BAD_EVENT_DATA":
                    case "BAD_EVENT_ORDER":
                    case "DUPLICATE_EVENT":
                    case "CART_RECONCILIATION_ENABLED":
                    case "MISSED_CONTEXT_INVALIDATION":
                    case "MISSING_GOOGLE_TAG_MANAGER":
                        return "ERROR";
                    case "WEB_PIXEL_LOG":
                    case "CONTEXT_PUSHED":
                    case "VALIDATION_PASS":
                        return "INFO";
                    case "CONSENT_CHECK_LIMIT_REACHED":
                    case "LOCAL_STORAGE_ACCESS_DENIED":
                        return "WARNING"
                }
            })(e),
            r = (e => {
                switch (e) {
                    case "INFO":
                        return console.log;
                    case "WARNING":
                        return console.warn;
                    case "ERROR":
                        return console.error
                }
            })(a),
            n = e.toLowerCase();
        r(`Elevar ${a}: ${e}`, ...t ? ["\n\n", ...t] : [], `

https://docs.getelevar.com/docs/data-layer-codes#${n}`)
    },
    m = "_elevar_",
    p = "_elevar_visitor_info",
    g = "_fbp",
    f = "_fbc",
    E = "_ga_",
    I = {
        GOOGLE_CLICK_ID: "gclid",
        GOOGLE_GBRAID: "gbraid",
        GOOGLE_WBRAID: "wbraid",
        UTM_CAMPAIGN: "utm_campaign",
        UTM_CONTENT: "utm_content",
        UTM_MEDIUM: "utm_medium",
        UTM_SOURCE: "utm_source",
        UTM_TERM: "utm_term"
    },
    S = {
        APPLOVIN: "aleid",
        ASPIRE: "transaction_id",
        AWIN: "awc",
        BING: "msclkid",
        CJ: "cjevent",
        FACEBOOK: "fbclid",
        GOOGLE_ADS: "gclsrc",
        IMPACT_RADIUS: "irclickid",
        IMPACT_RADIUS_ALT_ID: "im_ref",
        ITERABLE: "iterable_campaign",
        KLAVIYO: "_kx",
        LINKEDIN: "li_fat_id",
        OUTBRAIN: "dicbo",
        PARTNERIZE: "clickref",
        PEPPERJAM: "clickId",
        PEPPERJAM_PUBLISHER_ID: "ev_publisherId",
        PINTEREST: "epik",
        RAKUTEN: "ranSiteID",
        REDDIT: "rdt_cid",
        SHAREASALE: "sscid",
        SNAPCHAT: "ScCid",
        TABOOLA: "tblci",
        TIKTOK: "ttclid",
        TWITTER: "twclid",
        VOLUUM: "vlmcid"
    },
    O = {
        FACEBOOK: "fbadid",
        GOOGLE: "gadid",
        PINTEREST: "padid",
        SMARTLY: "smadid",
        SNAPCHAT: "scadid",
        TIKTOK: "ttadid"
    },
    v = {
        ELEVAR_SESSION_COUNT: "session_count",
        ELEVAR_SESSION_ID: "session_id",
        ELEVAR_USER_ID: "user_id",
        MARKET_ID: "market_id",
        GOOGLE_ADS_CLICK_ID: "google_ads_click_id",
        GTM_CONSENT: "consent",
        GTM_CONSENT_V2: "consent_v2",
        RAKUTEN_TIME_STAMP: "ranSiteID_ts",
        REFERRER: "referrer",
        SMARTLY_TIME_STAMP: "smadid_ts"
    };

function b(e) {
    if ("object" != typeof e || !e) return !1;
    let t = Object.getPrototypeOf(e);
    return null === t || t === Object.prototype
}

function w(...e) {
    return i(T, e)
}
let T = (e, t) => e.length >= t;

function R(e, t) {
    if (!w(t, 1)) return { ...e
    };
    if (!w(t, 2)) {
        let {
            [t[0]]: a, ...r
        } = e;
        return r
    }
    let a = { ...e
    };
    for (let e of t) delete a[e];
    return a
}
let A = [
        ["userId", null],
        ["sessionId", null],
        ["sessionCount", null],
        ["lastDlPushTimestamp", null],
        ["params", null],
        ["cookies", null],
        ["debug", null]
    ],
    h = async e => {
        let {
            utils: t
        } = d.context;
        await Promise.all((() => {
            if (!e) return A;
            try {
                let t = JSON.parse(e);
                if (Array.isArray(t)) return A.map(([e]) => {
                    let a = t.find(t => Array.isArray(t) && e === t[0] && ("string" == typeof t[1] || null === t[1])) ? ? null;
                    return [e, a ? a[1] : null]
                });
                return A
            } catch (e) {
                return _("UNEXPECTED", [e]), A
            }
        })().map(([e, a]) => null !== a ? Promise.resolve(t.localStorage.set(e, a)) : Promise.resolve()))
    },
    y = e => {
        switch (e) {
            case !1:
                return 0;
            case !0:
                return 1;
            case void 0:
                return -1
        }
    },
    N = e => {
        switch (e) {
            case 0:
                return !1;
            case 1:
                return !0;
            case -1:
                return
        }
    },
    k = async e => {
        let {
            utils: t
        } = d.context;
        try {
            let a = JSON.parse(e),
                [r] = a;
            if (1 === r) {
                let [e, r, n, i, o, s, l, c, u] = a, d = { ...s,
                    ...0 === l.length ? {} : {
                        consent_v2: Object.fromEntries(l.map(([e, t, a]) => {
                            let r = N(t),
                                n = N(a);
                            return [(e => {
                                switch (e) {
                                    case 1:
                                        return "ad_storage";
                                    case 2:
                                        return "ad_user_data";
                                    case 3:
                                        return "ad_personalization";
                                    case 4:
                                        return "analytics_storage";
                                    case 5:
                                        return "functionality_storage";
                                    case 6:
                                        return "personalization_storage";
                                    case 7:
                                        return "security_storage";
                                    default:
                                        return e
                                }
                            })(e), { ...void 0 !== r ? {
                                    default: r
                                } : {},
                                ...void 0 !== n ? {
                                    update: n
                                } : {}
                            }]
                        }))
                    },
                    ...r ? {
                        user_id: r
                    } : {},
                    ...n ? {
                        session_id: n
                    } : {},
                    ...i ? {
                        session_count: i
                    } : {}
                }, _ = (e, a) => {
                    if (a) return t.localStorage.set(e, a)
                };
                await Promise.all([_("userId", r), _("sessionId", n), _("sessionCount", i), _("lastDlPushTimestamp", o), t.localStorage.set("params", JSON.stringify(d)), _("cookies", c), _("debug", 1 === u ? "true" : null)])
            }
        } catch (e) {
            _("UNEXPECTED", [e])
        }
    },
    C = async () => {
        let {
            utils: e
        } = d.context, t = await e.cookie.get(c);
        if (t) await k(t);
        else {
            let t = await e.cookie.get(u);
            await h(t)
        }
    },
    D = async () => {
        let {
            utils: e,
            computed: t
        } = d.context;
        if (null !== t.apexDomain) {
            let a = async () => {
                    let t = {
                            partialParams: null,
                            packedConsent: []
                        },
                        a = await e.localStorage.get("params");
                    if (null === a) return t;
                    let r = JSON.parse(a);
                    if (!b(r)) return t;
                    let n = function(...e) {
                            return i(R, e)
                        }(r, ["user_id", "session_id", "session_count", "consent_v2"]),
                        o = r.consent_v2;
                    return b(o) ? {
                        partialParams: n,
                        packedConsent: Object.entries(o).map(([e, t]) => [(e => {
                            switch (e) {
                                case "ad_storage":
                                    return 1;
                                case "ad_user_data":
                                    return 2;
                                case "ad_personalization":
                                    return 3;
                                case "analytics_storage":
                                    return 4;
                                case "functionality_storage":
                                    return 5;
                                case "personalization_storage":
                                    return 6;
                                case "security_storage":
                                    return 7;
                                default:
                                    return e
                            }
                        })(e), y(t.default), y(t.update)])
                    } : { ...t,
                        partialParams: n
                    }
                },
                r = async () => +("true" === await e.localStorage.get("debug")),
                {
                    partialParams: n,
                    packedConsent: o
                } = await a(),
                s = [1, await e.localStorage.get("userId"), await e.localStorage.get("sessionId"), await e.localStorage.get("sessionCount"), await e.localStorage.get("lastDlPushTimestamp"), n, o, await e.localStorage.get("cookies"), await r()];
            await e.cookie.remove(u, {
                domain: t.apexDomain,
                secure: !0,
                sameSite: "strict"
            }), await e.cookie.set(c, JSON.stringify(s), {
                domain: t.apexDomain,
                expires: 365,
                secure: !0,
                sameSite: "strict"
            })
        }
    },
    P = (e = 21) => {
        let t = "",
            a = crypto.getRandomValues(new Uint8Array(e |= 0));
        for (; e--;) t += "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict" [63 & a[e]];
        return t
    },
    M = "OTHER",
    x = async e => {
        let {
            utils: t
        } = d.context, a = new Date, r = String(Math.floor(a.getTime() / 1e3)), [n, i, o] = await Promise.all([t.localStorage.get("sessionId"), t.localStorage.get("sessionCount"), t.localStorage.get("lastDlPushTimestamp")]), s = "FOR_EVENT" === e, l = !!o && Number(o) + 1800 <= Math.floor(Date.now() / 1e3);
        s && (M = null === o ? "FIRST_EVER" : l ? "FIRST_IN_SESSION" : "OTHER");
        let c = null === n || l ? r : n,
            u = null === i ? "1" : l ? String(Number(i) + 1) : i,
            _ = s ? r : o;
        await Promise.all([t.localStorage.set("sessionId", c), t.localStorage.set("sessionCount", u), ..._ ? [t.localStorage.set("lastDlPushTimestamp", _)] : []]), s && await D();
        let m = {
            id: c,
            count: u
        };
        return s ? {
            session: m,
            lastDlPushTimestamp: _,
            eventState: M,
            date: a
        } : {
            session: m
        }
    },
    L = async e => {
        let {
            utils: t,
            waitForAppPixelToSetUserId: a
        } = d.context;
        if (a) {
            let e = async (a = 1) => {
                let r = await t.localStorage.get("userId");
                if (r) return r;
                if (a > 8) {
                    let e = P();
                    return await U(e), e
                } {
                    let t;
                    return await (t = 2 ** a * 10, new Promise(e => setTimeout(e, t))), e(a + 1)
                }
            };
            return e()
        }
        if (e) return await U(e), e; {
            let e = P();
            return await U(e), e
        }
    },
    j = async e => {
        let {
            utils: t
        } = d.context, a = await t.localStorage.get("userId");
        if (null !== a) return a;
        if ("function" == typeof window.ElevarUserIdFn) try {
            let t = await window.ElevarUserIdFn();
            if ("string" == typeof t) return await U(t), t;
            return _("USERID_FN_BAD_RETURN"), await L(e)
        } catch (e) {
            _("USERID_FN_ERROR_THROWN", [e])
        }
        return L(e)
    },
    U = async e => {
        let {
            utils: t
        } = d.context;
        await t.localStorage.set("userId", e)
    },
    G = async () => {
        let e, {
            utils: t
        } = d.context;
        return null !== (e = await t.localStorage.get("params")) ? JSON.parse(e) : {}
    },
    $ = async e => {
        let {
            utils: t
        } = d.context;
        await t.localStorage.set("params", JSON.stringify(e))
    },
    F = async () => {
        let e, {
            utils: t
        } = d.context;
        return null !== (e = await t.localStorage.get("cookies")) ? JSON.parse(e) : {}
    },
    K = async e => {
        let {
            utils: t
        } = d.context;
        await t.localStorage.set("cookies", JSON.stringify(e))
    },
    B = e => (e => {
        let {
            config: t
        } = d.context;
        if (!t.consent_enabled || !t.strict_consent_enabled) return !0;
        let a = window.ElevarConsent ? .at(-1),
            r = a ? Object.entries(a).map(([e, t]) => t.update ? ? t.default ? e : null).filter(e => null !== e) : [],
            n = (e, t) => {
                let a = "ga4" === e && (null === t || 0 === t.length) ? ["ad_storage", "analytics_storage"] : t;
                return null === a || a.every(e => r.includes(e))
            };
        if ("GLOBAL" === e.type) return Object.entries(t.destinations).map(([e, t]) => [e, t.map(e => e.consentMode)]).some(([e, t]) => t.some(t => n(e, t))); {
            let a = t.destinations[e.key];
            return !!a && Object.values(a).map(e => e.consentMode).some(t => n(e.key, t))
        }
    })({
        type: "DESTINATION",
        key: e
    }),
    W = Object.values(I),
    H = [...Object.values(O), ...Object.values(S)],
    J = [...W, ...H, ...Object.values(v)],
    V = null,
    z = ({
        stale: e,
        updated: t
    }) => {
        let a = Object.fromEntries(e.filter(([e]) => W.includes(e))),
            r = t.some(([e]) => W.includes(e)),
            n = t.some(([e, t]) => e === v.REFERRER && a[e] !== t);
        return Object.fromEntries(r ? [...e.filter(([e]) => !W.includes(e)), ...t].filter(([e]) => e !== v.REFERRER) : n ? [...e, ...t].filter(([e]) => !W.includes(e)) : [...e, ...t])
    },
    X = {
        gclid: ["ga4", "google_ads"],
        gbraid: ["ga4", "google_ads"],
        wbraid: ["ga4", "google_ads"],
        utm_campaign: null,
        utm_content: null,
        utm_medium: null,
        utm_source: null,
        utm_term: null,
        aleid: ["applovin"],
        transaction_id: ["aspire"],
        awc: ["awin"],
        msclkid: ["bing"],
        cjevent: ["cj"],
        fbclid: ["facebook"],
        gclsrc: [],
        irclickid: ["impact_radius"],
        im_ref: ["impact_radius"],
        iterable_campaign: ["iterable"],
        _kx: ["klaviyo"],
        li_fat_id: [],
        dicbo: ["outbrain"],
        clickref: ["partnerize"],
        clickId: ["pepperjam"],
        ev_publisherId: ["pepperjam"],
        epik: ["pinterest"],
        ranSiteID: ["rakuten"],
        rdt_cid: ["reddit"],
        sscid: ["shareasale"],
        ScCid: ["snapchat"],
        tblci: ["taboola"],
        ttclid: ["tiktok"],
        twclid: ["twitter"],
        vlmcid: ["voluum"],
        fbadid: ["facebook"],
        gadid: ["ga4"],
        padid: ["pinterest"],
        smadid: ["smartly"],
        scadid: ["snapchat"],
        ttadid: ["tiktok"],
        session_count: null,
        session_id: null,
        user_id: null,
        market_id: null,
        google_ads_click_id: ["google_ads"],
        consent: null,
        consent_v2: null,
        ranSiteID_ts: ["rakuten"],
        referrer: null,
        smadid_ts: ["smartly"]
    },
    Y = async ({
        isConsentRequired: e,
        userId: t,
        marketId: a,
        consentData: r,
        cartAttributes: n
    }) => {
        let {
            session: i
        } = await x(), o = z({
            stale: Object.entries(await G()),
            updated: Object.entries({ ...(() => {
                    let e, t, a, r, n, i, {
                            window: o
                        } = d.context,
                        s = new URLSearchParams(o.location.search);
                    return Object.fromEntries([...W, ...H].filter(e => s.has(e)).map(e => [e, s.get(e)]).concat((e = I.GOOGLE_CLICK_ID, t = I.GOOGLE_GBRAID, a = I.GOOGLE_WBRAID, r = s.get(e), n = s.get(t), i = s.get(a), r ? [
                        [v.GOOGLE_ADS_CLICK_ID, `gclid:${r}`]
                    ] : n ? [
                        [v.GOOGLE_ADS_CLICK_ID, `gbraid:${n}`]
                    ] : i ? [
                        [v.GOOGLE_ADS_CLICK_ID, `wbraid:${i}`]
                    ] : [])))
                })(),
                ...(() => {
                    let {
                        config: e,
                        window: t,
                        document: a,
                        computed: r
                    } = d.context;
                    if ("" === a.referrer) return {};
                    let n = new URL(a.referrer),
                        i = r.apexDomain ? [r.apexDomain, ...e.ignored_referrer_domains] : e.ignored_referrer_domains,
                        o = a.referrer === V,
                        s = n.hostname === t.location.hostname,
                        l = i.some(e => n.hostname === e || n.hostname.endsWith(`.${e}`));
                    return o || s || l ? {} : (V = a.referrer, {
                        referrer: a.referrer
                    })
                })(),
                user_id: t,
                session_id: i.id,
                session_count: i.count,
                ...a ? {
                    [v.MARKET_ID]: a
                } : {},
                ...r ? {
                    consent_v2: Object.fromEntries(Object.entries(r).map(([e, t]) => [e, { ..."boolean" == typeof t.default ? {
                            default: t.default
                        } : {},
                        ..."boolean" == typeof t.update ? {
                            update: t.update
                        } : {}
                    }]))
                } : {}
            })
        }), s = n ? (e => {
            let t = Object.entries(e).find(([e]) => e === p);
            if (!t) return {};
            try {
                let e = t[1].replaceAll("&quot;", '"');
                return JSON.parse(e)
            } catch (e) {
                return _("UNEXPECTED", [e]), {}
            }
        })(n) : {}, l = ([e]) => J.includes(e), c = (({
            isConsentRequired: e,
            data: t
        }) => {
            let {
                config: a
            } = d.context;
            if (!e || !a.strict_consent_enabled) return t; {
                let e = new Map;
                return Object.fromEntries(Object.entries(t).filter(([t]) => {
                    let a = X[t];
                    return null === a || a.some(t => {
                        if (e.has(t)) return e.get(t); {
                            let a = B(t);
                            return e.set(t, a), a
                        }
                    })
                }))
            }
        })({
            isConsentRequired: e,
            data: (({
                stale: e,
                fresh: t,
                intermediate: a
            }) => {
                let r = O.SMARTLY in a && e[O.SMARTLY] !== t[O.SMARTLY],
                    n = S.RAKUTEN in a && e[S.RAKUTEN] !== t[S.RAKUTEN];
                return { ...a,
                    ...r ? {
                        [v.SMARTLY_TIME_STAMP]: Math.floor(Date.now() / 1e3)
                    } : v.SMARTLY_TIME_STAMP in e ? {
                        [v.SMARTLY_TIME_STAMP]: e[v.SMARTLY_TIME_STAMP]
                    } : {},
                    ...n ? {
                        [v.RAKUTEN_TIME_STAMP]: Math.floor(Date.now() / 1e3)
                    } : v.RAKUTEN_TIME_STAMP in e ? {
                        [v.RAKUTEN_TIME_STAMP]: e[v.RAKUTEN_TIME_STAMP]
                    } : {}
                }
            })({
                stale: s,
                fresh: o,
                intermediate: z({
                    stale: Object.entries(s).filter(l),
                    updated: Object.entries(o).filter(l)
                })
            })
        });
        return await $(c), Object.entries(c).some(([e, t]) => {
            let a;
            return a = s[e] ? ? null, JSON.stringify(t) !== JSON.stringify(a)
        }) ? {
            [p]: JSON.stringify(c)
        } : {}
    },
    q = e => Object.fromEntries(Object.entries(e).map(([e, t]) => [e, "string" == typeof e && e.includes(E) && t ? t.startsWith("GS1") ? t.split(".").map((e, t) => 5 === t ? "0" : e).join(".") : t.split("$").map(e => e.startsWith("t") ? "t0" : e).join("$") : t])),
    Z = ["AwinChannelCookie", "_uetsid", "_uetvid", g, f, "_ga", "_rdt_uuid", "_scid", "ttclid", "_ttp"],
    Q = {
        AwinChannelCookie: ["awin"],
        _uetsid: ["bing"],
        _uetvid: ["bing"],
        _fbp: ["facebook"],
        _fbc: ["facebook"],
        _ga: ["ga4"],
        _ga_: ["__IS_PREFIX", "ga4"],
        _rdt_uuid: ["reddit"],
        _scid: ["snapchat"],
        ttclid: ["tiktok"],
        _ttp: ["tiktok"]
    },
    ee = async ({
        isConsentRequired: e,
        freshCookies: t,
        localCookies: a
    }) => {
        let {
            config: r,
            utils: n,
            computed: i
        } = d.context, o = await G();
        if (!(!e || (r.strict_consent_enabled ? B("facebook") : b(o.consent_v2) && b(o.consent_v2.ad_storage) && (o.consent_v2.ad_storage.update ? ? o.consent_v2.ad_storage.default) && b(o.consent_v2.analytics_storage) && (o.consent_v2.analytics_storage.update ? ? o.consent_v2.analytics_storage.default) && b(o.consent_v2.ad_personalization) && (o.consent_v2.ad_personalization.update ? ? o.consent_v2.ad_personalization.default) && b(o.consent_v2.ad_user_data) && (o.consent_v2.ad_user_data.update ? ? o.consent_v2.ad_user_data.default)))) return [];
        let s = o[S.FACEBOOK],
            l = a[f],
            c = a[g],
            u = `fb.1.${Date.now()}`,
            _ = "string" == typeof s && l ? .split(".")[3] !== s ? `${u}.${s}` : null,
            m = c ? null : `${u}.${Math.floor(1e9+9e9*Math.random())}`;
        return (_ || !t[f] && l) && await n.cookie.set(f, _ ? ? l, {
            domain: i.apexDomain ? ? location.hostname.replace("www.", ""),
            expires: 90
        }), (m || !t[g] && c) && await n.cookie.set(g, m ? ? c, {
            domain: i.apexDomain ? ? location.hostname.replace("www.", ""),
            expires: 90
        }), [..._ ? [
            [f, _]
        ] : [], ...m ? [
            [g, m]
        ] : []]
    },
    et = async ({
        isConsentRequired: e,
        cartAttributes: t
    }) => {
        let {
            utils: a
        } = d.context, r = q(await a.cookie.getAll()), n = [...Z, ...Object.keys(r).filter(e => e.startsWith(E))], i = q(await F()), o = t ? q(Object.fromEntries(Object.entries(t).filter(([e]) => n.includes(e.replace(m, ""))).map(([e, t]) => [e.replace(m, ""), t]))) : {}, s = n.map(e => {
            let t = r[e],
                a = i[e],
                n = o[e];
            return t !== a && void 0 !== t ? [e, t] : a !== n && void 0 !== a ? [e, a] : null
        }).filter(e => null !== e), l = (({
            isConsentRequired: e,
            data: t
        }) => {
            let {
                config: a
            } = d.context;
            if (!e || !a.strict_consent_enabled) return t; {
                let e = new Map;
                return Object.fromEntries(Object.entries(t).filter(([t]) => {
                    let a = t.startsWith(E) ? E : t,
                        r = Q[a] ? .filter(e => "__IS_PREFIX" !== e) ? ? null;
                    return null === r || r.some(t => {
                        if (e.has(t)) return e.get(t); {
                            let a = B(t);
                            return e.set(t, a), a
                        }
                    })
                }))
            }
        })({
            isConsentRequired: e,
            data: { ...i,
                ...Object.fromEntries(s)
            }
        }), c = await ee({
            isConsentRequired: e,
            freshCookies: r,
            localCookies: l
        });
        await K({ ...l,
            ...Object.fromEntries(c)
        });
        let u = s.filter(([e]) => !c.some(([t]) => e === t));
        return Object.fromEntries([...c, ...u].map(([e, t]) => [`${m}${e}`, t]))
    },
    ea = async e => {
        let t;
        return await C(), await Y({
            isConsentRequired: e.isConsentRequired,
            userId: await j(e.event.clientId),
            marketId: (t = e.event.data.checkout.localization.market.id, t ? .replace("gid://shopify/Market/", "") ? ? ""),
            consentData: null,
            cartAttributes: null
        }), await et({
            isConsentRequired: e.isConsentRequired,
            cartAttributes: null
        }), await D(), [{
            name: p,
            value: JSON.stringify(await G())
        }, ...Object.entries(await F()).filter(e => void 0 !== e[1]).map(([e, t]) => ({
            name: `${m}${e}`,
            value: t
        })).toSorted((e, t) => e.name.localeCompare(t.name))]
    },
    er = async ({
        api: e,
        log: t,
        event: a
    }) => {
        let r, n, i, {
                config: o
            } = d.context,
            s = await ea({
                isConsentRequired: o.consent_enabled,
                event: a
            });
        t({
            event: "fullyManagedHandler.commonInfo",
            context: {
                event: a,
                notes: s
            }
        });
        let l = (r = a.data.checkout, n = a.data.checkout.order ? .id ? .split("/").at(-1), {
                event_name: (e => {
                    switch (e) {
                        case "checkout_started":
                            return "dl_begin_checkout";
                        case "checkout_contact_info_submitted":
                            return "dl_add_contact_info";
                        case "checkout_shipping_info_submitted":
                            return "dl_add_shipping_info";
                        case "payment_info_submitted":
                            return "dl_add_payment_info";
                        case "checkout_completed":
                            return "dl_purchase"
                    }
                })(a.name),
                event: {
                    context: {
                        document_location: a.context.document.location.href,
                        document_title: a.context.document.title,
                        referrer: a.context.document.referrer
                    },
                    event_data: {
                        token: r.token ? ? "",
                        currency: r.currencyCode ? ? e.init.data.shop.paymentSettings.currencyCode,
                        customer: {
                            email: r.email ? ? void 0,
                            phone: r.phone ? ? void 0
                        },
                        ..."checkout_completed" === a.name && n ? {
                            order: {
                                id: n
                            }
                        } : {},
                        line_items: r.lineItems.map(e => e.variant ? {
                            id: e.id ? ? "",
                            quantity: e.quantity,
                            title: e.title ? ? void 0,
                            sellingPlanName: e.sellingPlanAllocation ? .sellingPlan.name ? ? "one-time",
                            variant: {
                                id: e.variant.id ? ? "",
                                price: e.variant.price.amount,
                                sku: e.variant.sku,
                                title: e.variant.title,
                                image: e.variant.image ? .src ? e.variant.image.src.replace("_64x64", "") : void 0,
                                product: {
                                    id: e.variant.product.id ? ? "",
                                    title: e.variant.product.title,
                                    vendor: e.variant.product.vendor,
                                    url: `${a.context.document.location.origin}${e.variant.product.url??""}`
                                }
                            }
                        } : null).filter(e => null !== e),
                        shipping_address: {
                            phone: r.shippingAddress ? .phone ? ? void 0,
                            city: r.shippingAddress ? .city ? ? void 0,
                            country: r.shippingAddress ? .country ? ? void 0,
                            country_code: r.shippingAddress ? .countryCode ? ? void 0,
                            province: r.shippingAddress ? .province ? ? void 0,
                            province_code: r.shippingAddress ? .provinceCode ? ? void 0,
                            zip: r.shippingAddress ? .zip ? ? void 0
                        },
                        subtotal_price: r.subtotalPrice ? .amount ? ? 0,
                        total_price: r.totalPrice ? .amount ? ? 0,
                        total_tax: r.totalTax ? .amount,
                        shipping_price: r.shippingLine ? .price ? .amount
                    },
                    event_time: a.timestamp,
                    note_attributes: s
                }
            }),
            c = `${l.event_name}_${a.data.checkout.token}`,
            u = (i = {
                event_id: c,
                event: l.event_name
            }, btoa(o.signing_key + (i.event_id ? `:${i.event_id}` : "") + (i.event ? `:${i.event}` : ""))),
            _ = new URLSearchParams({
                signature: u,
                source_url: a.context.document.location.href,
                timestamp: String(Math.floor(Date.now() / 1e3)),
                shop: o.shop_url
            }).toString();
        await fetch(`${o.connector_url}/base/order-notes?${_}`, {
            method: "POST",
            body: JSON.stringify(l),
            headers: {
                "Content-Type": "application/json"
            }
        }), t({
            event: "fullyManagedHandler.stashedInfo",
            context: {
                webEvent: l,
                id: c,
                signature: u,
                query: _
            }
        })
    },
    en = async e => {
        let {
            utils: t
        } = d.context;
        e.clientId && !await t.localStorage.get("userId") && await t.localStorage.set("userId", e.clientId)
    },
    ei = async (t, a) => {
        try {
            var r, s;
            let c, u;
            r = {
                type: "SHOPIFY_WEB_PIXEL_STRICT",
                api: t
            }, c = {
                config: a,
                details: r,
                ..."api" in r ? function(...e) {
                    return i(o, e)
                }(r.api.init.context, ["window", "document", "navigator"]) : {
                    window,
                    document,
                    navigator
                },
                utils: "api" in r ? (s = r.api, {
                    cookie: {
                        get: async e => {
                            let t = await s.browser.cookie.get(e);
                            return n.converter.read(t, e)
                        },
                        getAll: async () => {
                            let e = await s.browser.cookie.get();
                            return e ? Object.fromEntries(e.split(";").filter(e => e.includes("=")).map(e => e.trim().split("=")).map(([e, t]) => [decodeURIComponent(e), n.converter.read(t, e)])) : {}
                        },
                        set: async (e, t, a) => {
                            let r = [`${e}=${n.converter.write(t,e)}`, ...a ? .domain ? [`domain=${a.domain}`] : [], ...a ? .expires ? [`expires=${Date.now()+864e5*a.expires}`] : [], ...a ? .secure ? ["secure"] : [], ...a ? .sameSite ? [`samesite=${a.sameSite}`] : [], "path=/"].join(";");
                            await s.browser.cookie.set(r)
                        },
                        remove: async (e, t) => {
                            let a = [`${e}=''`, ...t ? .domain ? [`domain=${t.domain}`] : [], ...t ? .secure ? ["secure"] : [], ...t ? .sameSite ? [`samesite=${t.sameSite}`] : [], "path=/"].join(";");
                            await s.browser.cookie.set(a)
                        }
                    },
                    localStorage: {
                        get: async e => s.browser.localStorage.getItem(l[e]),
                        set: (e, t) => s.browser.localStorage.setItem(l[e], t),
                        remove: e => s.browser.localStorage.removeItem(l[e]),
                        removeAll: async () => {
                            await Promise.all(Object.values(l).map(e => s.browser.localStorage.removeItem(e)))
                        }
                    }
                }) : {
                    cookie: {
                        get: e => n.get(e) ? ? null,
                        getAll: () => n.get(),
                        set: (e, t, a) => {
                            n.set(e, t, a)
                        },
                        remove: (e, t) => {
                            n.remove(e, t)
                        }
                    },
                    localStorage: {
                        get: e => window.localStorage.getItem(l[e]),
                        set: (e, t) => window.localStorage.setItem(l[e], t),
                        remove: e => window.localStorage.removeItem(l[e]),
                        removeAll: () => {
                            Object.values(l).forEach(e => window.localStorage.removeItem(e))
                        }
                    }
                },
                waitForAppPixelToSetUserId: "SHOPIFY_THEME" === r.type || "SHOPIFY_WEB_PIXEL_LAX" === r.type
            }, u = a.apex_domains.find(e => c.window.location.hostname.endsWith(e)) ? ? null, e = { ...c,
                computed: {
                    apexDomain: u
                }
            };
            let {
                utils: m
            } = d.context, p = await m.localStorage.get("shopifyPixelMode");
            if ("debug" === p) debugger;
            if (!a.consent_enabled || !a.strict_consent_enabled) {
                t.analytics.subscribe("page_viewed", e => void en(e));
                let e = ({
                    event: e,
                    context: t
                }) => {
                    "verbose" === p && _("WEB_PIXEL_LOG", [{
                        event: e,
                        context: t
                    }])
                };
                e({
                    event: "registerHandlers.commonInfo",
                    context: { ...t
                    }
                }), (({
                    api: e,
                    log: t
                }) => {
                    let a = a => {
                        er({
                            api: e,
                            log: t,
                            event: a
                        })
                    };
                    e.analytics.subscribe("checkout_started", a), e.analytics.subscribe("checkout_contact_info_submitted", a), e.analytics.subscribe("checkout_shipping_info_submitted", a), e.analytics.subscribe("payment_info_submitted", a), e.analytics.subscribe("checkout_completed", a)
                })({
                    api: t,
                    log: e
                })
            }
        } catch (e) {
            _("UNEXPECTED", [e])
        }
    };
var eo = a.R;
export {
    eo as handler
};