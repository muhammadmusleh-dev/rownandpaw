export default {
    "signing_key": "jxSJpolcAuL6NQwpsyFDvChQsng9lXGe",
    "connector_url": "https://hits.getelevar.com",
    "consent_enabled": false,
    "strict_consent_enabled": false,
    "allow_gtm": true,
    "market_groups": [{
        "id": 1050,
        "gtm_container": "GTM-58SHVHZ",
        "consentFallback": [],
        "markets": [{
            "source": "_Required",
            "external_id": "unconfigured"
        }, {
            "source": "_Required",
            "external_id": "no_market_id"
        }]
    }],
    "apex_domains": [],
    "ignored_referrer_domains": ["shop.app", "paypal.com", "hooks.stripe.com", "afterpay.com", "apay-us.amazon.com", "payments.amazon.co.uk", "payments.amazon.com", "payments-eu.amazon.com", "payments.amazon.de", "payments.amazon.it", "klarna.com", "klarnapayments.com", "pay.google.com", "checkout.sezzle.com", "myshopify.com", "pay.shopify.com", "global-e.com", "payment.payone.com", "secure.payplug.com", "tabby.ai", "tamara.co", "paytr.com", "pend.ch", "sfy-payments.molops.net"],
    "shop_url": "crownandpaw.myshopify.com",
    "event_config": {
        "cart_reconcile": true,
        "cart_view": true,
        "checkout_complete": true,
        "collection_view": true,
        "product_add_to_cart": true,
        "product_add_to_cart_ajax": true,
        "product_remove_from_cart": true,
        "product_select": true,
        "product_view": true,
        "search_results_view": true,
        "user": true,
        "save_order_notes": true
    },
    "script_src_custom_pages": "https://shopify-gtm-suite.getelevar.com/getelevar/3.31.0/dl-custom-pages.js",
    "script_src_custom_pages_proxied": "/static/getelevar/3.31.0/dl-custom-pages.js",
    "script_src_app_theme_embed": "/a/elevar/static/getelevar/3.31.0/dl-app-embed-block.js",
    "script_src_web_pixel_lax_custom": "https://shopify-gtm-suite.getelevar.com/getelevar/3.31.0/dl-web-pixel-lax-custom.js",
    "script_src_web_pixel_strict_app": "/a/elevar/static/getelevar/3.31.0/dl-web-pixel-strict-app.js",
    "sources": {},
    "destinations": {}
};