(() => {
    var N = Object.create;
    var x = Object.defineProperty;
    var O = Object.getOwnPropertyDescriptor;
    var P = Object.getOwnPropertyNames;
    var g = Object.getPrototypeOf,
        A = Object.prototype.hasOwnProperty;
    var c = (r, e) => () => (r && (e = r(r = 0)), e);
    var D = (r, e) => () => (e || r((e = {
        exports: {}
    }).exports, e), e.exports);
    var U = (r, e, o, d) => {
        if (e && typeof e == "object" || typeof e == "function")
            for (let t of P(e)) !A.call(r, t) && t !== o && x(r, t, {
                get: () => e[t],
                enumerable: !(d = O(e, t)) || d.enumerable
            });
        return r
    };
    var _ = (r, e, o) => (o = r != null ? N(g(r)) : {}, U(e || !r || !r.__esModule ? x(o, "default", {
        value: r,
        enumerable: !0
    }) : o, r));
    var E = (r, e, o) => new Promise((d, t) => {
        var n = i => {
                try {
                    p(o.next(i))
                } catch (a) {
                    t(a)
                }
            },
            s = i => {
                try {
                    p(o.throw(i))
                } catch (a) {
                    t(a)
                }
            },
            p = i => i.done ? d(i.value) : Promise.resolve(i.value).then(n, s);
        p((o = o.apply(r, e)).next())
    });
    var f, y = c(() => {
        f = "WebPixel::Render"
    });
    var m, T = c(() => {
        y();
        m = r => shopify.extend(f, r)
    });
    var l = c(() => {
        T()
    });
    var u = c(() => {
        l()
    });
    var b = D(I => {
        "use strict";
        u();
        m(d => E(null, [d], function*({
            analytics: r,
            browser: e,
            settings: o
        }) {
            r.subscribe("product_viewed", t => {
                var p, i;
                let n = (i = (p = t == null ? void 0 : t.data) == null ? void 0 : p.productVariant) == null ? void 0 : i.product;
                if (!n) return;
                let s = o.baseURL + "?productId=" + n.id + "&storeIdentity=" + o.storeIdentity;
                e.sendBeacon(s)
            })
        }))
    });
    var W = _(b());
})();