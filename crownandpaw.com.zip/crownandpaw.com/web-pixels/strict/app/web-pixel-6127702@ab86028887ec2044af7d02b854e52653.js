(() => {
    var b = Object.create;
    var g = Object.defineProperty;
    var u = Object.getOwnPropertyDescriptor;
    var N = Object.getOwnPropertyNames;
    var O = Object.getPrototypeOf,
        v = Object.prototype.hasOwnProperty;
    var s = (t, e) => () => (t && (e = t(t = 0)), e);
    var w = (t, e) => () => (e || t((e = {
        exports: {}
    }).exports, e), e.exports);
    var A = (t, e, i, o) => {
        if (e && typeof e == "object" || typeof e == "function")
            for (let r of N(e)) !v.call(t, r) && r !== i && g(t, r, {
                get: () => e[r],
                enumerable: !(o = u(e, r)) || o.enumerable
            });
        return t
    };
    var C = (t, e, i) => (i = t != null ? b(O(t)) : {}, A(e || !t || !t.__esModule ? g(i, "default", {
        value: t,
        enumerable: !0
    }) : i, t));
    var l = (t, e, i) => new Promise((o, r) => {
        var p = n => {
                try {
                    c(i.next(n))
                } catch (f) {
                    r(f)
                }
            },
            S = n => {
                try {
                    c(i.throw(n))
                } catch (f) {
                    r(f)
                }
            },
            c = n => n.done ? o(n.value) : Promise.resolve(n.value).then(p, S);
        c((i = i.apply(t, e)).next())
    });
    var m, x = s(() => {
        m = "WebPixel::Render"
    });
    var a, d = s(() => {
        x();
        a = t => shopify.extend(m, t)
    });
    var y = s(() => {
        d()
    });
    var _ = s(() => {
        y()
    });
    var T = w(E => {
        "use strict";
        _();
        var P = t => l(null, null, function*() {
            let o = (yield
                    import (t.settings.config_url)).default,
                r = o.script_src_web_pixel_strict_app;
            if (!(o.consent_enabled && o.strict_consent_enabled) && r) {
                let {
                    handler: p
                } = yield
                import (r);
                yield p(t, o)
            }
        });
        a(t => void P(t))
    });
    var B = C(T());
})();