(() => {
    var Xl = Object.create;
    var ui = Object.defineProperty;
    var ql = Object.getOwnPropertyDescriptor;
    var Gl = Object.getOwnPropertyNames;
    var Kl = Object.getPrototypeOf,
        Ql = Object.prototype.hasOwnProperty;
    var u = (t, e) => () => (t && (e = t(t = 0)), e);
    var Zl = (t, e) => () => (e || t((e = {
            exports: {}
        }).exports, e), e.exports),
        w = (t, e) => {
            for (var o in e) ui(t, o, {
                get: e[o],
                enumerable: !0
            })
        },
        Jl = (t, e, o, r) => {
            if (e && typeof e == "object" || typeof e == "function")
                for (let i of Gl(e)) !Ql.call(t, i) && i !== o && ui(t, i, {
                    get: () => e[i],
                    enumerable: !(r = ql(e, i)) || r.enumerable
                });
            return t
        };
    var tc = (t, e, o) => (o = t != null ? Xl(Kl(t)) : {}, Jl(e || !t || !t.__esModule ? ui(o, "default", {
        value: t,
        enumerable: !0
    }) : o, t));
    var v = (t, e, o) => new Promise((r, i) => {
        var n = l => {
                try {
                    s(o.next(l))
                } catch (m) {
                    i(m)
                }
            },
            a = l => {
                try {
                    s(o.throw(l))
                } catch (m) {
                    i(m)
                }
            },
            s = l => l.done ? r(l.value) : Promise.resolve(l.value).then(n, a);
        s((o = o.apply(t, e)).next())
    });
    var rt = u(() => {});
    var C, f = u(() => {
        rt();
        C = (p => (p[p.Expire = 365] = "Expire", p[p.SessionExpire = 1] = "SessionExpire", p[p.CookieVersion = 2] = "CookieVersion", p[p.SessionTimeout = 30 * 6e4] = "SessionTimeout", p[p.CookieInterval = 1] = "CookieInterval", p[p.PingInterval = 1 * 6e4] = "PingInterval", p[p.PingTimeout = 5 * 6e4] = "PingTimeout", p[p.SummaryInterval = 100] = "SummaryInterval", p[p.ClickText = 25] = "ClickText", p[p.PayloadLimit = 128] = "PayloadLimit", p[p.PageLimit = 128] = "PageLimit", p[p.ShutdownLimit = 2 * 36e5] = "ShutdownLimit", p[p.RetryLimit = 1] = "RetryLimit", p[p.PlaybackBytesLimit = 10485760] = "PlaybackBytesLimit", p[p.CollectionLimit = 128] = "CollectionLimit", p[p.ClickPrecision = 32767] = "ClickPrecision", p[p.BoxPrecision = 100] = "BoxPrecision", p[p.ScriptErrorLimit = 5] = "ScriptErrorLimit", p[p.DimensionLimit = 256] = "DimensionLimit", p[p.WordLength = 5] = "WordLength", p[p.RestartDelay = 250] = "RestartDelay", p[p.CallStackDepth = 20] = "CallStackDepth", p[p.RatingScale = 100] = "RatingScale", p[p.ViewportIntersectionRatio = .05] = "ViewportIntersectionRatio", p[p.IntersectionRatio = .8] = "IntersectionRatio", p[p.MaxFirstPayloadBytes = 1048576] = "MaxFirstPayloadBytes", p[p.MegaByte = 1048576] = "MegaByte", p[p.UploadFactor = 3] = "UploadFactor", p[p.MinUploadDelay = 100] = "MinUploadDelay", p[p.MaxUploadDelay = 30 * 1e3] = "MaxUploadDelay", p[p.ExtractLimit = 1e4] = "ExtractLimit", p[p.ChecksumPrecision = 28] = "ChecksumPrecision", p[p.UploadTimeout = 15e3] = "UploadTimeout", p[p.LongTask = 30] = "LongTask", p))(C || {})
    });
    var oc, c, J = u(() => {
        rt();
        oc = {
            projectId: null,
            delay: 1 * 1e3,
            lean: !1,
            lite: !1,
            track: !0,
            content: !0,
            drop: [],
            mask: [],
            unmask: [],
            regions: [],
            cookies: [],
            fraud: !0,
            checksum: [],
            report: null,
            upload: null,
            fallback: null,
            upgrade: null,
            action: null,
            dob: null,
            delayDom: !1,
            throttleDom: !0,
            conversions: !1,
            includeSubdomains: !0
        }, c = oc
    });
    var ct = u(() => {});

    function _t(t, e, o, r = !1, i) {
        if (t) {
            if (e == "input" && (i === "checkbox" || i === "radio")) return t;
            switch (o) {
                case 0:
                    return t;
                case 1:
                    switch (e) {
                        case "*T":
                        case "value":
                        case "placeholder":
                        case "click":
                            return sc(t);
                        case "input":
                        case "change":
                            return Tn(t)
                    }
                    return t;
                case 2:
                case 3:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return r ? Sn(t) : qo(t);
                        case "src":
                        case "srcset":
                        case "title":
                        case "alt":
                            return o === 3 ? e === "src" && (t != null && t.startsWith("blob:")) ? "blob:" : "" : t;
                        case "value":
                        case "click":
                        case "input":
                        case "change":
                            return Tn(t);
                        case "placeholder":
                            return qo(t)
                    }
                    break;
                case 4:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return r ? Sn(t) : qo(t);
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("\u2022");
                        case "checksum":
                            return ""
                    }
                    break;
                case 5:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return Ke(t, "\u25AA", "\u25AB");
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("\u2022");
                        case "checksum":
                        case "src":
                        case "srcset":
                        case "alt":
                        case "title":
                            return ""
                    }
                    break
            }
        }
        return t
    }

    function Ee(t, e = !1, o = !1) {
        let r = t;
        if (e) r = "https://Electron";
        else {
            let i = c.drop;
            if (i && i.length > 0 && t && t.indexOf("?") > 0) {
                let [n, a] = t.split("?"), s = "*na*";
                r = n + "?" + a.split("&").map(l => i.some(m => l.indexOf(`${m}=`) === 0) ? `${l.split("=")[0]}=${s}` : l).join("&")
            }
        }
        return o && (r = r.substring(0, nc)), r
    }

    function Sn(t) {
        let e = t.trim();
        if (e.length > 0) {
            let o = e[0],
                r = t.indexOf(o),
                i = t.substr(0, r),
                n = t.substr(r + e.length);
            return `${i}${e.length.toString(36)}${n}`
        }
        return t
    }

    function qo(t) {
        return t.replace(ac, "\u2022")
    }

    function Ke(t, e, o) {
        return Dn(), t && t.replace(kn, e).replace(di, o)
    }

    function Tn(t) {
        let e = (Math.floor(t.length / 5) + 1) * 5,
            o = "";
        for (let r = 0; r < e; r++) o += r > 0 && r % 5 === 0 ? " " : "\u2022";
        return o
    }

    function Dn() {
        if (mi && di === null) try {
            di = new RegExp("\\p{N}", "gu"), kn = new RegExp("\\p{L}", "gu"), fi = new RegExp("\\p{Sc}", "gu")
        } catch (t) {
            mi = !1
        }
    }

    function sc(t) {
        let e = -1,
            o = 0,
            r = !1,
            i = !1,
            n = !1,
            a = null;
        Dn();
        for (let s = 0; s < t.length; s++) {
            let l = t.charCodeAt(s);
            if (r = r || l >= 48 && l <= 57, i = i || l === 64, n = l === 9 || l === 10 || l === 13 || l === 32, s === 0 || s === t.length - 1 || n) {
                if (r || i) {
                    a === null && (a = t.split(""));
                    let m = t.substring(e + 1, n ? s : s + 1);
                    mi && fi !== null ? m = m.match(fi) ? m : Ke(m, "\u25AA", "\u25AB") : m = qo(m), a.splice(e + 1 - o, m.length, m), o += m.length - 1
                }
                n && (r = !1, i = !1, e = s)
            }
        }
        return a ? a.join("") : t
    }
    var ac, nc, mi, di, kn, fi, Ne = u(() => {
        rt();
        f();
        ct();
        J();
        ac = /\S/gi, nc = 255, mi = !0, di = null, kn = null, fi = null
    });

    function En() {
        Qo = performance.now() + performance.timeOrigin
    }

    function h(t = null) {
        if (t) return Math.max(Math.round(new Date(t).getTime() - Qo), 0);
        let e = performance.now(),
            o = performance.timeOrigin;
        return Math.max(Math.round(e + o - Qo), 0)
    }

    function Nn() {
        Qo = 0
    }
    var Qo, k = u(() => {
        Qo = 0
    });
    var lc, Ie, Qe = u(() => {
        lc = "0.8.31", Ie = lc
    });

    function ut(t, e = null) {
        let o = 0,
            r = 5381,
            i = r;
        for (let n = 0; n < t.length; n += 2) {
            let a = t.charCodeAt(n);
            if (r = (r << 5) + r ^ a, n + 1 < t.length) {
                let s = t.charCodeAt(n + 1);
                i = (i << 5) + i ^ s
            }
        }
        return o = Math.abs(r + i * 11579), (e ? o % Math.pow(2, e) : o).toString(36)
    }
    var Ce = u(() => {});
    var ie = {};
    w(ie, {
        activity: () => Jo,
        compute: () => bi,
        reset: () => Je,
        start: () => cc,
        state: () => Zo,
        stop: () => uc,
        track: () => St,
        visibility: () => hi
    });

    function cc() {
        Ze = !1, Je()
    }

    function Je() {
        Ze && (Zo = {
            time: h(),
            event: 4,
            data: {
                visible: d.visible,
                docWidth: d.docWidth,
                docHeight: d.docHeight,
                screenWidth: d.screenWidth,
                screenHeight: d.screenHeight,
                scrollX: d.scrollX,
                scrollY: d.scrollY,
                pointerX: d.pointerX,
                pointerY: d.pointerY,
                activityTime: d.activityTime,
                scrollTime: d.scrollTime,
                pointerTime: d.pointerTime,
                moveX: d.moveX,
                moveY: d.moveY,
                moveTime: d.moveTime,
                downX: d.downX,
                downY: d.downY,
                downTime: d.downTime,
                upX: d.upX,
                upY: d.upY,
                upTime: d.upTime,
                pointerPrevX: d.pointerPrevX,
                pointerPrevY: d.pointerPrevY,
                pointerPrevTime: d.pointerPrevTime
            }
        }), d = d || {
            visible: 1,
            docWidth: 0,
            docHeight: 0,
            screenWidth: 0,
            screenHeight: 0,
            scrollX: 0,
            scrollY: 0,
            pointerX: 0,
            pointerY: 0,
            activityTime: 0,
            scrollTime: 0,
            pointerTime: void 0,
            moveX: void 0,
            moveY: void 0,
            moveTime: void 0,
            downX: void 0,
            downY: void 0,
            downTime: void 0,
            upX: void 0,
            upY: void 0,
            upTime: void 0,
            pointerPrevX: void 0,
            pointerPrevY: void 0,
            pointerPrevTime: void 0
        }
    }

    function St(t, e, o, r) {
        switch (t) {
            case 8:
                d.docWidth = e, d.docHeight = o;
                break;
            case 11:
                d.screenWidth = e, d.screenHeight = o;
                break;
            case 10:
                d.scrollX = e, d.scrollY = o, d.scrollTime = r;
                break;
            case 12:
                d.moveX = e, d.moveY = o, d.moveTime = r, d.pointerPrevX = d.pointerX, d.pointerPrevY = d.pointerY, d.pointerPrevTime = d.pointerTime, d.pointerX = e, d.pointerY = o, d.pointerTime = r;
                break;
            default:
                d.pointerPrevX = d.pointerX, d.pointerPrevY = d.pointerY, d.pointerPrevTime = d.pointerTime, d.pointerX = e, d.pointerY = o, d.pointerTime = r;
                break
        }
        Ze = !0
    }

    function Jo(t) {
        d.activityTime = t
    }

    function hi(t, e) {
        d.visible = e === "visible" ? 1 : 0, d.visible || Jo(t), Ze = !0
    }

    function bi() {
        Ze && D(4)
    }

    function uc() {
        Je()
    }
    var Zo, d, Ze, Pe = u(() => {
        f();
        k();
        j();
        Zo = null, d = null, Ze = !1
    });

    function Ae(t, e) {
        pt() && t && typeof t === "string" && t.length < 255 && (e && typeof e === "string" && e.length < 255 ? we = {
            key: t,
            value: e
        } : we = {
            value: t
        }, D(24))
    }
    var we, tr = u(() => {
        f();
        Mt();
        j();
        we = null
    });
    var Ti = {};
    w(Ti, {
        dynamicEvent: () => Si,
        register: () => vi,
        start: () => pc,
        stop: () => mc
    });

    function pc() {
        xi = !0
    }

    function mc() {
        yi.reverse().forEach(t => {
            try {
                t()
            } catch (e) {}
        }), yi = [], xi = !1
    }

    function vi(t) {
        xi && typeof t == "function" && yi.push(t)
    }

    function Si(t) {}
    var yi, xi, to = u(() => {
        yi = [], xi = !1
    });

    function Pn() {
        X = {}, q = {}, it(5)
    }

    function wn() {
        X = {}, q = {}
    }

    function it(t) {
        t in X || (X[t] = 0), t in q || (q[t] = 0), X[t]++, q[t]++
    }

    function mt(t, e) {
        e !== null && (t in X || (X[t] = 0), t in q || (q[t] = 0), X[t] += e, q[t] += e)
    }

    function U(t, e) {
        e !== null && isNaN(e) === !1 && (t in X || (X[t] = 0), (e > X[t] || X[t] === 0) && (q[t] = e, X[t] = e))
    }

    function An() {
        D(0)
    }

    function _n() {
        q = {}
    }
    var X, q, dt = u(() => {
        f();
        j();
        X = null, q = null
    });

    function R(t) {
        return function() {
            let e = performance.now();
            try {
                t.apply(this, arguments)
            } catch (r) {
                throw er(r)
            }
            let o = performance.now() - e;
            mt(4, o), o > 30 && (it(7), U(6, o), t.dn && V(9, 0, `${t.dn}-${o}`))
        }
    }
    var Tt = u(() => {
        f();
        or();
        dt();
        kt()
    });

    function z(t, e, o) {
        return globalThis.setTimeout(R(t), e, o)
    }

    function L(t) {
        return globalThis.clearTimeout(t)
    }
    var Lt = u(() => {
        Tt()
    });

    function Mn(t) {
        return v(this, null, function*() {
            try {
                if (dc) {
                    let o, e = new ReadableStream({
                        start(r) {
                            return v(this, null, function*() {
                                r.enqueue(t), r.close()
                            })
                        }
                    }).pipeThrough(new TextEncoderStream).pipeThrough(new window.CompressionStream("gzip"));
                    return new Uint8Array(yield fc(e))
                }
            } catch (e) {}
            return null
        })
    }

    function fc(t) {
        return v(this, null, function*() {
            let e = t.getReader(),
                o = [],
                r = !1,
                i = [];
            for (; !r;) {
                if ({
                        done: r,
                        value: i
                    } = yield e.read(), r) return o;
                o.push(...i)
            }
            return o
        })
    }
    var dc, Rn = u(() => {
        f();
        dc = !1
    });
    var ao = {};
    w(ao, {
        data: () => io,
        reset: () => ki,
        start: () => gc,
        stop: () => hc
    });

    function gc() {
        ir = C.PingInterval, rr = 0
    }

    function ki() {
        ro && L(ro), ro = z(On, ir), rr = h()
    }

    function On() {
        io = {
            gap: h() - rr
        }, D(25), io.gap < C.PingTimeout ? ro = z(On, ir) : Ln()
    }

    function hc() {
        L(ro), rr = 0, ir = 0
    }
    var io, rr, ir, ro, ar = u(() => {
        f();
        Mt();
        k();
        Lt();
        j();
        rr = 0, ir = 0, ro = null
    });
    var no = {};
    w(no, {
        compute: () => Ei,
        data: () => at,
        reset: () => Ni,
        start: () => bc,
        stop: () => yc,
        track: () => Di
    });

    function bc() {
        at = {}
    }

    function yc() {
        at = {}
    }

    function Di(t, e) {
        if (!(t in at)) at[t] = [
            [e, 0]
        ];
        else {
            let o = at[t],
                r = o[o.length - 1];
            e - r[0] > 100 ? at[t].push([e, 0]) : r[1] = e - r[0]
        }
    }

    function Ei() {
        D(36)
    }

    function Ni() {
        at = {}
    }
    var at, nr = u(() => {
        f();
        j();
        at = null
    });

    function Ci() {
        sr = {}, lr = [], so = null, Hn = null
    }

    function B(o) {
        return v(this, arguments, function*(t, e = 0) {
            for (let i of lr)
                if (i.task === t) return;
            let r = new Promise(i => {
                let n = e === 1 ? "unshift" : "push";
                lr[n]({
                    task: t,
                    resolve: i,
                    id: Dt()
                })
            });
            return so === null && Hn === null && Ii(), r
        })
    }

    function Ii() {
        let t = lr.shift();
        t && (so = t, t.task().then(() => {
            t.id === Dt() && (t.resolve(), so = null, Ii())
        }).catch(e => {
            t.id === Dt() && (e && V(0, 1, e.name, e.message, e.stack), so = null, Ii())
        }))
    }

    function cr(t) {
        sr[Un(t)] = {
            start: performance.now(),
            calls: 0,
            yield: 30
        }
    }

    function ur(t) {
        let e = performance.now(),
            o = Un(t),
            r = e - sr[o].start;
        mt(t.cost, r), it(5), sr[o].calls > 0 && mt(4, r)
    }

    function Un(t) {
        return `${t.id}.${t.cost}`
    }
    var sr, lr, so, Hn, G = u(() => {
        rt();
        f();
        tt();
        dt();
        kt();
        sr = {}, lr = [], so = null, Hn = null
    });
    var ne, Ut = u(() => {
        rt();
        ne = (s => (s[s.LookAhead = 500] = "LookAhead", s[s.InputLookAhead = 1e3] = "InputLookAhead", s[s.Distance = 20] = "Distance", s[s.ScrollInterval = 50] = "ScrollInterval", s[s.PointerInterval = 25] = "PointerInterval", s[s.Throttle = 25] = "Throttle", s[s.TimelineSpan = 2 * 1e3] = "TimelineSpan", s))(ne || {})
    });

    function lo(t, e) {
        let o = 0,
            r = null,
            i = null;

        function n(...a) {
            let s = performance.now(),
                l = s - o;
            if (o !== 0 && l < e) {
                if (i = a, r) return;
                r = setTimeout(() => {
                    o = performance.now(), t.apply(this, i), i = null, r = null
                }, e - l)
            } else o = s, t.apply(this, a)
        }
        return n.cleanup = function() {
            r && (clearTimeout(r), r = null, i = null)
        }, n
    }
    var Pi = u(() => {});

    function Wn() {
        wi = []
    }

    function mr(t, e, o) {
        c.fraud && t !== null && o && o.length >= 5 && (Wt = {
            id: t,
            target: e,
            checksum: ut(o, 28)
        }, wi.indexOf(Wt.checksum) < 0 && (wi.push(Wt.checksum), fr(41)))
    }
    var wi, Wt, co = u(() => {
        f();
        J();
        Ce();
        Ai();
        wi = []
    });

    function Bn(t) {
        let e = [],
            o = {},
            r = 0,
            i = null;
        for (let n = 0; n < t.length; n++)
            if (typeof t[n] === "string") {
                let a = t[n],
                    s = o[a] || -1;
                s >= 0 ? i ? i.push(s) : (i = [s], e.push(i), r++) : (i = null, e.push(a), o[a] = r++)
            } else i = null, e.push(t[n]), r++;
        return e
    }
    var Fn = u(() => {
        f()
    });
    var se, ft, uo = u(() => {
        se = (g => (g[g.ELEMENT_NODE = 1] = "ELEMENT_NODE", g[g.ATTRIBUTE_NODE = 2] = "ATTRIBUTE_NODE", g[g.TEXT_NODE = 3] = "TEXT_NODE", g[g.CDATA_SECTION_NODE = 4] = "CDATA_SECTION_NODE", g[g.ENTITY_REFERENCE_NODE = 5] = "ENTITY_REFERENCE_NODE", g[g.ENTITY_NODE = 6] = "ENTITY_NODE", g[g.PROCESSING_INSTRUCTION_NODE = 7] = "PROCESSING_INSTRUCTION_NODE", g[g.COMMENT_NODE = 8] = "COMMENT_NODE", g[g.DOCUMENT_NODE = 9] = "DOCUMENT_NODE", g[g.DOCUMENT_TYPE_NODE = 10] = "DOCUMENT_TYPE_NODE", g[g.DOCUMENT_FRAGMENT_NODE = 11] = "DOCUMENT_FRAGMENT_NODE", g[g.NOTATION_NODE = 12] = "NOTATION_NODE", g))(se || {}), ft = class {
            constructor(e, o = null) {
                this._childNodes = [];
                this._previousSibling = null;
                this._nextSibling = null;
                this._internalNode = e, this._parentNode = o
            }
            updateInternalNode(e) {
                this._internalNode = e
            }
            get serializationId() {
                return this._internalNode.serializationId
            }
            get nodeType() {
                return this._internalNode.nodeType
            }
            get tagName() {
                return this._internalNode.tagName
            }
            get textContent() {
                return this._internalNode.textContent.trim()
            }
            get attributes() {
                let e = {};
                return this._internalNode.attributes == null || Object.entries(this._internalNode.attributes).forEach(([o, r]) => {
                    o != null && r != null && (e[o.toString()] = r.toString())
                }), e
            }
            get childNodes() {
                return this._childNodes
            }
            get children() {
                var e;
                return (e = this._childNodes) == null ? void 0 : e.filter(o => o.nodeType === 1)
            }
            set previousSibling(e) {
                this._previousSibling = e
            }
            get previousSibling() {
                return this._previousSibling
            }
            set nextSibling(e) {
                this._nextSibling = e
            }
            get nextSibling() {
                return this._nextSibling
            }
            get parentNode() {
                return this._parentNode
            }
            set parentNode(e) {
                this._parentNode = e
            }
            get parentElement() {
                var e;
                return ((e = this._parentNode) == null ? void 0 : e.nodeType) === 1 ? this._parentNode : null
            }
            get ownerDocument() {
                var e;
                return ((e = this._parentNode) == null ? void 0 : e.nodeType) === 9 ? this._parentNode : this.parentElement.ownerDocument
            }
            hasAttribute(e) {
                return this.attributes && e in this.attributes
            }
            getAttribute(e) {
                return this.hasAttribute(e) ? this.attributes[e] : null
            }
            querySelector(e) {
                return e = e.trim().toLowerCase(), this.findSingle(o => o.matchSelectorSegment(e))
            }
            querySelectorAll(e) {
                return e = e.trim().toLowerCase(), this.findAll(o => o.matchSelectorSegment(e))
            }
            matchSelectorSegment(e) {
                var o, r, i, n, a;
                return e === "*" ? !0 : e.startsWith("#") ? ((r = (o = this.attributes) == null ? void 0 : o.id) == null ? void 0 : r.toLowerCase()) === e.substring(1) : e.startsWith(".") ? (n = (i = this.attributes) == null ? void 0 : i.class) == null ? void 0 : n.includes(e.substring(1)) : ((a = this.tagName) == null ? void 0 : a.toLowerCase()) === e
            }
            findSingle(e) {
                let o = [this];
                for (; o.length > 0;) {
                    let r = o.shift();
                    if (e(r)) return r;
                    o.push(...r.childNodes)
                }
                return null
            }
            findAll(e) {
                let o = [],
                    r = [this];
                for (; r.length > 0;) {
                    let i = r.shift();
                    e(i) && o.push(i), r.push(...i.childNodes)
                }
                return o
            }
            traverse(e) {
                let o = [this];
                for (; o.length > 0;) {
                    let r = o.shift();
                    e(r), o.push(...r.childNodes)
                }
            }
            toHTML(e = 0) {
                let o = " ".repeat(e);
                if (this.nodeType === 3) return `${o}${this.textContent}`;
                let r = "";
                r = `${o}<${this.tagName}
`;
                for (let [i, n] of Object.entries(this.attributes)) r += `${o}  ${i}="${n.trim()}"
`;
                return r += `${o}  shopify-serialization-id="${this.serializationId}"
`, r += `${o}>
`, this.childNodes.forEach(i => {
                    r += i.toHTML(e + 2), r += `
`
                }), r += `${o}</${this.tagName}>`, r
            }
            printHTML() {
                console.log(this.toHTML())
            }
        }
    });
    var po, mo, _i = u(() => {
        uo();
        po = class extends ft {
            constructor(e, o) {
                super(o, null), this._internalDocument = e
            }
            get title() {
                return this._internalDocument.title
            }
            get referrer() {
                return this._internalDocument.referrer
            }
            get characterSet() {
                return this._internalDocument.characterSet
            }
            get location() {
                return this._internalDocument.location
            }
            get ownerDocument() {
                return null
            }
            get doctype() {
                return this.findSingle(e => e.nodeType === 10)
            }
            get documentElement() {
                return this.findSingle(e => e.tagName === "HTML")
            }
            get body() {
                return this.findSingle(e => e.tagName === "BODY")
            }
            getElementById(e) {
                return this.findSingle(o => {
                    var r;
                    return ((r = o.attributes) == null ? void 0 : r.id) === e
                })
            }
            getElementsByTagName(e) {
                return this.findAll(o => o.tagName === e)
            }
            getElementsByClassName(e) {
                return this.findAll(o => {
                    var r, i;
                    return (i = (r = o.attributes) == null ? void 0 : r.class) == null ? void 0 : i.includes(e)
                })
            }
        }, mo = class extends ft {
            constructor(e, o = null) {
                super(e, o)
            }
            get name() {
                return this.getAttribute("name")
            }
            get publicId() {
                return this.getAttribute("publicId")
            }
            get systemId() {
                return this.getAttribute("systemId")
            }
        }
    });
    var Bt, fo, go, ho, Mi = u(() => {
        uo();
        Bt = class extends ft {
            constructor(e, o = null) {
                super(e, o)
            }
            get id() {
                var e;
                return (e = this.getAttribute("id")) != null ? e : ""
            }
            get className() {
                var e;
                return (e = this.getAttribute("class")) != null ? e : ""
            }
            get namespaceURI() {
                var o, r;
                let e = this.getAttribute("xmlns");
                return e || (this.tagName === "svg" ? "http://www.w3.org/2000/svg" : (r = (o = this.parentElement) == null ? void 0 : o.namespaceURI) != null ? r : "http://www.w3.org/1999/xhtml")
            }
            get clientWidth() {
                return Math.floor(this._internalNode.clientRect.width)
            }
            get clientHeight() {
                return Math.floor(this._internalNode.clientRect.height)
            }
            get scrollWidth() {
                return Math.floor(this._internalNode.scroll.width)
            }
            get scrollHeight() {
                return Math.floor(this._internalNode.scroll.height)
            }
            get offsetWidth() {
                return Math.floor(this._internalNode.clientRect.width)
            }
            get offsetHeight() {
                return Math.floor(this._internalNode.clientRect.width)
            }
            get innerHTML() {
                return this.childNodes.map(e => e.toHTML()).join(`
`)
            }
            get outerHTML() {
                return this.toHTML()
            }
        }, fo = class extends Bt {
            constructor(e, o = null) {
                super(e, o)
            }
            get textContent() {
                return this.childNodes.map(e => e.textContent).join(`\r
`)
            }
            get dataset() {
                let e = {};
                return Object.entries(this.attributes).forEach(([o, r]) => {
                    if (o.startsWith("data-")) {
                        let i = o.substring(5);
                        e[i] = r
                    }
                }), e
            }
        }, go = class extends Bt {
            constructor(e, o = null) {
                super(e, o)
            }
            get type() {
                let e = this.getAttribute("type");
                if (e && e !== "") return e;
                switch (this.tagName) {
                    case "INPUT":
                    case "TEXTAREA":
                        return "text";
                    case "SELECT":
                        return "select-one"
                }
                return null
            }
            get value() {
                return this.getAttribute("value")
            }
            get placeholder() {
                return this.getAttribute("placeholder")
            }
            get checked() {
                return this._internalNode.checked === !0
            }
        }, ho = class extends Bt {
            constructor(e, o = null) {
                super(e, o)
            }
            get src() {
                return this.getAttribute("src")
            }
            get srcset() {
                return this.getAttribute("srcset")
            }
            get alt() {
                return this.getAttribute("alt")
            }
            get width() {
                return parseFloat(this.getAttribute("width"))
            }
            get height() {
                return parseFloat(this.getAttribute("height"))
            }
            get sizes() {
                return this.getAttribute("sizes")
            }
            get loading() {
                return this.getAttribute("loading")
            }
        }
    });

    function zn(t) {
        return v(this, null, function*() {
            nt = t, K = t.init.context.window, le = t.init.context.window.screen, et = t.init.context.window.location, P = yield xc(), Ec()
        })
    }

    function $n() {
        zi(), gt = !0
    }

    function Vn() {
        gt = !1, zi()
    }

    function zi() {
        Ri = [], Oi = [], Li = [], Hi = [], Ui = [], Wi = [], Bi = [], Fi = []
    }

    function xc() {
        return new Promise(t => {
            nt.analytics.subscribe("advanced_dom_available", e => {
                t($i(e.data.root))
            })
        })
    }

    function $i(t, e = null) {
        let o = vc(t.node, e);
        Ft.set(t.node.serializationId, o), t.children.forEach(r => {
            o.childNodes.push($i(r, o))
        });
        for (let r = 1; r < o.childNodes.length; r++) o.childNodes[r - 1].nextSibling = o.childNodes[r], o.childNodes[r].previousSibling = o.childNodes[r - 1];
        return o
    }

    function vc(t, e) {
        if (t.nodeType === 9) return new po(nt.init.context.document, t);
        if (t.nodeType === 10) return new mo(t, e);
        if (t.nodeType === 1) switch (t.tagName) {
            case "STYLE":
                return new fo(t, e);
            case "INPUT":
            case "TEXTAREA":
            case "SELECT":
                return new go(t, e);
            case "IMG":
                return new ho(t, e);
            default:
                return new Bt(t, e)
        }
        return new ft(t, e)
    }

    function Sc(t, e) {
        for (let o = 0; o < t.length; o++) {
            if (Ft.has(t[o].node.serializationId)) continue;
            let r = Ft.get(t[o].parentSerializationId);
            if (r == null) {
                console.error("addDomNodes :: Parent not found in map:", t[o]);
                continue
            }
            let i = $i(t[o], r),
                n = Ft.get(t[o].prevSiblingSerializationId),
                a = n == null ? void 0 : n.nextSibling,
                s = r.childNodes.indexOf(n);
            s === -1 ? r.childNodes.push(i) : r.childNodes.splice(s + 1, 0, i), i.previousSibling = n, i.nextSibling = a, n && (n.nextSibling = i), a && (a.previousSibling = i), e.addedNodes.push(i)
        }
    }

    function Tc(t, e) {
        for (let o = 0; o < t.length; o++) {
            let r = Ft.get(t[o].serializationId);
            if (r == null) continue;
            let i = r.parentNode;
            if (i == null) {
                console.error("removeDomNodes :: Node has no parent:", t[o]);
                continue
            }
            Dc(r);
            let n = r.previousSibling,
                a = r.nextSibling,
                s = i.childNodes.indexOf(r);
            r.parentNode = null, s > -1 ? i.childNodes.splice(s, 1) : console.error("removeDomNodes :: Node not found in parent children list:", t[o]), n && (n.nextSibling = a), a && (a.previousSibling = n), e.removedNodes.push(r)
        }
    }

    function kc(t, e) {
        for (let o = 0; o < t.length; o++) {
            let r = Ft.get(t[o].serializationId);
            if (r == null) {
                console.error("modifyDomNodes :: Node not found in map:", t[o]);
                continue
            }
            r.updateInternalNode(t[o]), e.modifiedNodes.push(r)
        }
    }

    function Dc(t) {
        let e = [t];
        for (; e.length > 0;) {
            let o = e.shift();
            Ft.delete(o.serializationId), e.push(...o.childNodes)
        }
    }

    function Vi(t) {
        Ri.push(t)
    }

    function Yi(t) {
        Oi.push(t)
    }

    function ji(t) {
        Li.push(t)
    }

    function Xi(t) {
        Hi.push(t)
    }

    function qi(t) {
        Ui.push(t)
    }

    function bo(t) {
        Wi.push(t)
    }

    function Gi(t) {
        Bi.push(t)
    }

    function Ki(t) {
        Fi.push(t)
    }

    function Ec() {
        Nc(), Ic(), Cc(), Pc(), wc(), Ac(), _c(), Mc()
    }

    function Nc() {
        nt.analytics.subscribe("advanced_dom_changed", t => {
            let e = new gr;
            Sc(t.data.addedFragments, e), Tc(t.data.removedNodes, e), kc(t.data.modifiedNodes, e), gt && e.length > 0 && Ri.forEach(o => o(e))
        })
    }

    function Ic() {
        nt.analytics.subscribe("advanced_dom_window_resized", t => {
            K = globalThis.window = t.context.window, le = t.context.window.screen, et = t.context.window.location, gt && Oi.forEach(e => e())
        })
    }

    function Cc() {
        nt.analytics.subscribe("advanced_dom_mouse_moved", t => {
            gt && Li.forEach(e => e(t))
        })
    }

    function Pc() {
        nt.analytics.subscribe("advanced_dom_clicked", t => {
            gt && Hi.forEach(e => e(t))
        })
    }

    function wc() {
        nt.analytics.subscribe("advanced_dom_scrolled", t => {
            gt && Ui.forEach(e => e(t))
        })
    }

    function Ac() {
        nt.analytics.subscribe("advanced_dom_input_changed", t => {
            let e = Ft.get(t.data.node.serializationId);
            if (e == null) {
                console.error("observeInputChange :: Node not found in map:", t.data.node);
                return
            }
            e.updateInternalNode(t.data.node), gt && Wi.forEach(o => o(t))
        })
    }

    function _c() {
        nt.analytics.subscribe("advanced_dom_form_submitted", t => {
            gt && Bi.forEach(e => e(t))
        })
    }

    function Mc() {
        nt.analytics.subscribe("advanced_dom_clipboard", t => {
            gt && Fi.forEach(e => e(t))
        })
    }
    var nt, gt, Ri, Oi, Li, Hi, Ui, Wi, Bi, Fi, Ft, P, K, le, et, gr, Qi = u(() => {
        _i();
        Mi();
        uo();
        _i();
        Mi();
        uo();
        nt = null, gt = !0, Ri = [], Oi = [], Li = [], Hi = [], Ui = [], Wi = [], Bi = [], Fi = [], Ft = new Map, P = null, K = null;
        gr = class {
            constructor() {
                this.addedNodes = [];
                this.removedNodes = [];
                this.modifiedNodes = []
            }
            get length() {
                return this.addedNodes.length + this.removedNodes.length + this.modifiedNodes.length
            }
        }
    });
    var Me = {};
    w(Me, {
        init: () => Ji,
        start: () => ta,
        stop: () => ea
    });

    function Ji(t, e) {
        zt = t, Yn = e.projectId, jn = e.upload
    }

    function ta() {
        Zi = !0, zt.analytics.subscribe("search_submitted", t => {
            ce(t, 210)
        }), zt.analytics.subscribe("cart_viewed", t => {
            ce(t, 247)
        }), zt.analytics.subscribe("checkout_completed", t => {
            ce(t, 201)
        }), zt.analytics.subscribe("checkout_started", t => {
            ce(t, 207)
        }), zt.analytics.subscribe("product_added_to_cart", t => {
            ce(t, 204)
        }), zt.analytics.subscribe("product_removed_from_cart", t => {
            ce(t, 246)
        }), zt.analytics.subscribe("product_viewed", t => {
            ce(t, 245)
        })
    }

    function ea() {
        Zi = !1
    }

    function ce(t, e) {
        var a, s, l, m, y, T, g, _, M, W, $, ot, De, gn, hn, bn, yn, xn, vn;
        if (!Zi) return;
        let o, r;
        e === 204 || e === 246 ? (o = (m = (l = (s = (a = t.data) == null ? void 0 : a.cartLine) == null ? void 0 : s.merchandise) == null ? void 0 : l.product) == null ? void 0 : m.title.substring(0, yo), r = o = (_ = (g = (T = (y = t.data) == null ? void 0 : y.cartLine) == null ? void 0 : T.merchandise) == null ? void 0 : g.product) == null ? void 0 : _.url.substring(0, yo)) : e === 245 && (o = ($ = (W = (M = t.data) == null ? void 0 : M.productVariant) == null ? void 0 : W.product) == null ? void 0 : $.title.substring(0, yo), r = (gn = (De = (ot = t.data) == null ? void 0 : ot.productVariant) == null ? void 0 : De.product) == null ? void 0 : gn.url.substring(0, yo));
        let i = {
                time: h(t.timestamp),
                event: 49,
                data: {
                    type: e,
                    productTitle: o,
                    productUrl: r
                }
            },
            n = (vn = (xn = (yn = (bn = (hn = t.context) == null ? void 0 : hn.window) == null ? void 0 : bn.location) == null ? void 0 : yn.href) == null ? void 0 : xn.substring(0, yo)) != null ? vn : "";
        Uc(i, n)
    }

    function Uc(t, e) {
        return v(this, null, function*() {
            yield ue.refresh();
            let o = Bc(e),
                r = Wc(t),
                i = JSON.stringify(o),
                n = `[${[JSON.stringify(r)]}]`,
                a = `{"e":${i},"a":${n}}`,
                s = new XMLHttpRequest;
            s.open("POST", jn, !0), s.timeout = 15e3, s.withCredentials = !0, s.send(a)
        })
    }

    function Wc(t) {
        var o, r;
        let e = [t.time, t.event, t.data.type];
        return (o = t.data.productTitle) != null && o.length && e.push(t.data.productTitle), (r = t.data.productUrl) != null && r.length && e.push(t.data.productUrl), e
    }

    function Bc(t) {
        let e = xo(),
            o = hr();
        return [Ie, Hc, 0, 0, Yn, e.id, o.session, o.count - 1, 0, 0, 0, t]
    }
    var Hc, yo, zt, Yn, jn, Zi, Xn = u(() => {
        f();
        k();
        Qe();
        tt();
        I();
        Hc = 255, yo = 255, zt = null, Yn = null, jn = null, Zi = !1
    });
    var ue = {};
    w(ue, {
        fetchCookie: () => vo,
        getCookie: () => vr,
        getSessionStorage: () => yr,
        init: () => ia,
        refresh: () => aa,
        setCookie: () => xr,
        setSessionStorage: () => br
    });

    function ia(o) {
        return v(this, arguments, function*(t, e = []) {
            So = t.browser, qn = t.init.context.window, Gn = t.init.context.navigator, yield aa();
            for (let r of e) yield vo(r)
        })
    }

    function aa() {
        return v(this, null, function*() {
            yield Promise.all([Fc("_cltk"), vo("_clsk"), vo("_clck")])
        })
    }

    function br(t, e) {
        So.sessionStorage.setItem(t, e), oa[t] = e
    }

    function yr(t) {
        return oa[t]
    }

    function Fc(t) {
        return v(this, null, function*() {
            let e = yield So.sessionStorage.getItem(t);
            oa[t] = e
        })
    }

    function xr(t, e, o) {
        if (!Gn.cookieEnabled) return;
        let r = $c(e),
            i = new Date;
        i.setDate(i.getDate() + o);
        let n = i ? "expires=" + i.toUTCString() : "",
            a = "domain=." + qn.location.hostname,
            s = `${t}=${r};${n};path=/;${a}`;
        So.cookie.set(s), ra[t] = e
    }

    function vr(t) {
        return ra[t]
    }

    function vo(t) {
        return v(this, null, function*() {
            let e = yield So.cookie.get(t), o = zc(e);
            ra[t] = o
        })
    }

    function zc(t) {
        if (t) try {
            let e = decodeURIComponent(t);
            for (; e !== t;) t = e, e = decodeURIComponent(t);
            return e
        } catch (e) {
            return t
        }
        return null
    }

    function $c(t) {
        return encodeURIComponent(t)
    }
    var So, qn, Gn, oa, ra, na = u(() => {
        f();
        oa = {}, ra = {}
    });
    var Y = {};
    w(Y, {
        ShopifyDocument: () => po,
        ShopifyDocumentType: () => mo,
        ShopifyDomElement: () => Bt,
        ShopifyDomImageElement: () => ho,
        ShopifyDomInputElement: () => go,
        ShopifyDomMutationRecord: () => gr,
        ShopifyDomNode: () => ft,
        ShopifyDomNodeType: () => se,
        ShopifyDomStyleElement: () => fo,
        document: () => P,
        fetchCookie: () => vo,
        getCookie: () => vr,
        getSessionStorage: () => yr,
        init: () => sa,
        location: () => et,
        navigator: () => Et,
        refresh: () => aa,
        registerClickCallback: () => Xi,
        registerClipboardCallback: () => Ki,
        registerDomMutationCallback: () => Vi,
        registerFormSubmissionCallback: () => Gi,
        registerInputChangeCallback: () => bo,
        registerMouseMoveCallback: () => ji,
        registerScrollCallback: () => qi,
        registerWindowResizeCallback: () => Yi,
        reset: () => zi,
        screen: () => le,
        setCookie: () => xr,
        setSessionStorage: () => br,
        shopping: () => Me,
        start: () => Vc,
        stop: () => Yc,
        storage: () => ue,
        window: () => K
    });

    function sa(t, e) {
        return v(this, null, function*() {
            yield ia(t, e.cookies), yield Ji(t, e), yield zn(t), Et = t.init.context.navigator, globalThis.window = K, globalThis.document = P, globalThis.navigator = Et
        })
    }

    function Vc() {
        ta(), $n()
    }

    function Yc() {
        Vn(), ea()
    }
    var Et, I = u(() => {
        Qi();
        Xn();
        na();
        Qi();
        na()
    });

    function Kn() {
        pe = null
    }

    function Qn() {
        Kn(), To()
    }

    function To() {
        let t = P.body,
            e = P.documentElement,
            o = t ? t.clientWidth : null,
            r = t ? t.scrollWidth : null,
            i = t ? t.offsetWidth : null,
            n = e ? e.clientWidth : null,
            a = e ? e.scrollWidth : null,
            s = e ? e.offsetWidth : null,
            l = Math.max(o, r, i, n, a, s),
            m = t ? t.clientHeight : null,
            y = t ? t.scrollHeight : null,
            T = t ? t.offsetHeight : null,
            g = e ? e.clientHeight : null,
            _ = e ? e.scrollHeight : null,
            M = e ? e.offsetHeight : null,
            W = Math.max(m, y, T, g, _, M);
        (pe === null || l !== pe.width || W !== pe.height) && l !== null && W !== null && (pe = {
            width: l,
            height: W
        }, $t(8))
    }

    function Zn() {
        Kn()
    }
    var pe, ko = u(() => {
        f();
        Do();
        I()
    });

    function $t(t, e = null) {
        var i;
        let o = e || h(),
            r = [o, t];
        switch (t) {
            case 8:
                let n = pe;
                r.push(n.width), r.push(n.height), St(t, n.width, n.height), x(r);
                break;
            case 7:
                for (let s of Re) r = [s.time, 7], r.push(s.data.id), r.push(s.data.interaction), r.push(s.data.visibility), r.push(s.data.name), x(r, !1);
                Tr();
                break;
            case 5:
            case 6:
                let a = la();
                if (a.length > 0) {
                    for (let s of a) {
                        let l = s.data,
                            m = s.metadata.active,
                            y = s.metadata.suspend,
                            T = s.metadata.privacy,
                            g = jc(s),
                            _ = m ? ["tag", "attributes", "value"] : ["tag"];
                        for (let M of _)
                            if (l[M] || l[M] === "") switch (M) {
                                case "tag":
                                    let W = (i = s.metadata) == null ? void 0 : i.size,
                                        $ = g ? -1 : 1;
                                    r.push(s.id * $), s.parent && m && (r.push(s.parent), s.previous && r.push(s.previous)), r.push(y ? "*M" : l[M]), W && W.length === 2 && r.push(`#${Jn(W[0])}.${Jn(W[1])}`);
                                    break;
                                case "attributes":
                                    for (let ot in l[M]) l[M][ot] !== void 0 && r.push(Xc(ot, l[M][ot], T));
                                    break;
                                case "value":
                                    mr(s.metadata.fraud, s.id, l[M]), r.push(_t(l[M], l.tag, T, g));
                                    break
                            }
                    }
                    t === 6 && Jo(o), x(Bn(r), !c.lean)
                }
                break
        }
    }

    function jc(t) {
        let e = t.metadata.privacy;
        return t.data.tag === "*T" && !(e === 0 || e === 1)
    }

    function Jn(t) {
        return t.toString(36)
    }

    function Xc(t, e, o) {
        return `${t}=${_t(e,t.indexOf("data-")===0?"data-":t,o)}`
    }
    var Do = u(() => {
        rt();
        f();
        ct();
        J();
        Ne();
        k();
        Pe();
        Fn();
        Nt();
        co();
        ko();
        ht();
        Vt()
    });

    function es() {
        Tr(), de = new WeakMap, Yt = {}, Eo = []
    }

    function ca(t, e) {
        de.has(t.serializationId) === !1 && de.set(t.serializationId, e)
    }

    function ua(t) {
        return de && de.has(t.serializationId)
    }

    function os(t, e) {
        let o = jt(t),
            r = t in Yt ? Yt[t] : {
                id: t,
                visibility: 0,
                interaction: 16,
                name: de.get(o.serializationId)
            },
            i = 16;
        switch (e) {
            case 9:
                i = 20;
                break;
            case 27:
                i = 30;
                break
        }
        qc(o, r, i, r.visibility)
    }

    function Oe() {
        let t = [];
        for (let e of Eo) {
            let o = It(e.node);
            o ? (e.state.data.id = o, Yt[o] = e.state.data, Re.push(e.state)) : t.push(e)
        }
        Eo = t, Re.length > 0 && $t(7)
    }

    function qc(t, e, o, r) {
        let i = o > e.interaction || r > e.visibility;
        e.interaction = o > e.interaction ? o : e.interaction, e.visibility = r > e.visibility ? r : e.visibility, e.id ? (e.id in Yt && i || !(e.id in Yt)) && (Yt[e.id] = e, Re.push(ts(e))) : Eo.push({
            node: t,
            state: ts(e)
        })
    }

    function ts(t) {
        return {
            time: h(),
            data: {
                id: t.id,
                interaction: t.interaction,
                visibility: t.visibility,
                name: t.name
            }
        }
    }

    function Tr() {
        Re = []
    }

    function rs() {
        Tr(), de = null, Yt = {}, Eo = []
    }
    var Re, de, Yt, Eo, Vt = u(() => {
        f();
        ct();
        k();
        ht();
        Do();
        Re = [], de = null, Yt = {}, Eo = []
    });

    function as() {
        Le = {}
    }

    function pa(t, e) {
        let o = t.attributes,
            r = t.prefix ? t.prefix[e] : null,
            i = e === 0 ? `~${t.position-1}` : `:nth-of-type(${t.position})`;
        switch (t.tag) {
            case "STYLE":
            case "TITLE":
            case "LINK":
            case "META":
            case "*T":
            case "*D":
                return "";
            case "HTML":
                return "HTML";
            default:
                if (r === null) return "";
                r = `${r}>`, t.tag = t.tag.indexOf("svg:") === 0 ? t.tag.substr("svg:".length) : t.tag;
                let n = `${r}${t.tag}${i}`,
                    a = "id" in o && o.id.length > 0 ? o.id : null,
                    s = t.tag !== "BODY" && "class" in o && o.class.length > 0 ? o.class.trim().split(/\s+/).filter(l => is(l)).join(".") : null;
                if (s && s.length > 0)
                    if (e === 0) {
                        let l = `${Zc(r)}${t.tag}.${s}`;
                        l in Le || (Le[l] = []), Le[l].indexOf(t.id) < 0 && Le[l].push(t.id), n = `${l}~${Le[l].indexOf(t.id)}`
                    } else n = `${r}${t.tag}.${s}${i}`;
                return n = a && is(a) ? `${Qc(r)}#${a}` : n, n
        }
    }

    function Qc(t) {
        let e = t.lastIndexOf("*S"),
            o = t.lastIndexOf("iframe:HTML"),
            r = Math.max(e, o);
        return r < 0 ? "" : t.substring(0, t.indexOf(">", r) + 1)
    }

    function Zc(t) {
        let e = t.split(">");
        for (let o = 0; o < e.length; o++) {
            let r = e[o].indexOf("~"),
                i = e[o].indexOf(".");
            e[o] = e[o].substring(0, i > 0 ? i : r > 0 ? r : e[o].length)
        }
        return e.join(">")
    }

    function is(t) {
        if (!t || Kc.some(e => t.toLowerCase().indexOf(e) >= 0)) return !1;
        for (let e = 0; e < t.length; e++) {
            let o = t.charCodeAt(e);
            if (o >= 48 && o <= 57) return !1
        }
        return !0
    }
    var Kc, Le, ns = u(() => {
        f();
        ct();
        Kc = "load,active,fixed,visible,focus,show,collaps,animat".split(","), Le = {}
    });
    var Q = {};
    w(Q, {
        add: () => eu,
        get: () => su,
        getId: () => It,
        getNode: () => jt,
        getValue: () => ba,
        has: () => Co,
        hashText: () => he,
        lookup: () => ds,
        parse: () => He,
        start: () => ga,
        stop: () => ha,
        update: () => ou,
        updates: () => la
    });

    function ga() {
        ps(), He(P, !0)
    }

    function ha() {
        ps()
    }

    function ps() {
        E = [], fe = [], kr = {}, fa = [], ma = [], ss = "address,password,contact".split(","), ls = "password,secret,pass,social,ssn,code,hidden".split(","), cs = "radio,checkbox,range,button,reset,submit".split(","), us = "INPUT,SELECT,TEXTAREA".split(","), ge = new Map, No = new Map, Io = new Map, as()
    }

    function He(t, e = !1) {
        try {
            e && c.unmask.forEach(o => {
                o.indexOf("!") < 0 ? ma.push(o) : fa.push(o.substring(1))
            }), c.regions.forEach(o => t.querySelectorAll(o[1]).forEach(r => ca(r, `${o[0]}`))), c.mask.forEach(o => t.querySelectorAll(o).forEach(r => No.set(r.serializationId, 3))), c.checksum.forEach(o => t.querySelectorAll(o[1]).forEach(r => Io.set(r.serializationId, o[0]))), ma.forEach(o => t.querySelectorAll(o).forEach(r => No.set(r.serializationId, 0)))
        } catch (o) {
            console.error("Error parsing selectors:", o), V(5, 1, o ? o.name : null)
        }
    }

    function It(t, e = !1) {
        if (t == null) return null;
        let o = t.serializationId;
        return ge.has(o) || e ? o : null
    }

    function eu(t, e, o, r) {
        let i = e ? It(e) : null,
            n = It(t, !0),
            a = gs(t),
            s = null,
            l = ua(t) ? n : null,
            m = Io.has(n) ? Io.get(n) : null,
            y = c.content ? 1 : 3;
        i >= 0 && E[i] && (s = E[i], s.children.push(n), l = l === null ? s.region : l, m = m === null ? s.metadata.fraud : m, y = s.metadata.privacy), o.attributes && "data-clarity-region" in o.attributes && (ca(t, o.attributes["data-clarity-region"]), l = n), ge.set(n, t), E[n] = {
            id: n,
            parent: i,
            previous: a,
            children: [],
            data: o,
            selector: null,
            hash: null,
            region: l,
            metadata: {
                active: !0,
                suspend: !1,
                privacy: y,
                position: null,
                fraud: m,
                size: null
            }
        }, ru(t, E[n], s), ms(E[n]), ya(n, r)
    }

    function ou(t, e, o, r) {
        let i = It(t),
            n = e ? It(e) : null,
            a = gs(t),
            s = !1,
            l = !1;
        if (i in E) {
            let m = E[i];
            if (m.metadata.active = !0, m.previous !== a && (s = !0, m.previous = a), m.parent !== n) {
                s = !0;
                let y = m.parent;
                if (m.parent = n, n !== null && n >= 0) {
                    let T = a === null ? 0 : E[n].children.indexOf(a) + 1;
                    E[n].children.splice(T, 0, i), m.region = ua(t) ? i : E[n].region
                } else lu(i, r);
                if (y !== null && y >= 0) {
                    let T = E[y].children.indexOf(i);
                    T >= 0 && E[y].children.splice(T, 1)
                }
                l = !0
            }
            for (let y in o) au(m.data, o, y) && (s = !0, m.data[y] = o[y]);
            ms(m), ya(i, r, s, l)
        }
    }

    function ru(t, e, o) {
        var l;
        let r = e.data,
            i = e.metadata,
            n = i.privacy,
            a = r.attributes || {},
            s = r.tag.toUpperCase();
        switch (!0) {
            case us.indexOf(s) >= 0:
                let m = a.type,
                    y = "",
                    T = ["class", "style"];
                Object.keys(a).filter($ => !T.includes($)).forEach($ => {
                    var ot;
                    y += (ot = a[$]) == null ? void 0 : ot.toLowerCase()
                });
                let g = ls.some($ => y.indexOf($) >= 0);
                i.privacy = s === "INPUT" && cs.indexOf(m) >= 0 ? n : g ? 4 : 2;
                break;
            case "data-clarity-mask" in a:
                i.privacy = 3;
                break;
            case "data-clarity-unmask" in a:
                i.privacy = 0;
                break;
            case No.has(t.serializationId):
                i.privacy = No.get(t.serializationId);
                break;
            case Io.has(t.serializationId):
                i.privacy = 2;
                break;
            case s === "*T":
                let _ = o && o.data ? o.data.tag : "",
                    M = o && o.selector ? o.selector[1] : "",
                    W = ["STYLE", "TITLE", "svg:style"];
                i.privacy = W.includes(_) || fa.some($ => M.indexOf($) >= 0) ? 0 : n;
                break;
            case n === 1:
                i.privacy = iu(a.class, ss, i);
                break;
            case s === "IMG":
                (l = a.src) != null && l.startsWith("blob:") && (i.privacy = 3);
                break
        }
    }

    function iu(t, e, o) {
        return t && e.some(r => t.indexOf(r) >= 0) ? 2 : o.privacy
    }

    function au(t, e, o) {
        if (typeof t[o] == "object" && typeof e[o] == "object") {
            for (let r in t[o])
                if (t[o][r] !== e[o][r]) return !0;
            for (let r in e[o])
                if (e[o][r] !== t[o][r]) return !0;
            return !1
        }
        return t[o] !== e[o]
    }

    function nu(t, e) {
        e.metadata.position = 1;
        let o = t ? t.children.indexOf(e.id) : -1;
        for (; o-- > 0;) {
            let r = E[t.children[o]];
            if (e.data.tag === r.data.tag) {
                e.metadata.position = r.metadata.position + 1;
                break
            }
        }
        return e.metadata.position
    }

    function ms(t) {
        let e = t.parent && t.parent in E ? E[t.parent] : null,
            o = e ? e.selector : null,
            r = t.data,
            i = nu(e, t),
            n = {
                id: t.id,
                tag: r.tag,
                prefix: o,
                position: i,
                attributes: r.attributes
            };
        t.selector = [pa(n, 0), pa(n, 1)], t.hash = t.selector.map(a => a ? ut(a) : null), t.hash.forEach(a => kr[a] = t.id)
    }

    function he(t) {
        let e = ds(t),
            o = jt(e);
        return o !== null && o.textContent !== null ? o.textContent.substr(0, 25) : ""
    }

    function jt(t) {
        return ge.has(t) ? ge.get(t) : null
    }

    function ba(t) {
        return t in E ? E[t] : null
    }

    function su(t) {
        let e = It(t);
        return e in E ? E[e] : null
    }

    function ds(t) {
        return t in kr ? kr[t] : null
    }

    function Co(t) {
        return ge.has(t.serializationId)
    }

    function la() {
        let t = [];
        for (let e of fe) e in E && t.push(E[e]);
        return fe = [], t
    }

    function lu(t, e) {
        if (t in E) {
            let o = E[t];
            o.metadata.active = !1, o.parent = null, ya(t, e), fs(t)
        }
    }

    function fs(t) {
        ge.delete(t);
        let e = t in E ? E[t] : null;
        if (e && e.children)
            for (let o of e.children) fs(o)
    }

    function gs(t) {
        let e = null;
        for (; e === null && t.previousSibling;) e = It(t.previousSibling), t = t.previousSibling;
        return e
    }

    function ya(t, e, o = !0, r = !1) {
        if (c.lean && c.lite) return;
        let i = fe.indexOf(t);
        i >= 0 && e === 1 && r ? (fe.splice(i, 1), fe.push(t)) : i === -1 && o && fe.push(t)
    }
    var ge, E, fe, kr, fa, ma, ss, ls, cs, us, No, Io, ht = u(() => {
        rt();
        f();
        ct();
        J();
        Ce();
        kt();
        Vt();
        ns();
        I();
        ge = null, E = [], fe = [], kr = {}, fa = [], ma = [], ss = [], ls = [], cs = [], us = [], No = null, Io = null
    });

    function Z(t, e, o = null) {
        let r = {
            id: 0,
            hash: null,
            privacy: 2
        };
        if (t == null) return r;
        let i = ba(t);
        return i == null || (r.id = i.id, r.hash = i.hash, r.privacy = i.metadata.privacy, i.region && os(i.region, e), i.metadata.fraud && mr(i.metadata.fraud, i.id, o || i.data.value)), r
    }
    var xa = u(() => {
        rt();
        co();
        ht();
        Vt()
    });

    function hs() {
        Er(), bo(cu)
    }

    function cu(t) {
        let e = jt(t.data.node.serializationId);
        if (e == null) return;
        let o = e.type,
            r = e.value,
            i = c.fraud && r && r.length >= 5 && "password,secret,pass,social,ssn,code,hidden".indexOf(o) === -1 ? ut(r, 28) : "";
        Dr.push({
            time: h(t.timestamp),
            event: 42,
            data: {
                target: e.serializationId,
                type: o,
                value: r,
                checksum: i
            }
        }), B(A.bind(this, 42))
    }

    function Er() {
        Dr = []
    }

    function bs() {
        Er()
    }
    var Dr, va = u(() => {
        f();
        ct();
        J();
        Ce();
        G();
        k();
        ht();
        I();
        st();
        Dr = []
    });

    function xs() {
        Ir(), Xi(mu)
    }

    function mu(t) {
        let e = t.data,
            o = Math.round(e.pageX),
            r = Math.round(e.pageY),
            i = e.node,
            n = fu(i),
            a = n ? Math.max(Math.floor((o - n.x) / n.w * 32767), 0) : 0,
            s = n ? Math.max(Math.floor((r - n.y) / n.h * 32767), 0) : 0;
        o !== null && r !== null && (Nr.push({
            time: h(t.timestamp),
            event: 9,
            data: {
                target: i.serializationId,
                x: o,
                y: r,
                eX: a,
                eY: s,
                button: i.tagName.toLowerCase() === "button" ? i.serializationId : 0,
                reaction: du(i),
                context: gu(i),
                text: "",
                link: i.attributes.href ? i.attributes.href : null,
                hash: null,
                trust: 1,
                isFullText: 0
            }
        }), B(A.bind(this, 9)))
    }

    function du(t) {
        if (t.nodeType === 1) {
            let e = t.tagName.toLowerCase();
            if (pu.indexOf(e) >= 0) return 0
        }
        return 1
    }

    function fu(t) {
        let {
            x: e,
            y: o,
            height: r,
            width: i
        } = t.clientRect;
        return i > 0 && r > 0 ? {
            x: Math.floor(e + K.pageXOffset),
            y: Math.floor(o + K.pageYOffset),
            w: Math.floor(i),
            h: Math.floor(r)
        } : null
    }

    function gu(t) {
        var e, o;
        if ((e = t == null ? void 0 : t.attributes) != null && e.target) switch ((o = t == null ? void 0 : t.attributes) == null ? void 0 : o.target) {
            case "_blank":
                return 1;
            case "_parent":
                return 2;
            case "_top":
                return 3
        }
        return 0
    }

    function Ir() {
        Nr = []
    }

    function vs() {
        Ir()
    }
    var pu, Nr, Sa = u(() => {
        f();
        Ut();
        G();
        k();
        I();
        I();
        st();
        pu = ["input", "textarea", "radio", "button", "canvas", "select"], Nr = []
    });

    function Ts() {
        Pr(), Ki(hu)
    }

    function hu(t) {
        let e = null;
        switch (t.data.action) {
            case "cut":
                e = 0;
                break;
            case "copy":
                e = 1;
                break;
            case "paste":
                e = 2;
                break
        }
        Cr.push({
            time: h(t.timestamp),
            event: 38,
            data: {
                target: t.data.node.serializationId,
                action: e
            }
        }), B(A.bind(this, 38))
    }

    function Pr() {
        Cr = []
    }

    function ks() {
        Pr()
    }
    var Cr, Ta = u(() => {
        f();
        Ut();
        G();
        k();
        I();
        st();
        Cr = []
    });

    function Es() {
        wr(), bo(yu)
    }

    function yu(t) {
        let e = jt(t.data.node.serializationId);
        if (e == null) return;
        let o = e.value;
        bu.includes(e.type) && (o = e.checked ? "true" : "false");
        let r = {
            target: e.serializationId,
            type: e.type,
            value: o,
            trust: 1
        };
        Xt.length > 0 && Xt[Xt.length - 1].data.target === r.target && Xt.pop(), Xt.push({
            time: h(t.timestamp),
            event: 27,
            data: r
        }), L(ka), ka = z(xu, 1e3, 27)
    }

    function xu(t) {
        B(A.bind(this, t))
    }

    function wr() {
        Xt = []
    }

    function Ns() {
        L(ka), wr()
    }
    var bu, ka, Xt, Da = u(() => {
        f();
        Ut();
        G();
        k();
        Lt();
        ht();
        I();
        st();
        bu = ["checkbox", "radio"], ka = null, Xt = []
    });

    function Cs() {
        Na(), ji(vu)
    }

    function vu(t) {
        let e = t.data.pageX,
            o = t.data.pageY;
        if (e == null || o == null) return;
        let r = {
            time: h(t.timestamp),
            event: 12,
            data: {
                target: t.data.node.serializationId,
                x: e,
                y: o
            }
        };
        lt.length > 0 && Su(lt[lt.length - 1], r) && lt.pop(), lt.push(r), L(Ea), Ea = z(Ps, 500, r.event)
    }

    function Ps(t) {
        B(A.bind(this, t))
    }

    function Na() {
        lt = []
    }

    function ws() {
        L(Ea), lt.length > 0 && Ps(lt[lt.length - 1].event)
    }

    function Su(t, e) {
        let o = t.data.x - e.data.x,
            r = t.data.y - e.data.y,
            i = Math.sqrt(o * o + r * r),
            n = e.time - t.time;
        return e.event === t.event && e.data.target === t.data.target && i < 20 && n < 25
    }
    var lt, Ea, Ia = u(() => {
        f();
        Ut();
        G();
        k();
        Lt();
        I();
        st();
        lt = [], Ea = null
    });

    function Ms() {
        Pa = !1, Yi(_s), Rs()
    }

    function Rs() {
        let t = P.documentElement;
        Ar = {
            width: t && "clientWidth" in t ? Math.min(t.clientWidth, K.innerWidth) : K.innerWidth,
            height: t && "clientHeight" in t ? Math.min(t.clientHeight, K.innerHeight) : K.innerHeight
        }, Pa ? (L(Ca), Ca = z(Tu, 500, 11)) : (A(11), Pa = !0)
    }

    function Tu(t) {
        B(A.bind(this, t))
    }

    function wa() {
        Ar = null, L(Ca), _s.cleanup()
    }

    function Os() {
        wa()
    }
    var Ar, Ca, Pa, _s, Aa = u(() => {
        f();
        Ut();
        G();
        Pi();
        Lt();
        I();
        I();
        st();
        Ca = null, Pa = !1, _s = lo(Rs, 500)
    });

    function Hs() {
        Mr(), Gi(ku)
    }

    function ku(t) {
        _r.push({
            time: h(t.timestamp),
            event: 39,
            data: {
                target: t.data.node.serializationId
            }
        }), B(A.bind(this, 39))
    }

    function Mr() {
        _r = []
    }

    function Us() {
        Mr()
    }
    var _r, _a = u(() => {
        f();
        G();
        k();
        I();
        st();
        _r = []
    });

    function Bs() {
        Po = [], Rr()
    }

    function Rr() {
        wo = []
    }

    function Fs(t, e, o, r, i, n = 1, a = 0) {
        Po.push({
            time: t,
            event: 22,
            data: {
                type: e,
                hash: o,
                x: r,
                y: i,
                reaction: n,
                context: a
            }
        }), St(e, r, i, t)
    }

    function zs() {
        if (!b) return;
        wo = [];
        let t = [],
            e = (b.start || 0) + (b.duration || 0),
            o = Math.max(e - ne.TimelineSpan, 0);
        for (let r of Po) r.time >= o && (r.time <= e && wo.push(r), t.push(r));
        Po = t, A(22)
    }

    function $s() {
        Po = [], Rr()
    }
    var Po, wo, Or = u(() => {
        f();
        Ut();
        Pe();
        We();
        st();
        Po = [], wo = []
    });

    function Vs() {
        Du()
    }

    function Du() {
        Lr = {
            visible: "visible"
        }, A(28, h())
    }

    function Ra() {
        Lr = null
    }

    function Ys() {
        Ra()
    }
    var Lr, Oa = u(() => {
        f();
        k();
        st()
    });

    function A(t, e = null) {
        return v(this, null, function*() {
            let o = e || h(),
                r = [o, t];
            switch (t) {
                case 13:
                case 14:
                case 12:
                case 15:
                case 16:
                case 17:
                case 18:
                case 19:
                case 20:
                    for (let a of lt) {
                        let s = Z(a.data.target, a.event);
                        s.id > 0 && (r = [a.time, a.event], r.push(s.id), r.push(a.data.x), r.push(a.data.y), a.data.id !== void 0 && (r.push(a.data.id), a.data.isPrimary !== void 0 && r.push(a.data.isPrimary.toString())), x(r), St(a.event, a.data.x, a.data.y, a.time))
                    }
                    Na();
                    break;
                case 9:
                case 48:
                    for (let a of Nr) {
                        let s = Z(a.data.target, a.event, a.data.text);
                        r = [a.time, a.event];
                        let l = s.hash ? s.hash.join(".") : "";
                        r.push(s.id), r.push(a.data.x), r.push(a.data.y), r.push(a.data.eX), r.push(a.data.eY), r.push(a.data.button), r.push(a.data.reaction), r.push(a.data.context), r.push(_t(a.data.text, "click", s.privacy)), r.push(Ee(a.data.link)), r.push(l), r.push(a.data.trust), r.push(a.data.isFullText), x(r), Fs(a.time, a.event, l, a.data.x, a.data.y, a.data.reaction, a.data.context)
                    }
                    Ir();
                    break;
                case 38:
                    for (let a of Cr) {
                        r = [a.time, a.event];
                        let s = Z(a.data.target, a.event);
                        s.id > 0 && (r.push(s.id), r.push(a.data.action), x(r))
                    }
                    Pr();
                    break;
                case 11:
                    let i = Ar;
                    r.push(i.width), r.push(i.height), St(t, i.width, i.height), wa(), x(r);
                    break;
                case 27:
                    for (let a of Xt) {
                        let s = Z(a.data.target, a.event, a.data.value);
                        r = [a.time, a.event], r.push(s.id), r.push(_t(a.data.value, "input", s.privacy, !1, a.data.type)), r.push(a.data.trust), x(r)
                    }
                    wr();
                    break;
                case 10:
                    for (let a of Ct) {
                        let s = Z(a.data.target, a.event),
                            l = Z(a.data.top, a.event),
                            m = Z(a.data.bottom, a.event),
                            y = l != null && l.hash ? l.hash.join(".") : "",
                            T = m != null && m.hash ? m.hash.join(".") : "";
                        s.id > 0 && (r = [a.time, a.event], r.push(s.id), r.push(a.data.x), r.push(a.data.y), r.push(y), r.push(T), x(r), St(a.event, a.data.x, a.data.y, a.time))
                    }
                    Xs();
                    break;
                case 42:
                    for (let a of Dr) {
                        r = [a.time, a.event];
                        let s = Z(a.data.target, a.event);
                        s.id > 0 && (r = [a.time, a.event], r.push(s.id), r.push(a.data.type), r.push(_t(a.data.value, "change", s.privacy)), r.push(_t(a.data.checksum, "checksum", s.privacy)), x(r))
                    }
                    Er();
                    break;
                case 39:
                    for (let a of _r) {
                        r = [a.time, a.event];
                        let s = Z(a.data.target, a.event);
                        s.id > 0 && (r.push(s.id), x(r))
                    }
                    Mr();
                    break;
                case 22:
                    for (let a of wo) r = [a.time, a.event], r.push(a.data.type), r.push(a.data.hash), r.push(a.data.x), r.push(a.data.y), r.push(a.data.reaction), r.push(a.data.context), x(r, !1);
                    Rr();
                    break;
                case 28:
                    let n = Lr;
                    r.push(n.visible), x(r), hi(o, n.visible), Ra();
                    break
            }
        })
    }
    var st = u(() => {
        f();
        Ne();
        k();
        Pe();
        Nt();
        va();
        Sa();
        Ta();
        Da();
        Ia();
        Aa();
        Hr();
        _a();
        Or();
        Oa();
        xa()
    });

    function qs() {
        Ct = [], Gs(), qi(Ks)
    }

    function Gs(t = null) {
        var y, T, g, _;
        let e = (y = t == null ? void 0 : t.context) == null ? void 0 : y.window,
            o = (T = t == null ? void 0 : t.data) == null ? void 0 : T.node;
        if (!o) return;
        let r = (o == null ? void 0 : o.nodeType) === 9 ? Math.round(e.pageXOffset) : Math.round((g = o == null ? void 0 : o.scroll) == null ? void 0 : g.x),
            i = (o == null ? void 0 : o.nodeType) === 9 ? Math.round(e.pageYOffset) : Math.round((_ = o == null ? void 0 : o.scroll) == null ? void 0 : _.y),
            n = o == null ? void 0 : o.serializationId,
            a = o == null ? void 0 : o.serializationId,
            s = {
                time: h(t == null ? void 0 : t.timestamp),
                event: 10,
                data: {
                    target: o == null ? void 0 : o.serializationId,
                    x: r,
                    y: i,
                    top: n,
                    bottom: a
                }
            };
        if (t === null && r === 0 && i === 0 || r === null || i === null) {
            Ao = n, _o = a;
            return
        }
        let l = Ct.length,
            m = l > 1 ? Ct[l - 2] : null;
        m && Nu(m, s) && Ct.pop(), Ct.push(s), L(Ha), Ha = z(Eu, 500, 10)
    }

    function Xs() {
        Ct = [], Ao = null, _o = null
    }

    function Eu(t) {
        B(A.bind(this, t))
    }

    function Nu(t, e) {
        let o = t.data.x - e.data.x,
            r = t.data.y - e.data.y;
        return o * o + r * r < 400 && e.time - t.time < 50
    }

    function Qs() {
        var t, e;
        if (Ao) {
            let o = Z(Ao, null);
            N(31, (t = o == null ? void 0 : o.hash) == null ? void 0 : t.join("."))
        }
        if (_o) {
            let o = Z(_o, null);
            N(32, (e = o == null ? void 0 : o.hash) == null ? void 0 : e.join("."))
        }
    }

    function Zs() {
        L(Ha), Ks.cleanup(), Ct = [], Ao = null, _o = null
    }
    var Ct, Ao, _o, Ha, Ks, Hr = u(() => {
        f();
        Ut();
        G();
        Pi();
        k();
        Lt();
        qt();
        xa();
        I();
        I();
        st();
        Ct = [], Ao = null, _o = null, Ha = null;
        Ks = lo(Gs, 25)
    });

    function Wr(t, e) {
        var a;
        if (e === 2 && Co(t) === !1) return;
        e !== 0 && t.nodeType === 3 && ((a = t.parentNode) == null ? void 0 : a.tagName) === "STYLE" && (t = t.parentNode);
        let r = Co(t) === !1 ? "add" : "update",
            i = t.parentElement;
        switch (t.nodeType) {
            case 10:
                let s = t,
                    m = {
                        name: s.name ? s.name : "HTML",
                        publicId: s.publicId,
                        systemId: s.systemId
                    },
                    y = {
                        tag: "*D",
                        attributes: m
                    };
                Q[r](t, i, y, e);
                break;
            case 9:
                He(t);
                break;
            case 3:
                if (r === "update" || i && Co(i) && i.tagName !== "STYLE" && i.tagName !== "NOSCRIPT") {
                    let M = {
                        tag: "*T",
                        value: t.textContent
                    };
                    Q[r](t, i, M, e)
                }
                break;
            case 1:
                let T = t,
                    g = T.tagName,
                    _ = Pu(T);
                switch (T.namespaceURI === "http://www.w3.org/2000/svg" && (g = "svg:" + g), g) {
                    case "NOSCRIPT":
                        let M = {
                            tag: g,
                            attributes: {},
                            value: ""
                        };
                        Q[r](t, i, M, e);
                        break;
                    case "META":
                        var n = "property" in _ ? "property" : "name" in _ ? "name" : null;
                        if (n && "content" in _) {
                            let De = _.content;
                            switch (_[n]) {
                                case "og:title":
                                    N(20, De);
                                    break;
                                case "og:type":
                                    N(19, De);
                                    break;
                                case "generator":
                                    N(21, De);
                                    break
                            }
                        }
                        break;
                    case "HEAD":
                        let W = {
                            tag: g,
                            attributes: _
                        };
                        W.attributes["*B"] = et.protocol + "//" + et.host + et.pathname, Q[r](t, i, W, e);
                        break;
                    case "STYLE":
                        let $ = {
                            tag: g,
                            attributes: _,
                            value: Cu(T)
                        };
                        Q[r](t, i, $, e);
                        break;
                    default:
                        let ot = {
                            tag: g,
                            attributes: _
                        };
                        Q[r](t, i, ot, e);
                        break
                }
                break;
            default:
                break
        }
    }

    function Cu(t) {
        return t.textContent ? t.textContent.trim() : ""
    }

    function Pu(t) {
        let e = {},
            o = t.attributes;
        return o && Object.entries(o).forEach(([r, i]) => {
            Iu.indexOf(r) < 0 && (e[r] = i)
        }), t.tagName === "INPUT" && !("value" in e) && t.value && (e.value = t.value), e
    }
    var Iu, Ua = u(() => {
        f();
        ct();
        qt();
        I();
        ht();
        Iu = ["title", "alt", "onload", "onfocus", "onerror", "data-drupal-form-submit-last", "aria-label"]
    });

    function Br(t, e) {
        let o = [t];
        for (; o.length > 0;) {
            let r = o.shift();
            for (let i = 0; i < r.childNodes.length; i++) o.push(r.childNodes[i]);
            Wr(r, e)
        }
    }
    var Wa = u(() => {
        Ua()
    });

    function Fr() {
        wu(), R(To)(), R(Oe)(), R(Qs)()
    }

    function wu() {
        let t = h(),
            e = {
                id: Dt(),
                cost: 3
            };
        cr(e), Br(P, 0), $t(5, t), ur(e)
    }
    var Ba = u(() => {
        f();
        ct();
        Tt();
        G();
        k();
        tt();
        Hr();
        ko();
        Do();
        Vt();
        Wa();
        I()
    });
    var zr = {};
    w(zr, {
        data: () => Be,
        start: () => Au,
        stop: () => _u,
        upgrade: () => Fe
    });

    function Au() {
        !c.lean && c.upgrade && c.upgrade("Config"), Be = null
    }

    function Fe(t) {
        pt() && c.lean && (c.lean = !1, Be = {
            key: t
        }, ze(), $e(), c.upgrade && c.upgrade(t), D(3), c.lite && Fr())
    }

    function _u() {
        Be = null
    }
    var Be, $r = u(() => {
        f();
        Mt();
        J();
        j();
        tt();
        Ba();
        Be = null
    });
    var Yr = {};
    w(Yr, {
        compute: () => Fa,
        data: () => Gt,
        identify: () => Vr,
        reset: () => Mo,
        set: () => Kt,
        start: () => Mu,
        stop: () => Ru
    });

    function Mu() {
        Mo()
    }

    function Kt(t, e) {
        let o = typeof e === "string" ? [e] : e;
        Ve(t, o)
    }

    function Vr(t, e = null, o = null, r = null) {
        return v(this, null, function*() {
            let i = {
                userId: yield Lu(t), userHint: r || Ou(t)
            };
            return Ve("userId", [i.userId]), Ve("userHint", [i.userHint]), Ve("userType", [Hu(t)]), e && (Ve("sessionId", [e]), i.sessionId = e), o && (Ve("pageId", [o]), i.pageId = o), i
        })
    }

    function Ve(t, e) {
        if (pt() && t && e && typeof t === "string" && t.length < 255) {
            let o = t in Gt ? Gt[t] : [];
            for (let r = 0; r < e.length; r++) typeof e[r] === "string" && e[r].length < 255 && o.push(e[r]);
            Gt[t] = o
        }
    }

    function Fa() {
        D(34)
    }

    function Mo() {
        Gt = {}
    }

    function Ru() {
        Mo()
    }

    function Ou(t) {
        return t && t.length >= 5 ? `${t.substring(0,2)}${Ke(t.substring(2),"*","*")}` : Ke(t, "*", "*")
    }

    function Lu(t) {
        return v(this, null, function*() {
            try {
                if (crypto && t) {
                    let e = yield crypto.subtle.digest("SHA-256", new TextEncoder().encode(t));
                    return Array.prototype.map.call(new Uint8Array(e), o => ("00" + o.toString(16)).slice(-2)).join("")
                } else return ""
            } catch (e) {
                return ""
            }
        })
    }

    function Hu(t) {
        return t && t.indexOf("@") > 0 ? "email" : "string"
    }
    var Gt, Ro = u(() => {
        f();
        Mt();
        Ne();
        j();
        Gt = null
    });

    function Uu(t) {
        try {
            return JSON.parse(t)
        } catch (e) {
            return []
        }
    }

    function el(t) {
        try {
            if (!tl) return;
            Uu(t).forEach(o => {
                tl(o)
            })
        } catch (e) {}
    }
    var tl, za = u(() => {
        tl = null
    });

    function il() {
        Pn(), rl.forEach(t => R(t.start)())
    }

    function al() {
        rl.slice().reverse().forEach(t => R(t.stop)()), wn()
    }

    function nl() {
        Fa(), bi(), ja(), An(), Ei(), Ya(), Va(), Xa()
    }
    var rl, Oo = u(() => {
        Tt();
        Pe();
        Xr();
        qt();
        We();
        jr();
        Ho();
        tt();
        dt();
        ar();
        nr();
        $r();
        Nt();
        Ro();
        tr();
        tt();
        dt();
        za();
        $r();
        Ro();
        rl = [ie, Pt, Yr, Ye, no, Uo, Ht, Ue, $a, ao, zr, Lo]
    });
    var $a = {};
    w($a, {
        queue: () => x,
        start: () => Wu,
        stop: () => Bu,
        track: () => wt
    });

    function Wu() {
        Qr = !0, Fo = 0, Zt = 0, Qt = !1, Kr = 0, Wo = [], Bo = [], be = {}, wt = null
    }

    function x(t, e = !0) {
        if (!Qr) return;
        let o = h(),
            r = t.length > 1 ? t[1] : null,
            i = JSON.stringify(t);
        switch (c.lean ? !Qt && Zt + i.length > 10485760 && (V(10, 0), Qt = !0) : Qt = !1, r) {
            case 5:
                if (Qt) break;
                Fo += i.length;
            case 37:
            case 6:
            case 43:
            case 45:
            case 46:
                if (Qt) break;
                Zt += i.length, Wo.push(i);
                break;
            default:
                Bo.push(i);
                break
        }
        it(25);
        let n = $u();
        o - Kr > n * 2 && (L(je), je = null), e && je === null && (r !== 25 && ki(), je = z(cl, n), Kr = o, Ka(Zt))
    }

    function Bu() {
        L(je), cl(!0), Fo = 0, Zt = 0, Qt = !1, Kr = 0, Wo = [], Bo = [], be = {}, wt = null, Qr = !1
    }

    function cl(t = !1) {
        return v(this, null, function*() {
            if (!Qr) return;
            je = null;
            let e = c.lean === !1 && Zt > 0 && (Zt < 1048576 || b.sequence > 0);
            e && U(1, 1), Oe(), zs(), nl();
            let o = t === !0;
            if (!b) return;
            let r = JSON.stringify(Qa(o)),
                i = `[${Bo.join()}]`,
                n = e ? `[${Wo.join()}]` : "",
                s = Fu({
                    e: r,
                    a: i,
                    p: n
                }),
                l = o ? null : yield Mn(s);
            mt(2, l ? l.length : s.length), qa(s, l, b.sequence), Bo = [], e && (Wo = [], Zt = 0, Fo = 0, Qt = !1)
        })
    }

    function Fu(t) {
        return t.p.length > 0 ? `{"e":${t.e},"a":${t.a},"p":${t.p}}` : `{"e":${t.e},"a":${t.a}}`
    }

    function qa(t, e, o) {
        if (typeof c.upload === "string") {
            let r = c.upload;
            if (!1 === !1) {
                o in be ? be[o].attempts++ : be[o] = {
                    data: t,
                    attempts: 1
                };
                let n = new XMLHttpRequest;
                n.open("POST", r, !0), n.timeout = 15e3, n.ontimeout = () => {
                    er(new Error(`Timeout : ${r}`))
                }, o !== null && (n.onreadystatechange = () => {
                    R(zu)(n, o)
                }), n.withCredentials = !0, e ? (n.setRequestHeader("Accept", "application/x-clarity-gzip"), n.send(e)) : n.send(t)
            }
        } else if (c.upload) {
            let r = c.upload;
            r(t), ul(o)
        }
    }

    function zu(t, e) {
        var o = be[e];
        t && t.readyState === 4 && o && ((t.status < 200 || t.status > 208) && o.attempts <= 1 ? t.status >= 400 && t.status < 500 ? Jt(6) : (t.status === 0 && (c.upload = c.fallback ? c.fallback : c.upload), wt = {
            sequence: e,
            attempts: o.attempts,
            status: t.status
        }, D(2), qa(o.data, null, e)) : (wt = {
            sequence: e,
            attempts: o.attempts,
            status: t.status
        }, o.attempts > 1 && D(2), t.status === 200 && t.responseText && Vu(t.responseText), t.status === 0 && (qa(o.data, null, e), Jt(3)), t.status >= 200 && t.status <= 208 && ul(e), delete be[e]))
    }

    function ul(t) {
        t === 1 && ($e(), ze())
    }

    function $u() {
        let t = c.lean === !1 && Fo > 0 ? 100 : b.sequence * c.delay;
        return typeof c.upload === "string" ? Math.max(Math.min(t, C.MaxUploadDelay), 100) : c.delay
    }

    function Vu(t) {
        let e = t && t.length > 0 ? t.split(`
`) : [];
        for (var o of e) {
            let r = o && o.length > 0 ? o.split(/ (.*)/) : [""];
            switch (r[0]) {
                case "END":
                    Jt(6);
                    break;
                case "UPGRADE":
                    Fe("Auto");
                    break;
                case "ACTION":
                    c.action && r.length > 1 && c.action(r[1]);
                    break;
                case "EXTRACT":
                    r.length > 1 && Ga(r[1]);
                    break;
                case "SIGNAL":
                    r.length > 1 && el(r[1]);
                    break;
                case "MODULE":
                    r.length > 1 && Si(r[1]);
                    break;
                case "SNAPSHOT":
                    c.lean = !1;
                    break
            }
        }
    }
    var Fo, Zt, Wo, Bo, je, be, Qr, Kr, Qt, wt, Nt = u(() => {
        f();
        ye();
        J();
        to();
        Tt();
        or();
        k();
        Lt();
        Rn();
        j();
        We();
        jr();
        Oo();
        Ho();
        tt();
        dt();
        ar();
        za();
        kt();
        Or();
        Vt();
        Fo = 0, Zt = 0, je = null, Kr = 0, Qt = !1
    });

    function fr(t) {
        return v(this, null, function*() {
            let e = [h(), t];
            switch (t) {
                case 33:
                    te && (e.push(te.code), e.push(te.name), e.push(te.message), e.push(te.stack), e.push(te.severity), x(e, !1));
                    break;
                case 41:
                    Wt && (e.push(Wt.id), e.push(Wt.target), e.push(Wt.checksum), x(e, !1));
                    break
            }
        })
    }
    var Ai = u(() => {
        f();
        k();
        Nt();
        co();
        kt()
    });

    function pl() {
        xe = {}
    }

    function V(t, e, o = null, r = null, i = null) {
        let n = o ? `${o}|${r}` : "";
        t in xe && xe[t].indexOf(n) >= 0 || (te = {
            code: t,
            name: o,
            message: r,
            stack: i,
            severity: e
        }, t in xe ? xe[t].push(n) : xe[t] = [n], fr(33))
    }

    function ml() {
        xe = {}
    }
    var xe, te, kt = u(() => {
        f();
        Ai();
        xe = {}
    });
    var Lo = {};
    w(Lo, {
        clone: () => fl,
        compute: () => Va,
        data: () => At,
        keys: () => Xe,
        reset: () => $o,
        start: () => Yu,
        stop: () => ju,
        trigger: () => Ga,
        update: () => Zr
    });

    function Yu() {
        $o()
    }

    function Ga(t) {
        try {
            var e = t && t.length > 0 ? t.split(/ (.*)/) : [""],
                o = e[0].split(/\|(.*)/),
                r = parseInt(o[0]),
                i = o.length > 1 ? o[1] : "",
                n = e.length > 1 ? JSON.parse(e[1]) : {};
            Jr[r] = {}, Za[r] = {}, ti[r] = {}, Ja[r] = i;
            for (var a in n) {
                let s = parseInt(a),
                    l = n[a],
                    m = 2;
                switch (l.startsWith("~") ? m = 0 : l.startsWith("!") && (m = 4), m) {
                    case 0:
                        let y = l.slice(1);
                        Jr[r][s] = Xu(y);
                        break;
                    case 2:
                        Za[r][s] = l;
                        break;
                    case 4:
                        let T = l.slice(1);
                        ti[r][s] = T;
                        break
                }
            }
        } catch (s) {
            V(8, 1, s ? s.name : null)
        }
    }

    function fl(t) {
        return JSON.parse(JSON.stringify(t))
    }

    function Va() {
        try {
            for (let t in Jr) {
                let e = parseInt(t);
                if (Ja[e] == "" || document.querySelector(Ja[e])) {
                    let o = Jr[e];
                    for (let n in o) {
                        let a = parseInt(n),
                            s = qu(tn(fl(o[a])));
                        s && Zr(e, a, s)
                    }
                    let r = Za[e];
                    for (let n in r) {
                        let a = !1,
                            s = parseInt(n),
                            l = r[s];
                        l.startsWith("@") && (a = !0, l = l.slice(1));
                        let m = document.querySelectorAll(l);
                        if (m) {
                            let y = Array.from(m).map(T => T.textContent).join("<SEP>");
                            Zr(e, s, (a ? ut(y).trim() : y).slice(0, 1e4))
                        }
                    }
                    let i = ti[e];
                    for (let n in i) {
                        let a = parseInt(n),
                            s = he(i[a]).trim().slice(0, 1e4);
                        Zr(e, a, s)
                    }
                }
            }
            Xe.size > 0 && D(40)
        } catch (t) {
            V(5, 1, t ? t.name : null)
        }
    }

    function $o() {
        Xe.clear()
    }

    function Zr(t, e, o) {
        var r = !1;
        t in At || (At[t] = {}, r = !0), !Gu(ti[t]) && (!(e in At[t]) || At[t][e] != o) && (r = !0), At[t][e] = o, r && Xe.add(t)
    }

    function ju() {
        $o()
    }

    function Xu(t) {
        let e = [],
            o = t.split(".");
        for (; o.length > 0;) {
            let r = o.shift(),
                i = r.indexOf("["),
                n = r.indexOf("{"),
                a = r.indexOf("}");
            e.push({
                name: i > 0 ? r.slice(0, i) : n > 0 ? r.slice(0, n) : r,
                type: i > 0 ? 1 : n > 0 ? 2 : 3,
                condition: n > 0 ? r.slice(n + 1, a) : null
            })
        }
        return e
    }

    function tn(t, e = window) {
        if (t.length == 0) return e;
        let o = t.shift(),
            r;
        if (e && e[o.name]) {
            let n = e[o.name];
            if (o.type !== 1 && dl(n, o.condition)) r = tn(t, n);
            else if (Array.isArray(n)) {
                let a = [];
                for (var i of n)
                    if (dl(i, o.condition)) {
                        let s = tn(t, i);
                        s && a.push(s)
                    }
                r = a
            }
            return r
        }
        return null
    }

    function qu(t) {
        return t && JSON.stringify(t).slice(0, 1e4)
    }

    function dl(t, e) {
        if (e) {
            let o = e.split(":");
            return o.length > 1 ? t[o[0]] == o[1] : t[o[0]]
        }
        return !0
    }

    function Gu(t) {
        return Object.keys(t).length == 0
    }
    var At, Xe, Jr, Za, ti, Ja, jr = u(() => {
        rt();
        f();
        ye();
        Ce();
        kt();
        j();
        At = {}, Xe = new Set, Jr = {}, Za = {}, ti = {}, Ja = {}
    });

    function D(t) {
        let o = [h(), t];
        switch (t) {
            case 4:
                {
                    let r = Zo;r && r.data && (o = [r.time, r.event], o.push(r.data.visible), o.push(r.data.docWidth), o.push(r.data.docHeight), o.push(r.data.screenWidth), o.push(r.data.screenHeight), o.push(r.data.scrollX), o.push(r.data.scrollY), o.push(r.data.pointerX), o.push(r.data.pointerY), o.push(r.data.activityTime), o.push(r.data.scrollTime), o.push(r.data.pointerTime), o.push(r.data.moveX), o.push(r.data.moveY), o.push(r.data.moveTime), o.push(r.data.downX), o.push(r.data.downY), o.push(r.data.downTime), o.push(r.data.upX), o.push(r.data.upY), o.push(r.data.upTime), o.push(r.data.pointerPrevX), o.push(r.data.pointerPrevY), o.push(r.data.pointerPrevTime), x(o, !1)),
                    Je();
                    break
                }
            case 25:
                o.push(io.gap), x(o);
                break;
            case 35:
                o.push(xt.check), x(o, !1);
                break;
            case 3:
                o.push(Be.key), x(o);
                break;
            case 2:
                o.push(wt.sequence), o.push(wt.attempts), o.push(wt.status), x(o, !1);
                break;
            case 24:
                we.key && o.push(we.key), o.push(we.value), x(o);
                break;
            case 34:
                {
                    let r = Object.keys(Gt);
                    if (r.length > 0) {
                        for (let i of r) o.push(i), o.push(Gt[i]);
                        Mo(), x(o, !1)
                    }
                    break
                }
            case 0:
                {
                    let r = Object.keys(q);
                    if (r.length > 0) {
                        for (let i of r) {
                            let n = parseInt(i, 10);
                            o.push(n), o.push(Math.round(q[i]))
                        }
                        _n(), x(o, !1)
                    }
                    break
                }
            case 1:
                {
                    let r = Object.keys(yt);
                    if (r.length > 0) {
                        for (let i of r) {
                            let n = parseInt(i, 10);
                            o.push(n), o.push(yt[i])
                        }
                        en(), x(o, !1)
                    }
                    break
                }
            case 36:
                {
                    let r = Object.keys(at);
                    if (r.length > 0) {
                        for (let i of r) {
                            let n = parseInt(i, 10);
                            o.push(n), o.push([].concat(...at[i]))
                        }
                        Ni(), x(o, !1)
                    }
                    break
                }
            case 40:
                {
                    Xe.forEach(i => {
                        o.push(i);
                        let n = [];
                        for (let a in At[i]) {
                            let s = parseInt(a, 10);
                            n.push(s), n.push(At[i][a])
                        }
                        o.push(n)
                    }),
                    $o(),
                    x(o, !1);
                    break
                }
            case 47:
                o.push(ve.source), o.push(ve.ad_Storage), o.push(ve.analytics_Storage), x(o, !1);
                break
        }
    }
    var j = u(() => {
        f();
        k();
        Pe();
        Xr();
        tr();
        qt();
        jr();
        Ho();
        dt();
        ar();
        nr();
        $r();
        Ro();
        Nt()
    });
    var Ye = {};
    w(Ye, {
        check: () => Ka,
        compute: () => Ya,
        data: () => xt,
        start: () => Ku,
        stop: () => Qu,
        trigger: () => Jt
    });

    function Ku() {
        xt = {
            check: 0
        }
    }

    function Ka(t) {
        if (xt.check === 0) {
            let e = xt.check;
            e = b.sequence >= 128 ? 1 : e, e = b.pageNum >= 128 ? 7 : e, e = h() > C.ShutdownLimit ? 2 : e, e = t > 10485760 ? 2 : e, e !== xt.check && Jt(e)
        }
    }

    function Jt(t) {
        xt.check = t, t !== 5 && (on(), qe())
    }

    function Ya() {
        xt.check !== 0 && D(35)
    }

    function Qu() {
        xt = null
    }
    var xt, Ho = u(() => {
        f();
        ye();
        k();
        We();
        tt();
        j()
    });
    var Pt = {};
    w(Pt, {
        compute: () => ja,
        data: () => ee,
        log: () => N,
        reset: () => en,
        start: () => Zu,
        stop: () => Ju,
        updates: () => yt
    });

    function Zu() {
        ee = {}, yt = {}, Vo = !1
    }

    function Ju() {
        ee = {}, yt = {}, Vo = !1
    }

    function N(t, e) {
        if (e && (e = `${e}`, t in ee || (ee[t] = []), ee[t].indexOf(e) < 0)) {
            if (ee[t].length > 128) {
                Vo || (Vo = !0, Jt(5));
                return
            }
            ee[t].push(e), t in yt || (yt[t] = []), yt[t].push(e)
        }
    }

    function ja() {
        D(1)
    }

    function en() {
        yt = {}, Vo = !1
    }
    var ee, yt, Vo, qt = u(() => {
        f();
        Ho();
        j();
        ee = null, yt = null, Vo = !1
    });
    var Uo = {};
    w(Uo, {
        compute: () => Xa,
        config: () => rn,
        consent: () => oi,
        data: () => ve,
        start: () => ep,
        stop: () => op,
        trackConsentv2: () => an
    });

    function ep() {
        var t, e;
        ei = !0, (e = (t = window.google_tag_data) == null ? void 0 : t.ics) != null && e.addListener && window.google_tag_data.ics.addListener(["ad_storage", "analytics_storage"], rp)
    }

    function op() {
        ei = !0
    }

    function rp() {
        var i;
        let t = (i = window.google_tag_data) == null ? void 0 : i.ics;
        if (!(t != null && t.getConsentState)) return;
        let e = t.getConsentState("analytics_storage"),
            o = t.getConsentState("ad_storage"),
            r = ip({
                ad_Storage: o,
                analytics_Storage: e
            });
        bt(r, 2)
    }

    function ip(t) {
        return {
            ad_Storage: t.ad_Storage === 1 ? "granted" : "denied",
            analytics_Storage: t.analytics_Storage === 1 ? "granted" : "denied"
        }
    }

    function rn(t) {
        gl(t.analytics_Storage ? 1 : 0), ve = t
    }

    function oi() {
        gl(2)
    }

    function gl(t) {
        N(36, t.toString())
    }

    function an(t) {
        ve = t, D(47)
    }

    function Xa() {
        ei && (D(47), ei = !1)
    }
    var ve, ei, Xr = u(() => {
        f();
        qt();
        j();
        tt();
        ve = null, ei = !0
    });
    var Ht = {};
    w(Ht, {
        callback: () => ze,
        callbacks: () => Se,
        clear: () => on,
        consent: () => Gr,
        consentv2: () => bt,
        data: () => F,
        electron: () => ri,
        id: () => Dt,
        metadata: () => qr,
        save: () => $e,
        session: () => hr,
        shortid: () => Yo,
        start: () => np,
        stop: () => sp,
        user: () => xo
    });

    function np() {
        var l, m, y;
        let t = Et && "userAgent" in Et ? Et.userAgent : "",
            e = (y = typeof Intl != "undefined" && ((m = (l = Intl == null ? void 0 : Intl.DateTimeFormat()) == null ? void 0 : l.resolvedOptions()) == null ? void 0 : m.timeZone)) != null ? y : "",
            o = new Date().getTimezoneOffset().toString(),
            r = P && P.title ? P.title : "";
        ri = t.indexOf("Electron") > 0 ? 1 : 0;
        let i = hr(),
            n = xo();
        F = {
            projectId: c.projectId || ut(et.host),
            userId: n.id,
            sessionId: i.session,
            pageNum: i.count
        }, c.lean = c.track && i.upgrade !== null ? i.upgrade === 0 : c.lean, c.upload = c.track && typeof c.upload === "string" && i.upload && i.upload.length > "https://".length ? i.upload : c.upload, N(0, t), N(3, r), N(1, Ee(et.href, !!ri)), N(2, P.referrer), N(15, lp()), N(16, P.documentElement.attributes.lang), N(17, P.documentElement.attributes.dir), N(28, n.dob.toString()), N(29, n.version.toString()), N(34, e), N(35, o), U(0, i.ts), U(1, 0), U(35, ri), Et && N(9, Et.language), le && (U(14, Math.round(le.width)), U(15, Math.round(le.height)));
        for (let T of c.cookies) {
            let g = nn(T);
            g && Kt(T, g)
        }
        vt == null && (vt = {
            ad_Storage: c.track ? "granted" : "denied",
            analytics_Storage: c.track ? "granted" : "denied"
        });
        let s = bl(vt, 0);
        rn(s), yl(n)
    }

    function sp() {
        F = null, Se.forEach(t => {
            t.called = !1
        })
    }

    function qr(t, e = !0, o = !1, r = !1) {
        let i = c.lean ? 0 : 1,
            n = !1;
        F && (i || e === !1) && (t(F, !c.lean, r ? vt : void 0), n = !0), (o || !n) && Se.push({
            callback: t,
            wait: e,
            recall: o,
            called: n,
            consentInfo: r
        })
    }

    function Dt() {
        return F ? [F.userId, F.sessionId, F.pageNum].join(".") : ""
    }

    function Gr(t = !0) {
        if (!t) {
            bt();
            return
        }
        bt({
            ad_Storage: "granted",
            analytics_Storage: "granted"
        }), oi()
    }

    function bt(t = ap, e = 1) {
        let o = {
            ad_Storage: hl(t.ad_Storage),
            analytics_Storage: hl(t.analytics_Storage)
        };
        if (vt && o.ad_Storage === vt.ad_Storage && o.analytics_Storage === vt.analytics_Storage) return;
        vt = o, ze(!0);
        let r = bl(vt, e);
        if (!r.analytics_Storage && c.track) {
            c.track = !1, jo("_clsk", "", -Number.MAX_VALUE), jo("_clck", "", -Number.MAX_VALUE), qe(), setTimeout(ii, 250);
            return
        }
        pt() && r.analytics_Storage && (c.track = !0, yl(xo(), 1), $e()), an(r), oi()
    }

    function bl(t, e) {
        return {
            source: e,
            ad_Storage: t.ad_Storage === "granted" ? 1 : 0,
            analytics_Storage: t.analytics_Storage === "granted" ? 1 : 0
        }
    }

    function hl(t) {
        return typeof t == "string" ? t.toLowerCase() : "denied"
    }

    function on() {
        jo("_clsk", "", 0)
    }

    function lp() {
        if (c.track) {
            let t = yr("_cltk");
            return t == null && (t = Yo(), br("_cltk", t)), t
        } else return Yo()
    }

    function ze(t = !1) {
        let e = c.lean ? 0 : 1;
        cp(e, t)
    }

    function $e() {
        if (!F || !c.track) return;
        let t = Math.round(Date.now()),
            e = c.upload && typeof c.upload === "string" ? c.upload.replace("https://", "") : "",
            o = c.lean ? 0 : 1;
        jo("_clsk", [F.sessionId, t, F.pageNum, o, e].join("^"), 1)
    }

    function cp(t, e = !1) {
        if (Se.length > 0)
            for (let o = 0; o < Se.length; o++) {
                let r = Se[o];
                r.callback && (!r.called && !e || r.consentInfo && e) && (!r.wait || t) && (r.callback(F, !c.lean, r.consentInfo ? vt : void 0), r.called = !0, r.recall || (Se.splice(o, 1), o--))
            }
    }

    function yl(t, e = null) {
        e = e === null ? t.consent : e;
        let o = Math.ceil((Date.now() + 365 * 864e5) / 864e5),
            r = t.dob === 0 ? c.dob === null ? 0 : c.dob : t.dob;
        if (t.expiry === null || Math.abs(o - t.expiry) >= 1 || t.consent !== e || t.dob !== r) {
            let i = [F.userId, 2, o.toString(36), e, r];
            jo("_clck", i.join("^"), 365)
        }
    }

    function Yo() {
        return Math.floor(Math.random() * Math.pow(2, 32)).toString(36)
    }

    function hr() {
        let t = {
                session: Yo(),
                ts: Math.round(Date.now()),
                count: 1,
                upgrade: null,
                upload: ""
            },
            e = nn("_clsk", !c.includeSubdomains);
        if (e) {
            let o = e.includes("^") ? e.split("^") : e.split("|");
            o.length >= 5 && t.ts - oe(o[1]) < C.SessionTimeout && (t.session = o[0], t.count = oe(o[2]) + 1, t.upgrade = oe(o[3]), t.upload = o.length >= 6 ? `https://${o[5]}/${o[4]}` : `https://${o[4]}`)
        }
        return t
    }

    function oe(t, e = 10) {
        return parseInt(t, e)
    }

    function xo() {
        let t = {
                id: Yo(),
                version: 0,
                expiry: null,
                consent: 0,
                dob: 0
            },
            e = nn("_clck", !c.includeSubdomains);
        if (e && e.length > 0) {
            let o = e.includes("^") ? e.split("^") : e.split("|");
            o.length > 1 && (t.version = oe(o[1])), o.length > 2 && (t.expiry = oe(o[2], 36)), o.length > 3 && oe(o[3]) === 1 && (t.consent = 1), o.length > 4 && oe(o[1]) > 1 && (t.dob = oe(o[4])), c.track = c.track || t.consent === 1, t.id = c.track ? o[0] : t.id
        }
        return t
    }

    function nn(t, e = !1) {
        let o = vr(t);
        return o == null ? null : e ? o.endsWith("~1") ? o.substring(0, o.length - 2) : null : o
    }

    function jo(t, e, o) {
        (c.track || e == "") && xr(t, e, o)
    }
    var F, Se, ri, vt, ap, tt = u(() => {
        rt();
        f();
        ye();
        Mt();
        J();
        Ce();
        Ne();
        Xr();
        qt();
        dt();
        Ro();
        I();
        I();
        F = null, Se = [], ri = 0, vt = null, ap = {
            ad_Storage: "denied",
            analytics_Storage: "denied"
        }
    });
    var Ue = {};
    w(Ue, {
        data: () => b,
        envelope: () => Qa,
        start: () => up,
        stop: () => pp
    });

    function up() {
        let t = F;
        b = {
            version: Ie,
            sequence: 0,
            start: 0,
            duration: 0,
            projectId: t.projectId,
            userId: t.userId,
            sessionId: t.sessionId,
            pageNum: t.pageNum,
            upload: 0,
            end: 0,
            applicationPlatform: 0,
            url: ""
        }
    }

    function pp() {
        b = null
    }

    function Qa(t) {
        return b.start = b.start + b.duration, b.duration = h() - b.start, b.sequence++, b.upload = 0, b.end = t ? 1 : 0, b.applicationPlatform = 0, b.url = Ee(et.href, !1, !0), [b.version, b.sequence, b.start, b.duration, b.projectId, b.userId, b.sessionId, b.pageNum, b.upload, b.end, b.applicationPlatform, b.url]
    }
    var b, We = u(() => {
        f();
        Ne();
        k();
        Qe();
        tt();
        I();
        b = null
    });

    function sn() {
        ai = []
    }

    function er(t) {
        if (ai && ai.indexOf(t.message) === -1) {
            let e = c.report;
            if (e && e.length > 0 && b) {
                let o = {
                    v: b.version,
                    p: b.projectId,
                    u: b.userId,
                    s: b.sessionId,
                    n: b.pageNum
                };
                t.message && (o.m = t.message), t.stack && (o.e = t.stack);
                let r = new XMLHttpRequest;
                r.open("POST", e, !0), r.send(JSON.stringify(o)), ai.push(t.message)
            }
        }
        return t
    }
    var ai, or = u(() => {
        J();
        We()
    });

    function ni() {
        Ge = !0, En(), Ci(), sn()
    }

    function xl() {
        sn(), Ci(), Nn(), Ge = !1
    }

    function pt() {
        return Ge
    }

    function vl() {
        try {
            return Ge === !1 && typeof Promise != "undefined" && "now" in Date && "now" in performance && typeof WeakMap != "undefined"
        } catch (t) {
            return !1
        }
    }

    function Sl(t) {
        if (t === null || Ge) return !1;
        for (let e in t) e in c && (c[e] = t[e]);
        return !0
    }

    function Ln() {
        Ge && (Ae("clarity", "suspend"), qe())
    }
    var Ge, Mt = u(() => {
        f();
        ye();
        J();
        or();
        G();
        k();
        tr();
        Ge = !1
    });
    var ln = {};
    w(ln, {
        start: () => dp,
        stop: () => fp
    });

    function dp() {
        Wn(), pl()
    }

    function fp() {
        ml()
    }
    var Tl = u(() => {
        kt();
        co()
    });
    var cn = {};
    w(cn, {
        start: () => gp,
        stop: () => hp
    });

    function gp() {
        Bs(), xs(), Ts(), Cs(), Es(), Ms(), Vs(), qs(), hs(), Hs()
    }

    function hp() {
        $s(), vs(), ks(), ws(), Ns(), Os(), Ys(), Zs(), bs(), Us()
    }
    var kl = u(() => {
        va();
        Sa();
        Ta();
        Da();
        Ia();
        Aa();
        Hr();
        _a();
        Or();
        Oa()
    });

    function Dl() {
        Te = {}, Vi(bp)
    }

    function El() {
        Te = {}, si = []
    }

    function bp(t) {
        let e = h();
        Di(6, e), si.push({
            time: e,
            mutation: t
        }), yp(), z(To), R(Oe)()
    }

    function yp() {
        let t = {
            id: Dt(),
            cost: 3
        };
        for (cr(t); si.length > 0;) {
            let e = si.shift();
            xp(e.mutation), $t(6, e.time)
        }
        vp(), ur(t)
    }

    function xp(t) {
        He(P), un(t.modifiedNodes, 4), un(t.addedNodes, 1), un(t.removedNodes, 2)
    }

    function un(t, e) {
        let o = t ? t.length : 0;
        for (let r = 0; r < o; r++) {
            let i = t[r];
            e === 1 ? Br(i, e) : Wr(i, e)
        }
    }

    function vp() {
        let t = h();
        Object.keys(Te).length > 1e4 && (Te = {}, it(38));
        for (let e of Object.keys(Te)) {
            let o = Te[e];
            t > o[1] + 3e4 && delete Te[e]
        }
    }
    var si, Te, Nl = u(() => {
        f();
        ct();
        Tt();
        G();
        k();
        Lt();
        tt();
        dt();
        nr();
        ko();
        ht();
        Do();
        Vt();
        Wa();
        I();
        I();
        Ua();
        si = [], Te = {}
    });
    var pn = {};
    w(pn, {
        hashText: () => he,
        start: () => Tp,
        stop: () => kp
    });

    function Tp() {
        Qn(), es(), ga(), Dl(), Fr()
    }

    function kp() {
        rs(), ha(), El(), Zn()
    }
    var li = u(() => {
        Ba();
        ko();
        ht();
        Nl();
        Vt();
        ht()
    });

    function Il(t) {
        return v(this, null, function*() {
            let o = [h(), t];
            switch (t) {
                case 29:
                    o.push(O.fetchStart), o.push(O.connectStart), o.push(O.connectEnd), o.push(O.requestStart), o.push(O.responseStart), o.push(O.responseEnd), o.push(O.domInteractive), o.push(O.domComplete), o.push(O.loadEventStart), o.push(O.loadEventEnd), o.push(O.redirectCount), o.push(O.size), o.push(O.type), o.push(O.protocol), o.push(O.encodedSize), o.push(O.decodedSize), Xo(), x(o);
                    break
            }
        })
    }
    var Cl = u(() => {
        f();
        k();
        Nt();
        ci()
    });

    function Xo() {
        O = null
    }

    function Pl(t) {
        O = {
            fetchStart: Math.round(t.fetchStart),
            connectStart: Math.round(t.connectStart),
            connectEnd: Math.round(t.connectEnd),
            requestStart: Math.round(t.requestStart),
            responseStart: Math.round(t.responseStart),
            responseEnd: Math.round(t.responseEnd),
            domInteractive: Math.round(t.domInteractive),
            domComplete: Math.round(t.domComplete),
            loadEventStart: Math.round(t.loadEventStart),
            loadEventEnd: Math.round(t.loadEventEnd),
            redirectCount: Math.round(t.redirectCount),
            size: t.transferSize ? t.transferSize : 0,
            type: t.type,
            protocol: t.nextHopProtocol,
            encodedSize: t.encodedBodySize ? t.encodedBodySize : 0,
            decodedSize: t.decodedBodySize ? t.decodedBodySize : 0
        }, Il(29)
    }
    var O, ci = u(() => {
        f();
        Cl();
        O = null
    });

    function wl() {
        PerformanceObserver.supportedEntryTypes ? Ep() : V(3, 0)
    }

    function Ep() {
        try {
            ke && ke.disconnect(), ke = new PerformanceObserver(R(Np));
            for (let t of Dp) PerformanceObserver.supportedEntryTypes.indexOf(t) >= 0 && (t === "layout-shift" && mt(9, 0), ke.observe({
                type: t,
                buffered: !0
            }))
        } catch (t) {
            V(3, 1)
        }
    }

    function Np(t) {
        Ip(t.getEntries())
    }

    function Ip(t) {
        for (let e = 0; e < t.length; e++) {
            let o = t[e];
            switch (o.entryType) {
                case "navigation":
                    Pl(o);
                    break;
                case "resource":
                    let r = o.name;
                    N(4, Cp(r)), (r === c.upload || r === c.fallback) && U(28, o.duration);
                    break;
                case "longtask":
                    it(7);
                    break;
                case "first-input":
                    U(10, o.processingStart - o.startTime);
                    break;
                case "layout-shift":
                    o.hadRecentInput || mt(9, o.value * 1e3);
                    break;
                case "largest-contentful-paint":
                    U(8, o.startTime);
                    break
            }
        }
    }

    function Al() {
        ke && ke.disconnect(), ke = null
    }

    function Cp(t) {
        try {
            return new URL(t).host
        } catch (e) {
            return ""
        }
    }
    var ke, Dp, _l = u(() => {
        f();
        J();
        Tt();
        qt();
        dt();
        kt();
        ci();
        Dp = ["navigation", "resource", "longtask", "first-input", "layout-shift", "largest-contentful-paint", "event"]
    });
    var dn = {};
    w(dn, {
        start: () => wp,
        stop: () => Ap
    });

    function wp() {
        Xo(), wl()
    }

    function Ap() {
        Al(), Xo()
    }
    var Ml = u(() => {
        ci();
        _l()
    });

    function ii(t = null) {
        vl() && (Sl(t), ni(), il(), Rl.forEach(e => R(e.start)()))
    }

    function qe() {
        pt() && (Rl.slice().reverse().forEach(t => R(t.stop)()), al(), xl())
    }
    var Rl, ye = u(() => {
        f();
        Mt();
        to();
        Tt();
        G();
        Qe();
        Oo();
        Tl();
        kl();
        li();
        Ml();
        I();
        to();
        k();
        Oo();
        Nt();
        li();
        Rl = [Y, ln, Ti, pn, cn, dn]
    });

    function Ll(t, e) {
        return v(this, null, function*() {
            let o = yield Ul(e);
            yield sa(t, o), ii(o), Kt("C_IS", _p), Mp(t)
        })
    }

    function Hl(t, e) {
        return v(this, null, function*() {
            let o = yield Ul(e);
            yield ue.init(t, o.cookies), yield Me.init(t, o), ni(), Me.start()
        })
    }

    function Ul(t) {
        return v(this, null, function*() {
            let e = yield fetch(`https://www.clarity.ms/tag/shopify/${t}`);
            if (!e.ok) throw new Error(`Failed to fetch Clarity configs: ${e.statusText}`);
            return e.json()
        })
    }

    function Mp(t) {
        Ol(t.init.customerPrivacy), t.customerPrivacy.subscribe("visitorConsentCollected", e => Ol(e.customerPrivacy))
    }

    function Ol(t) {
        bt({
            ad_Storage: t.marketingAllowed ? "granted" : "denied",
            analytics_Storage: t.analyticsProcessingAllowed ? "granted" : "denied"
        })
    }
    var _p, Wl = u(() => {
        ye();
        Mt();
        Tt();
        Qe();
        I();
        to();
        k();
        Oo();
        Nt();
        li();
        _p = "13"
    });
    var Bl, Fl = u(() => {
        Bl = "WebPixel::Render"
    });
    var fn, zl = u(() => {
        Fl();
        fn = t => shopify.extend(Bl, t)
    });
    var $l = u(() => {
        zl()
    });
    var Vl = u(() => {
        $l()
    });
    var jl = Zl(Yl => {
        Wl();
        Vl();
        var Op = ["/checkouts/"];
        fn(t => v(null, null, function*() {
            var e;
            try {
                let o = (e = t.settings.projectId) == null ? void 0 : e.trim();
                if (o == null || o === "") {
                    console.error("Clarity Project ID is required in settings. Exiting Clarity pixel...");
                    return
                }
                Lp(t.init.context.window) ? yield Ll(t, o): yield Hl(t, o)
            } catch (o) {
                console.error("Clarity pixel failed to start...", o)
            }
        }));
        var Lp = t => {
            let e = t.location.pathname;
            return Op.some(o => e.includes(o))
        }
    });
    var Tb = tc(jl());
})();