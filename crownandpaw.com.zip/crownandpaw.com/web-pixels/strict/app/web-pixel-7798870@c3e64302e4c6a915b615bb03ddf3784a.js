(() => {
    var g;
    (function(e) {
        e.checkout_address_info_submitted = "checkout_address_info_submitted", e.checkout_completed = "checkout_completed", e.checkout_contact_info_submitted = "checkout_contact_info_submitted", e.checkout_shipping_info_submitted = "checkout_shipping_info_submitted", e.checkout_started = "checkout_started", e.collection_viewed = "collection_viewed", e.page_viewed = "page_viewed", e.payment_info_submitted = "payment_info_submitted", e.product_added_to_cart = "product_added_to_cart", e.product_viewed = "product_viewed", e.search_submitted = "search_submitted", e.custom_event = "custom_event", e.clicked = "clicked"
    })(g || (g = {}));
    var p;
    (function(e) {
        e.page_enter = "page_enter", e.add_to_cart = "add_to_cart", e.cart_updated = "cart_updated", e.view_item = "view_item", e.checkout = "checkout", e.search = "search", e.custom_event = "custom_event", e.purchase = "purchase", e.click_item = "click_item"
    })(p || (p = {}));
    var k = class extends Event {
        constructor(t, o) {
            super(t), this.context = o
        }
    };
    var j = "amEventSid";
    var N = "_recordTime",
        V = "amUtmSource",
        Y = "amUtmMedium",
        z = "amUtmContent",
        W = "amUtmCampaign",
        H = "amUtmSCP";
    var F = "_ga",
        M = "_ama",
        R = "_am_id",
        U = "/";
    var J = "G-82HPXE066K",
        Q = {
            testing: "https://www.automizely-analytics.io/analytics/collect",
            staging: "https://api-staging.automizely.com/analytics/collect",
            production: "https://www.automizely-analytics.com/analytics/collect"
        };

    function Oe() {
        let e = new Date().getTime(),
            t = typeof performance != "undefined" && performance.now && performance.now() * 1e3 || 0;
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(o) {
            let n = Math.random() * 16;
            return e > 0 ? (n = (e + n) % 16 | 0, e = Math.floor(e / 16)) : (n = (t + n) % 16 | 0, t = Math.floor(t / 16)), (o === "x" ? n : n & 3 | 8).toString(16)
        })
    }

    function D() {
        let e = "";
        try {
            e = URL.createObjectURL(new Blob)
        } catch (n) {}
        let t = e.toString();
        try {
            URL.revokeObjectURL(e)
        } catch (n) {}
        let o = t.split(/[:/]/g).pop();
        return o ? o.toLowerCase() : Oe()
    }

    function Z(e, t) {
        return Math.floor(Math.random() * (t - e) + e)
    }

    function ee(e) {
        let t = `${Z(1,9)}`;
        for (let o = 1; o < e; o++) t += Z(0, 9);
        return t
    }

    function K(e) {
        for (let t in e)(e[t] === void 0 || e[t] === null) && delete e[t];
        return e
    }

    function w(e) {
        return !e || isNaN(parseFloat(e)) ? 0 : Math.round(parseFloat(e) * 100)
    }
    var O;
    (function(e) {
        e.Home = "P00001", e.Collections = "P00002", e.SearchResults = "P00003", e.Product = "P00004", e.Cart = "P00005", e.ThankYou = "P00006", e.Checkout = "P00007", e.PostPurchase = "P00008", e.OrderStatus = "P00009", e.OrderIndex = "P00010"
    })(O || (O = {}));
    var oe;
    (function(e) {
        e.cart = "/cart.js", e.cartCheckout = "/cart"
    })(oe || (oe = {}));
    var ne = [{
        page_type: "home",
        regexp: /^\/$/,
        page_sn: O.Home
    }, {
        page_type: "collections",
        regexp: /^\/collections\/((?!products\/).)*$/,
        page_sn: O.Collections
    }, {
        page_type: "collection",
        regexp: /\/collections\/((?!products\/).)*$/,
        page_sn: O.Collections
    }, {
        page_type: "searchresults",
        regexp: /.*a?\/search$/,
        page_sn: O.SearchResults
    }, {
        page_type: "product",
        regexp: /^\/products\/[^/]+$/,
        page_sn: O.Product
    }, {
        page_type: "",
        regexp: /^\/cart$/,
        page_sn: O.Cart
    }, {
        page_type: "",
        regexp: /.*\/checkouts\/.+thank_you/,
        page_sn: O.ThankYou
    }];
    var L = function(e, t, o, n) {
        function i(r) {
            return r instanceof o ? r : new o(function(a) {
                a(r)
            })
        }
        return new(o || (o = Promise))(function(r, a) {
            function c(l) {
                try {
                    s(n.next(l))
                } catch (u) {
                    a(u)
                }
            }

            function _(l) {
                try {
                    s(n.throw(l))
                } catch (u) {
                    a(u)
                }
            }

            function s(l) {
                l.done ? r(l.value) : i(l.value).then(c, _)
            }
            s((n = n.apply(e, t || [])).next())
        })
    };

    function T(e) {
        var t, o, n;
        let i = e.window.location.pathname,
            r = (n = (o = (t = e.window.ShopifyAnalytics) === null || t === void 0 ? void 0 : t.meta) === null || o === void 0 ? void 0 : o.page) === null || n === void 0 ? void 0 : n.pageType;
        return [...ne, {
            page_type: "thank_you",
            regexp: /^([^]+)?checkouts(\/c)?[^]+\/thank[_-]you/,
            page_sn: O.ThankYou
        }, {
            page_type: "checkout",
            regexp: /\/checkouts\/\w+\/[\w-]+\/\w+$/,
            page_sn: O.Checkout
        }, {
            page_type: "checkout",
            regexp: /\/.*\/checkouts\/.*$/,
            page_sn: O.Checkout
        }].find(c => c.regexp.test(i) || r === c.page_type) || {
            page_type: r,
            regexp: /.+/,
            page_sn: ""
        }
    }

    function ie(e) {
        var t, o, n;
        let i = ((n = (o = (t = e.window.ShopifyAnalytics) === null || t === void 0 ? void 0 : t.meta) === null || o === void 0 ? void 0 : o.page) === null || n === void 0 ? void 0 : n.customerId) || "";
        return {
            userId: i,
            isLogged: !!i
        }
    }

    function q(e, t) {
        var o;
        return L(this, void 0, void 0, function*() {
            let n = [];
            try {
                n = (o = yield t.cookie.get()) === null || o === void 0 ? void 0 : o.split(";")
            } catch (r) {}
            let i = `${e}=`;
            for (let r of n)
                if (r = r.trim(), r.substring(0, i.length) === i) return r.substring(i.length);
            return ""
        })
    }

    function Ce(e) {
        return L(this, void 0, void 0, function*() {
            let t = yield q(F, e), o = t.indexOf(".");
            if (o > -1 && (o = t.indexOf(".", o + 1), o > -1)) {
                let n = t.substring(o + 1);
                return n.length >= 12 ? n : ""
            }
            return ""
        })
    }

    function re(e) {
        return L(this, void 0, void 0, function*() {
            let t = yield Ce(e), o = yield e.cookie.get(M), n = t || o || D(), i = new Date(Date.now() + 31536e3 * 1e3);
            return e.cookie.set(`${M}=${n}; expires=${i.toISOString()}; path=${U}`), n
        })
    }

    function Pe() {
        return ["kadensse", "bad-no"]
    }
    var ce = (e, t) => {
        let {
            hostname: o
        } = e.window.location, n = o.includes("myshopify.com") ? o.split(".")[0] : o;
        if (Pe().includes(n)) {
            let i = new Date;
            t.cookie.set(`${R}=deleted; expires=${i.toISOString()}; path=${U}`), t.cookie.set(`${M}=deleted; expires=${i.toISOString()}; path=${U}`)
        }
    };

    function de() {
        let e = new Date().getTime();
        return typeof e == "number" ? e : 0
    }

    function be() {
        let e = new Date;
        return e.getSeconds() + 60 * e.getMinutes() + 60 * 60 * e.getHours()
    }

    function B(e, t) {
        var o, n;
        return L(this, void 0, void 0, function*() {
            let i = Date.now(),
                r = yield(o = e.sessionStorage) === null || o === void 0 ? void 0 : o.getItem(t), a = Number(yield(n = e.sessionStorage) === null || n === void 0 ? void 0 : n.getItem(t + N));
            return r && i - a < 1800 || (r = D(), e.sessionStorage.setItem(t, r), e.sessionStorage.setItem(t + N, `${i}`)), r
        })
    }
    var ae = () => `${be()}.${ee(8)}`,
        se = (e, t) => {
            if (!t || t.length === 0) return !1;
            switch (e) {
                case g.page_viewed:
                    return t.includes(p.page_enter);
                case g.clicked:
                    return t.includes(p.click_item);
                case g.product_added_to_cart:
                    return t.includes(p.add_to_cart) || t.includes(p.cart_updated);
                case g.product_viewed:
                case g.collection_viewed:
                    return t.includes(p.view_item);
                case g.checkout_started:
                    return t.includes(p.checkout);
                case g.checkout_completed:
                    return t.includes(p.purchase);
                case g.search_submitted:
                    return t.includes(p.search);
                case g.custom_event:
                    return t.includes(p.custom_event);
                default:
                    return !1
            }
        };
    var A = function(e, t, o, n) {
            function i(r) {
                return r instanceof o ? r : new o(function(a) {
                    a(r)
                })
            }
            return new(o || (o = Promise))(function(r, a) {
                function c(l) {
                    try {
                        s(n.next(l))
                    } catch (u) {
                        a(u)
                    }
                }

                function _(l) {
                    try {
                        s(n.throw(l))
                    } catch (u) {
                        a(u)
                    }
                }

                function s(l) {
                    l.done ? r(l.value) : i(l.value).then(c, _)
                }
                s((n = n.apply(e, t || [])).next())
            })
        },
        De = "amwcp1",
        Ae = "3.3",
        ue = {
            _: "ep",
            event_time: "epn"
        },
        P = {},
        Ne = "shopify";

    function _e(e, t, o, n, i) {
        return A(this, void 0, void 0, function*() {
            return yield Me({
                gaMeasurementId: J || "",
                state: {
                    [e]: {
                        shortCode: (i == null ? void 0 : i.productShortCode) || ""
                    }
                }
            }, t, o, n)
        })
    }

    function pe(e, t, o, n, i, r, a, c) {
        var _, s, l;
        return A(this, void 0, void 0, function*() {
            let u = {
                state: {},
                appEntries: {},
                eventMap: new WeakMap
            };
            u.state[t] = {
                shortCode: (a == null ? void 0 : a.productShortCode) || ""
            };
            let x = `${t}.${(a==null?void 0:a.entry)||""}`;
            if (u.appEntries = u.appEntries || {}, u.appEntries.hasOwnProperty(x)) return;
            u.appEntries[x] = 1;
            let f = u.eventMap,
                v = f.get(e);
            if (v || (v = {
                    data: [],
                    sentDataLen: -1,
                    sentAppLen: -1
                }, f.set(e, v)), v.eventId || (v.eventId = D()), e.type === p.search) {
                let d = (_ = e.context) === null || _ === void 0 ? void 0 : _.data;
                v.data = [{
                    user_client_id: d.client_id,
                    page: {
                        page_sn: d == null ? void 0 : d.page_sn
                    },
                    params: {
                        query: encodeURIComponent((s = d == null ? void 0 : d.query) !== null && s !== void 0 ? s : "")
                    }
                }]
            } else {
                let d = (l = e.context) === null || l === void 0 ? void 0 : l.data;
                v.data = [{
                    user_client_id: d.client_id,
                    page: (d == null ? void 0 : d.page) || {
                        page_sn: d == null ? void 0 : d.page_sn
                    },
                    ecommerce: (d == null ? void 0 : d.ecommerce) || K({
                        checkout_token: d == null ? void 0 : d.checkout_token,
                        items: d == null ? void 0 : d.items,
                        carts: d == null ? void 0 : d.carts,
                        checkout: d == null ? void 0 : d.checkout,
                        order_id: d == null ? void 0 : d.order_id,
                        total_value: d == null ? void 0 : d.total_value,
                        total_tax: d == null ? void 0 : d.total_tax,
                        total_shipping: d == null ? void 0 : d.total_shipping,
                        currency_code: d == null ? void 0 : d.currency_code
                    }),
                    params: d == null ? void 0 : d.extraParams,
                    promotion: d == null ? void 0 : d.promotion
                }]
            }
            let h = Object.keys(u.state).length;
            if (v.sentDataLen === v.data.length && v.sentAppLen === h) return;
            v.sentDataLen = v.data.length, v.sentAppLen = h, a != null && a.basicData && le(a.basicData), a != null && a.mappedOrgId && le({
                __organization_id: a.mappedOrgId
            });
            let y = yield Ke(v, o, n, i, r, u, c);
            return $e(e.type, je(y))
        })
    }

    function Me(e, t, o, n) {
        return A(this, void 0, void 0, function*() {
            let r = Q[n] + "?" + Le(yield Te(t, o)),
                a = Re(e);
            return `${r}${a}`
        })
    }

    function Re(e) {
        let t = [];
        for (let o in e.state) e.state[o].shortCode && t.push(e.state[o].shortCode);
        return t.sort(), `&_psc=${t.join(",")}`
    }

    function Ue(e, t) {
        return A(this, void 0, void 0, function*() {
            return {
                pageLocation: e.document.location.href,
                pageReferrer: e.document.referrer,
                pageTitle: e.document.title,
                screenResolution: `${e.window.outerWidth||0}x${e.window.outerHeight||0}`,
                language: e.navigator.language || "",
                sessionId: yield B(t, j)
            }
        })
    }

    function Le(e) {
        let t = "";
        for (let o in e) t += (t ? "&" : "") + `${o}=${encodeURIComponent(e[o])}`;
        return t
    }

    function Te(e, t) {
        return A(this, void 0, void 0, function*() {
            let o = yield Ue(e, t), n = yield re(t);
            return {
                v: "2",
                gtm: De,
                sr: o.screenResolution,
                ul: o.language,
                cid: n,
                dl: o.pageLocation,
                dr: o.pageReferrer,
                dt: o.pageTitle,
                sid: o.sessionId
            }
        })
    }

    function $e(e, t) {
        let o = `en=${encodeURIComponent(e)}`;
        for (let n in t) o += `&${ue[n]||ue._}.${encodeURIComponent(n)}=${encodeURIComponent(t[n])}`;
        return o
    }

    function je(e) {
        let t = [],
            o = {};
        for (let n in e) {
            let i = e[n];
            if (typeof i == "object") {
                let r = t.length,
                    a = Array.isArray(i);
                t.push(n);
                for (let c in i) {
                    let _ = parseInt(c, 10);
                    if (a && (isNaN(_) || `${_}` !== c)) continue;
                    let s, l;
                    typeof i[c] == "object" ? (s = `${r}${c}+`, l = JSON.stringify(i[c])) : (s = `${r}${c}`, l = i[c]), o[s] = l
                }
            } else n[0] === "_" ? o[`-${n}`] = i : o[n] = i
        }
        return o.km = t.join(","), o
    }

    function Ke(e, t, o, n, i, r, a) {
        var c, _, s, l, u, x, f, v, h;
        return A(this, void 0, void 0, function*() {
            let y = T(t),
                d = [],
                E = {},
                m = {};
            for (let S of e.data)
                if (S.ecommerce && !m.ecommerce && (m.ecommerce = S.ecommerce), S.params && !m.params && (m.params = S.params), S.page && !m.page && (m.page = S.page), S.user_id && !m.user_id && (m.user_id = S.user_id), S.user_client_id && !m.user_client_id && (m.user_client_id = S.user_client_id), S.promotion) {
                    let $ = Object.assign({}, S.promotion);
                    d.push($), $.app_name && (E[$.app_name] = !0)
                }
            P.promotion && P.promotion.app_name && !E[P.promotion.app_name] && d.push(P.promotion), d.length > 0 && (m.promotions = d);
            let I = t.window.location.hostname.includes("myshopify.com") && t.window.location.hostname.split(".")[0],
                C = {
                    kit: Ae,
                    event_time: de(),
                    platform: "WEB",
                    user_id: ((_ = (c = a == null ? void 0 : a.data) === null || c === void 0 ? void 0 : c.customer) === null || _ === void 0 ? void 0 : _.id) || ie(t).userId,
                    session_id: yield B(o, j), log_id: e.eventId || "", environment: i, product_code: "automizely", collector: "SDK-PIXEL", app_connections: {
                        app_platform: Ne || P.app_platform || "",
                        app_key: n.app_key,
                        app_names: Object.keys(r.state),
                        __organization_id: n.hashed_organization_id || ""
                    }, page: Object.assign(K({
                        page_referrer: t.document.referrer,
                        page_location: t.window.location.href,
                        page_id: ae() || "",
                        page_type: (s = y == null ? void 0 : y.page_type) !== null && s !== void 0 ? s : "",
                        page_sn: (l = y == null ? void 0 : y.page_sn) !== null && l !== void 0 ? l : "",
                        utm_source: yield(u = o == null ? void 0 : o.sessionStorage) === null || u === void 0 ? void 0 : u.getItem(V), utm_medium: yield(x = o == null ? void 0 : o.sessionStorage) === null || x === void 0 ? void 0 : x.getItem(Y), utm_content: yield(f = o == null ? void 0 : o.sessionStorage) === null || f === void 0 ? void 0 : f.getItem(z), utm_campaign: yield(v = o == null ? void 0 : o.sessionStorage) === null || v === void 0 ? void 0 : v.getItem(W), _sc_p: yield(h = o == null ? void 0 : o.sessionStorage) === null || h === void 0 ? void 0 : h.getItem(H)
                    }), m.page)
                },
                b = yield q(R, o);
            return b && (C._am_id = b), delete m.page, Object.assign(C, m)
        })
    }

    function le(e) {
        let t;
        for (t in e) t === "promotion" ? e.promotion && (P.promotion = e.promotion || {}) : P[t] || (P[t] = e[t])
    }
    var qe = function(e, t, o, n) {
        function i(r) {
            return r instanceof o ? r : new o(function(a) {
                a(r)
            })
        }
        return new(o || (o = Promise))(function(r, a) {
            function c(l) {
                try {
                    s(n.next(l))
                } catch (u) {
                    a(u)
                }
            }

            function _(l) {
                try {
                    s(n.throw(l))
                } catch (u) {
                    a(u)
                }
            }

            function s(l) {
                l.done ? r(l.value) : i(l.value).then(c, _)
            }
            s((n = n.apply(e, t || [])).next())
        })
    };

    function ve(e, t) {
        var o, n, i, r, a, c;
        let _ = t.checkout.token,
            s = t.checkout.lineItems.map((u, x) => {
                var f, v, h, y, d, E, m, I, C, b, S;
                return {
                    item_name: (u == null ? void 0 : u.title) || ((f = u.variant) === null || f === void 0 ? void 0 : f.title),
                    item_id: ((h = (v = u.variant) === null || v === void 0 ? void 0 : v.product) === null || h === void 0 ? void 0 : h.id) || "",
                    pay_value: w((y = u.variant) === null || y === void 0 ? void 0 : y.price.amount),
                    currency_code: (d = u.variant) === null || d === void 0 ? void 0 : d.price.currencyCode,
                    item_brand: (I = (m = (E = u.variant) === null || E === void 0 ? void 0 : E.product) === null || m === void 0 ? void 0 : m.vendor) !== null && I !== void 0 ? I : "",
                    item_category_id: (b = (C = u.variant) === null || C === void 0 ? void 0 : C.product.type) !== null && b !== void 0 ? b : "",
                    item_variant_id: ((S = u.variant) === null || S === void 0 ? void 0 : S.id) || (u == null ? void 0 : u.id),
                    idx: x,
                    quantity: u.quantity
                }
            });
        return new k(p.purchase, {
            data: Object.assign(Object.assign({}, e), {
                items: s,
                checkout_token: _,
                order_id: (n = (o = t.checkout) === null || o === void 0 ? void 0 : o.order) === null || n === void 0 ? void 0 : n.id,
                total_value: w((i = t.checkout.totalPrice) === null || i === void 0 ? void 0 : i.amount),
                total_tax: w((r = t.checkout.totalTax) === null || r === void 0 ? void 0 : r.amount),
                total_shipping: w((a = t.checkout.shippingLine) === null || a === void 0 ? void 0 : a.price.amount),
                currency_code: (c = t.checkout.totalPrice) === null || c === void 0 ? void 0 : c.currencyCode
            })
        })
    }

    function me(e, t, o) {
        let n = t.checkout.token,
            i = {
                stage: o
            },
            r = t.checkout.lineItems.map((c, _) => {
                var s, l, u, x, f, v, h, y, d, E, m;
                return {
                    item_name: (c == null ? void 0 : c.title) || ((s = c.variant) === null || s === void 0 ? void 0 : s.title),
                    item_id: ((u = (l = c == null ? void 0 : c.variant) === null || l === void 0 ? void 0 : l.product) === null || u === void 0 ? void 0 : u.id) || "",
                    price: w((x = c.variant) === null || x === void 0 ? void 0 : x.price.amount),
                    currency_code: (f = c.variant) === null || f === void 0 ? void 0 : f.price.currencyCode,
                    item_brand: (y = (h = (v = c.variant) === null || v === void 0 ? void 0 : v.product) === null || h === void 0 ? void 0 : h.vendor) !== null && y !== void 0 ? y : "",
                    item_category: (E = (d = c.variant) === null || d === void 0 ? void 0 : d.product.type) !== null && E !== void 0 ? E : "",
                    item_variant_id: ((m = c == null ? void 0 : c.variant) === null || m === void 0 ? void 0 : m.id) || (c == null ? void 0 : c.id),
                    idx: _,
                    quantity: c.quantity
                }
            });
        return new k(p.checkout, {
            data: Object.assign(Object.assign({}, e), {
                items: r,
                checkout: i,
                checkout_token: n
            })
        })
    }

    function fe(e, t) {
        let o = t.collection.productVariants.map((i, r) => {
            var a, c, _;
            return {
                item_name: i.product.title,
                item_id: ((a = i == null ? void 0 : i.product) === null || a === void 0 ? void 0 : a.id) || "",
                price: w(i.price.amount),
                currency_code: i.price.currencyCode,
                item_brand: (c = i.product.vendor) !== null && c !== void 0 ? c : "",
                item_category: (_ = i.product.type) !== null && _ !== void 0 ? _ : "",
                item_variant_id: (i == null ? void 0 : i.id) || "",
                idx: r
            }
        });
        return new k(p.view_item, {
            data: Object.assign(Object.assign({}, e), {
                items: o
            })
        })
    }

    function ge(e, t) {
        var o, n, i, r, a;
        let c = {
            item_name: t.productVariant.product.title,
            item_id: ((n = (o = t == null ? void 0 : t.productVariant) === null || o === void 0 ? void 0 : o.product) === null || n === void 0 ? void 0 : n.id) || "",
            price: w(t.productVariant.price.amount),
            currency_code: t.productVariant.price.currencyCode,
            item_brand: (i = t.productVariant.product.vendor) !== null && i !== void 0 ? i : "",
            item_category: (r = t.productVariant.product.type) !== null && r !== void 0 ? r : "",
            item_variant_id: ((a = t == null ? void 0 : t.productVariant) === null || a === void 0 ? void 0 : a.id) || ""
        };
        return new k(p.view_item, {
            data: Object.assign(Object.assign({}, e), {
                items: [c]
            })
        })
    }

    function he(e) {
        return new k(p.page_enter, {
            data: e
        })
    }

    function xe(e, t, o) {
        var n, i, r, a, c, _, s, l, u, x, f, v;
        let h = {
                item_name: (n = t.cartLine) === null || n === void 0 ? void 0 : n.merchandise.product.title,
                item_id: (i = t.cartLine) === null || i === void 0 ? void 0 : i.merchandise.product.id,
                price: w((r = t.cartLine) === null || r === void 0 ? void 0 : r.merchandise.price.amount),
                currency_code: (a = t.cartLine) === null || a === void 0 ? void 0 : a.merchandise.price.currencyCode,
                item_brand: (_ = (c = t.cartLine) === null || c === void 0 ? void 0 : c.merchandise.product.vendor) !== null && _ !== void 0 ? _ : "",
                item_category: (l = (s = t.cartLine) === null || s === void 0 ? void 0 : s.merchandise.product.type) !== null && l !== void 0 ? l : "",
                item_variant_id: (f = (x = (u = t.cartLine) === null || u === void 0 ? void 0 : u.merchandise) === null || x === void 0 ? void 0 : x.id) !== null && f !== void 0 ? f : "",
                quantity: (v = t.cartLine) === null || v === void 0 ? void 0 : v.quantity
            },
            y = new k(p.add_to_cart, {
                data: Object.assign(Object.assign({}, e), {
                    items: [h]
                })
            }),
            d = new k(p.cart_updated, {
                data: Object.assign(Object.assign({}, e), {
                    carts: [Object.assign(Object.assign({}, h), {
                        is_updated: !0
                    })]
                })
            }),
            E = [];
        return (!o || o.includes(p.add_to_cart)) && E.push(y), (!o || o.includes(p.cart_updated)) && E.push(d), E
    }

    function ye(e, t) {
        return new k(p.search, {
            data: Object.assign(Object.assign({}, e), {
                query: t.searchResult.query
            })
        })
    }

    function Ie(e, t, o) {
        var n, i;
        return ((i = (n = o == null ? void 0 : o.data) === null || n === void 0 ? void 0 : n.promotion) === null || i === void 0 ? void 0 : i.app_name) !== e ? [] : new k(o == null ? void 0 : o.event, {
            data: Object.assign(Object.assign({}, t), o == null ? void 0 : o.data)
        })
    }

    function Ee(e, t, o = "", n = "") {
        var i, r;
        let a = ((i = t == null ? void 0 : t.element) === null || i === void 0 ? void 0 : i.tagName) || "",
            c = ((r = t == null ? void 0 : t.element) === null || r === void 0 ? void 0 : r.href) || "";
        return a.toLowerCase() === "a" && c.includes("/products/") ? new k(p.click_item, {
            data: Object.assign(Object.assign({}, e), {
                ecommerce: {
                    items: [{
                        item_url: c.startsWith("/") ? `${o}${c}` : c,
                        currency_code: n
                    }]
                }
            })
        }) : []
    }

    function X(e, t, o, n, i, r, a, c) {
        return qe(this, void 0, void 0, function*() {
            if (Object.keys(e).length <= 0) return;
            let _ = yield _e(t, o, n, r, a);
            if (!_) return;
            let s = yield pe(e, t, o, n, i, r, a, c);
            yield fetch(_, {
                keepalive: !0,
                method: "POST",
                body: s
            })
        })
    }

    function Se({
        appName: e,
        api: t,
        environment: o,
        options: n,
        whiteEventList: i
    }) {
        let {
            analytics: r,
            browser: a,
            settings: c,
            init: _
        } = t;
        (c == null ? void 0 : c.allow_collect_personal_data) === "true" && r.subscribe("all_events", s => {
            var l, u, x, f, v, h;
            if (ce(s.context, a), !se(s.name, i)) return;
            let y = (u = (l = T(s.context)) === null || l === void 0 ? void 0 : l.page_sn) !== null && u !== void 0 ? u : "",
                d = (x = s == null ? void 0 : s.context) === null || x === void 0 ? void 0 : x.window.location.origin,
                E = ((h = (v = (f = s == null ? void 0 : s.context) === null || f === void 0 ? void 0 : f.Shopify) === null || v === void 0 ? void 0 : v.currency) === null || h === void 0 ? void 0 : h.active) || "",
                m = {
                    client_id: s.clientId,
                    page_sn: y
                },
                I = [];
            switch (s.name) {
                case g.checkout_completed:
                    I = ve(m, s.data);
                    break;
                case g.checkout_started:
                    I = me(m, s.data, s.name);
                    break;
                case g.collection_viewed:
                    I = fe(m, s.data);
                    break;
                case g.product_viewed:
                    I = ge(m, s.data);
                    break;
                case g.page_viewed:
                    I = he(m);
                    break;
                case g.product_added_to_cart:
                    I = xe(m, s.data, i);
                    break;
                case g.search_submitted:
                    I = ye(m, s.data);
                    break;
                case g.custom_event:
                    I = Ie(e, m, s.customData);
                    break;
                case g.clicked:
                    I = Ee(m, s.data, d, E);
                    break;
                default:
                    break
            }
            if (Array.isArray(I)) {
                Promise.all(I.map(C => {
                    X(C, e, s.context, a, c, o, n, _)
                }));
                return
            }
            X(I, e, s.context, a, c, o, n, _)
        })
    }
    var ke = "WebPixel::Render";
    var G = e => shopify.extend(ke, e);
    G(e => {
        Se({
            appName: "aftership",
            api: e,
            environment: "production",
            options: {
                productShortCode: "as"
            },
            whiteEventList: [p.add_to_cart, p.cart_updated, p.checkout, p.purchase, p.view_item, p.custom_event, p.page_enter, p.click_item, p.search]
        })
    });
})();