(() => {
    var i = (l, c, s) => new Promise((u, _) => {
        var g = r => {
                try {
                    d(s.next(r))
                } catch (m) {
                    _(m)
                }
            },
            f = r => {
                try {
                    d(s.throw(r))
                } catch (m) {
                    _(m)
                }
            },
            d = r => r.done ? u(r.value) : Promise.resolve(r.value).then(g, f);
        d((s = s.apply(l, c)).next())
    });
    var b = "WebPixel::Render";
    var w = l => shopify.extend(b, l);
    w(_ => i(null, [_], function*({
        init: l,
        analytics: c,
        browser: s,
        settings: u
    }) {
        function g() {
            return i(this, null, function*() {
                let t = yield f(), e = yield d();
                return e !== null && t !== null && e.storedAt === t.storedAt || e !== null && (t === null || t.storedAt < e.storedAt) ? e : t !== null && (e === null || e.storedAt < t.storedAt) ? t : null
            })
        }

        function f() {
            return i(this, null, function*() {
                let t = `SHOPLIFT_SESSION_${u.shop}`,
                    e = yield s.localStorage.getItem(t);
                if (e) try {
                    return JSON.parse(e)
                } catch (a) {}
                return null
            })
        }

        function d() {
            return i(this, null, function*() {
                let t = yield s.cookie.get("SHOPLIFT");
                if (t === void 0 || t === "") return null;
                try {
                    return JSON.parse(t)
                } catch (e) {}
                return null
            })
        }

        function r() {
            return i(this, null, function*() {
                var n;
                let t = yield m("Shoplift_Analytics"), e = yield C("Shoplift_Analytics"), a = {
                    timestamp: new Date,
                    visitor: null,
                    queue: [],
                    gaQueue: []
                };
                return (n = [t, e].filter(o => o !== null).sort((o, y) => +y.timestamp - +o.timestamp)[0]) != null ? n : a
            })
        }

        function m(t) {
            return i(this, null, function*() {
                let e = yield s.localStorage.getItem(t);
                if (e === null) return null;
                try {
                    return JSON.parse(e)
                } catch (a) {}
                return null
            })
        }

        function C(t) {
            return i(this, null, function*() {
                let e = yield s.cookie.get(t);
                if (e === null) return null;
                try {
                    return JSON.parse(e)
                } catch (a) {}
                return null
            })
        }

        function I(t) {
            return t !== null && t.id !== "" && !t.isProcessing && !t.needsPersistence && !!t.visitorTests && !t.visitorTests.find(e => e.needsPersistence)
        }

        function T(t) {
            return t !== null && t.id !== ""
        }

        function k() {
            return i(this, null, function*() {
                let t = yield g(), e = yield r(), a = e.visitor === null, n = a ? t : e.visitor, o = a ? I(t) : T(n);
                return {
                    visitor: n,
                    isReady: o
                }
            })
        }

        function A() {
            return i(this, null, function*() {
                return yield s.cookie.get("_shopify_y")
            })
        }

        function O(t) {
            return /iPad|Tablet|Playbook|Silk/i.test(t) ? "tablet" : /Mobile|Android|iPhone|iPod|IEMobile|Opera Mini/i.test(t) ? "mobile" : "desktop"
        }
        let h = u.shopliftUrl.replace("api/events", "");

        function S(t) {
            return i(this, null, function*() {
                let {
                    visitor: e,
                    isReady: a
                } = yield k();
                a ? yield V(`${h}api/events/checkout`, {
                    visitorId: e.id,
                    cart: l.data.cart,
                    customer: l.data.customer,
                    checkout: t
                }): setTimeout(() => i(null, null, function*() {
                    return yield S(t)
                }), 500)
            })
        }

        function D(t, e) {
            return i(this, null, function*() {
                yield V(`${h}api/v0/events/page-view`, {
                    shop: u.shop,
                    visitorDetails: e,
                    events: [{
                        type: 4,
                        path: t,
                        timestamp: e.createdAt
                    }]
                })
            })
        }

        function v(t) {
            return i(this, null, function*() {
                let e = yield s.cookie.get("cart");
                e && (yield V(`${h}api/v0/events/page-view`, {
                    shop: u.shop,
                    visitorDetails: t,
                    events: [{
                        type: 5,
                        cart: {
                            token: e,
                            currency: yield s.cookie.get("cart_currency"), total_price: 0, items_subtotal_price: 0, total_discount: 0, items: []
                        },
                        timestamp: t.createdAt
                    }]
                }))
            })
        }

        function V(t, e) {
            return i(this, null, function*() {
                for (let a = 0; a < 3; a++) {
                    if (yield s.sendBeacon(t, JSON.stringify(e))) return;
                    yield new Promise(n => setTimeout(n, 500))
                }
            })
        }

        function p(t) {
            return i(this, null, function*() {
                var n, o, y, P;
                let e = t.window.location.search,
                    a = new URLSearchParams(e);
                return {
                    shopifyAnalyticsId: yield A(), device: O(t.navigator.userAgent), utmSource: (n = a.get("utm_source")) != null ? n : "", utmMedium: (o = a.get("utm_medium")) != null ? o : "", utmCampaign: (y = a.get("utm_campaign")) != null ? y : "", utmContent: (P = a.get("utm_content")) != null ? P : "", referrer: t.document.referrer, createdAt: new Date().toISOString()
                }
            })
        }
        c.subscribe("checkout_started", t => i(null, null, function*() {
            let e = yield p(t.context);
            yield v(e)
        })), c.subscribe("product_added_to_cart", t => i(null, null, function*() {
            let e = yield p(t.context);
            yield v(e)
        })), c.subscribe("product_removed_from_cart", t => i(null, null, function*() {
            let e = yield p(t.context);
            yield v(e)
        })), c.subscribe("checkout_completed", t => i(null, null, function*() {
            yield S(t.data.checkout)
        })), c.subscribe("page_viewed", t => i(null, null, function*() {
            let e = t.context.document.location.href,
                a = yield p(t.context);
            yield D(e, a)
        }))
    }));
})();