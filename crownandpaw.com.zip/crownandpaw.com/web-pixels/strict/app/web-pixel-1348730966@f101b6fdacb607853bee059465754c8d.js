(() => {
    var Q = Object.create;
    var h = Object.defineProperty,
        Y = Object.defineProperties,
        Z = Object.getOwnPropertyDescriptor,
        $ = Object.getOwnPropertyDescriptors,
        tt = Object.getOwnPropertyNames,
        A = Object.getOwnPropertySymbols,
        et = Object.getPrototypeOf,
        T = Object.prototype.hasOwnProperty,
        ot = Object.prototype.propertyIsEnumerable;
    var w = (t, e, o) => e in t ? h(t, e, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: o
        }) : t[e] = o,
        n = (t, e) => {
            for (var o in e || (e = {})) T.call(e, o) && w(t, o, e[o]);
            if (A)
                for (var o of A(e)) ot.call(e, o) && w(t, o, e[o]);
            return t
        },
        y = (t, e) => Y(t, $(e));
    var p = (t, e) => () => (t && (e = t(t = 0)), e);
    var at = (t, e) => () => (e || t((e = {
        exports: {}
    }).exports, e), e.exports);
    var dt = (t, e, o, a) => {
        if (e && typeof e == "object" || typeof e == "function")
            for (let d of tt(e)) !T.call(t, d) && d !== o && h(t, d, {
                get: () => e[d],
                enumerable: !(a = Z(e, d)) || a.enumerable
            });
        return t
    };
    var it = (t, e, o) => (o = t != null ? Q(et(t)) : {}, dt(e || !t || !t.__esModule ? h(o, "default", {
        value: t,
        enumerable: !0
    }) : o, t));
    var I = (t, e, o) => new Promise((a, d) => {
        var i = r => {
                try {
                    c(o.next(r))
                } catch (l) {
                    d(l)
                }
            },
            s = r => {
                try {
                    c(o.throw(r))
                } catch (l) {
                    d(l)
                }
            },
            c = r => r.done ? a(r.value) : Promise.resolve(r.value).then(i, s);
        c((o = o.apply(t, e)).next())
    });
    var V, v = p(() => {
        V = "WebPixel::Render"
    });
    var f, L = p(() => {
        v();
        f = t => shopify.extend(V, t)
    });
    var N = p(() => {
        L()
    });
    var O = p(() => {
        N()
    });
    var u, R, E, P, z, q, B, D = p(() => {
        "use strict";
        u = t => {
            let e = t.billingAddress ? {
                    billingLocation: {
                        city: t.billingAddress.city,
                        country: t.billingAddress.country,
                        countryCode: t.billingAddress.countryCode,
                        province: t.billingAddress.province,
                        provinceCode: t.billingAddress.provinceCode,
                        zip: t.billingAddress.zip
                    }
                } : {},
                o = t.shippingAddress ? {
                    shippingLocation: {
                        city: t.shippingAddress.city,
                        country: t.shippingAddress.country,
                        countryCode: t.shippingAddress.countryCode,
                        province: t.shippingAddress.province,
                        provinceCode: t.shippingAddress.provinceCode,
                        zip: t.shippingAddress.zip
                    }
                } : {};
            return n(n({
                checkoutToken: t.token,
                phone: t.phone,
                email: t.email,
                transactions: t.transactions
            }, e), o)
        }, R = t => y(n({}, u(t.data.checkout)), {
            lineItems: t.data.checkout.lineItems,
            variantIds: [...new Set(t.data.checkout.lineItems.map(e => {
                var o;
                return (o = e.variant) == null ? void 0 : o.id
            }).filter(e => e))],
            productIds: [...new Set(t.data.checkout.lineItems.map(e => {
                var o, a;
                return (a = (o = e.variant) == null ? void 0 : o.product) == null ? void 0 : a.id
            }).filter(e => e))]
        }), E = t => n({}, u(t.data.checkout)), P = t => {
            var e;
            return y(n({}, u(t.data.checkout)), {
                deliveryOptionsSelected: (e = t.data.checkout.delivery) == null ? void 0 : e.selectedDeliveryOptions
            })
        }, z = P, q = t => n({}, u(t.data.checkout)), B = t => {
            var o, a;
            let e = (o = t.data.checkout.order) == null ? void 0 : o.id;
            return y(n({}, u(t.data.checkout)), {
                orderId: e && parseInt(e),
                orderCustomer: (a = t.data.checkout.order) == null ? void 0 : a.customer
            })
        }
    });
    var X, j, G, J, U, W = p(() => {
        "use strict";
        X = t => ({}), j = t => {
            var e, o, a, d, i, s, c, r, l, m;
            return {
                cartLine: t.data.cartLine,
                product: {
                    variantId: (o = (e = t.data.cartLine) == null ? void 0 : e.merchandise) == null ? void 0 : o.id,
                    productId: (i = (d = (a = t.data.cartLine) == null ? void 0 : a.merchandise) == null ? void 0 : d.product) == null ? void 0 : i.id,
                    variantTitle: (c = (s = t.data.cartLine) == null ? void 0 : s.merchandise) == null ? void 0 : c.title,
                    productTitle: (m = (l = (r = t.data.cartLine) == null ? void 0 : r.merchandise) == null ? void 0 : l.product) == null ? void 0 : m.title
                }
            }
        }, G = t => ({
            product: {
                variantId: t.data.productVariant.id,
                productId: t.data.productVariant.product.id,
                variantTitle: t.data.productVariant.title,
                productTitle: t.data.productVariant.product.title
            }
        }), J = t => {
            var e, o;
            return {
                collection: {
                    collectionId: t.data.collection.id,
                    collectionName: t.data.collection.title,
                    productIds: [...new Set((o = (e = t.data.collection.productVariants) == null ? void 0 : e.map(a => {
                        var d;
                        return (d = a.product) == null ? void 0 : d.id
                    })) == null ? void 0 : o.filter(a => a))]
                }
            }
        }, U = t => {
            var e, o;
            return {
                searchResult: {
                    query: t.data.searchResult.query,
                    productIds: [...new Set((o = (e = t.data.searchResult.productVariants) == null ? void 0 : e.map(a => {
                        var d;
                        return (d = a.product) == null ? void 0 : d.id
                    })) == null ? void 0 : o.filter(a => a))]
                }
            }
        }
    });
    var H = at(F => {
        "use strict";
        O();
        D();
        W();

        function rt(t, e, o, a) {
            return I(this, null, function*() {
                var C, b, S, x, _, k;
                let d = null;
                try {
                    d = (yield a.cookie.get("ig-vars")) || (yield a.localStorage.getItem("ig-vars")) || null, d && (d = decodeURIComponent(d))
                } catch (g) {}
                let i = e.data.cart,
                    s = ((b = (C = i == null ? void 0 : i.attributes) == null ? void 0 : C.find(g => g.key === "igId")) == null ? void 0 : b.value) || null,
                    c = ((k = (_ = (x = (S = t.data) == null ? void 0 : S.checkout) == null ? void 0 : x.attributes) == null ? void 0 : _.find(g => g.key === "igId")) == null ? void 0 : k.value) || (yield a.cookie.get("ig-id")) || (yield a.localStorage.getItem("ig-id")) || s || null,
                    {
                        origin: r,
                        hash: l,
                        pathname: m,
                        search: K,
                        host: M
                    } = e.context.window.location;
                return {
                    eventTimestamp: t.timestamp,
                    eventType: t.name,
                    eventId: t.id,
                    storeName: o.shopId,
                    shopId: o.shopId,
                    userId: c,
                    shopifyClientId: t.clientId,
                    igVars: d,
                    userAgent: t.context.navigator.userAgent,
                    httpReferrer: t.context.document.referrer,
                    pageTitle: t.context.document.title,
                    customer: e.data.customer,
                    cart: {
                        id: i == null ? void 0 : i.id,
                        igId: s
                    },
                    location: {
                        origin: r,
                        host: M,
                        pathname: m,
                        search: K,
                        hash: l
                    }
                }
            })
        }
        var ct = "https://api.intelligems.io/v3/track";

        function nt(t) {
            fetch(ct, {
                method: "POST",
                body: JSON.stringify({
                    Detail: t
                }),
                keepalive: !0
            })
        }
        f(({
            analytics: t,
            init: e,
            settings: o,
            browser: a
        }) => {
            let d = {
                checkout_completed: B,
                checkout_started: R,
                product_added_to_cart: j,
                product_viewed: G,
                collection_viewed: J,
                checkout_contact_info_submitted: E,
                checkout_address_info_submitted: q,
                checkout_shipping_info_submitted: P,
                payment_info_submitted: z,
                search_submitted: U,
                page_viewed: X
            };
            for (let i of Object.keys(d)) {
                let s = d[i];
                t.subscribe(i, c => I(null, null, function*() {
                    return nt(n(n({}, yield rt(c, e, o, a)), s(c)))
                }))
            }
        })
    });
    var wt = it(H());
})();