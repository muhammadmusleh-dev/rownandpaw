(() => {
    var g = (i, l, n) => new Promise((u, o) => {
        var a = t => {
                try {
                    s(n.next(t))
                } catch (r) {
                    o(r)
                }
            },
            p = t => {
                try {
                    s(n.throw(t))
                } catch (r) {
                    o(r)
                }
            },
            s = t => t.done ? u(t.value) : Promise.resolve(t.value).then(a, p);
        s((n = n.apply(i, l)).next())
    });
    var k = "WebPixel::Render";
    var m = i => shopify.extend(k, i);
    var h = (p, s) => g(null, [p, s], function*(i, {
            shopDomain: l,
            dealBlockId: n,
            productId: u,
            abTestVariantId: o,
            sessionId: a
        }) {
            let t = "kaching_visited_deal_blocks",
                r = yield i.getItem(t), d = r ? JSON.parse(r) : [];
            if (d.includes(n)) return;
            d.push(n), i.setItem(t, JSON.stringify(d)), yield fetch("https://bundles-stats.kachingappz.app/impressions", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    shopDomain: l,
                    dealBlockId: n,
                    productId: u,
                    abTestVariantId: o,
                    sessionId: a
                }),
                keepalive: !0
            })
        }),
        I = h;
    m(({
        analytics: i,
        browser: l,
        init: n,
        settings: u
    }) => {
        let o = !1,
            a = null,
            p = !1,
            s;
        i.subscribe("page_viewed", e => {
            r(e), d("page_viewed event tracked"), o = !0, t()
        }), i.subscribe("kaching_bundle_viewed", e => {
            r(e), d("kaching_bundle_viewed event tracked"), a = {
                dealBlockId: e.customData.deal_block_id,
                productId: e.customData.product_id,
                abTestVariantId: e.customData.ab_test_variant_id,
                sessionId: e.customData.session_id
            }, t()
        });

        function t() {
            return g(this, null, function*() {
                if (p || !o || !a) return;
                let {
                    productId: e,
                    dealBlockId: c,
                    abTestVariantId: f,
                    sessionId: b
                } = a;
                p = !0, I(l.sessionStorage, {
                    shopDomain: u.shopifyDomain,
                    dealBlockId: c,
                    productId: e,
                    abTestVariantId: f,
                    sessionId: b
                }), s && s.includes("kaching=debug") && d("Visit tracked", {
                    productId: e,
                    dealBlockId: c,
                    abTestVariantId: f,
                    sessionId: b
                })
            })
        }

        function r(e) {
            if (!s) try {
                s = e.context.document.location.href
            } catch (c) {
                console.error(c)
            }
        }

        function d(e, c = null) {
            !s || !s.includes("kaching=debug") || console.debug("[Kaching Bundles Pixel]", e, c)
        }
    });
})();