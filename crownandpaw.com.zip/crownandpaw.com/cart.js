{
    "token": "hWN79WSPW20dwad7ATrinO3H?key=7af8c5fdb054082a90332495a8ddbebf",
    "note": "",
    "attributes": {
        "_kaching_session_id": "9b0e36b1-815e-4111-ac0a-d9b3bc370e13"
    },
    "original_total_price": 0,
    "total_price": 0,
    "total_discount": 0,
    "total_weight": 0.0,
    "item_count": 0,
    "items": [],
    "requires_shipping": false,
    "currency": "PKR",
    "items_subtotal_price": 0,
    "cart_level_discount_applications": [],
    "discount_codes": []
}