(() => {
    "use strict";
    var e, t, n, i, o, a = {},
        r = {};

    function l(e) {
        var t = r[e];
        if (void 0 !== t) return t.exports;
        var n = r[e] = {
            exports: {}
        };
        return a[e].call(n.exports, n, n.exports, l), n.exports
    }
    l.m = a, e = [], l.O = (t, n, i, o) => {
        if (!n) {
            var a = 1 / 0;
            for (c = 0; c < e.length; c++) {
                for (var [n, i, o] = e[c], r = !0, s = 0; s < n.length; s++)(!1 & o || a >= o) && Object.keys(l.O).every(e => l.O[e](n[s])) ? n.splice(s--, 1) : (r = !1, o < a && (a = o));
                if (r) {
                    e.splice(c--, 1);
                    var d = i();
                    void 0 !== d && (t = d)
                }
            }
            return t
        }
        o = o || 0;
        for (var c = e.length; c > 0 && e[c - 1][2] > o; c--) e[c] = e[c - 1];
        e[c] = [n, i, o]
    }, l.n = e => {
        var t = e && e.__esModule ? () => e.default : () => e;
        return l.d(t, {
            a: t
        }), t
    }, n = Object.getPrototypeOf ? e => Object.getPrototypeOf(e) : e => e.__proto__, l.t = function(e, i) {
        if (1 & i && (e = this(e)), 8 & i) return e;
        if ("object" == typeof e && e) {
            if (4 & i && e.__esModule) return e;
            if (16 & i && "function" == typeof e.then) return e
        }
        var o = Object.create(null);
        l.r(o);
        var a = {};
        t = t || [null, n({}), n([]), n(n)];
        for (var r = 2 & i && e;
            ("object" == typeof r || "function" == typeof r) && !~t.indexOf(r); r = n(r)) Object.getOwnPropertyNames(r).forEach(t => a[t] = () => e[t]);
        return a.default = () => e, l.d(o, a), o
    }, l.d = (e, t) => {
        for (var n in t) l.o(t, n) && !l.o(e, n) && Object.defineProperty(e, n, {
            enumerable: !0,
            get: t[n]
        })
    }, l.f = {}, l.e = e => Promise.all(Object.keys(l.f).reduce((t, n) => (l.f[n](e, t), t), [])), l.u = e => e + "-" + {
        translations0: "f06922b906d3147c90cc",
        translations1: "c1cc14653b54498151d2",
        translations2: "40179196c028c9b0b0f1",
        translations3: "b5e7835e6a4047bce550",
        translations4: "1d20cf6d00eb648f3298",
        translations5: "95a7d65b965f55e79d8a",
        translations6: "de9cf3c97f1affe8b451",
        translations7: "577d8be7920131d22f71",
        translations8: "89fef3991b0a9af976ea",
        translations9: "2a5288e70f597c83a8c8",
        translations10: "483d4c33de11231298fc",
        translations11: "c597428a8ffe2f83c88c",
        translations12: "8265b30a7417362d8af4",
        translations13: "3fc16887333325659665",
        translations14: "f067e817d77dfad45610",
        translations15: "d37e3ed380db14353de6",
        translations16: "22c818d1daf78160656b",
        translations17: "6d887154bbda09667876",
        translations18: "9731d3a3e30e541fc6d4",
        translations19: "00d01e25a5234d69c77a",
        "src_smile-ui_app_containers_Launcher_Launcher_tsx": "6317e6dbd6383dd84349",
        "src_smile-ui_app_containers_Nudges_Nudges_tsx": "be7240b2a50b0ac32ccb",
        "src_smile-ui_app_components_Panel_Cards_Shared_ReferralUrlShare_tsx-src_smile-ui_app_componen-8ff2a5": "7c9d3b38c2cabb780d15",
        "src_smile-ui_app_containers_Prompt_Prompt_tsx": "83adb6472a1050d439b3",
        "src_smile-ui_app_containers_Panel_PanelView_tsx": "04b5f2f8206040fbddf1",
        "panel-container-styles": "2a377b423450b6ddd8e7",
        "panel-content-styles": "f3b608c30c0b7cab68c6",
        "launcher-container-styles": "ed1cc7b1479aba7073fd",
        "launcher-content-styles": "db5dc10fa04f2f3d7f93",
        "prompt-container-styles": "d3ee91d0835f9bb280b4",
        "prompt-content-styles": "02955c06bf9c0d044df5"
    }[e] + ".modern.js", l.miniCssF = e => e + "." + {
        "panel-container-styles": "1f2e6359f0714c827d9d",
        "launcher-container-styles": "04dbf396d0741a0ff79f",
        "prompt-container-styles": "650585dabd16fbf1f196"
    }[e] + ".css", l.g = function() {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || new Function("return this")()
        } catch (e) {
            if ("object" == typeof window) return window
        }
    }(), l.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), i = {}, o = "smile-ui:", l.l = (e, t, n, a) => {
        if (i[e]) i[e].push(t);
        else {
            var r, s;
            if (void 0 !== n)
                for (var d = document.getElementsByTagName("script"), c = 0; c < d.length; c++) {
                    var u = d[c];
                    if (u.getAttribute("src") == e || u.getAttribute("data-webpack") == o + n) {
                        r = u;
                        break
                    }
                }
            r || (s = !0, (r = document.createElement("script")).charset = "utf-8", l.nc && r.setAttribute("nonce", l.nc), r.setAttribute("data-webpack", o + n), r.src = e), i[e] = [t];
            var m = (t, n) => {
                    r.onerror = r.onload = null, clearTimeout(p);
                    var o = i[e];
                    if (delete i[e], r.parentNode && r.parentNode.removeChild(r), o && o.forEach(e => e(n)), t) return t(n)
                },
                p = setTimeout(m.bind(null, void 0, {
                    type: "timeout",
                    target: r
                }), 12e4);
            r.onerror = m.bind(null, r.onerror), r.onload = m.bind(null, r.onload), s && document.head.appendChild(r)
        }
    }, l.r = e => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, l.p = "https://js.smile.io/v1/", (() => {
        if ("undefined" != typeof document) {
            var e = {
                runtime: 0
            };
            l.f.miniCss = (t, n) => {
                e[t] ? n.push(e[t]) : 0 !== e[t] && {
                    "panel-container-styles": 1,
                    "launcher-container-styles": 1,
                    "prompt-container-styles": 1
                }[t] && n.push(e[t] = (e => new Promise((t, n) => {
                    var i = l.miniCssF(e),
                        o = l.p + i;
                    if (((e, t) => {
                            for (var n = document.getElementsByTagName("link"), i = 0; i < n.length; i++) {
                                var o = (r = n[i]).getAttribute("data-href") || r.getAttribute("href");
                                if ("stylesheet" === r.rel && (o === e || o === t)) return r
                            }
                            var a = document.getElementsByTagName("style");
                            for (i = 0; i < a.length; i++) {
                                var r;
                                if ((o = (r = a[i]).getAttribute("data-href")) === e || o === t) return r
                            }
                        })(i, o)) return t();
                    ((e, t, n, i, o) => {
                        var a = document.createElement("link");
                        a.rel = "stylesheet", a.type = "text/css", l.nc && (a.nonce = l.nc), a.onerror = a.onload = n => {
                            if (a.onerror = a.onload = null, "load" === n.type) i();
                            else {
                                var r = n && n.type,
                                    l = n && n.target && n.target.href || t,
                                    s = new Error("Loading CSS chunk " + e + " failed.\n(" + r + ": " + l + ")");
                                s.name = "ChunkLoadError", s.code = "CSS_CHUNK_LOAD_FAILED", s.type = r, s.request = l, a.parentNode && a.parentNode.removeChild(a), o(s)
                            }
                        }, a.href = t, document.head.appendChild(a)
                    })(e, o, 0, t, n)
                }))(t).then(() => {
                    e[t] = 0
                }, n => {
                    throw delete e[t], n
                }))
            }
        }
    })(), (() => {
        var e = {
            runtime: 0
        };
        l.f.j = (t, n) => {
            var i = l.o(e, t) ? e[t] : void 0;
            if (0 !== i)
                if (i) n.push(i[2]);
                else if ("runtime" != t) {
                var o = new Promise((n, o) => i = e[t] = [n, o]);
                n.push(i[2] = o);
                var a = l.p + l.u(t),
                    r = new Error;
                l.l(a, n => {
                    if (l.o(e, t) && (0 !== (i = e[t]) && (e[t] = void 0), i)) {
                        var o = n && ("load" === n.type ? "missing" : n.type),
                            a = n && n.target && n.target.src;
                        r.message = "Loading chunk " + t + " failed.\n(" + o + ": " + a + ")", r.name = "ChunkLoadError", r.type = o, r.request = a, i[1](r)
                    }
                }, "chunk-" + t, t)
            } else e[t] = 0
        }, l.O.j = t => 0 === e[t];
        var t = (t, n) => {
                var i, o, [a, r, s] = n,
                    d = 0;
                if (a.some(t => 0 !== e[t])) {
                    for (i in r) l.o(r, i) && (l.m[i] = r[i]);
                    if (s) var c = s(l)
                }
                for (t && t(n); d < a.length; d++) o = a[d], l.o(e, o) && e[o] && e[o][0](), e[o] = 0;
                return l.O(c)
            },
            n = self.webpackChunksmile_ui = self.webpackChunksmile_ui || [];
        n.forEach(t.bind(null, 0)), n.push = t.bind(null, n.push.bind(n))
    })()
})(), (async () => {
    let e, t, n, i, o, a, r = (() => {
            let e = navigator.userAgent;
            return e && e.headers && "string" == typeof e.headers["user-agent"] && (e = e.headers["user-agent"]), "string" == typeof e && (/(android|bb\d+|meego).+mobile|armv7l|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series[46]0|samsungbrowser|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(e) && !/CrOS/.test(e))
        })(),
        l = () => r ? "mobile" : "desktop",
        s = {
            square: 0,
            shaved: 5,
            rounded: 10,
            circular: 30
        },
        d = () => {
            let e = document.getElementById("smile-ui-lite-container");
            e && e.parentNode.removeChild(e)
        },
        c = () => {
            window.SmileUI && window.SmileUI.openPanel({
                data: {
                    trigger: "launcher"
                }
            })
        },
        u = () => {
            e && (clearTimeout(e), e = null), o || a || (o = !0, ["smile-shopify-f5bc8b0403871d87febf.modern.js", "vendor-ac982c9fa2617cb4198f.modern.js"].map(e => window.dispatchEvent(new CustomEvent("smile:load-async-script", {
                detail: e
            }))))
        };
    window.loadSmileSdk = u;
    let [m, p] = await Promise.all([window.__smile_ui_init_data__, window.__smile_ui_customer_data__]);
    const f = m.data;
    if (!((e, t) => {
            if (t && "disabled" === t.customer.state) return !1;
            let n = window.location.pathname,
                i = e.launcher.is_visible,
                o = e.launcher.visibility_setting.includes(l()),
                a = e.launcher.hide_on_index_page && "/" === n,
                r = e.launcher.hidden_url_paths.every(e => -1 === n.indexOf(e));
            return i && o && !a && r
        })(f, p)) return u();
    if ((e => {
            if (!e || e.account.load_js_sdk_at_launch) return !0;
            let n = new URLSearchParams(window.location.search);
            return !!(n.get("smile_deep_link") || n.get("st_intent") || window.location.hash.includes("smile-")) || (!!document.querySelector("[data-smile-deep-link]") || (document.getElementsByClassName("sweettooth-points-balance").length > 0 || (t = (i = e.nudges, o = window.location.pathname, i ? i.filter(function(e) {
                return o.indexOf(e.url_path) > -1
            }) : []).length > 0)));
            var i, o
        })(f)) {
        if (!t) return void u();
        e = setTimeout(u, 5e3)
    } else(() => {
        let e = document.createElement("link").relList,
            t = !!(e && e.supports && e.supports("prefetch"));

        function n(e) {
            let n = document.createElement("link");
            n.href = "https://js.smile.io/v1/" + e, n.setAttribute("crossorigin", ""), t ? n.rel = "prefetch" : (n.rel = "preload", n.as = "script"), document.querySelector("head").appendChild(n)
        }
        n("smile-shopify-f5bc8b0403871d87febf.modern.js"), n("vendor-ac982c9fa2617cb4198f.modern.js")
    })();
    window.addEventListener("hashchange", e => {
        new URL(e.newURL).hash.startsWith("#smile-") && (u(), a ? d() : i = !0)
    }), (e => {
        let {
            display_setting: t,
            launcher: o
        } = e, m = `smile_ui_${l()}_`, p = `border:0;outline:0;position:fixed;height:60px;z-index:0;overflow:hidden;box-shadow:0 0 25px 0 rgb(0 0 0 / 5%);${t[`${m}position`]}:${t[`${m}side_margin`]};bottom:${t[`${m}bottom_margin`]};border-radius:${s[o.border_radius_style]}px !important;`, f = document.createRange().createContextualFragment('<div id="smile-ui-lite-container"style="position:fixed;width:0;height:0;bottom:0;right:0;z-index:2147483647"aria-live="polite"><style>@keyframes smileLiteFadeInOut{from{opacity:0;transform:scale(.8)}to{opacity:1;transform:scale(1)}}#smile-ui-lite-launcher-frame-container{animation:smileLiteFadeInOut .2s ease-in-out!important;animation-delay:150ms!important;animation-fill-mode:forwards!important;transition:all .2s ease-in-out!important;opacity:0}#smile-ui-lite-launcher-frame-container.smile-improved-mobile-launcher{height:44px!important}</style><div id="smile-ui-lite-launcher-frame-container"><iframe title="Button to open loyalty program pop-up"id="smile-lite-launcher-frame"style="position:absolute;height:0;max-height:100%;max-width:100%;min-height:100%;min-width:100%;width:0;border:0;outline:0;top:0;right:0;bottom:0;left:0"></iframe></div></div>');
        f.getElementById("smile-ui-lite-launcher-frame-container").style.cssText = p, document.body.appendChild(f), (e => {
            let {
                launcher: t,
                account: o
            } = e, l = r && "text" === t.mobile_layout || !r && t.layout.includes("text"), m = r && "text" !== t.mobile_layout || !r && ("image" === t.layout || "text_and_icon" === t.layout), p = r && o.uses_improved_mobile_launcher ? "smile-improved-mobile-launcher" : "", f = r && o.uses_improved_mobile_launcher ? t.mobile_text : t.text, h = m && !l && !(r && o.uses_improved_mobile_launcher), b = "<!doctypehtml><html lang=\"en-US\"><head><meta charset=\"utf-8\"><meta content=\"width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no\"name=\"viewport\"><style>@font-face{font-family:'Proxima Nova';font-style:normal;font-weight:400;font-display:swap;src:local('Proxima Nova'),url('https://js.smile.io/v1/assets/fonts/proximanova-regular.woff2') format('woff2'),url('https://js.smile.io/v1/assets/fonts/proximanova-regular.woff') format('woff');unicode-range:U+000-5FF}*,::after,::before{box-sizing:border-box}:root{-moz-tab-size:4;tab-size:4}body,html{height:100%}html{line-height:1.15;-webkit-text-size-adjust:100%}body{margin:0;font-family:'Proxima Nova',arial,sans-serif;font-size:14px}button::-moz-focus-inner{border-style:none;padding:0}button:-moz-focusring{outline:1px dotted ButtonText}button{font-family:inherit;margin:0;text-transform:none;-webkit-appearance:button;height:60px;max-height:60px;line-height:30px;min-width:60px;display:inline-flex;align-items:center;position:fixed;bottom:0;text-align:center;font-size:16px;padding:15px 20px;border:none;outline:0;user-select:none;cursor:pointer;white-space:nowrap}button.smile-improved-mobile-launcher{height:44px;min-width:44px;padding:12px}button img{width:30px;height:30px}button.smile-improved-mobile-launcher img{width:20px;height:20px}button img+span{margin-left:12px}button:focus{position:relative}.close-icon{background-image:url(\"data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20'%3E%3Cpath fill='%23FFF' fill-rule='nonzero' d='M11.06 10l3.713 3.712a.75.75 0 0 1-1.06 1.061L10 11.061l-3.712 3.712a.75.75 0 0 1-1.061-1.06L8.939 10 5.227 6.288a.75.75 0 1 1 1.06-1.061L10 8.939l3.712-3.712a.75.75 0 0 1 1.061 1.06L11.061 10z'/%3E%3C/svg%3E\");height:26px;width:26px;padding:6px;margin:17px;position:absolute;top:0;right:0;left:0;bottom:0;background-size:100%;background-repeat:no-repeat;background-position:50%}</style><title>Button to open loyalty program pop-up</title></head><body></body></html>".replace("</body>", `<button aria-label="Open Smile.io Rewards Program" class="${p}" style="background-color:${t.color};color:${t.text_color};border-radius:${s[t.border_radius_style]}px;${h?"padding:15px":""}">\n        ${(m?`<img src="${t.icon_url}?color=${encodeURIComponent(t.text_color)}" role="presentation" alt="">`:"")+(l?`<span>${f}</span>`:"")}\n      </button></body>`), g = e.display_setting && e.display_setting.customer_locale;
            g && b.replace('lang="en-US"', `lang="${g}"`);
            let y = document.getElementById("smile-lite-launcher-frame");
            y.addEventListener("load", () => {
                let e = y.contentDocument.querySelector("button"),
                    t = document.getElementById("smile-ui-lite-launcher-frame-container");
                t.style.width = `${e.offsetWidth}px`, p && t.classList.add(p), e.addEventListener("click", () => {
                    u(), a ? (c(), d()) : (n = !0, i = !0)
                }, {
                    once: !0
                })
            }), y.srcdoc = b
        })(e), document.addEventListener("smile-ui-loaded", () => {
            new MutationObserver(function(e, t) {
                e.find(e => e.addedNodes && Array.from(e.addedNodes).find(e => e.childNodes && Array.from(e.childNodes).find(e => "smile-ui-container" === e.id))) && (a = !0, n && c(), i && d(), t.disconnect())
            }).observe(document.body, {
                attributes: !1,
                childList: !0,
                subtree: !0
            })
        })
    })(f), document.dispatchEvent(new Event("smile-lite-loaded"))
})();