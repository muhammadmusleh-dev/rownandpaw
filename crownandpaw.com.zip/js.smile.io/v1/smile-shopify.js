function loadSmileScript(e, t) {
    var i = document,
        n = i.createElement("script");
    n.async = !1, n.defer = !0, n.src = "https://js.smile.io/v1/" + e, t ? n.type = "module" : n.setAttribute("nomodule", ""), i.querySelector("head").appendChild(n)
}
window.__REACT_INTL_BYPASS_GLOBAL_CONTEXT__ = !0, "noModule" in document.createElement("script") || loadSmileScript("runtime-e0969da0a6b2401c264f.legacy.js", !1),
    function() {
        var e = document.querySelector(".smile-shopify-init");
        if ("fetch" in window && e) {
            var {
                channelKey: t,
                digest: i,
                customerAcceptsMarketing: n,
                customerEmail: a,
                customerFirstName: o,
                customerId: s,
                customerLastName: r,
                customerOrdersCount: c,
                customerTags: l,
                customerTotalSpent: m
            } = e.dataset, d = function() {
                var e = "smile_ncet",
                    t = new URLSearchParams(window.location.search).has("smile_no_cache"),
                    i = (new Date).getTime();
                try {
                    t && sessionStorage.setItem(e, (i + 9e5).toString());
                    var n = sessionStorage.getItem(e);
                    n && ((t = Number.parseInt(n) > i) || sessionStorage.removeItem(e))
                } catch (e) {}
                return t
            }(), u = {
                Accept: "application/json",
                "Smile-Channel-Key": t,
                "Smile-Client": "smile-ui",
                "Content-Type": "application/json",
                "X-Smile-Language": window.Shopify ? window.Shopify.locale : null
            }, p = new URL("https://platform.smile.io/smile_ui/init");
            p.searchParams.append("channel_key", t), d && p.searchParams.append("no_cache", d), window.__smile_ui_init_data__ = fetch(p.toString(), {
                headers: u
            }).then(function(e) {
                return e.json().then(function(t) {
                    return {
                        data: t,
                        headers: e.headers
                    }
                })
            }), i && (window.__smile_ui_customer_data__ = fetch("https://platform.smile.io/smile_ui/shopify/identify_customer", {
                method: "POST",
                headers: u,
                body: JSON.stringify({
                    customer: {
                        accepts_marketing: n,
                        email: a,
                        first_name: o,
                        id: s,
                        last_name: r,
                        orders_count: c,
                        tags: l,
                        total_spent: m
                    },
                    digest: i
                })
            }).then(function(e) {
                return e.json()
            }))
        }
    }(), window.addEventListener("smile:load-async-script", function(e) {
        loadSmileScript(e.detail, !0)
    }), "noModule" in document.createElement("script") ? loadSmileScript("smile-lite-e8d16072fe.js", !0) : (loadSmileScript("smile-shopify-f5bc8b0403871d87febf.modern.js", !0), loadSmileScript("vendor-ac982c9fa2617cb4198f.modern.js", !0), loadSmileScript("smile-shopify-ca370ec7d08485319fff.legacy.js", !1), loadSmileScript("vendor-5ac40c9bd8f52765b4d1.legacy.js", !1));