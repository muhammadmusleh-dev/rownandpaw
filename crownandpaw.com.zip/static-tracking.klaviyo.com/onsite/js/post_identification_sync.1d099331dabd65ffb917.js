(self.webpackChunk_klaviyo_onsite_modules = self.webpackChunk_klaviyo_onsite_modules || []).push([
    [7327], {
        61595: function(e, t, n) {
            "use strict";
            var a = n(15957);
            const r = "kl-post-identification-sync",
                i = JSON.stringify([]),
                s = () => {
                    try {
                        if ("undefined" != typeof localStorage && null !== localStorage) return localStorage
                    } catch (e) {}
                    return null
                },
                o = e => {
                    const t = s();
                    if (t) try {
                        t.setItem(r, JSON.stringify(e))
                    } catch (t) {
                        if (t instanceof Error && "QuotaExceededError" === t.name) {
                            if (0 === e.length) return;
                            e.shift(), o(e)
                        }
                    }
                },
                c = (e, t) => {
                    (e => {
                        const t = s();
                        if (!t) return;
                        const n = t.getItem(r),
                            a = null === n ? [] : JSON.parse(n);
                        a.push(e), o(a)
                    })(e), t && t()
                },
                l = (e = 1e3) => (async e => {
                    const t = s();
                    if (!t) return {
                        events: [],
                        deleteCallback: async () => {}
                    };
                    const n = JSON.parse(t.getItem(r) || i),
                        a = n.slice(0, e),
                        o = n.slice(e);
                    return {
                        events: a || [],
                        deleteCallback: async () => {
                            t.setItem(r, JSON.stringify(o))
                        }
                    }
                })(e),
                u = () => (() => {
                    const e = s();
                    e && e.removeItem(r)
                })(),
                d = (e, t) => {
                    var n;
                    const a = (new Date).toISOString(),
                        r = {
                            name: e.event,
                            time: (null == (n = e.properties) ? void 0 : n.time) || a,
                            properties: e.properties || {}
                        };
                    c(r, t)
                };
            var p = n(5645),
                f = n.n(p),
                m = (n(92461), n(44159), n(60873), n(72626)),
                h = n(24745),
                v = n(39586),
                y = n(32269);
            n(70917), n(93677), n(84304), n(75723), n(20696), n(38528), n(72418);
            const b = new Set(["$exchange_id", "email", "id", "$email", "$id", "$anonymous", "$phone_number"]),
                g = ["name", "properties"];
            let _ = !1;
            const k = (e, t, n, a, r) => {
                    const i = ((e, t, n, a) => ({
                        data: {
                            type: "event-bulk-create",
                            attributes: {
                                profile: {
                                    data: {
                                        type: "profile",
                                        attributes: Object.assign({}, t)
                                    }
                                },
                                events: {
                                    data: e.map((e => {
                                        const {
                                            name: t,
                                            properties: a
                                        } = e, r = f()(e, g), i = Object.assign({}, a, n || {}), s = i.service;
                                        delete i.service;
                                        const o = "klaviyo" === s ? {
                                            name: t,
                                            service: s
                                        } : {
                                            name: t
                                        };
                                        return {
                                            type: "event",
                                            attributes: Object.assign({
                                                metric: {
                                                    data: {
                                                        type: "metric",
                                                        attributes: o
                                                    }
                                                }
                                            }, r, {
                                                properties: i
                                            })
                                        }
                                    }))
                                }
                            },
                            relationships: a
                        }
                    }))(e, n, a, r);
                    return (0, h.W)((() => ((e, t) => fetch(`https://a.klaviyo.com/client/event-bulk-create/?company_id=${e}`, {
                        method: "POST",
                        headers: Object.assign({
                            "Access-Control-Allow-Headers": "*",
                            "Content-Type": "application/json"
                        }, (0, m.h)(), {
                            revision: "2025-01-15"
                        }),
                        body: JSON.stringify(t)
                    }))(t, i)), 5, 1e3 + 1e3 * Math.random(), [429])
                },
                w = {
                    $exchange_id: "_kx",
                    email: "email",
                    $email: "email",
                    $phone_number: "phone_number",
                    phone_number: "phone_number",
                    $id: "external_id",
                    id: "id",
                    $kid: "id",
                    $anonymous: "anonymous_id"
                },
                O = e => {
                    let t = {};
                    return Object.keys(w).forEach((n => {
                        if (a = n, !Set.prototype.has.call(b, a)) return;
                        var a;
                        const r = e[n];
                        if (!r) return;
                        const i = ("$email" === n || "email" === n) && !(0, v.v)(r),
                            s = "$phone_number" === n && !(0, y.y)(r);
                        i || s || (t = Object.assign({}, t, {
                            [w[n]]: r
                        }))
                    })), t
                },
                S = async (e, t, n, a, r) => {
                    if (0 === e.events.length) return;
                    const i = await k(e.events, t, n, a, r);
                    if (429 === i.status && console.warn(`KL: Saving event cache due to rate limit. Status: ${i.status}`), i.status >= 500) throw new Error(`Saving event cache due to failed request. Status: ${i.status}`);
                    await (null == e || null == e.deleteCallback ? void 0 : e.deleteCallback());
                    const s = await l();
                    return S(s, t, n, a, r)
                },
                $ = async (e, t, n, a, r) => {
                    const i = e || window.__klKey;
                    if (!i || _) return;
                    const s = O(t);
                    if (s && 0 !== Object.keys(s).length) {
                        _ = !0;
                        try {
                            const e = await l();
                            await S(e, i, s, n, r), u(), null == a || a()
                        } catch (e) {
                            if (e instanceof Error) throw e;
                            throw new Error("Failed to send bulk events")
                        } finally {
                            _ = !1
                        }
                    }
                };
            (() => {
                (0, a.e)("cacheEvent", d), (0, a.e)("sendCachedEvents", $)
            })()
        },
        5645: function(e) {
            e.exports = function(e, t) {
                if (null == e) return {};
                var n = {};
                for (var a in e)
                    if ({}.hasOwnProperty.call(e, a)) {
                        if (-1 !== t.indexOf(a)) continue;
                        n[a] = e[a]
                    }
                return n
            }, e.exports.__esModule = !0, e.exports.default = e.exports
        }
    },
    function(e) {
        e.O(0, [2462], (function() {
            return t = 61595, e(e.s = t);
            var t
        }));
        e.O()
    }
]);