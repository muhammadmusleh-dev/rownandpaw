Searchanise = window.Searchanise || {};
Searchanise.templates = {
    Platform: 'shopify',
    StoreName: 'Crown & Paw',
    AutocompleteLayout: 'multicolumn_new',
    AutocompleteStyle: 'ITEMS_MULTICOLUMN_LIGHT_NEW',
    AutocompleteShowMobileWidget: 'N',
    AutocompleteShowMoreLink: 'Y',
    AutocompleteIsMulticolumn: 'Y',
    AutocompleteTemplate: '<div class="snize-ac-results-content"><div class="snize-results-html" style="cursor:auto;" id="snize-ac-results-html-container"></div><div class="snize-ac-results-columns"><div class="snize-ac-results-column"><ul class="snize-ac-results-list" id="snize-ac-items-container-1"></ul><ul class="snize-ac-results-list" id="snize-ac-items-container-2"></ul><ul class="snize-ac-results-list" id="snize-ac-items-container-3"></ul><ul class="snize-ac-results-list snize-view-all-container"></ul></div><div class="snize-ac-results-column"><ul class="snize-ac-results-multicolumn-list" id="snize-ac-items-container-4"></ul></div></div></div>',
    AutocompleteMobileTemplate: '<div class="snize-ac-results-content"><div class="snize-mobile-top-panel"><div class="snize-close-button"><button type="button" class="snize-close-button-arrow"></button></div><form action="#" style="margin: 0px"><div class="snize-search"><input id="snize-mobile-search-input" autocomplete="off" class="snize-input-style snize-mobile-input-style"></div><div class="snize-clear-button-container"><button type="button" class="snize-clear-button" style="visibility: hidden"></button></div></form></div><ul class="snize-ac-results-list" id="snize-ac-items-container-1"></ul><ul class="snize-ac-results-list" id="snize-ac-items-container-2"></ul><ul class="snize-ac-results-list" id="snize-ac-items-container-3"></ul><ul id="snize-ac-items-container-4"></ul><div class="snize-results-html" style="cursor:auto;" id="snize-ac-results-html-container"></div><div class="snize-close-area" id="snize-ac-close-area"></div></div>',
    AutocompleteItem: '<li class="snize-product ${product_classes}" data-original-product-id="${original_product_id}" id="snize-ac-product-${product_id}"><a href="${autocomplete_link}" class="snize-item" draggable="false"><div class="snize-thumbnail"><img src="${image_link}" class="snize-item-image ${additional_image_classes}" alt="${autocomplete_image_alt}"></div><span class="snize-title">${title}</span><span class="snize-description">${description}</span>${autocomplete_product_code_html}${autocomplete_product_attribute_html}${autocomplete_prices_html}${reviews_html}<div class="snize-labels-wrapper">${autocomplete_in_stock_status_html}${autocomplete_product_discount_label}${autocomplete_product_tag_label}${autocomplete_product_custom_label}</div></a></li>',
    AutocompleteMobileItem: '<li class="snize-product ${product_classes}" data-original-product-id="${original_product_id}" id="snize-ac-product-${product_id}"><a href="${autocomplete_link}" class="snize-item"><div class="snize-thumbnail"><img src="${image_link}" class="snize-item-image ${additional_image_classes}" alt="${autocomplete_image_alt}"></div><div class="snize-product-info"><span class="snize-title">${title}</span><span class="snize-description">${description}</span>${autocomplete_product_code_html}${autocomplete_product_attribute_html}<div class="snize-ac-prices-container">${autocomplete_prices_html}</div><div class="snize-labels-wrapper">${autocomplete_in_stock_status_html}${autocomplete_product_discount_label}${autocomplete_product_tag_label}${autocomplete_product_custom_label}</div>${reviews_html}</div></a></li>',
    ResultsShow: 'Y',
    ResultsStyle: 'RESULTS_BIG_PICTURES_NEW',
    ShowBestsellingSorting: 'Y',
    ShowDiscountSorting: 'Y',
    CategorySortingRule: "searchanise",
    ShopifyMarketsSupport: 'Y',
    ShopifyLocales: {
        "en": {
            "locale": "en",
            "name": "English",
            "primary": true,
            "published": true
        }
    },
    StickySearchboxShow: 'N'
}