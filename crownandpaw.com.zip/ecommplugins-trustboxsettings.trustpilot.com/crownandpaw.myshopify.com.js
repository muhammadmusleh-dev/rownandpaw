const trustpilot_trustbox_settings = {
    "trustboxes": [],
    "activeTrustbox": 0,
    "pageUrls": {
        "landing": "https://crownandpaw.myshopify.com",
        "category": "https://crownandpaw.myshopify.com/collections/early-access",
        "product": "https://crownandpaw.myshopify.com/products/crown-paw-gift-card"
    }
};
dispatchEvent(new CustomEvent('trustpilotTrustboxSettingsLoaded'));