! function() {
    if (window.UploadKit = window.UploadKit || {}, !(window.UploadKit.clientLoaded || window.UploadKit.config && window.UploadKit.config.v2)) {
        if (window.UploadKit.clientLoaded = !0, window.UploadKit = window.UploadKit || {}, !document.querySelector("script[src*='uploadkit-app.js']") && document.querySelector("div.uploadkit")) {
            window.UploadKit.runImmediately = !0;
            var t = document.createElement("script");
            t.async = !0, t.src = "https://assets.getuploadkit.com/assets/uploadkit-app.js", document.head.appendChild(t)
        }
        window.UploadKit.scanAttributes = window.UploadKit.scanAttributes || function() {
            function t() {
                return NodeFilter.FILTER_ACCEPT
            }

            function e(t, e, a, o, n) {
                return n ? '<a href="https://cdn.getuploadkit.com/' + e + "/" + a + '-/preview/1200x1200" class="uploadkit-preview-link-image" title="' + atob(o) + '"><img src="https://cdn.getuploadkit.com/' + e + "/" + a + '-/resize/300x/" style="max-width: 50px; max-height: 50px; vertical-align: middle;" /></a>' : '<a href="https://cdn.getuploadkit.com/' + e + '/" class="uploadkit-preview-link" target="_blank">' + atob(o) + "</a>"
            }
            var a = new RegExp("https:\\/\\/cdn2?\\.shopify\\.com(?:-?uploadkit\\.(?:app|com))?\\/.*\\?.*id=[^&]*&uu=([^&]*)&mo=([^&]*)&fi=([^&]*)(?:(?!&image).)*(&image=true)?", "g"),
                o = t;
            o.acceptNode = t;
            for (var n = document.createTreeWalker(document.body, NodeFilter.SHOW_ALL, o, !1), i = []; n.nextNode();) {
                var r = n.currentNode;
                if (a.lastIndex = 0, 3 === r.nodeType && a.exec(r.textContent) && i.push(r), window.UploadKit.config && window.UploadKit.config.uploaders && 3 === r.nodeType && r.textContent.indexOf("_") > -1)
                    for (var d = 0; d < window.UploadKit.config.uploaders.length; d++) r.textContent = r.textContent.replace("_" + window.UploadKit.config.uploaders[d].name, window.UploadKit.config.uploaders[d].name)
            }
            for (var d = 0; d < i.length; d++) {
                var r = i[d];
                a.lastIndex = 0;
                if (a.exec(r.textContent)) {
                    var s = document.createElement("span");
                    s.innerHTML = r.textContent.replace(a, e), r.parentNode.insertBefore(s, r), r.parentNode.removeChild(r)
                }
            }
            if (i.length > 0) {
                var p = document.createElement("link");
                p.type = "text/css", p.rel = "stylesheet", p.href = "https://assets.getuploadkit.com/assets/luminous.css", document.head.appendChild(p);
                var l = document.createElement("script");
                l.type = "text/javascript", l.async = !0, l.src = "https://assets.getuploadkit.com/assets/luminous.js", document.head.appendChild(l), l.onload = function() {
                    new LuminousGallery(document.querySelectorAll("a.uploadkit-preview-link-image"))
                }
            }
        }, window.UploadKit.attributesScanned || (window.UploadKit.attributesScanned = !0), window.UploadKit.skipScanAttributes || window.UploadKit.scanAttributes()
    }
}();
var body = document.querySelector("body"),
    isAndroidUploadKit = navigator.userAgent.match(/android/i);
isAndroidUploadKit && (body.className = body.className + " android");
var isInstagramUploadKit = navigator.userAgent.match(/instagram/i);
isInstagramUploadKit && (body.className = body.className + " instagram-app");
var isFacebookUploadKit = navigator.userAgent.match(/FBAN|FBAV/i);
isFacebookUploadKit && (body.className = body.className + " facebook-app");
var isSnapchatUploadKit = navigator.userAgent.match(/snapchat/i);
isSnapchatUploadKit && (body.className = body.className + " snapchat-app"),
    function(t) {
        "use strict";
        if (!window.UploadKit || !1 !== window.UploadKit.EXTEND_XHR) {
            var e = t.prototype.open,
                a = t.prototype.send;
            t.prototype.open = function(t, a, o, n, i) {
                this._url = a, e.apply(this, arguments)
            }, t.prototype.send = function(t) {
                function e() {
                    4 == n.readyState && this._url && this._url.indexOf("/cart") > -1 && (setTimeout(function() {
                        window.UploadKit && window.UploadKit.scanAttributes && window.UploadKit.scanAttributes()
                    }, 200), window.UploadKit && window.UploadKit.callbacks && window.UploadKit.callbacks.afterCartRequest && window.UploadKit.callbacks.afterCartRequest.call(this)), o && o()
                }
                var o, n = this;
                this._url;
                this.noIntercept || (this.addEventListener ? this.addEventListener("readystatechange", e, !1) : (o = this.onreadystatechange, this.onreadystatechange = e)), a.call(this, t)
            }
        }
    }(XMLHttpRequest), window.UploadKit && window.UploadKit.enableUploadKitQuantities ? function(t) {
        var e = t;
        window.fetch = function() {
            function t(t) {
                for (var e = t.split("&"), a = [], o = 0; o < e.length; o++) {
                    var n = e[o].split("="),
                        i = decodeURIComponent(n[0]),
                        r = decodeURIComponent(n[1] || "");
                    a.push({
                        key: i,
                        value: r
                    })
                }
                return a
            }
            var a, o = this,
                n = arguments[0],
                i = arguments[1] || {},
                r = arguments;
            n && "function" == typeof n.toString && (a = n.toString()), n && "string" == typeof n.url && (a = n.url);
            var d = (i.method || "GET").toUpperCase();
            n instanceof Request && (d = n.method);
            var s = function() {
                var t = e.apply(o, r);
                return a && a.indexOf("/cart") > -1 && t.then(function() {
                    setTimeout(function() {
                        window.UploadKit && window.UploadKit.scanAttributes && window.UploadKit.scanAttributes()
                    }, 200)
                }), t
            };
            if (a && a.indexOf("/cart/add") > -1 && "POST" === d) {
                console.log("*1");
                var p = function(t) {
                    console.log("*2");
                    for (var a = !1, r = 0; r < t.length; r++) {
                        var p = t[r].key;
                        if (/^properties\[_uploadkit_qty_.*\]/.test(p)) {
                            a = !0;
                            break
                        }
                    }
                    if (console.log("hasUploadkitQtyFields", a), !a) return s();
                    for (var l = null, c = [], r = 0; r < t.length; r++) {
                        var p = t[r].key,
                            u = t[r].value;
                        "id" === p ? l = u : "quantity" === p ? u : c.push(t[r])
                    }
                    for (var w = [], h = [], r = 0; r < c.length; r++) {
                        var p = c[r].key,
                            u = c[r].value,
                            f = p.match(/^properties\[_uploadkit_qty_(.*)\]$/);
                        if (f) {
                            var m = f[1],
                                y = u;
                            w.push({
                                key: p,
                                hexValue: m,
                                qtyValue: y
                            })
                        } else h.push(c[r])
                    }
                    for (var v = [], g = 0; g < w.length; g++) {
                        for (var U = w[g], m = U.hexValue, y = U.qtyValue, K = {
                                id: l,
                                quantity: y,
                                properties: {}
                            }, k = [], r = 0; r < h.length; r++) {
                            var p = h[r].key,
                                u = h[r].value;
                            if (u && -1 !== u.indexOf(m)) {
                                var b = p.match(/^properties\[(.*)\]$/);
                                if (b) {
                                    var x = b[1];
                                    K.properties[x] = u
                                } else k.push(h[r])
                            } else k.push(h[r])
                        }
                        h = k, v.push(K)
                    }
                    for (var C = h, r = 0; r < v.length; r++) {
                        var K = v[r];
                        C.push({
                            key: "items[" + r + "][id]",
                            value: K.id
                        }), C.push({
                            key: "items[" + r + "][quantity]",
                            value: K.quantity
                        });
                        for (var A in K.properties) K.properties.hasOwnProperty(A) && C.push({
                            key: "items[" + r + "][properties][" + A + "]",
                            value: K.properties[A]
                        })
                    }
                    for (var q = "", r = 0; r < C.length; r++) r > 0 && (q += "&"), q += encodeURIComponent(C[r].key) + "=" + encodeURIComponent(C[r].value);
                    var N = {};
                    for (var p in i) i.hasOwnProperty(p) && (N[p] = i[p]);
                    if (N.method = d, N.body = q, N.headers) {
                        var T = !1;
                        for (var S in N.headers)
                            if (N.headers.hasOwnProperty(S) && "content-type" === S.toLowerCase()) {
                                T = !0, N.headers[S] = "application/x-www-form-urlencoded";
                                break
                            }
                        T || (N.headers["Content-Type"] = "application/x-www-form-urlencoded")
                    } else N.headers = {
                        "Content-Type": "application/x-www-form-urlencoded"
                    };
                    var _ = new Request(n instanceof Request ? n.url : n, N);
                    return e.call(o, _)
                };
                if (console.log("*3", a, i.body, i.headers), "string" == typeof i.body && i.headers && (i.headers["Content-Type"] || i.headers["content-type"]) && (i.headers["Content-Type"] || i.headers["content-type"]).indexOf("application/x-www-form-urlencoded") > -1) {
                    var l = t(i.body);
                    return p(l)
                }
                if (n instanceof Request) {
                    var c = n.clone();
                    return c.text().then(function(e) {
                        if ((c.headers.get("Content-Type") || "").toLowerCase().indexOf("application/x-www-form-urlencoded") > -1) {
                            var a = t(e);
                            return p(a)
                        }
                        return s()
                    }).catch(function() {
                        return s()
                    })
                }
                return s()
            }
            return e.apply(o, r)
        }
    }(window.fetch) : function(t) {
        var e = t;
        window.fetch = function() {
            var t, a = e.apply(this, arguments);
            return arguments && arguments[0] && "function" == typeof arguments[0].toString && (t = arguments[0].toString()), arguments && arguments[0] && "string" == typeof arguments[0].url && (t = arguments[0].url), t && t.indexOf("/cart") > -1 && a.then(function() {
                setTimeout(function() {
                    window.UploadKit && window.UploadKit.scanAttributes && window.UploadKit.scanAttributes()
                }, 200)
            }), a
        }
    }(window.fetch);