/** @jsx h */

import { h } from 'preact';

import type { POPUP_VIEWPORT_MODE } from '../../../constants';

import {
    ConsentPopup as Popup, ConsentPopupBackground as Background, ConsentPopupContainer as PopupContainer,
    ConsentPopupTeaser as Teaser
} from '../components';

import { TemplatePage } from './components';

import type { GetPopupAPIResponse, Milliseconds } from '@onetext/api';

type PopupTemplateProps = {
    popup : GetPopupAPIResponse,
    popupViewportMode ?: POPUP_VIEWPORT_MODE,
};

export const PopupTemplate = ({ popup, popupViewportMode } : PopupTemplateProps) : JSX.Element | null => {

    const config = popup.config;
    const teaser = config?.component?.teaser;

    return (
        <PopupContainer
            popup={ { ...popup, config } }
            delay={ config?.behavior?.delay?.popup?.milliseconds as Milliseconds }
            defaultPopupViewportMode={ popupViewportMode }
            autoOpenPopup={ config?.behavior?.autoOpenPopup }
        >
            <Popup
                layout={ config?.style?.layout }
                background={ <Background /> }
            >
                {
                    config?.template?.pages.map((page) => (
                        <TemplatePage page={ page } />
                    ))
                }
            </Popup>
            {
                teaser?.enabled
                    ? (
                        <Teaser
                            customText={ teaser.content }
                        />
                    )
                    : null
            }
        </PopupContainer>
    );
};
