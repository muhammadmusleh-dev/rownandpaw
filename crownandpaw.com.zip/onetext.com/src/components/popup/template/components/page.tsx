/** @jsx h */

import { h } from 'preact';

import { assertUnreachable } from '../../../../lib';
import {
    ConsentPopupButton as Button, ConsentPopupColumn as Column, ConsentPopupCountdown as Countdown,
    ConsentPopupCouponCode as CouponCode, ConsentPopupEmailField as EmailField, ConsentPopupImage as PopupImage,
    ConsentPopupLogo as Logo, ConsentPopupPage as Page, ConsentPopupPaymentForm as PaymentForm,
    ConsentPopupPhoneField as PhoneField, ConsentPopupQuizComponent as Quiz, ConsentPopupScanner as Scanner,
    ConsentPopupSpinner as Spinner, ConsentPopupTerms as Terms, ConsentPopupText as TextContent
} from '../../components';
import { useConsentPopupContext } from '../../context';

import type { PopupTemplatePage, PopupTemplateStackElement } from '@onetext/api';
import { ELEMENT_TYPE } from '@onetext/api';

export type TemplatePageProps = {
    page : PopupTemplatePage,
};

export const TemplatePage = ({ page } : TemplatePageProps) : JSX.Element => {

    const { showScanner } = useConsentPopupContext();

    const renderPageElements = (element : PopupTemplateStackElement) : JSX.Element => {
        switch (element.type) {
            case ELEMENT_TYPE.BUTTON:
                return (
                    <Button
                        overrideStyles={ element.style }
                        level={ element.level }
                        clickAction={ element.clickAction }
                    >
                        { element.content }
                    </Button>
                );

            case ELEMENT_TYPE.TEXT:
                return (
                    <TextContent
                        content={ element.content }
                        overrideStyles={ element.style }
                        size={ element.size }
                    />
                );

            case ELEMENT_TYPE.COUPON_CODE:
                return (
                    <CouponCode
                        content={ element.content }
                        overrideStyles={ element.style }
                    />
                );

            case ELEMENT_TYPE.EMAIL_FIELD:
                return <EmailField overrideStyles={ element.style } />;

            case ELEMENT_TYPE.PHONE_FIELD:
                return <PhoneField overrideStyles={ element.style } />;

            case ELEMENT_TYPE.TERMS:
                return (
                    <Terms
                        overrideStyles={ element.style }
                    />
                );

            case ELEMENT_TYPE.LOGO:
                return <Logo overrideStyles={ element.style } />;

            case ELEMENT_TYPE.IMAGE:
                return (
                    <PopupImage element={ element } />
                );
            case ELEMENT_TYPE.QUIZ:
                return (
                    <Quiz element={ element } />
                );

            case ELEMENT_TYPE.SPINNER:
                return (
                    <Spinner
                        overrideStyles={ element.style }
                    />
                );

            case ELEMENT_TYPE.COUNTDOWN:
                return (
                    <Countdown
                        overrideStyles={ element.style }
                    />
                );
            case ELEMENT_TYPE.PAYMENT_FORM:
                return (
                    <PaymentForm
                        overrideStyles={ element.style }
                    />
                );

            default:
                throw assertUnreachable(element);
        }
    };

    return (
        <Page
            overrideStyles={ page.style }
            openKeyboardOnSubmit>

            {
                showScanner
                    ? (
                        <Scanner />
                    )
                    : page.stacks.map((stack) => {
                        return (
                            <Column overrideStyles={ stack.style }>
                                { stack.elements.map(renderPageElements) }
                            </Column>
                        );

                    })
            }
        </Page>
    );
};
