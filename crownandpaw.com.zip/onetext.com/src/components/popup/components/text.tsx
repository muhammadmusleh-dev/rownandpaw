/** @jsx h */

import { h } from 'preact';

import { BaseText } from '../../base';
import { useConsentPopupContext } from '../context';

import type { PopupCommonStyle, PopupResponsiveStyle, TEXT_SIZE } from '@onetext/api';

type ConsentPopupTextProps = {
    content ?: string,
    overrideStyles ?: PopupResponsiveStyle,
    size ?: TEXT_SIZE,
};

export const ConsentPopupText = ({
    content,
    overrideStyles,
    size
} : ConsentPopupTextProps) : JSX.Element => {
    const { isDesktopMode, popup } = useConsentPopupContext();

    const getStyle = () : PopupCommonStyle => {
        const textConfig = popup.config?.component?.text;

        const elementInlineStyles = {
            ...overrideStyles?.mobile,
            ...isDesktopMode
                ? overrideStyles?.desktop
                : {}
        };

        if (size && textConfig) {
            const responsiveVariantStyle = textConfig.size[size].style;
            const {
                marginBottom, marginTop, marginLeft, marginRight,
                paddingBottom, paddingTop, paddingLeft, paddingRight,
                display
            } = elementInlineStyles;

            return {
                ...responsiveVariantStyle.mobile,
                ...isDesktopMode
                    ? responsiveVariantStyle.desktop
                    : {},
                marginBottom,
                marginTop,
                marginLeft,
                marginRight,
                paddingBottom,
                paddingTop,
                paddingLeft,
                paddingRight,
                display
            };
        }

        return elementInlineStyles;
    };

    return (
        <BaseText
            text={ content }
            style={ getStyle() }
        />
    );
};
