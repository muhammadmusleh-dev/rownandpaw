/** @jsx h */

import { h } from 'preact';

import { isValidEmail } from '../../../lib';
import { useConsentFormContext, useConsentPopupContext } from '../context';

import { ConsentPopupTextField } from './text-field';

import type { PopupResponsiveStyle } from '@onetext/api';

type ConsentPopupEmailFieldProps = {
    autofocus ?: boolean,
    placeholder ?: string,
    submitOnAutoComplete ?: boolean,
    className ?: string,
    overrideStyles ?: PopupResponsiveStyle,
};

export const ConsentPopupEmailField = ({
    autofocus,
    placeholder = 'Email Address',
    submitOnAutoComplete = true,
    className,
    overrideStyles
} : ConsentPopupEmailFieldProps) : JSX.Element => {
    const {
        setEmail,
        email
    } = useConsentPopupContext();

    const {
        submit
    } = useConsentFormContext();

    return (
        <ConsentPopupTextField
            type={ 'email' }
            id={ 'email' }
            name={ 'email' }
            autocomplete={ 'email' }
            autofocus={ autofocus }
            placeholder={ placeholder }
            defaultValue={ email }
            onValue={ setEmail }
            onAutoComplete={
                () => {
                    if (submitOnAutoComplete) {
                        void submit();
                    }
                }
            }
            inputPattern={ /^\S*$/ }
            required={ true }
            isValid={ isValidEmail }
            deformatter={ val => val.trim().toLowerCase() }
            className={ className }
            overrideStyles={ overrideStyles }
        />
    );
};
