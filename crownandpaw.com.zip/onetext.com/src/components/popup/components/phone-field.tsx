/** @jsx h */

import { countryPhoneData, phone as validateInternationalPhone } from 'phone';
import { Fragment, h } from 'preact';
import { useRef, useState } from 'preact/hooks';

import { countryCodeToFlag, isValidPhone, parsePhone, removePhoneCountryCode } from '../../../lib';
import { useConsentFormContext, useConsentPopupContext } from '../context';

import { ConsentPopupTextField } from './text-field';

import type { PopupResponsiveStyle } from '@onetext/api';
import { COUNTRY } from '@onetext/api';

type ConsentPopupPhoneFieldProps = {
    autofocus ?: boolean,
    placeholder ?: string,
    submitOnAutoComplete ?: boolean,
    className ?: string,
    overrideStyles ?: PopupResponsiveStyle,
};

export const ConsentPopupPhoneField = ({
    autofocus,
    placeholder = 'Phone Number',
    submitOnAutoComplete = true,
    className,
    overrideStyles
} : ConsentPopupPhoneFieldProps) : JSX.Element => {
    const {
        setPhoneCandidate,
        phoneCandidate
    } = useConsentPopupContext();

    const [ selectedCountryISOCode, setSelectedCountryISOCode ] = useState<string>(COUNTRY.US);
    const currentInputValue = useRef<string | undefined>(undefined);
    const countrySelectRef = useRef<HTMLSelectElement>(null);

    const {
        submit
    } = useConsentFormContext();

    const defaultLocalPhone = phoneCandidate
        ? removePhoneCountryCode(phoneCandidate.number, selectedCountryISOCode)
        : undefined;

    const getEffectiveCountryCode = () : string => {
        // This function fixes the closure issue by ensuring we always get the current
        // selectedCountryISOCode value instead of the stale value captured in the closure
        // when the callback functions were created.
        return selectedCountryISOCode;
    };

    const parseAndSetPhoneCandidate = (newLocalPhone : string, countryCode : string) : void => {
        const newPhone = parsePhone(newLocalPhone, {
            countryCode
        });

        setPhoneCandidate(newPhone
            ? {
                number: newPhone,
                countryCode
            }
            : undefined);
    };

    const onNewLocalPhone = (newLocalPhone : string | undefined) : void => {
        if (!newLocalPhone) {
            return;
        }

        const countryCode = getEffectiveCountryCode();

        parseAndSetPhoneCandidate(newLocalPhone, countryCode);
    };

    const handleCountryChange = (e : Event) : void => {
        const select = e.currentTarget as HTMLSelectElement;

        const country = countryPhoneData.find((countryInfo) =>
            countryInfo.alpha2 === select.value);

        if (country) {

            const newCountryCode = country.alpha2;

            setSelectedCountryISOCode(newCountryCode);

            if (currentInputValue.current) {
                parseAndSetPhoneCandidate(currentInputValue.current, newCountryCode);
            }

        }
    };

    const isValidLocalPhone = (newLocalPhone : string) : boolean => {
        currentInputValue.current = newLocalPhone;

        const countryCode = getEffectiveCountryCode();

        const parsedPhone = isValidPhone(newLocalPhone, {
            countryCode
        });

        return parsedPhone.isValid;
    };

    const onAutoComplete = () : void => {
        if (submitOnAutoComplete && phoneCandidate) {
            void submit();
        }
    };

    const onAutoCompleteStart = (newPartialLocalPhone : string) : void => {

        const internationalPhone = validateInternationalPhone(newPartialLocalPhone);

        if (internationalPhone.isValid && internationalPhone.countryIso2 !== selectedCountryISOCode) {
            parseAndSetPhoneCandidate(newPartialLocalPhone, internationalPhone.countryIso2);
            setSelectedCountryISOCode(internationalPhone.countryIso2);
        }

    };

    const deformatLocalPhone = (newPartialLocalPhone : string) : string => {
        return newPartialLocalPhone.replace(/\D+/g, '').replace(/^[01]/, '');
    };

    return (

        <ConsentPopupTextField
            type={ 'tel' }
            id={ 'phone' }
            name={ 'phone' }
            autocomplete={ 'tel' }
            autofocus={ autofocus }
            placeholder={ placeholder }
            defaultValue={ defaultLocalPhone }
            onValue={ onNewLocalPhone }
            onAutoComplete={ onAutoComplete }
            onAutoCompleteStart={ onAutoCompleteStart }
            inputPattern={ /^\d*$/ }
            required={ true }
            isValid={ isValidLocalPhone }
            deformatter={ deformatLocalPhone }
            className={ className }
            overrideStyles={ overrideStyles }
            leftContent={
                <Fragment>
                    <div
                        className={ 'flex items-center cursor-pointer gap-1' }
                        onClick={
                            () => {
                                const select = countrySelectRef.current;

                                if (select) {
                                    select.focus();
                                    select.blur();

                                    try {
                                        select.showPicker();
                                    } catch {
                                        select.click();
                                    }

                                }
                            }
                        }>
                        <span className={ 'text-2xl' }>
                            { countryCodeToFlag(selectedCountryISOCode) }
                        </span>

                        <span className={ 'text-black' }>&#x25BE;</span>
                    </div>
                    <select
                        className={ 'size-0.5 opacity-0' }
                        value={ selectedCountryISOCode }
                        ref={ countrySelectRef }
                        onChange={ handleCountryChange }>
                        {
                            countryPhoneData.map((country) => (
                                <option
                                    key={ country.alpha2 }
                                    value={ country.alpha2 }
                                >
                                    { country.country_name }
                                </option>
                            ))
                        }
                    </select>
                </Fragment>

            }
        />
    );
};
