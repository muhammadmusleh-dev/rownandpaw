/** @jsx h */

import { h } from 'preact';
import { useEffect, useState } from 'preact/hooks';

import { BaseCouponCode } from '../../base';
import { useConsentPopupContext } from '../context';

import type { PopupResponsiveStyle } from '@onetext/api';
import { DISCOUNT_TYPE } from '@onetext/api';

type ConsentPopupCouponCodeProps = {
    content : string,
    overrideStyles ?: PopupResponsiveStyle,
};

export const ConsentPopupCouponCode = ({
    content,
    overrideStyles
} : ConsentPopupCouponCodeProps) : JSX.Element => {
    const { isDesktopMode, setCouponCode } = useConsentPopupContext();
    const [ isCopied, setIsCopied ] = useState(false);

    const handleCopy = async () : Promise<void> => {
        await navigator.clipboard.writeText(content);
        setIsCopied(true);

        setTimeout(() => {
            setIsCopied(false);
        }, 2000);
    };

    useEffect(() => {
        setCouponCode({
            type: DISCOUNT_TYPE.CODE,
            code: content
        });
    }, []);

    return (
        <BaseCouponCode
            text={
                isCopied
                    ? 'Copied!'
                    : content
            }
            handleCopy={ handleCopy }
            style={
                {
                    ...overrideStyles?.mobile,
                    ...isDesktopMode
                        ? overrideStyles?.desktop
                        : {}
                }
            }
        />
    );
};
