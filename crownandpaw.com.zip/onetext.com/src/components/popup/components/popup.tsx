/** @jsx h */

import type { ComponentChildren } from 'preact';

import { h } from 'preact';
import { useEffect } from 'preact/hooks';

import { trackBuyerEvent } from '../../../biz';
import { track } from '../../../lib';
import { BasePopup } from '../../base';
import { Dialog } from '../../dialog';
import { useConsentPopupContext } from '../context';

import { CloseButton } from './close-button';

import { MODAL_TYPE, POPUP_LAYOUT, PUBLIC_BUYER_EVENT } from '@onetext/api';

type ConsentPopupProps = {
    children ?: ComponentChildren,
    layout ?: POPUP_LAYOUT,
    background ?: JSX.Element,
    overlayClassName ?: string,
    modalClassName ?: string,
};

export const ConsentPopup = ({
    children,
    layout = POPUP_LAYOUT.MODAL,
    background,
    overlayClassName,
    modalClassName
} : ConsentPopupProps) : JSX.Element | null => {
    const {
        accountToken,
        activePageID,
        isPopupOpen,
        honeypot,
        setHoneypot,
        suppressPopup,
        popup
    } = useConsentPopupContext();

    const closeButtonConfig = popup.config?.component?.closeButton;

    useEffect(() => {
        if (activePageID) {
            const EVENT_NAME = 'consent_popup_page_render';

            track(EVENT_NAME, {
                activePageID
            });

            trackBuyerEvent(
                {
                    buyerEvent: PUBLIC_BUYER_EVENT.POPUP_PAGE_RENDER,
                    payload:    {
                        popupToken:       popup.token,
                        activePageNumber: activePageID
                    }
                }
            );
        }
    }, [ activePageID, popup ]);

    useEffect(() => {
        track('consent_popup_init', {
            accountToken
        });

        if (suppressPopup.suppressed) {
            track('consent_popup_suppress', {
                reason: suppressPopup.reason
            });
        } else {
            track('consent_popup_render', {
                accountToken
            });
        }
    }, [ suppressPopup.suppressed ]);

    if (!isPopupOpen || suppressPopup.suppressed) {
        return null;
    }

    return (
        <Dialog>
            <BasePopup
                closeButton={
                    <CloseButton
                        type={ MODAL_TYPE.POPUP }
                        overrideStyles={ closeButtonConfig?.style }
                    />
                }
                background={ background }
                layout={ layout }
                overlayClassName={ overlayClassName }
                modalClassName={ modalClassName }
                config={ popup.config }
            >
                <input
                    type={ 'text' }
                    name={ 'website' }
                    autoComplete={ 'off' }
                    tabIndex={ -1 }
                    style={
                        {
                            position:      'absolute',
                            left:          '-9999px',
                            opacity:       0,
                            pointerEvents: 'none',
                            width:         '1px',
                            height:        '1px'
                        }
                    }
                    value={ honeypot }
                    onChange={
                        (e) => {
                            const target = e.target as HTMLInputElement;
                            setHoneypot(target.value);
                        }
                    }
                    aria-hidden={ 'true' }
                />
                { children }
            </BasePopup>
        </Dialog>
    );
};
