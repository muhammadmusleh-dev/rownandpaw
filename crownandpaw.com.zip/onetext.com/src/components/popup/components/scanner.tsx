/** @jsx h */

import { h } from 'preact';
import QRCode from 'react-qr-code';

import { useConsentPopupContext } from '../context';

import { ConsentPopupButton as Button } from './button';
import { ConsentPopupText as TextContent } from './text';

import { TEXT_SIZE } from '@onetext/api';

export const ConsentPopupScanner = () : JSX.Element | null => {

    const { tapToTextLink } = useConsentPopupContext();

    if (!tapToTextLink) {
        return null;
    }

    return (
        <div
            className={ 'flex items-center flex-col justify-center gap-4' }>
            <TextContent
                content={ 'Scan to continue' }
                size={ TEXT_SIZE.LG }
            />
            <TextContent
                content={ 'Point your camera at the QR code below' }
                size={ TEXT_SIZE.SM }
            />
            <div className={ 'bg-white rounded-lg p-4 border border-gray-200 shadow-md' }>
                <QRCode
                    value={ tapToTextLink }
                    bgColor={ '#ffffff' }
                    fgColor={ '#000000' }
                    size={ 250 }
                />
            </div>
            <Button>
                { 'Continue' }
            </Button>
        </div>
    );
};
