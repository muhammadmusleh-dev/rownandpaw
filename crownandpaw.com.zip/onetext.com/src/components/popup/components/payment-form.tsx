/** @jsx h */
import { h } from 'preact';
import { useEffect, useMemo, useState } from 'preact/hooks';

import { getStoredAccountToken } from '../../../biz';
import { getSDKAccountToken, isDevelopment, isEditorMode, isPreviewMode } from '../../../lib';
import { BasePaymentForm } from '../../base';
import { useConsentPopupContext } from '../context';

import type { PopupResponsiveStyle } from '@onetext/api';

const TRUSTED_ORIGINS = new Set([
    'https://localhost.onetext.com:8443',
    'https://onetext.com',
    'https://sandbox.onetext.com'
]);

enum IFRAME_MESSAGE_TYPE {
    CARD_VAULT_SUCCESS = 'CARD_VAULT_SUCCESS',
    CARD_VAULT_ERROR = 'CARD_VAULT_ERROR'
}

type IframeMessage = {
    type : IFRAME_MESSAGE_TYPE,
};

type ConsentPopupPaymentFormProps = {
    overrideStyles ?: PopupResponsiveStyle,
};

const DEMO_VISITOR_TOKEN = 'demo_visitor_token';
const DEMO_MERCHANT_TOKEN = 'demo_merchant_token';

export const ConsentPopupPaymentForm = ({ overrideStyles } : ConsentPopupPaymentFormProps) : JSX.Element => {

    const { isDesktopMode, submitPage, popup } = useConsentPopupContext();
    const [ isLoading, setIsLoading ] = useState(true);
    const [ hasError, setHasError ] = useState(false);

    const isInTestMode = isDevelopment() || isPreviewMode() || isEditorMode();
    const brandName = popup.config?.component?.terms?.brandName;

    const visitorAccountToken = isInTestMode
        ? DEMO_VISITOR_TOKEN
        : getStoredAccountToken();

    const hostAccountToken = isInTestMode
        ? DEMO_MERCHANT_TOKEN
        : getSDKAccountToken();

    const iframeMessageHandler = (event : MessageEvent<IframeMessage>) : void => {
        if (!TRUSTED_ORIGINS.has(event.origin)) {
            return;
        }

        const message = event.data;

        if (message.type === IFRAME_MESSAGE_TYPE.CARD_VAULT_SUCCESS) {
            void submitPage();
        }
    };

    const handleIframeLoad = () : void => {
        setIsLoading(false);
        setHasError(false);
    };

    const handleIframeError = () : void => {
        setIsLoading(false);
        setHasError(true);
    };

    useEffect(() => {
        if (!visitorAccountToken || !hostAccountToken) {
            // If the account token is not found, we need to submit the page
            // to avoid the popup from being stuck on the payment form page
            void submitPage();
        }

        window.addEventListener('message', iframeMessageHandler);

        return () => {
            window.removeEventListener('message', iframeMessageHandler);
        };
    }, [ visitorAccountToken, hostAccountToken ]);

    const style = useMemo(() => {
        return {
            ...overrideStyles?.mobile,
            ...(isDesktopMode
                ? overrideStyles?.desktop
                : {})
        };
    }, [ overrideStyles, isDesktopMode ]);

    return (
        <BasePaymentForm
            style={ style }
            handleIframeLoad={ handleIframeLoad }
            handleIframeError={ handleIframeError }
            isLoading={ isLoading }
            hasError={ hasError }
            hostAccountToken={ hostAccountToken }
            brandName={ brandName }
        />
    );
};
