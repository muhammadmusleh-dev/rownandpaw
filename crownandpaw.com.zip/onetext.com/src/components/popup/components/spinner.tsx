/** @jsx h */

import { h } from 'preact';
import { useCallback, useMemo, useState } from 'preact/hooks';

import { trackBuyerEvent } from '../../../biz';
import { BasePopupSpinner } from '../../base';
import { useConsentPopupContext } from '../context';

import type { PopupResponsiveStyle } from '@onetext/api';
import { PUBLIC_BUYER_EVENT } from '@onetext/api';

type ConsentPopupSpinnerProps = {
    overrideStyles ?: PopupResponsiveStyle,
};

const ONETEXT_SPINNER_RESULT_PROPERTY_NAME = 'onetext_spinner_result';

export const ConsentPopupSpinner = ({
    overrideStyles
} : ConsentPopupSpinnerProps) : JSX.Element => {
    const { popup, isDesktopMode, setProperties, submitPage } = useConsentPopupContext();

    const [ isSpinning, setIsSpinning ] = useState(false);

    const {
        shuffledOptions,
        selectedOption
    } = useMemo(() => {
        const spinnerOptions = popup.config?.component?.spinner?.options;
        const options = Array.isArray(spinnerOptions)
            ? [ ...spinnerOptions ]
            : [];

        if (options.length > 0) {
            const shouldRandomise = Boolean(popup.config?.component?.spinner?.randomize);

            if (shouldRandomise) {
                const randomIndex = Math.floor(Math.random() * options.length);
                const randomOptions = options[randomIndex];

                if (randomOptions) {
                    options.splice(randomIndex, 1);
                    options.splice(0, 0, randomOptions);
                }

                return {
                    shuffledOptions: options,
                    selectedOption:  randomOptions
                };
            }

            return {
                shuffledOptions: options,
                selectedOption:  options[0]
            };

        }

        throw new Error('No options provided');
    }, [ popup.config?.component?.spinner?.options ]);

    const onSpinEnd = useCallback(() => {

        if (selectedOption) {
            setProperties(existingProperties => {
                return {
                    ...existingProperties,
                    [ ONETEXT_SPINNER_RESULT_PROPERTY_NAME ]: selectedOption.value
                };
            });

            trackBuyerEvent({
                buyerEvent: PUBLIC_BUYER_EVENT.POPUP_SPINNER_RESULT,
                payload:    {
                    popupToken:    popup.token,
                    propertyName:  ONETEXT_SPINNER_RESULT_PROPERTY_NAME,
                    propertyValue: selectedOption.value

                }
            });

        }

        void submitPage();
    }, [ setProperties, popup, selectedOption ]);

    const startSpinning = () : void => {
        setIsSpinning(true);

        setTimeout(() => {
            onSpinEnd();
        }, 7000);
    };

    return (
        <BasePopupSpinner
            isDesktopMode={ isDesktopMode }
            style={
                {
                    ...overrideStyles?.mobile,
                    ...isDesktopMode
                        ? overrideStyles?.desktop
                        : {}
                }
            }
            config={ popup.config }
            options={ shuffledOptions }
            isSpinning={ isSpinning }
            startSpinning={ startSpinning }
        />
    );
};
