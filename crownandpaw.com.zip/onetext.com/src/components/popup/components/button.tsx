/** @jsx h */

import type { ComponentChildren } from 'preact';

import { h } from 'preact';
import { useEffect, useState } from 'preact/hooks';

import { assertUnreachable, delay } from '../../../lib';
import { BaseButton } from '../../base';
import { LoadingDots } from '../../loading-dots';
import { useConsentFormContext, useConsentPopupContext } from '../context';

import type { Milliseconds, PopupButtonElement, PopupResponsiveStyle } from '@onetext/api';
import { BUTTON_CLICK_ACTION, BUTTON_LEVEL } from '@onetext/api';

const DEFAULT_CLICK_ACTION : PopupButtonElement['clickAction'] = { type: BUTTON_CLICK_ACTION.SUBMIT };

type ConsentPopupButtonProps = {
    children : ComponentChildren,
    className ?: string,
    overrideStyles ?: PopupResponsiveStyle,
    submitDelay ?: Milliseconds,
    level ?: BUTTON_LEVEL,
    clickAction ?: PopupButtonElement['clickAction'],
};

export const ConsentPopupButton = ({
    children,
    level = BUTTON_LEVEL.PRIMARY,
    className = undefined,
    submitDelay,
    clickAction = DEFAULT_CLICK_ACTION,
    overrideStyles
} : ConsentPopupButtonProps) : JSX.Element => {

    const {
        closePopup, popup, isDesktopMode,
        registerTapToTextFlow, unregisterTapToTextFlow
    } = useConsentPopupContext();
    const { submit, attemptSubmit, loading: formLoading } = useConsentFormContext();

    const [ buttonLoading, setButtonLoading ] = useState(false);
    const [ disabled, setDisabled ] = useState(false);
    const [ hover, setHover ] = useState(false);
    const [ focus, setFocus ] = useState(false);

    const loading = (
        buttonLoading ||
        formLoading
    );

    useEffect(() => {
        if (clickAction.type === BUTTON_CLICK_ACTION.TAP_TO_TEXT) {
            registerTapToTextFlow();
        }

        return () => {
            if (clickAction.type === BUTTON_CLICK_ACTION.TAP_TO_TEXT) {
                unregisterTapToTextFlow();
            }
        };
    }, [ clickAction, registerTapToTextFlow ]);

    const onClick = async (event : Event) : Promise<void> => {
        event.preventDefault();
        event.stopPropagation();

        switch (clickAction.type) {
            case BUTTON_CLICK_ACTION.CLOSE:
                closePopup();
                return;
            case BUTTON_CLICK_ACTION.TAP_TO_TEXT:
            case BUTTON_CLICK_ACTION.SUBMIT:
                setButtonLoading(true);
                setDisabled(true);

                if (!attemptSubmit()) {
                    setButtonLoading(false);
                    setDisabled(false);
                    return;
                }

                if (submitDelay) {
                    await delay(submitDelay);
                }

                await submit();
                setButtonLoading(false);
                setDisabled(false);

                return;

            case BUTTON_CLICK_ACTION.REDIRECT_TO_URL: {
                const redirectAction = clickAction;

                if (redirectAction.openInNewTab) {
                    window.open(redirectAction.url as string, '_blank');
                } else {
                    window.location.href = redirectAction.url as string;
                }

                return;
            }

            default:
                assertUnreachable(clickAction);
        }

    };

    const onMouseEnter = () : void => setHover(true);
    const onMouseLeave = () : void => setHover(false);
    const onFocus = () : void => setFocus(true);
    const onBlur = () : void => setFocus(false);

    return (
        <BaseButton
            onClick={ (e) => void onClick(e) }
            onMouseEnter={ onMouseEnter }
            onMouseLeave={ onMouseLeave }
            onFocus={ onFocus }
            onBlur={ onBlur }
            disabled={ disabled }
            config={ popup.config }
            level={ level }
            hover={ hover }
            focus={ focus }
            isDesktop={ isDesktopMode }
            className={ className }
            style={
                {
                    ...overrideStyles?.mobile,
                    ...isDesktopMode
                        ? overrideStyles?.desktop
                        : {}
                }
            }
        >
            {
                loading
                    ? <LoadingDots />
                    : children
            }
        </BaseButton>
    );
};
