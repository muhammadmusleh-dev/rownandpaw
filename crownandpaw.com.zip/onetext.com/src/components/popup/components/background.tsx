/** @jsx h */

import { h } from 'preact';

import { BaseBackground } from '../../base';
import { useConsentPopupContext } from '../context';

export const ConsentPopupBackground = () : JSX.Element | null => {
    const { popup, isDesktopMode } = useConsentPopupContext();

    return (
        <BaseBackground
            config={ popup.config }
            isDesktopMode={ isDesktopMode }
        />
    );
};
