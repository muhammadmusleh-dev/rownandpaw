/** @jsx h */

import { h } from 'preact';
import { useEffect, useState } from 'preact/hooks';

import { run } from '../../../lib';
import { BaseCountdown } from '../../base';
import { useConsentPopupContext } from '../context';

import type { PopupResponsiveStyle } from '@onetext/api';

type ConsentPopupCountdownProps = {
    overrideStyles ?: PopupResponsiveStyle,
};

export const ConsentPopupCountdown = ({
    overrideStyles
} : ConsentPopupCountdownProps) : JSX.Element => {
    const { isDesktopMode, popup } = useConsentPopupContext();

    const countdownConfig = popup.config?.component?.countdown;

    if (!countdownConfig) {
        throw new Error('Countdown component is not configured');
    }

    const { endTime } = countdownConfig;

    const countdownStyles = {
        ...countdownConfig.style.mobile,
        ...isDesktopMode
            ? countdownConfig.style.desktop
            : {}
    };

    const containerStyles = {
        ...overrideStyles?.mobile,
        ...isDesktopMode
            ? overrideStyles?.desktop
            : {}
    };

    const [ timeRemaining, setTimeRemaining ] = useState(endTime
        ? endTime - Date.now()
        : 0);

    const digits = run(() => {

        if (timeRemaining <= 0) {
            return [ 0, 0, 0, 0 ];
        }

        const days = Math.floor(timeRemaining / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeRemaining / (1000 * 60 * 60)) % 24);
        const minutes = Math.floor((timeRemaining / (1000 * 60)) % 60);
        const seconds = Math.floor((timeRemaining / 1000) % 60);

        return [
            days,
            hours,
            minutes,
            seconds
        ];
    });

    useEffect(() => {
        const interval = setInterval(() => {
            setTimeRemaining(prev => prev - 1000);
        }, 1000);

        return () => clearInterval(interval);
    }, [ countdownConfig ]);

    return (
        <BaseCountdown
            containerStyles={ containerStyles }
            countdownStyles={ countdownStyles }
            config={ countdownConfig }
            digits={ digits }
        />
    );
};
