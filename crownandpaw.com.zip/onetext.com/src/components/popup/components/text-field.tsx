/** @jsx h */

import { h } from 'preact';
import { useCallback, useEffect, useMemo, useRef, useState } from 'preact/hooks';

import { clsx } from '../../../jsx';
import { identity } from '../../../lib';
import { useConsentFormContext, useConsentPopupContext } from '../context';

import type { PopupFieldConfig, PopupResponsiveStyle } from '@onetext/api';

type ConsentPopupTextFieldProps<Type extends string> = {
    type ?: string,
    id ?: string,
    name ?: string,
    autocomplete ?: string,
    placeholder ?: string,
    autofocus ?: boolean,
    defaultValue ?: Type,
    onValue ?: (value : Type | undefined) => void,
    onAutoComplete ?: () => void,
    onAutoCompleteStart ?: (value : string) => void,
    inputPattern ?: RegExp,
    required ?: boolean,
    isValid ?: (value : string) => boolean,
    deformatter ?: (value : string) => string,
    maxLength ?: number,
    className ?: string,
    overrideStyles ?: PopupResponsiveStyle,
    leftContent ?: JSX.Element,
};

const defaultIsValid = () : boolean => true;

export const ConsentPopupTextField = <Type extends string>({
    type,
    id,
    name,
    autocomplete,
    placeholder,
    autofocus = false,
    defaultValue,
    onAutoComplete,
    onAutoCompleteStart,
    onValue,
    inputPattern,
    required = true,
    isValid = defaultIsValid,
    deformatter = identity,
    maxLength,
    className,
    overrideStyles,
    leftContent
} : ConsentPopupTextFieldProps<Type>) : JSX.Element => {
    const inputRef = useRef<HTMLInputElement | null>(null);
    const formContext = useConsentFormContext();
    const [ currentValue, setCurrentValue ] = useState<string | undefined>(defaultValue);
    const [ priorCurrentValue, setPriorCurrentValue ] = useState<string | undefined>(defaultValue);
    const { popup, isDesktopMode } = useConsentPopupContext();
    const fieldStyle : PopupFieldConfig['style'] = popup.config?.component?.field?.style ?? {};

    const isValueValid = useCallback((value : string | undefined) : boolean => {
        if (required && !value) {
            return false;
        }

        if (value && !isValid(value)) {
            return false;
        }

        if (maxLength && value && value.length > maxLength) {
            return false;
        }

        return true;
    }, [ isValid, required, maxLength ]);

    const isCurrentValueValid = useMemo(() => {
        return isValueValid(currentValue);
    }, [ currentValue, isValid ]);

    useEffect(() => {
        const registeredField = formContext.registerField({
            isValid: () => isCurrentValueValid
        });

        return registeredField.unregister;
    }, [ formContext, isCurrentValueValid ]);

    useEffect(() => {
        setPriorCurrentValue(currentValue);

        if (
            priorCurrentValue === undefined &&
            currentValue &&
            currentValue.length >= 3 &&
            isCurrentValueValid &&
            autocomplete &&
            onAutoComplete
        ) {
            onAutoComplete();
        }
    }, [ currentValue, isCurrentValueValid, priorCurrentValue, autocomplete, onAutoComplete ]);

    const focus = useCallback(() : void => {
        const input = inputRef.current;

        if (input) {
            // if not focused, focus
            if (!document.activeElement?.isSameNode(input)) {
                input.focus({
                    preventScroll: true
                });

                const rect = input.getBoundingClientRect();
                const scrollTo = rect.top - 200;

                window.scrollTo({
                    top:      scrollTo,
                    behavior: 'smooth'
                });
            }
        }
    }, [ inputRef.current ]);

    useEffect(() => {
        if (autofocus) {
            focus();
            setTimeout(focus, 10);
        }
    }, [ autofocus, focus ]);

    const updateCurrentValue = (value : string) : void => {
        setCurrentValue(value);

        if (onValue) {
            onValue(
                isValueValid(value)
                    ? value as Type
                    : undefined
            );
        }
    };

    const onKeyDown = (event : KeyboardEvent) : void => {
        const input = event.currentTarget as HTMLInputElement;

        if (event.currentTarget && event.key) {
            const modifierKey = (
                event.metaKey ||
                event.ctrlKey ||
                event.altKey
            );

            if (event.key.length === 1 && !modifierKey) {
                const newValue = input.value + event.key;

                if (inputPattern && !inputPattern.test(newValue)) {
                    event.preventDefault();

                }
            } else if (event.key === 'Enter') {
                void formContext.submit();
            }
        }
    };

    const onInput = (event : Event) : void => {
        const input = event.currentTarget as HTMLInputElement;

        if (priorCurrentValue === undefined &&
            input.value &&
            input.value.length >= 3 &&
            autocomplete &&
            onAutoCompleteStart
        ) {
            onAutoCompleteStart(input.value);
        }

        const value = deformatter(input.value).slice(0, maxLength);

        updateCurrentValue(value);
        input.value = value;
    };

    return (
        <div
            className={
                clsx(
                    'border border-solid rounded-md px-[10px] py-[8px] flex items-center gap-2',
                    'min-w-[200px] w-full h-[48px] bg-white outline-none text-black max-w-[384px]',
                    className
                )
            }
            style={
                {
                    ...fieldStyle,
                    ...overrideStyles?.mobile,
                    ...isDesktopMode
                        ? overrideStyles?.desktop
                        : {},
                    ...isCurrentValueValid || !formContext.displayValidity
                        ? undefined
                        : { borderColor: 'red' }
                }
            }>
            { leftContent }
            <input
                id={ id }
                name={ name }
                autocomplete={ autocomplete }
                ref={ inputRef }
                type={ type }
                placeholder={ placeholder }
                value={ currentValue }
                onInput={ onInput }
                onKeyDown={ onKeyDown }
                className={ 'w-full outline-none text-inherit bg-inherit' }
                data-testid={
                    type
                        ? `${ type }-field-input`
                        : undefined
                }
            />
        </div>
    );
};
