/** @jsx h */

import { h } from 'preact';
import { useCallback, useEffect, useState } from 'preact/hooks';

import type { TeaserTextRenderFunction } from '../../../types';

import { trackBuyerEvent } from '../../../biz';
import { removeLastClosedTime, track } from '../../../lib';
import { BasePopupTeaser } from '../../base';
import { useConsentPopupContext } from '../context';

import { CloseButton } from './close-button';

import { CLOSE_BUTTON_POSITION, MODAL_TYPE, POSITION, PUBLIC_BUYER_EVENT } from '@onetext/api';

type ConsentPopupTeaserProps = {
    className ?: string,
    customText ?: string | TeaserTextRenderFunction,
    closeButtonPosition ?: CLOSE_BUTTON_POSITION,
};

export const ConsentPopupTeaser = ({
    className,
    customText,
    closeButtonPosition = CLOSE_BUTTON_POSITION.RIGHT
} : ConsentPopupTeaserProps) : JSX.Element | null => {
    const {
        popup,
        openPopup,
        isTeaserOpen,
        accountToken,
        suppressTeaser,
        properties
    } = useConsentPopupContext();

    const [ hover, setHover ] = useState(false);

    useEffect(() => {
        track('consent_teaser_render', { accountToken });
    }, []);

    useEffect(() => {
        track('consent_teaser_init', {
            accountToken
        });

        if (suppressTeaser.suppressed) {
            track('consent_teaser_suppress', {
                reason: suppressTeaser.reason
            });
        } else {
            track('consent_teaser_render', {
                accountToken
            });

            trackBuyerEvent({
                buyerEvent: PUBLIC_BUYER_EVENT.POPUP_TEASER_RENDER,
                payload:    {
                    popupToken: popup.token
                }
            });
        }
    }, [ suppressTeaser.suppressed, popup ]);

    const handleClick = useCallback(() : void => {
        removeLastClosedTime({ type: MODAL_TYPE.POPUP });
        openPopup();
    }, [ popup, openPopup ]);

    return (
        <BasePopupTeaser
            onClick={ handleClick }
            onMouseEnter={ () => setHover(true) }
            onMouseLeave={ () => setHover(false) }
            className={ className }
            aria-label={ 'View offer' }
            closeButton={
                <CloseButton
                    key={ 'close' }
                    overrideStyles={
                        {
                            mobile: {
                                position:    POSITION.RELATIVE,
                                top:         'auto',
                                left:        'auto',
                                right:       'auto',
                                height:      '16px',
                                width:       '16px',
                                strokeWidth: '1.75'
                            },
                            desktop: {
                                height:      '16px',
                                width:       '16px',
                                strokeWidth: '1.75'
                            }
                        }
                    }
                    animate={ false }
                    type={ MODAL_TYPE.TEASER }
                />
            }
            config={ popup.config }
            isTeaserOpen={ isTeaserOpen }
            isTeaserSuppressed={ suppressTeaser.suppressed }
            properties={ properties }
            closeButtonPosition={ closeButtonPosition }
            hover={ hover }
            customText={ customText }
        />
    );
};
