/** @jsx h */

import type { ComponentChildren } from 'preact';

import { h } from 'preact';
import { useCallback, useEffect, useMemo, useRef, useState } from 'preact/hooks';

import type { POPUP_VIEWPORT_MODE } from '../../../constants';
import type { PhoneCandidate } from '../../../types';
import type { ConsentPopupContextType } from '../context';

import { getCoreFlowLink, startOptInStatusPoll } from '../../../api';
import {
    getStoredAccountToken, getStoredBrowserIdentifier, getStoredBrowserSessionIdentifier, onPopupEmailSubmit,
    onPopupPhoneSubmit, submitCustomerOptIn, trackBuyerEvent
} from '../../../biz';
import {
    getPopupProgress, isDevelopment, isEditorMode, isPreviewMode, parseTokenID,
    promiseTry, savePopupProgress, setLastClosedTime, shouldSuppressPopup, shouldSuppressTeaser,
    track, trackError
} from '../../../lib';
import { Style } from '../../style';
import { ConsentPopupContext } from '../context';
import { useIsDesktopMode } from '../hooks';

import type { CodeDiscount, COUNTRY, Email, GetPopupAPIResponse, Milliseconds, TOKEN, TokenType } from '@onetext/api';
import { CORE_FLOW_TYPE, CUSTOMER_PROPERTY_NAME, MESSAGE_CHANNEL, MODAL_TYPE, PUBLIC_BUYER_EVENT } from '@onetext/api';

type ConsentPopupContainerProps = {
    popup : GetPopupAPIResponse,
    delay ?: Milliseconds,
    suppressedRoutes ?: ReadonlyArray<string>,
    suppressedKeywords ?: ReadonlyArray<string>,
    suppressedQueryParams ?: ReadonlyArray<string>,
    shownToCountries ?: Array<COUNTRY>,
    children ?: ComponentChildren,
    initialProperties ?: Record<string, string>,
    defaultPopupViewportMode ?: POPUP_VIEWPORT_MODE,
    autoOpenPopup ?: boolean,
};

const DEFAULT_EMPTY_PROPERTIES : Record<string, string> = {};

export const ConsentPopupContainer = ({
    popup,
    delay = 3000 as Milliseconds,
    suppressedRoutes,
    suppressedKeywords,
    suppressedQueryParams,
    shownToCountries,
    children,
    initialProperties = DEFAULT_EMPTY_PROPERTIES,
    defaultPopupViewportMode,
    autoOpenPopup
} : ConsentPopupContainerProps) : JSX.Element => {

    const {
        email: defaultEmail,
        phone: defaultPhone,
        hasSubmittedEmail: defaultHasSubmittedEmail = false,
        hasSubmittedPhone: defaultHasSubmittedPhone = false
    } = getPopupProgress() ?? {};

    const [ accountToken, setAccountToken ] = useState<TokenType<TOKEN.ACCOUNT> | undefined>(getStoredAccountToken());
    const [ email, setEmail ] = useState<Email | undefined>(defaultEmail);
    const [ phoneCandidate, setPhoneCandidate ] = useState<PhoneCandidate | undefined>(defaultPhone);
    const [ couponCode, setCouponCode ] = useState<CodeDiscount | undefined>();
    const [ honeypot, setHoneypot ] = useState<string>('');

    const [ properties, setProperties ] = useState<Record<string, string>>(initialProperties);

    const [ pageIDs, setPageIDs ] = useState<Array<number>>([]);
    const [ activePageID, setActivePageID ] = useState<number | undefined>();
    const [ isPopupOpen, setIsPopupOpen ] = useState<boolean>(false);
    const [ isTeaserOpen, setIsTeaserOpen ] = useState<boolean>(true);

    const [ showScanner, setShowScanner ] = useState<boolean>(false);
    const [ tapToTextLink, setTapToTextLink ] = useState<string | undefined>();

    const [ hasSubmittedEmail, setHasSubmittedEmail ] = useState(defaultHasSubmittedEmail);
    const [ hasSubmittedPhone, setHasSubmittedPhone ] = useState(defaultHasSubmittedPhone);

    const shouldStartTapToTextFlow = useRef<boolean>(false);

    const incrementalPageID = useRef(0);

    const isDesktopMode = useIsDesktopMode({
        defaultPopupViewportMode
    });

    const getNewPageID = () : number => {
        incrementalPageID.current += 1;
        return incrementalPageID.current;
    };

    const registerTapToTextFlow = useCallback(() => {
        shouldStartTapToTextFlow.current = true;
    }, []);

    const unregisterTapToTextFlow = useCallback(() => {
        shouldStartTapToTextFlow.current = false;
    }, []);

    const registerPage = useCallback((pageID : number) => {
        setActivePageID(existingPageID => {
            return existingPageID ?? pageID;
        });

        setPageIDs(currentPageIDs => {
            return [
                ...currentPageIDs,
                pageID
            ];
        });

        return () => {
            setPageIDs(currentPageIDs => {
                return currentPageIDs.filter(currentPageID => currentPageID !== pageID);
            });
        };
    }, [ activePageID, setActivePageID, setPageIDs ]);

    const startTapToTextFlow = useCallback(async () => {

        if (isEditorMode()) {
            return;
        }

        if (honeypot) {
            track('consent_popup_honeypot_triggered', {
                honeypotValue: honeypot
            });

            return;
        }

        try {
            track('consent_popup_start_tap_to_text_flow', {
                popupToken: popup.token
            });

            unregisterTapToTextFlow();

            setShowScanner(false);

            const customerBrowserIdentifier = getStoredBrowserIdentifier();
            const customerBrowserSessionIdentifier = getStoredBrowserSessionIdentifier();

            const { body } = await getCoreFlowLink({
                coreFlowType:     CORE_FLOW_TYPE.WELCOME,
                email,
                forceSMSRedirect: isDesktopMode
                    ? false
                    : true,
                customerBrowserIdentifier,
                customerBrowserSessionIdentifier,
                popupToken: popup.token,
                channel:    MESSAGE_CHANNEL.SMS_MMS
            });

            // start polling for opt-in status in the background
            // it will check if the user opts in and marks them as identified
            const { link, shortID } = body;

            startOptInStatusPoll({
                shortID,
                maxAttempts: 20,
                intervalMs:  5000 as Milliseconds
            });

            if (isDesktopMode) {
                setTapToTextLink(link);
                setShowScanner(true);
                return;
            }

            window.location.href = link;

        } catch (err) {
            trackError(err, {
                type: 'tap_to_text_button_error'
            });
        }

    }, [ isEditorMode ]);

    const submitData = useCallback(() => {
        return promiseTry(async () => {
            if (isEditorMode()) {
                return;
            }

            if (honeypot) {
                // if bot activity is detected, track the event and return early
                track('consent_popup_honeypot_triggered', {
                    honeypotValue: honeypot
                });

                return;
            }

            track('consent_popup_submit', {
                accountToken,
                hasPhone:      Boolean(phoneCandidate),
                hasEmail:      Boolean(email),
                hasProperties: Boolean(Object.keys(properties).length)
            });

            if (accountToken || email || phoneCandidate) {
                const isFirstTimeSubmittingEmail = email && !hasSubmittedEmail;
                const isFirstTimeSubmittingPhone = phoneCandidate && !hasSubmittedPhone;

                if (isFirstTimeSubmittingEmail) {
                    onPopupEmailSubmit.emit({
                        email
                    });

                    setHasSubmittedEmail(true);

                    savePopupProgress({
                        hasSubmittedEmail: true,
                        email
                    });

                    trackBuyerEvent(
                        {
                            buyerEvent: PUBLIC_BUYER_EVENT.POPUP_EMAIL_OPT_IN,
                            payload:    {
                                popupToken: popup.token,
                                email
                            }
                        }
                    );
                }

                if (isFirstTimeSubmittingPhone) {
                    onPopupPhoneSubmit.emit({
                        phone: phoneCandidate.number
                    });

                    setHasSubmittedPhone(true);

                    savePopupProgress({
                        hasSubmittedPhone: true,
                        phone:             phoneCandidate
                    });

                    trackBuyerEvent(
                        {
                            buyerEvent: PUBLIC_BUYER_EVENT.POPUP_SMS_OPT_IN,
                            payload:    {
                                popupToken: popup.token,
                                phone:      phoneCandidate.number
                            }
                        }
                    );
                }

                const popupID = parseTokenID(popup.token);

                const customerProperties : Record<string, string> = {
                    ...properties,
                    ...(popup.config?.behavior?.properties),
                    ...(popupID && { [CUSTOMER_PROPERTY_NAME.POPUP_ID]: popupID }),
                    [CUSTOMER_PROPERTY_NAME.POPUP_NAME]: popup.name
                };

                const payload = {
                    accountToken,
                    email,
                    phone:                     phoneCandidate?.number,
                    customerProperties,
                    allowRateLimitWelcomeFlow: !isFirstTimeSubmittingPhone,
                    popupToken:                popup.token,
                    couponCode
                };

                const response = await submitCustomerOptIn(payload);

                if (response.accountToken) {
                    setAccountToken(response.accountToken);
                }
            }
        }).catch(err => {
            trackError(err, {
                type: 'consent_popup_submit'
            });
        });
    }, [
        accountToken,
        email,
        phoneCandidate,
        properties,
        hasSubmittedEmail,
        hasSubmittedPhone,
        couponCode,
        popup,
        activePageID,
        honeypot
    ]);

    const advancePage = useCallback(() => {
        if (!activePageID) {
            throw new Error('No active page');
        }

        const currentPageIndex = pageIDs.indexOf(activePageID);

        if (currentPageIndex === -1) {
            throw new Error('Can not find current page');
        }

        const nextPageIndex = currentPageIndex + 1;

        if (nextPageIndex >= pageIDs.length) {
            setIsPopupOpen(false);
            return;
        }

        setActivePageID(pageIDs[nextPageIndex]);
    }, [ activePageID, pageIDs, setActivePageID, setIsPopupOpen ]);

    const submitPage = useCallback(() => {
        return promiseTry(() => {
            void submitData();

            if (shouldStartTapToTextFlow.current) {
                if (!isDesktopMode) {
                    advancePage();
                }

                void startTapToTextFlow();

            } else {
                setShowScanner(false);
                advancePage();
            }

        });
    }, [
        activePageID,
        accountToken,
        email,
        phoneCandidate,
        couponCode,
        properties,
        advancePage,
        hasSubmittedEmail,
        hasSubmittedPhone,
        startTapToTextFlow,
        submitData,
        isDesktopMode
    ]);

    const openPopup = useCallback(() => {
        setIsPopupOpen(true);
        setIsTeaserOpen(false);
    }, [ setIsPopupOpen, setIsTeaserOpen ]);

    const closePopup = useCallback(() => {
        setIsPopupOpen(false);
        setIsTeaserOpen(true);

        setLastClosedTime({ type: MODAL_TYPE.POPUP });

        incrementalPageID.current = 0;
    }, [ popup, setIsPopupOpen, setIsTeaserOpen ]);

    const closeTeaser = useCallback(() => {
        setIsTeaserOpen(false);

        setLastClosedTime({ type: MODAL_TYPE.TEASER });
    }, [ popup, setIsTeaserOpen ]);

    const hasSubmittedPopup = useMemo(() => {
        return hasSubmittedEmail && hasSubmittedPhone && !isPopupOpen;
    }, [ hasSubmittedEmail, hasSubmittedPhone, isPopupOpen ]);

    const suppressTeaser = useMemo(() => {
        return shouldSuppressTeaser({
            popup,
            suppressedRoutes,
            suppressedKeywords,
            suppressedQueryParams,
            shownToCountries,
            hasSubmittedPopup
        });
    }, [ popup,
        suppressedRoutes,
        suppressedKeywords,
        suppressedQueryParams,
        shownToCountries,
        hasSubmittedPopup,
        isTeaserOpen,
        isPopupOpen
    ]);

    const suppressPopup = useMemo(() => {
        return shouldSuppressPopup({
            popup,
            suppressedRoutes,
            suppressedKeywords,
            suppressedQueryParams,
            shownToCountries,
            hasSubmittedPopup
        });
    }, [ popup,
        suppressedRoutes,
        suppressedKeywords,
        suppressedQueryParams,
        shownToCountries,
        hasSubmittedPopup,
        isPopupOpen,
        isTeaserOpen
    ]);

    const popupContext : ConsentPopupContextType = useMemo(() => {
        return {
            popup,
            accountToken,
            email,
            setEmail,
            phoneCandidate,
            setPhoneCandidate,
            properties,
            setProperties,
            registerPage,
            activePageID,
            submitPage,
            isPopupOpen,
            setIsPopupOpen,
            isTeaserOpen,
            setIsTeaserOpen,
            openPopup,
            closePopup,
            closeTeaser,
            suppressedRoutes,
            getNewPageID,
            suppressTeaser,
            suppressPopup,
            isDesktopMode,
            couponCode,
            setCouponCode,
            honeypot,
            setHoneypot,
            showScanner,
            setShowScanner,
            tapToTextLink,
            setTapToTextLink,
            registerTapToTextFlow,
            unregisterTapToTextFlow
        };
    }, [
        popup,
        accountToken,
        email,
        setEmail,
        phoneCandidate,
        setPhoneCandidate,
        properties,
        setProperties,
        registerPage,
        activePageID,
        submitPage,
        isPopupOpen,
        setIsPopupOpen,
        isTeaserOpen,
        setIsTeaserOpen,
        openPopup,
        closePopup,
        closeTeaser,
        suppressedRoutes,
        getNewPageID,
        suppressTeaser,
        suppressPopup,
        isDesktopMode,
        couponCode,
        setCouponCode,
        honeypot,
        setHoneypot,
        showScanner,
        setShowScanner,
        tapToTextLink,
        setTapToTextLink,
        registerTapToTextFlow,
        unregisterTapToTextFlow
    ]);

    useEffect(() => {
        const fontLinks : Array<HTMLLinkElement> = [];

        if (popup.config?.style?.font?.options) {
            const fontOptions = popup.config.style.font.options;

            for (const fontOption of fontOptions) {
                const url = fontOption.url;

                const link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = url;
                document.head.appendChild(link);

                fontLinks.push(link);
            }
        }

        return () => {
            fontLinks.forEach((link) => {
                document.head.removeChild(link);
            });
        };
    }, [ popup ]);

    useEffect(() : void => {
        if (suppressPopup.suppressed || autoOpenPopup === false) {
            return;
        }

        if (delay && !isDevelopment() && !isPreviewMode() && !isEditorMode()) {
            setTimeout(() => openPopup(), delay);
        } else {
            openPopup();
        }
    }, [ suppressPopup.suppressed, openPopup, delay ]);

    return (
        <ConsentPopupContext.Provider value={ popupContext }>
            <Style>
                { children }
            </Style>
        </ConsentPopupContext.Provider>
    );
};
