// Set up preact context

import { createContext } from 'preact';
import { useContext } from 'preact/hooks';

import type { ShouldSuppressResult } from '../../../lib';
import type { PhoneCandidate, SetState } from '../../../types';

import type { CodeDiscount, Email, GetPopupAPIResponse, TOKEN, TokenType } from '@onetext/api';

export type ConsentPopupContextType = {
    popup : GetPopupAPIResponse,
    accountToken : TokenType<TOKEN.ACCOUNT> | undefined,
    properties : Record<string, string>,
    setProperties : SetState<Record<string, string>>,
    email : Email | undefined,
    setEmail : SetState<Email | undefined>,
    phoneCandidate : PhoneCandidate | undefined,
    setPhoneCandidate : SetState<PhoneCandidate | undefined>,
    registerPage : (pageID : number) => () => void,
    getNewPageID : () => number,
    activePageID : number | undefined,
    submitPage : () => Promise<void>,
    isPopupOpen : boolean,
    setIsPopupOpen : SetState<boolean>,
    isTeaserOpen : boolean,
    setIsTeaserOpen : SetState<boolean>,
    openPopup : () => void,
    closePopup : () => void,
    closeTeaser : () => void,
    suppressedRoutes : ReadonlyArray<string> | undefined,
    suppressTeaser : ShouldSuppressResult,
    suppressPopup : ShouldSuppressResult,
    isDesktopMode : boolean,
    couponCode : CodeDiscount | undefined,
    setCouponCode : (code : CodeDiscount | undefined) => void,
    honeypot : string,
    setHoneypot : SetState<string>,
    showScanner : boolean,
    setShowScanner : SetState<boolean>,
    tapToTextLink : string | undefined,
    setTapToTextLink : SetState<string | undefined>,
    registerTapToTextFlow : () => void,
    unregisterTapToTextFlow : () => void,
};

export const ConsentPopupContext = createContext<ConsentPopupContextType | undefined>(undefined);

export const useConsentPopupContext = () : ConsentPopupContextType => {
    const context = useContext(ConsentPopupContext);

    if (!context) {
        throw new Error('Can not find consent popup context');
    }

    return context;
};
