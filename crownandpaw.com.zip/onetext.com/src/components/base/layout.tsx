import type { ComponentChild, JSX } from 'react';

import React, { forwardRef } from 'react';

import { clsx } from '../../jsx';

type BasePopupLayoutProps = {
    children : ComponentChild,
    className ?: string,
    style ?: JSX.CSSProperties,
};

const defaultStyle : JSX.CSSProperties = {};

export const BasePopupRow = ({
    children,
    className = '',
    style = defaultStyle
} : BasePopupLayoutProps) : JSX.Element => (
    <div
        className={
            clsx(
                'flex flex-col items-center justify-center h-full',
                className
            )
        }
        style={ style }
    >
        { children }
    </div>
);

export const BasePopupColumns = ({
    children,
    className = '',
    style = defaultStyle
} : BasePopupLayoutProps) : JSX.Element => {
    return (
        <div
            className={
                clsx(
                    'flex h-full w-full justify-center items-center md:flex-row flex-col',
                    className
                )
            }
            style={ style }
        >
            { children }
        </div>
    );
};

export const BasePopupColumn = forwardRef<
    HTMLDivElement,
    BasePopupLayoutProps & JSX.HTMLAttributes<HTMLDivElement>
>(
    (
        {
            children,
            className = '',
            style = defaultStyle,
            ...props
        } : BasePopupLayoutProps,
        ref : React.Ref<HTMLDivElement> | undefined
    ) : JSX.Element => (
        <div
            ref={ ref }
            className={
                clsx(
                    'flex flex-col items-center justify-center h-full',
                    className
                )
            }
            style={ style }
            { ...props }
        >
            { children }
        </div>
    )
);

BasePopupColumn.displayName = 'BasePopupColumn';
