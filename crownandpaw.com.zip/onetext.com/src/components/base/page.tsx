import type { ComponentChild, JSX } from 'react';

import React from 'react';

import { clsx } from '../../jsx';

import type { PopupCommonStyle } from '@onetext/api';

type BasePopupPageProps = {
    background ?: ComponentChild,
    style ?: PopupCommonStyle,
} & JSX.HTMLAttributes<HTMLDivElement>;

export const BasePopupPage = ({
    children,
    className = undefined,
    background,
    style,
    ...props
} : BasePopupPageProps) : JSX.Element | null => {
    return (
        <>
            { background }
            <div
                className={
                    clsx(
                        'relative w-full h-full flex items-center justify-center',
                        className
                    )
                }
                style={ style }
                { ...props }
            >
                { children }
            </div>
        </>
    );
};
