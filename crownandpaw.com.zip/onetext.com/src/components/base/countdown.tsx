import type { JSX } from 'react';

import React from 'react';

import { clsx } from '../../jsx';
import { getBoxShadowStyles, run } from '../../lib';

import type { PopupCommonStyle, PopupCountdownConfig } from '@onetext/api';
import { COUNTDOWN_LABEL_FORMAT_MAP } from '@onetext/api';

type BaseCountdownProps = {
    containerStyles ?: PopupCommonStyle,
    countdownStyles : PopupCommonStyle,
    digits : Array<number>,
    config : PopupCountdownConfig,
};

export const BaseCountdown = ({
    containerStyles,
    countdownStyles,
    digits,
    config
} : BaseCountdownProps) : JSX.Element => {
    const { label } = config;

    const labels = COUNTDOWN_LABEL_FORMAT_MAP[ label.format ];

    const boxShadow = getBoxShadowStyles(countdownStyles);

    return (
        <div
            className={
                clsx(
                    'w-full cursor-pointer text-center'
                )
            }
            style={ { ...containerStyles, boxShadow } }
        >
            <div
                class={
                    clsx(
                        'flex flex-row gap-2 justify-center items-center'
                    )
                }
            >
                {
                    run(() => {
                        return digits.map((digit, index) => {

                            const firstNonZeroIndex = digits.findIndex(d => d !== 0);

                            if (digit === 0 && index <= firstNonZeroIndex && index <= 1) {
                                return null;
                            }

                            const labelText = labels.split(', ')[index];
                            const { fontSize, color, backgroundColor, fontWeight, fontFamily } = countdownStyles;

                            return (
                                <div
                                    class={
                                        'flex flex-col items-center justify-center gap-2 px-2 pt-3 pb-2 rounded-lg'
                                    }
                                    style={ { backgroundColor, fontFamily } }
                                    key={ index }
                                >
                                    <span class={ 'countdown' }>
                                        <span
                                            class={ 'text-center' }
                                            style={
                                                {
                                                    '--value':    digit,
                                                    'lineHeight': fontSize,
                                                    fontSize,
                                                    color,
                                                    fontWeight,
                                                    backgroundColor
                                                }
                                            }
                                        />
                                    </span>
                                    {
                                        labelText
                                            ? (
                                                <span
                                                    class={ 'font-bold text-center' }
                                                    style={ { fontSize: label.fontSize, color } }
                                                >
                                                    { labelText }
                                                </span>
                                            )
                                            : null
                                    }
                                </div>
                            );
                        });
                    })
                }
            </div>
        </div>
    );
};
