import type { JSX } from 'react';

import React from 'react';

import { DEFAULT_BUTTON_CONFIG, POPUP_VIEWPORT_MODE } from '../../constants';
import { clsx } from '../../jsx';
import { getBoxShadowStyles } from '../../lib';

import type { PopupCommonStyle, PopupConfig } from '@onetext/api';
import { BUTTON_LEVEL, COMPONENT_STATE, STYLE_ATTRIBUTE } from '@onetext/api';

type BaseButtonProps = {
    config ?: PopupConfig,
    style ?: PopupCommonStyle,
    level ?: BUTTON_LEVEL,
    hover ?: boolean,
    focus ?: boolean,
    isDesktop ?: boolean,
} & Omit<JSX.IntrinsicElements['button'], 'size' | 'style'>;

export const BaseButton = (
    {
        style, children, className, config,
        level = BUTTON_LEVEL.PRIMARY,
        hover,
        focus,
        isDesktop,
        ...props
    } : BaseButtonProps
) : JSX.Element => {
    const getColorValue = (
        buttonLevel : BUTTON_LEVEL,
        attribute : STYLE_ATTRIBUTE,
        state : COMPONENT_STATE
    ) : string => {
        const buttonConfig = config?.component?.button ?? DEFAULT_BUTTON_CONFIG;

        return buttonConfig.level?.[buttonLevel]?.color?.[attribute]?.[state] ??
            DEFAULT_BUTTON_CONFIG.level?.[buttonLevel]?.color?.[attribute]?.[state] ??
            '';
    };

    const getVariantColorStyle = (
        buttonLevel : BUTTON_LEVEL
    ) : { [key : string] : string } => {
        const baseBackgroundColor = getColorValue(buttonLevel, STYLE_ATTRIBUTE.BACKGROUND, COMPONENT_STATE.BASE);
        const hoverBackgroundColor = getColorValue(buttonLevel, STYLE_ATTRIBUTE.BACKGROUND, COMPONENT_STATE.HOVER);
        const baseTextColor = getColorValue(buttonLevel, STYLE_ATTRIBUTE.TEXT, COMPONENT_STATE.BASE);
        const hoverTextColor = getColorValue(buttonLevel, STYLE_ATTRIBUTE.TEXT, COMPONENT_STATE.HOVER);
        const baseBorderColor = getColorValue(buttonLevel, STYLE_ATTRIBUTE.BORDER, COMPONENT_STATE.BASE);
        const hoverBorderColor = getColorValue(buttonLevel, STYLE_ATTRIBUTE.BORDER, COMPONENT_STATE.HOVER);
        return {
            color: hover || focus
                ? hoverTextColor
                : baseTextColor,
            background: hover || focus
                ? hoverBackgroundColor
                : baseBackgroundColor,
            borderColor: hover || focus
                ? hoverBorderColor
                : baseBorderColor
        };
    };

    const getButtonVariantStyles = () : PopupCommonStyle => {

        const viewMode = isDesktop
            ? POPUP_VIEWPORT_MODE.DESKTOP
            : POPUP_VIEWPORT_MODE.MOBILE;

        return config?.component?.button?.level?.[level]?.style?.[viewMode] ??
            DEFAULT_BUTTON_CONFIG.level?.[level]?.style?.[viewMode] ?? {};
    };

    const getApplicableInlineStyles = () : PopupCommonStyle => {
        // Note: Only allow whitelisted style keys here to prevent leaking unwanted styles from props.
        // If additional inline properties are needed, extend this mapping explicitly - otherwise we should always
        // use the global config styles.
        return {
            paddingTop:    style?.paddingTop,
            paddingRight:  style?.paddingRight,
            paddingBottom: style?.paddingBottom,
            paddingLeft:   style?.paddingLeft,
            marginTop:     style?.marginTop,
            marginRight:   style?.marginRight,
            marginBottom:  style?.marginBottom,
            marginLeft:    style?.marginLeft
        };
    };

    const { borderColor, ...variantColorStyles } = getVariantColorStyle(level);
    const buttonVariantStyles = getButtonVariantStyles();

    const boxShadow = getBoxShadowStyles(buttonVariantStyles);

    const applicableInlineStyles = getApplicableInlineStyles();

    return (
        <button
            type={ 'button' }
            className={
                clsx(
                    'disabled:cursor-wait disabled:opacity-50 focus:outline-none',
                    'h-12 cursor-pointer w-full p-2 min-w-[200px] max-w-[384px] text-center outline-none',
                    className
                )
            }
            style={
                {
                    ...borderColor
                        ? { border: `1px solid ${ borderColor }` }
                        : {},
                    ...variantColorStyles,
                    ...buttonVariantStyles,
                    ...applicableInlineStyles,
                    boxShadow
                }
            }
            { ...props }
        >
            { children }
        </button>
    );
};

