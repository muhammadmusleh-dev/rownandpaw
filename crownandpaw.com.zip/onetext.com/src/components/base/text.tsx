import type { JSX } from 'react';

import React from 'react';

import { getBoxShadowStyles, getTextShadowStyles, getTextStrokeStyles } from '../../lib';

import type { PopupCommonStyle } from '@onetext/api';

type BaseTextProps = {
    style ?: PopupCommonStyle,
    text : string | undefined,
};

export const BaseText = ({
    style,
    text
} : BaseTextProps) : JSX.Element => {
    const textShadow = getTextShadowStyles(style);
    const webKitTextStroke = getTextStrokeStyles(style);
    const boxShadow = getBoxShadowStyles(style);

    return (
        <div
            className={ 'w-full shrink-0 leading-[1.5] text-center break-words whitespace-pre-wrap' }
            style={
                {
                    ...style,
                    ...webKitTextStroke,
                    textShadow,
                    boxShadow
                }
            }
        >
            { text }
        </div>
    );
};
