import type { JSX } from 'react';

import React from 'react';

import { isDevelopment, isEditorMode, isPreviewMode, run } from '../../lib';

import type { PopupCommonStyle } from '@onetext/api';

type BasePaymentFormProps = {
    style : PopupCommonStyle,
    hostAccountToken : string | undefined,
    brandName : string | undefined,
    handleIframeLoad : () => void,
    handleIframeError : () => void,
    isLoading : boolean,
    hasError : boolean,
};

const BASE_URL = isDevelopment()
    ? `https://localhost.onetext.com:8443`
    : `https://onetext.com`;

export const BasePaymentForm = ({
    style, hostAccountToken, brandName, handleIframeLoad, handleIframeError,
    isLoading, hasError
} : BasePaymentFormProps) : JSX.Element => {

    const queryParams = new URLSearchParams();

    const inTestMode = isDevelopment() || isPreviewMode() || isEditorMode();

    if (hostAccountToken) {
        queryParams.set('hostAccountToken', hostAccountToken);
    }

    if (brandName) {
        queryParams.set('brandName', brandName);
    }

    queryParams.set('testMode', inTestMode.toString());

    const CARD_VAULT_FORM_URL = `${ BASE_URL }/embed/vault?${ queryParams.toString() }`;

    return (
        <div
            className={ 'relative' }
            style={ style }
        >
            {
                run(() => {
                    if (isLoading) {
                        return (
                            <div
                                className={ 'absolute inset-0 flex items-center justify-center border-none' }
                                data-testid={ 'loading-spinner' }
                            >
                                <div className={ 'animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600' } />
                            </div>
                        );
                    }

                    if (hasError) {
                        return (
                            <div
                                className={ 'absolute inset-0 flex items-center justify-center bg-red-50 border-none' }
                                data-testid={ 'error-message' }
                            >
                                <p className={ 'text-red-600 text-sm' }>{ 'Failed to load payment form' }</p>
                            </div>
                        );
                    }
                })
            }

            <iframe
                src={ CARD_VAULT_FORM_URL }
                className={ 'border-none w-[calc(100%+16px)] h-full' }
                allowFullScreen
                title={ 'Card Details Form' }
                data-testid={ 'card-details-form' }
                onLoad={ handleIframeLoad }
                onError={ handleIframeError }
                scrolling={ 'no' }
                style={
                    {
                        opacity: isLoading || hasError
                            ? 0
                            : 1,
                        transition: 'opacity 0.3s ease-in-out'
                    }
                }
            />
        </div>
    );
};

