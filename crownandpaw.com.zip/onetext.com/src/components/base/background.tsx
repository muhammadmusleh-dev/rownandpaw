import type { JSX } from 'react';

import React, { Fragment } from 'react';

import { clsx } from '../../jsx';
import { isEditorMode, run } from '../../lib';

import { BaseImage } from './image';

import type { PopupConfig } from '@onetext/api';
import { TEMPLATE_CANVAS_TYPE } from '@onetext/api';

type BaseBackgroundProps = {
    config ?: PopupConfig,
    isDesktopMode : boolean,
};

type Position = {
    bottom : string,
    right : string,
    top : string,
    left : string,
};

export const BaseBackground = ({
    config, isDesktopMode
} : BaseBackgroundProps) : JSX.Element | null => {
    const background = config?.template?.background;

    const calculateClosestQuadrantPosition = ({ bottom, right, top, left } : Position) : Partial<Position> => {
        const parsedTop = Number.parseFloat(top);
        const parsedBottom = Number.parseFloat(bottom);
        const parsedRight = Number.parseFloat(right);
        const parsedLeft = Number.parseFloat(left);

        if (parsedTop < parsedBottom) {
            if (parsedLeft < parsedRight) {
                return {
                    top,
                    left
                };
            }

            return {
                top,
                right
            };
        }

        if (parsedLeft < parsedRight) {
            return {
                bottom,
                left
            };
        }

        return {
            bottom,
            right
        };

    };

    return (
        <div
            className={
                clsx('absolute inset-0', isEditorMode()
                    ? 'z-0'
                    : '-z-10')
            }
        >
            {
                run(() => {
                    if (
                        background?.type === TEMPLATE_CANVAS_TYPE.SINGLE_IMAGE
                    ) {

                        const style = isDesktopMode
                            ? background.style?.desktop
                            : background.style?.mobile;

                        const filterBlur = style?.filterBlur;
                        const filterBrightness = style?.filterBrightness;
                        const backgroundImageSrc = style?.backgroundImage;

                        if (!backgroundImageSrc) {
                            return null;
                        }

                        return (
                            <div
                                className={
                                    clsx(
                                        'absolute inset-0',
                                        'w-full h-full bg-no-repeat bg-cover bg-center'
                                    )
                                }
                                style={
                                    {
                                        filter: `${ filterBlur
                                            ? `blur(${ filterBlur })`
                                            : '' } ${ typeof filterBrightness === 'number'
                                                ? `brightness(${ filterBrightness })`
                                                : '' }`,
                                        ...style,
                                        backgroundImage: `url(${ backgroundImageSrc })`
                                    }
                                }
                            />
                        );

                    }

                    if (background?.type === TEMPLATE_CANVAS_TYPE.MULTI_IMAGE) {
                        const backgroundElements = background.elements;

                        return (
                            <Fragment>
                                {
                                    backgroundElements.map((element) => {

                                        const { bottom, right, top, left, ...responsiveStyle } = {
                                            ...element.style?.mobile,
                                            ...(isDesktopMode
                                                ? element.style?.desktop
                                                : {})
                                        };

                                        if (!bottom || !right || !top || !left) {
                                            throw new Error('Background element is missing required position values');
                                        }

                                        const closestQuadrantPosition = calculateClosestQuadrantPosition({
                                            bottom,
                                            right,
                                            top,
                                            left
                                        });

                                        const style = {
                                            ...responsiveStyle,
                                            ...closestQuadrantPosition
                                        };

                                        return (
                                            <BaseImage
                                                key={ element.id }
                                                src={ element.src }
                                                alt={ element.alt }
                                                style={ style }
                                            />
                                        );

                                    })
                                }
                            </Fragment>
                        );
                    }

                    return null;

                })
            }

        </div>
    );
};
