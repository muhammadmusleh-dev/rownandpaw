import type { JSX } from 'react';

import React from 'react';

import { clsx } from '../../jsx';
import { isEditorMode } from '../../lib';

import type { PopupCommonStyle } from '@onetext/api';

type BaseCloseButtonProps = {
    delay ?: boolean,
    className ?: string,
    animate ?: boolean,
    style ?: PopupCommonStyle,
} & Omit<JSX.IntrinsicElements['button'], 'size' | 'style'>;

export const BaseCloseButton = ({
    delay = true,
    className,
    animate = true,
    style,
    ...props
} : BaseCloseButtonProps) : JSX.Element => {

    const { height = '25', width = '25', strokeWidth = '1.1', ...rest } = style ?? {};

    return (
        <button
            type={ 'button' }
            className={
                clsx(
                    'w-6 h-6',
                    animate && 'fade-in-up',
                    animate && (delay
                        ? 'animation-delay-[0.75s]'
                        : 'animation-delay-[0s]'),
                    className
                )
            }
            style={
                {
                    position: isEditorMode()
                        ? 'absolute'
                        : 'fixed',
                    top:     '20px',
                    right:   '20px',
                    cursor:  'pointer',
                    outline: 'none',
                    zIndex:  50,
                    height,
                    width,
                    ...rest
                }
            }
            aria-label={ 'Close offer' }
            { ...props }
        >
            <svg
                width={ width }
                height={ height }
                viewBox={ '0 0 25 25' }
                fill={ 'none' }
                stroke-width={ strokeWidth }
                xmlns={ 'http://www.w3.org/2000/svg' }>
                <path
                    d={ 'M2.97266 2.97168L22.1799 22.1789' }
                    stroke={ 'currentColor' }
                    stroke-width={ strokeWidth } />
                <path
                    d={ 'M22.1799 2.97168L2.97266 22.1789' }
                    stroke={ 'currentColor' }
                    stroke-width={ strokeWidth } />
            </svg>
        </button>
    );
};
