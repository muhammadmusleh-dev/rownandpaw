import type { JSX } from 'react';

import React from 'react';

import { clsx } from '../../jsx';
import { getBoxShadowStyles } from '../../lib';

import type { PopupCommonStyle } from '@onetext/api';

type BaseCouponCodeProps = {
    style ?: PopupCommonStyle,
    text : string | undefined,
    handleCopy : () => Promise<void>,
};

export const BaseCouponCode = ({
    style,
    text,
    handleCopy
} : BaseCouponCodeProps) : JSX.Element => {

    const boxShadow = getBoxShadowStyles(style);

    return (
        <div
            className={
                clsx(
                    'w-full cursor-pointer text-center'
                )
            }
            style={ { ...style, boxShadow } }
            onClick={ () => void handleCopy() }
        >
            { text }
        </div>
    );
};
