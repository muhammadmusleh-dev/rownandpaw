import type { JSX } from 'react';

import clsx from 'clsx';
import React from 'react';

import { getBoxShadowStyles } from '../../lib';

import type { PopupCommonStyle } from '@onetext/api';

type BaseImageProps = {
    style ?: PopupCommonStyle,
    shouldSubmitPage ?: boolean,
    submitPage ?: () => Promise<void>,
} & Omit<JSX.IntrinsicElements['img'], 'style'>;

export const BaseImage = ({
    style, submitPage, shouldSubmitPage, ...props
} : BaseImageProps) : JSX.Element => {

    const boxShadow = getBoxShadowStyles(style);

    return (
        <img
            className={
                clsx(
                    shouldSubmitPage
                        ? 'cursor-pointer'
                        : '',
                    'max-w-none'
                )
            }
            onClick={
                shouldSubmitPage
                    ? () => void submitPage?.()
                    : undefined
            }
            style={ { ...style, boxShadow } }
            { ...props }
        />
    );
};
