import type { FunctionComponent, JSX } from 'react';

import React from 'react';

import { clsx } from '../../jsx';
import { getBoxShadowStyles } from '../../lib';

import type { PopupCommonStyle, PopupConfig, PopupSpinnerConfig, PopupSpinnerOption } from '@onetext/api';

type BasePopupSpinnerProps = {
    config ?: PopupConfig,
    style ?: PopupCommonStyle,
    isDesktopMode : boolean,
    options : Array<PopupSpinnerOption>,
    isSpinning : boolean,
    startSpinning : () => void,
};

const DEFAULT_BORDER_WIDTH = 12;

const defaultColors : PopupSpinnerConfig = {
    randomize: false,
    element:   {
        arrow: {
            style: {
                background: {
                    base:  'rgba(243, 243, 243, 1.0)',
                    hover: '#1d4ed8'
                }
            }
        },
        hubcap: {
            style: {
                background: {
                    base:  'rgba(16, 96, 185, 1.0)',
                    hover: '#1d4ed8'
                },
                border: {
                    base:  'rgba(232, 232, 232, 1.0)',
                    hover: '#1d4ed8'
                }
            }
        },
        wheel: {
            style: {
                background: {
                    base:  'rgba(252, 252, 252, 1.0)',
                    hover: '#1d4ed8'
                },
                border: {
                    base:  'rgba(95, 169, 255, 1.0)',
                    hover: '#1d4ed8'
                }
            }
        }
    },
    options: [
        {
            label: '25% OFF',
            color: {
                text: {
                    base:  'rgba(0, 0, 0, 1.0)',
                    hover: '#ffffff'
                },
                background: {
                    base:  'rgba(243, 243, 243, 1.0)',
                    hover: '#1d4ed8'
                },
                border: {
                    base:  '#1982FC',
                    hover: '#1d4ed8'
                }
            },
            value: 'off_25'
        },
        {
            label: '10% Off',
            color: {
                text: {
                    base:  '#ffffff',
                    hover: '#ffffff'
                },
                background: {
                    base:  '#0f70db',
                    hover: '#1d4ed8'
                },
                border: {
                    base:  '#0f70db',
                    hover: '#1d4ed8'
                }
            },
            value: 'off_10'
        },
        {
            label: 'Free Shipping',
            color: {
                text: {
                    base: '#000000'
                },
                background: {
                    base: 'rgba(218, 218, 218, 1.0)'
                }
            },
            value: 'free_shipping'
        }
    ]
};

const Arrow : FunctionComponent<
    { backgroundColor : string | undefined }
> = ({ backgroundColor }) => (
    <div
        className={
            clsx(
                'absolute w-[22px] h-[51px] top-[-12px] left-1/2 z-[8]',
                '-translate-x-[calc(50%+4px)] md:-translate-x-[calc(50%+6px)]'
            )
        }>
        <div
            data-popup-element={ 'arrow' }
            className={
                'w-[22px] h-[51px] z-10 relative'
            }>
            <svg
                width={ '22' }
                height={ '51' }
                viewBox={ '0 0 22 51' }
                fill={ 'none' }
                xmlns={ 'http://www.w3.org/2000/svg' }>
                <path
                    d={
 `
     M0 20.1165
     C0 13 1.28333 -1.09271e-08 11 0
     C20.7167 1.09271e-08 22 13 22 20.1165
     C22 25.6147 17.7862 38.819 14.5747 48.0842
     C13.3691 51.5623 8.63089 51.5623 7.4253 48.0842
     C4.21378 38.819 0 25.6147 0 20.1165Z
 `
                    }
                    fill={ backgroundColor } />
            </svg>
        </div>
        <div
            data-popup-element={ 'arrow-shadow' }
            className={
                clsx(
                    'absolute rounded-full w-3 h-3 left-1/2 top-0.5 z-[6]',
                    '-translate-x-[calc(50%)]',
                    'shadow-[0px_12px_28px_4px_rgba(0,0,0,0.65)]'
                )
            }
        />
    </div>
);

const Hubcap : FunctionComponent<{
    backgroundColor : string | undefined,
    borderColor : string | undefined,
    borderWidth ?: number,
}> = ({
    backgroundColor,
    borderColor,
    borderWidth = DEFAULT_BORDER_WIDTH
}) => (
    <div
        className={
            clsx(
                'rounded-full w-[20%] h-[20%]',
                'absolute z-[4] top-1/2 left-1/2',
            `shadow-[inset_0px_0px_5px_2px_rgba(0,0,0,0.1)]`
            )
        }
        style={
            {
                backgroundColor,
                borderColor,
                borderWidth,
                transform: `translate(-50%, -50%)`
            }
        }
    />
);

const getFontStyles = (style : PopupCommonStyle | undefined) : JSX.CSSProperties => {
    if (!style) {
        return {};
    }

    const styles : JSX.CSSProperties = {};

    if (style.fontSize) {
        styles.fontSize = style.fontSize;
    }

    if (style.lineHeight) {
        styles.lineHeight = style.lineHeight;
    }

    if (style.fontWeight) {
        styles.fontWeight = style.fontWeight;
    }

    if (style.fontFamily) {
        styles.fontFamily = style.fontFamily;
    }

    if (style.textAlign) {
        styles.textAlign = style.textAlign;
    }

    if (style.textTransform) {
        styles.textTransform = style.textTransform;
    }

    if (style.letterSpacing) {
        styles.letterSpacing = style.letterSpacing;
    }

    return styles;
};

export const BasePopupSpinner = ({
    isDesktopMode,
    style,
    config,
    options,
    isSpinning,
    startSpinning
} : BasePopupSpinnerProps) : JSX.Element => {
    const spinnerConfig = config?.component?.spinner;

    const spinnerColors = { ...defaultColors, ...spinnerConfig };

    const size = style?.width;

    const segmentsLength = options.length * 2;
    const borderWidth = DEFAULT_BORDER_WIDTH;
    const wheelSize = isDesktopMode
        ? (size ?? 440)
        : (size ?? 285);

    const segmentAngle = 360 / segmentsLength;
    const textOffset = 30;
    const OVERLAP_ANGLE = segmentAngle * 0.5;

    const boxShadow = getBoxShadowStyles(style);

    const generateArcPoints = ({
        startAngle,
        endAngle,
        radius,
        centerX,
        centerY
    } : {
        startAngle : number,
        endAngle : number,
        radius : number,
        centerX : number,
        centerY : number,
    }) : string => {
        const points = [ `${ centerX }% ${ centerY }%` ];

        const steps = Math.max(
            32,
            Math.ceil(Math.abs(endAngle - startAngle) / (Math.PI / 24))
        );

        for (let i = 0; i <= steps; i++) {
            const currentAngle = startAngle + ((endAngle - startAngle) * (i / steps));
            const x = centerX + (Math.cos(currentAngle) * radius);
            const y = centerY + (Math.sin(currentAngle) * radius);
            points.push(`${ x }% ${ y }%`);
        }

        return points.join(', ');
    };

    return (
        <div
            onClick={ startSpinning }
            className={
                clsx(
                    'relative isolate cursor-pointer',
                    isDesktopMode
                        ? 'text-[16px] leading-[16px]'
                        : 'text-[12px] leading-[12px]'
                )
            }
            style={
                {
                    ...style,
                    width:  size,
                    height: size,
                    boxShadow
                }
            }>
            <Arrow backgroundColor={ spinnerColors.element.arrow?.style?.background?.base } />
            <Hubcap
                backgroundColor={ spinnerColors.element.hubcap?.style?.background?.base }
                borderColor={ spinnerColors.element.hubcap?.style?.border?.base }
            />
            <div
                className={
                    clsx(
                        'relative rounded-full z-[3] overflow-hidden',
                        'shadow-[0px_5px_20px_0px_rgba(51,51,51,0.16)]'
                    )
                }
                style={
                    {
                        width:           wheelSize,
                        height:          wheelSize,
                        backgroundColor: spinnerColors.element.wheel?.style?.background?.base,
                        borderColor:     spinnerColors.element.wheel?.style?.border?.base,
                        borderWidth,
                        transformOrigin: 'center'
                    }
                }>
                <div
                    className={
                        clsx(
                            'relative w-full h-full z-[2] overflow-hidden rotate-[-100deg]',
                            isSpinning
                                ? 'spin-final'
                                : 'spin-tease'
                        )
                    }>
                    {
                        options.map((currentOption, index) => {
                            const angle = (index / segmentsLength) * 360;
                            const textAngle = angle + (segmentAngle / 2);

                            const startAngleRad = ((angle - OVERLAP_ANGLE) * Math.PI) / 180;
                            const endAngleRad = ((angle + segmentAngle + OVERLAP_ANGLE) * Math.PI) / 180;

                            const textAngleRad = (textAngle * Math.PI) / 180;
                            const textX = 50 + (textOffset * Math.cos(textAngleRad));
                            const textY = 50 + (textOffset * Math.sin(textAngleRad));

                            const arcParams = {
                                startAngle: startAngleRad,
                                endAngle:   endAngleRad,
                                radius:     50,
                                centerX:    50,
                                centerY:    50
                            };

                            return (
                                <div
                                    key={ index }
                                    className={ 'absolute inset-0' }
                                    style={
                                        {
                                            transform:       `rotate(${ angle }deg)`,
                                            transformOrigin: 'center',
                                            clipPath:        `polygon(${ generateArcPoints(arcParams) })`,
                                            backgroundColor: currentOption.color.background?.base
                                        }
                                    }>
                                    <div
                                        className={
                                            clsx(
                                                'absolute',
                                                'twentieth-century',
                                                'tracking-[0.4px] antialiased text-white'

                                            )
                                        }
                                        style={
                                            {
                                                position:        'absolute',
                                                left:            `${ textX }%`,
                                                top:             `${ textY }%`,
                                                transform:       `translate(-50%, -50%) rotate(${ textAngle }deg)`,
                                                transformOrigin: 'center',
                                                textAlign:       'center',
                                                maxWidth:        '140px',
                                                overflow:        'hidden',
                                                textOverflow:    'ellipsis',
                                                whiteSpace:      'wrap',
                                                color:           currentOption.color.text?.base,
                                                ...getFontStyles(style)
                                            }
                                        }>
                                        { currentOption.label }
                                    </div>
                                </div>
                            );
                        })
                    }
                </div>
            </div>

        </div>
    );
};
