import type { JSX } from 'react';

import React from 'react';

import { clsx } from '../../jsx';
import { getBoxShadowStyles } from '../../lib';

import type { PopupCommonStyle, PopupConfig, PopupFieldConfig } from '@onetext/api';

type BaseTextFieldProps = {
    className ?: string,
    config ?: PopupConfig,
    isValid ?: boolean,
    style ?: PopupCommonStyle,
    leftContent ?: JSX.Element,
    defaultValue ?: string | undefined,
} & Omit<JSX.IntrinsicElements['input'], 'style' >;

export const BaseTextField = ({
    isValid,
    className,
    config,
    style,
    leftContent,
    ...props
} : BaseTextFieldProps) : JSX.Element => {
    const fieldStyle : PopupFieldConfig['style'] = config?.component?.field?.style ?? {};

    const boxShadow = getBoxShadowStyles(fieldStyle);

    return (
        <div
            className={
                clsx(
                    'border border-solid rounded-md px-[10px] py-[8px] flex items-center gap-2 text-sm',
                    'min-w-[200px] w-full h-[48px] bg-white outline-none text-black max-w-[384px]',
                    isValid
                        ? 'border-slate-500'
                        : 'border-red-500',
                    className
                )
            }
            style={
                {
                    ...fieldStyle,
                    ...style,
                    boxShadow,
                    ...style?.borderColor
                        ? { border: `1px solid ${ style.borderColor }` }
                        : {}
                }
            }
        >
            { leftContent }
            <input
                className={ 'w-full outline-none text-inherit bg-inherit border-none p-0' }
                { ...props }
            />
        </div>

    );
};
