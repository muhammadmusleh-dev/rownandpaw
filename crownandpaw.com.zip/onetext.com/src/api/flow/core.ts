import type { CallAPIResult } from '../api';

import { getSDKAccountToken, getSDKClientID, isDevice, promiseTry } from '../../lib';
import { callOneTextAPI, constructOneTextURL, redirectInPopup } from '../api';

import type {
    CORE_FLOW_TYPE, Email, HTTPUrl, PostCoreFlowLinkAPI, PostFlowCoreStartAPI,
    TOKEN, TokenType
} from '@onetext/api';
import { HTTP_METHOD, MESSAGE_CHANNEL } from '@onetext/api';

export const startCoreFlow = (
    body : PostFlowCoreStartAPI['request']
) : Promise<CallAPIResult<PostFlowCoreStartAPI['response']>> => {
    return callOneTextAPI({
        method: HTTP_METHOD.POST,
        path:   'flow/core/start',
        body
    });
};

export const getCoreFlowLink = (
    body : PostCoreFlowLinkAPI['request']
) : Promise<CallAPIResult<PostCoreFlowLinkAPI['response']>> => {
    return callOneTextAPI({
        method: HTTP_METHOD.POST,
        path:   'flow/core/link',
        body
    });
};

type GetRawCoreFlowLinkOptions = {
    message ?: string,
    email ?: Email,
    coreFlowType : string,
    customFlowParameters ?: Record<string, unknown>,
    forceSMSRedirect ?: boolean,
    customerBrowserIdentifier ?: string,
    customerBrowserSessionIdentifier ?: string,
    popupToken ?: TokenType<TOKEN.POPUP>,
};

export const getRawCoreFlowLink = ({
    coreFlowType,
    email,
    message,
    customFlowParameters,
    forceSMSRedirect = false,
    customerBrowserIdentifier,
    customerBrowserSessionIdentifier,
    popupToken
} : GetRawCoreFlowLinkOptions) : HTTPUrl => {
    const accountToken = getSDKAccountToken();
    const clientID = getSDKClientID();

    if (!accountToken && !clientID) {
        throw new Error(`Can not determine clientID`);
    }

    const query : Record<string, string> = {
        coreFlowType,
        domain: window.location.origin
    };

    if (customFlowParameters) {
        query.parameters = JSON.stringify(customFlowParameters);
    }

    if (message) {
        query.message = message;
    }

    if (accountToken) {
        query.accountToken = accountToken;
    }

    if (clientID) {
        query.clientID = clientID;
    }

    if (forceSMSRedirect) {
        query.forceSMSRedirect = 'true';
    }

    if (email) {
        query.email = email;
    }

    if (customerBrowserIdentifier) {
        query.customerBrowserIdentifier = customerBrowserIdentifier;
    }

    if (customerBrowserSessionIdentifier) {
        query.customerBrowserSessionIdentifier = customerBrowserSessionIdentifier;
    }

    if (popupToken) {
        query.popupToken = popupToken;
    }

    return constructOneTextURL({
        path: 'flow/start',
        query
    });
};

type GenerateCoreFlowLinkOptions = {
    message ?: string,
    coreFlowType : CORE_FLOW_TYPE.WELCOME,
    customFlowParameters ?: JSONObject,
    forceSMSRedirect ?: boolean,
    raw ?: boolean,
    email ?: Email,
    customerBrowserIdentifier ?: string,
    customerBrowserSessionIdentifier ?: string,
    popupToken ?: TokenType<TOKEN.POPUP>,
};

export const generateCoreFlowLink = async ({
    message,
    coreFlowType,
    customFlowParameters,
    forceSMSRedirect,
    raw,
    email,
    customerBrowserIdentifier,
    customerBrowserSessionIdentifier,
    popupToken
} : GenerateCoreFlowLinkOptions) : Promise<{ link : string } | { link : string, shortID : string }> => {
    if (raw) {
        return {
            link: getRawCoreFlowLink({
                message,
                email,
                coreFlowType,
                customFlowParameters,
                forceSMSRedirect,
                customerBrowserIdentifier,
                customerBrowserSessionIdentifier,
                popupToken
            })
        };
    }

    const { body } = await getCoreFlowLink({
        message,
        channel: MESSAGE_CHANNEL.SMS_MMS,
        coreFlowType,
        customFlowParameters,
        forceSMSRedirect,
        email,
        customerBrowserIdentifier,
        customerBrowserSessionIdentifier,
        popupToken
    });

    return {
        link:    body.link,
        shortID: body.shortID
    };
};

type SendCoreFlowStartMessageOptions = {
    message ?: string,
    email ?: string,
    coreFlowType : string,
    customFlowParameters ?: Record<string, unknown>,
    forceSMSRedirect ?: boolean,
};

export const sendCoreFlowStartMessage = ({
    coreFlowType,
    message,
    customFlowParameters,
    forceSMSRedirect = false
} : SendCoreFlowStartMessageOptions) : Promise<void> => {
    return promiseTry(() => {
        if (isDevice()) {
            return redirectInPopup({
                url: getRawCoreFlowLink({
                    coreFlowType,
                    message,
                    customFlowParameters,
                    forceSMSRedirect
                })
            });
        }
    });
};
