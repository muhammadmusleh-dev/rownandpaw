import { identifyCustomer } from '../biz';
import { poll, trackError } from '../lib';

import type { CallAPIResult } from './api';

import { callOneTextAPI } from './api';

import type { GetShortTokenInboundCheckAPI, Milliseconds, PostOptInAPI } from '@onetext/api';
import { HTTP_METHOD } from '@onetext/api';

export const submitOptIn = (
    body : PostOptInAPI['request']
) : Promise<CallAPIResult<PostOptInAPI['response']>> => {
    return callOneTextAPI({
        method: HTTP_METHOD.POST,
        path:   'optin',
        body
    });
};

export const getShortTokenInboundCheck = (
    query : GetShortTokenInboundCheckAPI['request']
) : Promise<CallAPIResult<GetShortTokenInboundCheckAPI['response']>> => {
    return callOneTextAPI({
        method: HTTP_METHOD.GET,
        path:   'short-token/inbound/check',
        query
    });
};

type StartOptInStatusPollOptions = {
    shortID : string,
    maxAttempts ?: number,
    intervalMs ?: Milliseconds,
};

export const startOptInStatusPoll = ({
    shortID,
    maxAttempts = 60,
    intervalMs = 2000 as Milliseconds
} : StartOptInStatusPollOptions) : void => {
    void poll({
        fn: async () => {
            const result = await getShortTokenInboundCheck({
                shortID
            });

            return result.body;
        },
        shouldStop: (body) => Boolean(body.messageReceived && body.hasMarketingPermission),
        intervalMs,
        maxAttempts,
        onError:    (err) => {
            trackError(err, {
                type:      'poll_optin_status_error',
                hardError: false
            });
        }
    }).then((body) => {
        if (body?.messageReceived && body.hasMarketingPermission) {
            return identifyCustomer({
                email: body.email,
                phone: body.phone
            });
        }
    });
};

