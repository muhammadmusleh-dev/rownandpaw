import type { PopupButtonConfig } from '@onetext/api';
import { FONT_WEIGHT, POPUP_FONT_PROVIDER, TEXT_TRANSFORM } from '@onetext/api';

const DEFAULT_BUTTON_STYLE = {
    mobile: {
        textTransform: TEXT_TRANSFORM.UPPERCASE,
        height:        '40px',
        borderRadius:  '4px',
        fontSize:      '16px',
        lineHeight:    '1.5',
        fontWeight:    FONT_WEIGHT._500,
        letterSpacing: '0.5px',
        padding:       '12px 24px'
    },
    desktop: {
        textTransform: TEXT_TRANSFORM.UPPERCASE,
        height:        '40px',
        borderRadius:  '4px',
        fontSize:      '16px',
        lineHeight:    '1.5',
        fontWeight:    FONT_WEIGHT._500,
        letterSpacing: '0.5px',
        padding:       '12px 24px'
    }
};

export const DEFAULT_BUTTON_CONFIG : PopupButtonConfig = {
    level: {
        primary: {
            color: {
                text: {
                    base:  '#ffffff',
                    hover: '#ffffff'
                },
                background: {
                    base:  '#2563eb',
                    hover: '#1d4ed8'
                }
            },
            style: DEFAULT_BUTTON_STYLE
        },
        secondary: {
            color: {
                text: {
                    base:  '#1d4ed8',
                    hover: '#1d4ed8'
                },
                background: {
                    base:  '#dbeafe',
                    hover: '#bfdbfe'
                }
            },
            style: DEFAULT_BUTTON_STYLE
        }
    }
} as const;

export const DEFAULT_STYLE_CONFIG = {
    color: {
        background: '#ffffff',
        text:       '#000000'
    },
    font: {
        default: {
            fontFamily:   'Helvetica Neue',
            fontProvider: POPUP_FONT_PROVIDER.BROWSER
        }
    }
} as const;

export const DEFAULT_TEASER_CONFIG = {
    color: {
        text: {
            base:  '#000',
            hover: '#000'
        },
        background: {
            base:  '#fff',
            hover: '#fff'
        },
        border: {
            base:  '#000',
            hover: '#000'
        }
    }
} as const;
