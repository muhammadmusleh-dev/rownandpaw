export enum SDK_ATTRIBUTE {
    SRC = 'src',
    ENV = 'data-env',
    ACCOUNT_TOKEN = 'data-account-token',
    CLIENT_ID = 'data-client-id',
    API_DOMAIN = 'data-api-domain',
    POPUP_ID = 'data-popup-id',
    EDITOR = 'data-editor'
}

export enum LOCALSTORAGE_KEY {
    ONETEXT_ACCOUNT_TOKEN = 'onetext-account-token',
    BROWSER_IDENTIFIER = 'onetext-browser-id',
    SUPPRESS_POPUP_PERMANENTLY = 'onetext-suppress-popup-permanently',
    ONETEXT_POPUP_LAST_CLOSED_AT = 'ot_popup_last_closed_at',
    ONETEXT_TEASER_LAST_CLOSED_AT = 'ot_teaser_last_closed_at',
    ONETEXT_POPUP_PROGRESS = 'ot_popup_progress'
}

export enum SESSIONSTORAGE_KEY {
    BROWSER_SESSION_IDENTIFIER = 'onetext-browser-session-id'
}
