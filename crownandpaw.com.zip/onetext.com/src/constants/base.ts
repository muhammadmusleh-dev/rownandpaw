export const Z_INDEX_MAX = 2_147_483_647;

