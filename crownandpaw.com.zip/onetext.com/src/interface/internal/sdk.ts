import { getURLQueryParam, isDevelopment, isPreviewMode, trackWebsiteView } from '../../lib';

export const sdk = {
    isDevelopment,
    isPreviewMode,
    getURLQueryParam,
    trackWebsiteView
};
