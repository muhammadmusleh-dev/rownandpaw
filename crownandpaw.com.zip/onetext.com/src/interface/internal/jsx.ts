import { clsx, deepmerge, element, render, useEffect, useState } from '../../jsx';

export const jsx = {
    element,
    render,
    useState,
    useEffect,
    clsx,
    deepmerge
};
