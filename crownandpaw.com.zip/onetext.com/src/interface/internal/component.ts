import { Fragment } from 'preact';

import {
    ConsentMultiPopup, ConsentPopup, ConsentPopupBackground, ConsentPopupButton, ConsentPopupCaptcha,
    ConsentPopupColumn, ConsentPopupColumns, ConsentPopupContainer, ConsentPopupCountdown, ConsentPopupCouponCode,
    ConsentPopupEmailField, ConsentPopupImage, ConsentPopupLogo, ConsentPopupPage, ConsentPopupPaymentForm,
    ConsentPopupPhoneField, ConsentPopupQuiz, ConsentPopupQuizOption, ConsentPopupRow, ConsentPopupSpinner,
    ConsentPopupTeaser, ConsentPopupTerms, ConsentPopupText, ConsentPopupVerticalSpacer
} from '../../components';

export const component = {
    consent: {
        popup: {
            MultiPopup:     ConsentMultiPopup,
            Popup:          ConsentPopup,
            Page:           ConsentPopupPage,
            Button:         ConsentPopupButton,
            EmailField:     ConsentPopupEmailField,
            PhoneField:     ConsentPopupPhoneField,
            Quiz:           ConsentPopupQuiz,
            QuizOption:     ConsentPopupQuizOption,
            Row:            ConsentPopupRow,
            Columns:        ConsentPopupColumns,
            Column:         ConsentPopupColumn,
            VerticalSpacer: ConsentPopupVerticalSpacer,
            Spinner:        ConsentPopupSpinner,
            Terms:          ConsentPopupTerms,
            Teaser:         ConsentPopupTeaser,
            PopupContainer: ConsentPopupContainer,
            Text:           ConsentPopupText,
            Logo:           ConsentPopupLogo,
            Background:     ConsentPopupBackground,
            Captcha:        ConsentPopupCaptcha,
            Image:          ConsentPopupImage,
            CouponCode:     ConsentPopupCouponCode,
            Countdown:      ConsentPopupCountdown,
            PaymentForm:    ConsentPopupPaymentForm,
            Fragment
        }
    }
};
