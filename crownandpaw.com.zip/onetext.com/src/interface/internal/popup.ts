import { PopupTemplate, registerPopup, renderPopup } from '../../components';

export const popup = {
    render:   renderPopup,
    register: registerPopup,
    template: PopupTemplate
};
