import { submitCustomerOptIn } from '../../biz';

import type { TOKEN, TokenType } from '@onetext/api';

type SubmitOptions = {
    phone ?: string,
    email ?: string,
    customerProperties ?: Record<string, string>,
};

type SubmitResponse = {
    accountToken : TokenType<TOKEN.ACCOUNT> | undefined,
};

const submit = ({ email, phone, customerProperties } : SubmitOptions) : Promise<SubmitResponse> => {
    return submitCustomerOptIn({
        popupToken: undefined,
        email,
        phone,
        customerProperties
    });
};

export const optin = {
    submit
};
