import { getCustomer } from '../../biz';

type Customer = {
    recognized : boolean,
};

const get = () : Promise<Customer> => getCustomer();

export const customer = {
    get
};
