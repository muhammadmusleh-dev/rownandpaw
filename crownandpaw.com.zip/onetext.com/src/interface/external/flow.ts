import { launchFlow } from '../../biz';

import type { PhoneNumber } from '@onetext/api';
import { CORE_FLOW_TYPE } from '@onetext/api';

type LaunchCustomFlowOptions = {
    externalID : string,
    phoneNumber ?: PhoneNumber,
    email ?: string,
    incomingMessageText ?: string,
    parameters ?: JSONObject,
    allowAutoThreadSwitch ?: boolean,
    allowModal ?: boolean,
    followQuietHours ?: boolean,
};

const launchCustomFlow = ({
    externalID,
    phoneNumber,
    email,
    incomingMessageText,
    parameters,
    allowAutoThreadSwitch,
    allowModal,
    followQuietHours = true
} : LaunchCustomFlowOptions) : Promise<void> => {
    if (!externalID) {
        throw new Error(`Expected externalID`);
    }

    return launchFlow({
        externalID,
        phoneNumber,
        email,
        incomingMessageText,
        parameters,
        allowAutoThreadSwitch,
        allowModal,
        followQuietHours
    });
};

type LaunchCoreFlowOptions = {
    type : CORE_FLOW_TYPE.WELCOME,
    phoneNumber ?: PhoneNumber,
    email ?: string,
    incomingMessageText ?: string,
    customFlowParameters ?: JSONObject,
    allowAutoThreadSwitch ?: boolean,
    allowModal ?: boolean,
    followQuietHours ?: boolean,
    marketingConsentGranted ?: boolean,
};

const launchCoreFlow = ({
    type,
    phoneNumber,
    email,
    incomingMessageText,
    customFlowParameters,
    allowAutoThreadSwitch,
    allowModal,
    followQuietHours = true
} : LaunchCoreFlowOptions) : Promise<void> => {
    return launchFlow({
        coreFlowType: type,
        phoneNumber,
        email,
        incomingMessageText,
        parameters:   customFlowParameters,
        allowAutoThreadSwitch,
        allowModal,
        followQuietHours
    });
};

const coreFlowTypes = {
    welcome: CORE_FLOW_TYPE.WELCOME
};

export const flow = {
    core: {
        types: coreFlowTypes,
        start: launchCoreFlow
    },
    custom: {
        start: launchCustomFlow
    }
};
