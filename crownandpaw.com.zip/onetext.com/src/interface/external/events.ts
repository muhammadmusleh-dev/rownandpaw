import { events as eventTracker } from '../../biz';

import type { Email } from '@onetext/api';

type EventsAPI = {
    popup : {
        email : {
            submit : {
                listen : (listener : (payload : { email : Email }) => Promise<void> | void) => { cancel : () => void },
                emit : (payload : { email : Email }) => void,
            },
        },
        phone : {
            submit : {
                listen : (listener : (payload : { phone : string }) => Promise<void> | void) => { cancel : () => void },
                emit : (payload : { phone : string }) => void,
            },
        },
    },
};

export const events : EventsAPI = {
    popup: {
        email: {
            submit: eventTracker.popup.email.submit
        },
        phone: {
            submit: eventTracker.popup.phone.submit
        }
    }
};
