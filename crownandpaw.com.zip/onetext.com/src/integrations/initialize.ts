import { initializeKlaviyoIntegration } from './klaviyo';
import { initializeShopifyIntegration } from './shopify';

export const initializeIntegrations = async () : Promise<void> => {
    await Promise.all([
        initializeKlaviyoIntegration(),
        initializeShopifyIntegration()
    ]);
};
