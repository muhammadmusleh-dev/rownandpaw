import type { LOCALSTORAGE_KEY } from '../constants';

import {
    assertUnreachable, isValidLocalStorageKey, localStorageGet, localStorageRemove, localStorageSet
} from './util';

import type { Milliseconds, PopupConfig } from '@onetext/api';
import { MODAL_TYPE } from '@onetext/api';

const POPUP_COOLDOWN_MS = 7 * 24 * 60 * 60 * 1000 as Milliseconds; // 7 days in milliseconds
const TEASER_COOLDOWN_MS = 1 * 24 * 60 * 60 * 1000 as Milliseconds; // 1 day in milliseconds

type CooldownParams = {
    type : MODAL_TYPE,
    brandConfig ?: PopupConfig,
};

const constructKey = ({ type } : CooldownParams) : LOCALSTORAGE_KEY => {
    const prefix = `ot_${ type }`;
    const parts = [ prefix, 'last_closed_at' ];
    const key = parts.filter(Boolean).join('_');

    if (!isValidLocalStorageKey(key)) {
        throw new Error(`Invalid localStorage key: ${ key }`);
    }

    return key;
};

export const setLastClosedTime = (params : CooldownParams) : void => {
    const key = constructKey(params);
    localStorageSet(key, Date.now().toString());
};

const getCooldownMilliseconds = (type : MODAL_TYPE, brandConfig ?: PopupConfig) : Milliseconds => {

    switch (type) {
        case MODAL_TYPE.POPUP:
            return brandConfig?.behavior?.cooldown?.popup?.milliseconds
                ? brandConfig.behavior.cooldown.popup.milliseconds
                : POPUP_COOLDOWN_MS;
        case MODAL_TYPE.TEASER:
            return brandConfig?.behavior?.cooldown?.teaser?.milliseconds
                ? brandConfig.behavior.cooldown.teaser.milliseconds
                : TEASER_COOLDOWN_MS;
        default:
            throw assertUnreachable(type);
    }
};

export const isCoolingDown = ({ type, brandConfig } : CooldownParams) : boolean => {
    const keyWithoutToken = constructKey({ type });
    const lastClosedAt = localStorageGet<string>(keyWithoutToken);

    if (!lastClosedAt) {
        return false;
    }

    const cooldownMs = getCooldownMilliseconds(type, brandConfig);
    return (Date.now() - Number.parseInt(lastClosedAt, 10)) < cooldownMs;
};

export const removeLastClosedTime = (params : CooldownParams) : void => {
    const key = constructKey(params);
    localStorageRemove(key);
};
