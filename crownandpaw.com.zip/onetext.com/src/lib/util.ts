import type { PhoneResult } from 'phone';

import { phone as validateInternationalPhone } from 'phone';

import type { Cancelable } from '../types';

import { LOCALSTORAGE_KEY } from '../constants';

import { getURLQuery } from './dom';
import { eventEmitter } from './event';

import type { Email, HTTPQuery, HTTPQueryInput, HTTPUrl, Milliseconds, Percentage } from '@onetext/api';
import { ENV } from '@onetext/api';

const envs = Object.values(ENV);

// eslint-disable-next-line security/detect-non-literal-regexp
const tokenRegex = new RegExp(`^onetext(?:_\\w+)+_(${ envs.join('|') })_`);

export const tokenToEnv = (token : string) : ENV => {
    const match = token.match(tokenRegex);

    if (!match) {
        throw new Error(`Can not determine SDK environment`);
    }

    const env = match[1];

    if (!env) {
        throw new Error(`Can not determine SDK environment`);
    }

    if (!envs.includes(env)) {
        throw new Error(`Invalid SDK environment: ${ env }`);
    }

    return env as ENV;
};

export const run = <Type>(handler : () => Type) : Type => {
    return handler();
};

export const promiseTry = async <Type>(handler : () => Promise<Type> | Type) : Promise<Type> => {
    return await handler();
};

export const onLocalStorageChange = eventEmitter<{
    key : LOCALSTORAGE_KEY,
    value : unknown,
}>();

export const isValidLocalStorageKey = (value : string) : value is LOCALSTORAGE_KEY => {
    return Object.values(LOCALSTORAGE_KEY).includes(value);
};

let localStorageEnabled : boolean | undefined;

export const isLocalStorageEnabled = () : boolean => {
    if (localStorageEnabled !== undefined) {
        return localStorageEnabled;
    }

    try {
        if (typeof window === 'undefined') {
            return false;
        }

        // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
        if (window.localStorage) {
            const value = Math.random().toString();
            window.localStorage.setItem('__test__localStorage__', value);
            const result = window.localStorage.getItem('__test__localStorage__');
            window.localStorage.removeItem('__test__localStorage__');

            if (value === result) {
                localStorageEnabled = true;
                return true;
            }
        }
    } catch {
        // pass
    }

    localStorageEnabled = false;
    return false;
};

const memoryLocalStorage : Record<string, string> = {};

export const localStorageGet = <Type>(key : LOCALSTORAGE_KEY) : Type | undefined => {
    if (!isLocalStorageEnabled()) {
        return;
    }

    let result = memoryLocalStorage[key];

    if (result === undefined) {
        try {
            result = window.localStorage.getItem(key) ?? undefined;
        } catch {
            return;
        }
    }

    if (result === undefined) {
        return;
    }

    try {
        const parsed = JSON.parse(result);
        return parsed as Type;
    } catch {
        // If JSON.parse fails, the value might be a plain string
        // Return the original string if Type is string, otherwise undefined
        if (typeof result === 'string') {
            return result as Type;
        }
    }
};

export const localStorageSet = <Type>(key : LOCALSTORAGE_KEY, value : Type) : Type => {
    if (!isLocalStorageEnabled()) {
        return value;
    }

    const serializedValue = JSON.stringify(value);
    memoryLocalStorage[key] = serializedValue;

    try {
        window.localStorage.setItem(key, serializedValue);
    } catch {
        return value;
    }

    onLocalStorageChange.emit({
        key,
        value
    });

    return value;
};

export const localStorageRemove = (key : LOCALSTORAGE_KEY) : void => {
    if (!isLocalStorageEnabled()) {
        return;
    }

    delete memoryLocalStorage[key];

    try {
        window.localStorage.removeItem(key);
    } catch {
        // pass
    }
};

export const localStorageUpdate = <Type>(
    key : LOCALSTORAGE_KEY,
    updater : (value : Type) => Type,
    defaultValue : () => Type
) : Type => {
    return localStorageSet(key, updater(localStorageGet(key) ?? defaultValue()));
};

export const localStorageOnChange = <Type>(
    key : LOCALSTORAGE_KEY,
    callback : (value : Type) => void
) : void => {
    onLocalStorageChange.listen(({ key: changedKey, value }) => {
        if (changedKey === key) {
            callback(value as Type);
        }
    });
};

type LocalStorageNamespaceOptions<Type> = {
    namespace : LOCALSTORAGE_KEY,
    defaultValue : () => Type,
};

type LocalStorageNamespace<Type> = {
    get : () => Type,
    set : (value : Type) => Type,
    update : (updater : (value : Type) => Type) => Type,
    onChange : (callback : (value : Type) => void) => void,
    remove : () => void,
};

export const localStorageNamespace = <Type>({
    namespace,
    defaultValue
} : LocalStorageNamespaceOptions<Type>) : LocalStorageNamespace<Type> => {
    return {
        get:      () => localStorageGet(namespace) ?? defaultValue(),
        set:      value => localStorageSet(namespace, value),
        update:   updater => localStorageUpdate(namespace, updater, defaultValue),
        onChange: callback => localStorageOnChange(namespace, callback),
        remove:   () => localStorageRemove(namespace)
    };
};

export const getUserAgent = () : string | undefined => {
    try {
        return window.navigator.mockUserAgent ?? window.navigator.userAgent;
    } catch {
        // pass
    }
};

export const isDevice = (userAgent : string | undefined = getUserAgent()) : boolean => {
    if (!userAgent) {
        return false;
    }

    if ((/android|webos|iphone|ipad|ipod|bada|symbian|palm|crios|blackberry|iemobile|windowsmobile|opera mini/i).test(userAgent)) {
        return true;
    }

    return false;
};

export const noop = () : void => {
    // pass
};

export const assertExists = <T>(thing : undefined | null | T) : T => {
    if (thing === null || thing === undefined) {
        throw new Error(`Expected value to be present`);
    }

    return thing;
};

export const getStackTrace = () : string => {
    try {
        throw new Error('_');
    } catch (err) {
        return (err as Error).stack ?? '';
    }
};

const currentScript : HTMLScriptElement | undefined = typeof document === 'undefined'
    ? undefined
    : document.currentScript as HTMLScriptElement | undefined;

type GetCurrentScript = () => HTMLScriptElement;

export const getCurrentScript : GetCurrentScript = () => {
    if (
        // eslint-disable-next-line @typescript-eslint/prefer-optional-chain
        currentScript &&
        currentScript.src &&
        (
            currentScript.src.startsWith('http://') ||
            currentScript.src.startsWith('https://') ||
            currentScript.src.startsWith('/')
        ) &&
        !currentScript.src.startsWith('data:')
    ) {
        return currentScript;
    }

    throw new Error('Can not determine current script');
};

export const getCurrentScriptURL = () : string => {
    return getCurrentScript().src;
};

export const getCurrentScriptBasePath = () : string => {
    return getCurrentScriptURL().replace(/[^/]*$/, '');
};

export const getBody = () : HTMLBodyElement => {
    const body = document.body as HTMLBodyElement | undefined;

    if (!body) {
        throw new Error(`Body element not found`);
    }

    return body;
};

export const awaitBody = async () : Promise<HTMLBodyElement> => {
    const existingBody = document.body as HTMLBodyElement | undefined;

    if (existingBody) {
        return existingBody;
    }

    return new Promise<HTMLBodyElement>(resolve => {
        const check = () : void => {
            const body = document.body as HTMLBodyElement | undefined;

            if (body) {
                resolve(body);
            }
        };

        window.addEventListener('load', check);
        document.addEventListener('DOMContentLoaded', check);
    });
};

export const debounce = <
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    FunctionType extends (...args : Array<any>) => any
>(
    func : FunctionType,
    delay : number
) : ((...args : Parameters<FunctionType>) => void) => {
    let timeoutId : ReturnType<typeof setTimeout>;

    const wrapper = (...args : ReadonlyArray<unknown>) : void => {
        clearTimeout(timeoutId);

        timeoutId = setTimeout(() => {
            func(...args);
        }, delay);
    };

    return wrapper;
};

export const debouncePromise = <
    FunctionReturnType,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    FunctionType extends (...args : Array<any>) => Promise<FunctionReturnType>,
    FinalReturnType extends Awaited<ReturnType<FunctionType>>
>(
    func : FunctionType,
    delay : number
) : ((...args : Parameters<FunctionType>) => Promise<FinalReturnType>) => {
    let timer : ReturnType<typeof setTimeout>;

    let promise : Promise<FinalReturnType> | undefined;
    let resolve : ((value : FinalReturnType) => void) | undefined;
    let reject : ((err : unknown) => void) | undefined;

    const wrapper = (...args : ReadonlyArray<unknown>) : Promise<FinalReturnType> => {
        clearTimeout(timer);

        // eslint-disable-next-line promise/param-names
        promise ??= new Promise<FinalReturnType>((res, rej) => {
            resolve = res;
            reject = rej;
        });

        const innerResolve = resolve;
        const innerReject = reject;

        if (!innerResolve || !innerReject) {
            throw new Error('Promise not initialized');
        }

        timer = setTimeout(() => {
            void promiseTry(async () => {
                let result;

                try {
                    result = await func(...args);
                    innerResolve(result as unknown as FinalReturnType);
                } catch (err) {
                    innerReject(err);
                } finally {
                    promise = undefined;
                    resolve = undefined;
                    reject = undefined;
                }
            });
        }, delay);

        return promise;
    };

    return wrapper;
};

type Eventable = {
    addEventListener : (type : string, handler : (event : Event) => void) => void,
    removeEventListener : (type : string, handler : (event : Event) => void) => void,
};

export const listen = (
    item : Eventable,
    eventName : string,
    handler : (event : Event) => void
) : Cancelable => {
    item.addEventListener(eventName, handler);

    return {
        cancel: () => {
            item.removeEventListener(eventName, handler);
        }
    };
};

type MemoizeOptions = {
    ttl ?: number,
};

export const memoize = <
    FunctionType extends (...args : Array<unknown>) => unknown
>(
    func : FunctionType,
    opts : MemoizeOptions = {}
) : ((...args : Parameters<FunctionType>) => ReturnType<FunctionType>) => {
    const {
        ttl = 5 * 60 * 1000
    } = opts;

    let result : {
        value : ReturnType<FunctionType>,
        timestamp : number,
    } | undefined;

    return (...args : Parameters<FunctionType>) => {
        const now = Date.now();

        if (result && now - result.timestamp < ttl) {
            return result.value;
        }

        result = {
            value:     func(...args) as ReturnType<FunctionType>,
            timestamp: now
        };

        return result.value;
    };
};

export const assertUnreachable = (value : never) : Error => {
    throw new Error(`Unreachable value: ${ JSON.stringify(value) }`);
};

export type ExpandedPromise<Type> = {
    promise : Promise<Type>,
    resolve : (value : Type) => void,
    reject : (error : unknown) => void,
};

export const createPromise = <Type>() : ExpandedPromise<Type> => {
    let promiseResolve;
    let promiseReject;

    const promise = new Promise<Type>((resolve, reject) => {
        promiseResolve = resolve;
        promiseReject = reject;
    });

    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
    if (!promiseResolve || !promiseReject) {
        throw new Error('Promise not initialized');
    }

    return {
        promise,
        resolve: promiseResolve,
        reject:  promiseReject
    };
};

export const isValidEmail = (email : string) : email is Email => {
    if (!(/^[^\s@]+@[^\s@]+\.[^\s@]+$/).test(email)) {
        return false;
    }

    return true;
};

type ValidatePhoneOptions = {
    countryCode : string,
    strictDetection ?: boolean,
    validateMobilePrefix ?: boolean,
};

export const isValidPhone = (phone : string, {
    countryCode,
    strictDetection = true,
    validateMobilePrefix = true
} : ValidatePhoneOptions) : PhoneResult => {
    return validateInternationalPhone(phone, {
        country: countryCode,
        validateMobilePrefix,
        strictDetection
    });
};

export const removePhoneCountryCode = (phone : string, countryCode : string) : string => {
    return phone.replace(countryCode, '');
};

type ParsePhoneOptions = {
    countryCode : string,
};

export const parsePhone = (potentialPhone : string, {
    countryCode
} : ParsePhoneOptions) : string | undefined => {
    const normalizedPhone = potentialPhone.replace(/\D+/g, '');

    const phone = isValidPhone(normalizedPhone, {
        countryCode,
        strictDetection:      true,
        validateMobilePrefix: true
    });

    return phone.phoneNumber
        ? phone.phoneNumber
        : undefined;
};

export const identity = <Type>(value : Type) : Type => {
    return value;
};

export const randomInteger = (min : number, max : number) : number => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
};

export const delay = (ms : Milliseconds) : Promise<void> => new Promise(resolve => {
    setTimeout(resolve, ms);
});

type PollOptions<Result> = {
    fn : () => Promise<Result>,
    shouldStop : (result : Result) => boolean,
    intervalMs : Milliseconds,
    maxAttempts ?: number,
    onError ?: (err : unknown) => void,
};

export const poll = async <Result>({
    fn,
    shouldStop,
    intervalMs,
    maxAttempts = Number.POSITIVE_INFINITY,
    onError
} : PollOptions<Result>) : Promise<Result | undefined> => {
    let attempts = 0;

    const doPoll = async () : Promise<Result | undefined> => {
        if (attempts >= maxAttempts) {
            return;
        }

        attempts += 1;

        try {
            const result = await fn();

            if (shouldStop(result)) {
                return result;
            }

            await delay(intervalMs);
            return doPoll();
        } catch (err) {
            if (onError) {
                onError(err);
            }

            await delay(intervalMs);
            return doPoll();
        }
    };

    await delay(intervalMs);
    return doPoll();
};

export const isIncompatibleBrowser = () : boolean => {
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
    if (!Symbol.iterator) {
        return true;
    }

    const arr : ReadonlyArray<never> = [];

    if (!arr[Symbol.iterator]) {
        return true;
    }

    if (typeof window.scrollTo !== 'function') {
        return true;
    }

    if (typeof Object.fromEntries !== 'function') {
        return true;
    }

    try {
        getURLQuery();
    } catch {
        return true;
    }

    return false;
};

export const urlEncode = (str : string) : string => encodeURIComponent(str);

export const formatQuery = (obj : HTTPQueryInput = {}) : string => Object.keys(obj).filter(key => {
    return typeof obj[key] === 'string' || typeof obj[key] === 'boolean' || typeof obj[key] === 'number';
}).map(key => {
    const val = obj[key];

    if (typeof val !== 'string' && typeof val !== 'boolean' && typeof val !== 'number') {
        throw new TypeError(`Invalid type for query`);
    }

    return `${ urlEncode(key) }=${ urlEncode(val.toString()) }`;
}).join('&');

export const parseQuery = (queryString : string) : HTTPQuery => {
    const params : HTTPQuery = {};

    if (!queryString) {
        return params;
    }

    if (queryString.indexOf('=') === -1) {
        return params;
    }

    for (const pair of queryString.split('&')) {
        const [ key, value ] = pair.split('=');

        if (key && value) {
            params[decodeURIComponent(key)] = decodeURIComponent(value);
        }
    }

    return params;
};

export const extendQuery = (originalQuery : string, props : HTTPQueryInput = {}) : string => {

    if (!Object.keys(props).length) {
        return originalQuery;
    }

    const queryPrefix = originalQuery.match(/^([^=]+)(&|$)/)?.[1] ?? '';

    return (queryPrefix
        ? `${ queryPrefix }&`
        : ``) + formatQuery({
        ...parseQuery(originalQuery.slice(queryPrefix.length)),
        ...props
    });
};

export const extendUrl = (url : string, options : { query ?: HTTPQueryInput, hash ?: HTTPQueryInput }) : HTTPUrl => {

    const query = options.query ?? {};
    const hash = options.hash ?? {};

    let originalUrl;
    let originalQuery;
    let originalHash;

    [ originalUrl = '', originalHash = '' ] = url.split('#');
    [ originalUrl = '', originalQuery = '' ] = originalUrl.split('?');

    const queryString = extendQuery(originalQuery, query);
    const hashString = extendQuery(originalHash, hash);

    if (queryString) {
        originalUrl = `${ originalUrl }?${ queryString }`;
    }

    if (hashString) {
        originalUrl = `${ originalUrl }#${ hashString }`;
    }

    return originalUrl as HTTPUrl;
};

let sessionStorageEnabled : boolean | undefined;

export const isSessionStorageEnabled = () : boolean => {
    if (sessionStorageEnabled !== undefined) {
        return sessionStorageEnabled;
    }

    try {
        if (typeof window === 'undefined') {
            return false;
        }

        const testKey = 'onetext_session_storage_test';
        sessionStorage.setItem(testKey, 'test');
        sessionStorage.removeItem(testKey);

        sessionStorageEnabled = true;
        return true;
    } catch {
        sessionStorageEnabled = false;
        return false;
    }
};

const memorySessionStorage : {
    [ key : string ] : string | undefined,
} = {};

export const sessionStorageSet = (key : string, value : string) : string => {
    memorySessionStorage[key] = value;

    try {
        if (isSessionStorageEnabled()) {
            sessionStorage.setItem(key, value);
        }
    } catch {
        // pass
    }

    return value;
};

export const sessionStorageGet = (key : string) : string | undefined => {
    const memoryValue = memorySessionStorage[key];

    if (memoryValue !== undefined) {
        return memoryValue;
    }

    try {
        if (isSessionStorageEnabled()) {
            const value = sessionStorage.getItem(key) ?? undefined;

            if (value !== undefined) {
                memorySessionStorage[key] = value;
            }

            return value;
        }
    } catch {
        // pass
    }

    return undefined;
};

export const sessionStorageRemove = (key : string) : void => {
    delete memorySessionStorage[key];

    try {
        if (isSessionStorageEnabled()) {
            sessionStorage.removeItem(key);
        }
    } catch {
        // pass
    }
};

export const stringToPercentile = (str : string) : Percentage => {
    let hash = 0x81_1C_9D_C5; // FNV-1a 32-bit offset basis

    for (let i = 0; i < str.length; i++) {
        // eslint-disable-next-line unicorn/prefer-code-point, no-bitwise
        hash ^= str.charCodeAt(i);
        // eslint-disable-next-line no-bitwise
        hash = (hash * 0x01_00_01_93) >>> 0; // Multiply by FNV prime and ensure uint32
    }

    return (hash % 100) as Percentage;
};

export const isUUID = (str : string) : boolean => {
    return Boolean((/^[\da-f]{8}(?:-[\da-f]{4}){3}-[\da-f]{12}$/).test(str));
};

export const countryCodeToFlag = (countryCode : string) : string => {
    return countryCode
        .toUpperCase()
        .split('')
        .map(char => String.fromCodePoint(0x1_F1_E6 + (char.codePointAt(0) ?? 65) - 65))
        .join('');
};

export const now = () : Milliseconds => {
    return Date.now() as Milliseconds;
};
