import { trackBuyerEvent } from '../biz';

import { isDevelopment, isEditorMode } from './sdk';

import type { HTTPUrl, TOKEN, TokenType } from '@onetext/api';
import { PUBLIC_BUYER_EVENT } from '@onetext/api';

export type TrackWebsiteViewParams = {
    popupToken ?: TokenType<TOKEN.POPUP>,
};

type WebsiteViewPayload = {
    url : HTTPUrl,
    popupToken ?: TokenType<TOKEN.POPUP>,
};

export const trackWebsiteView = (params : TrackWebsiteViewParams = {}) : void => {
    if (isDevelopment() || isEditorMode()) {
        return;
    }

    const payload : WebsiteViewPayload = {
        url:        window.location.href as HTTPUrl,
        popupToken: params.popupToken
    };

    trackBuyerEvent({
        buyerEvent: PUBLIC_BUYER_EVENT.PAGE_VIEW,
        payload
    });
};
