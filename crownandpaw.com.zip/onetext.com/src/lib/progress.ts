import type { PhoneCandidate } from '../types';

import { LOCALSTORAGE_KEY } from '../constants';

import { isDevelopment, isEditorMode, isPreviewMode } from './sdk';
import { localStorageNamespace } from './util';

import type { Email } from '@onetext/api';

type PopupProgress = {
    phone ?: PhoneCandidate,
    email ?: Email,
    hasSubmittedEmail ?: boolean,
    hasSubmittedPhone ?: boolean,
};

const popupsProgressStorageNamespace = localStorageNamespace<PopupProgress>({
    namespace:    LOCALSTORAGE_KEY.ONETEXT_POPUP_PROGRESS,
    defaultValue: () => ({})
});

export const getPopupProgress = () : PopupProgress | undefined => {

    if (isDevelopment() || isPreviewMode() || isEditorMode()) {
        return;
    }

    const progressRecord = popupsProgressStorageNamespace.get();
    return progressRecord;
};

export const savePopupProgress = (payload : PopupProgress) : void => {

    if (isDevelopment() || isPreviewMode() || isEditorMode()) {
        return;
    }

    const progressRecord = getPopupProgress() ?? {};

    popupsProgressStorageNamespace.set({
        ...progressRecord,
        ...payload
    });
};
