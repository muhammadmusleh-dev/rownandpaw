import { SDK_ATTRIBUTE } from '../constants';

import { getURLQueryParam } from './dom';
import { delay, getCurrentScript, isUUID, tokenToEnv } from './util';

import type { ENV, Milliseconds, TOKEN, TokenType } from '@onetext/api';
import { HTTP_METHOD, NODE_ENV, ONETEXT, QUERY_PARAM } from '@onetext/api';

export const isDevelopment = () : boolean => {
    return process.env.NODE_ENV === NODE_ENV.DEVELOPMENT;
};

export const getSDKScript = () : HTMLScriptElement => {
    return getCurrentScript();
};

export const getSDKUrl = () : string => {
    return getSDKScript().src;
};

export const getAPIDomain = () : string => {
    const script = getSDKScript();
    const domain = script.getAttribute(SDK_ATTRIBUTE.API_DOMAIN);

    if (domain) {
        return domain;
    }

    const url = new URL(script.src);
    return `${ url.protocol }//${ url.host }`;
};

export const getSDKAttribute = (name : SDK_ATTRIBUTE) : string | undefined => {
    const value = getSDKScript().getAttribute(name);

    if (value) {
        return value;
    }

    return undefined;
};

export const getSDKScriptQueryParams = () : URLSearchParams => {
    const scriptSrc = getSDKAttribute(SDK_ATTRIBUTE.SRC);

    if (!scriptSrc) {
        return new URLSearchParams();
    }

    let url : URL;

    if ((/^https?:\/\//).test(scriptSrc)) {
        url = new URL(scriptSrc);
    } else if (isDevelopment() && scriptSrc.startsWith('/')) {
        url = new URL(scriptSrc, window.location.origin);
    } else {
        return new URLSearchParams();
    }

    return url.searchParams;
};

export const getSDKQueryParam = (name : QUERY_PARAM) : string | undefined => {
    const queryParams = getSDKScriptQueryParams();
    const queryParamValue = queryParams.get(name);

    if (queryParamValue) {
        return queryParamValue;
    }

    return undefined;
};

export const getSDKAccountToken = () : string | undefined => {
    return getSDKAttribute(SDK_ATTRIBUTE.ACCOUNT_TOKEN) ?? getSDKQueryParam(QUERY_PARAM.ACCOUNT_TOKEN);
};

export const getSDKClientID = () : string | undefined => {
    return getSDKAttribute(SDK_ATTRIBUTE.CLIENT_ID) ?? getSDKQueryParam(QUERY_PARAM.CLIENT_ID);
};

export const getSDKEnv = () : ENV => {
    const sdkEnv = getSDKAttribute(SDK_ATTRIBUTE.ENV);

    if (sdkEnv) {
        return sdkEnv as ENV;
    }

    const sdkAccountToken = getSDKAccountToken();

    if (sdkAccountToken) {
        return tokenToEnv(sdkAccountToken);
    }

    const sdkClientID = getSDKClientID();

    if (sdkClientID) {
        return tokenToEnv(sdkClientID);
    }

    throw new Error(`Can not determine SDK environment`);
};

export const getSDKTimestamp = () : Milliseconds | undefined => {
    const timestamp = getSDKQueryParam(QUERY_PARAM.TIMESTAMP);

    if (!timestamp?.match(/^\d+$/)) {
        return;
    }

    const milliseconds = Number.parseInt(timestamp, 10);

    return milliseconds as Milliseconds;
};

export const isPreviewMode = () : boolean => {
    return Boolean(
        isDevelopment() ||
        getURLQueryParam(QUERY_PARAM.ONETEXT_PREVIEW)
    );
};

export const isEditorMode = () : boolean => {
    return Boolean(getSDKAttribute(SDK_ATTRIBUTE.EDITOR)) ||
        Boolean(getSDKQueryParam(QUERY_PARAM.ONETEXT_EDITOR));
};

export const getSDKAuthUsername = () : string | undefined => {
    return getSDKAccountToken() ?? getSDKClientID();
};

export const getSDKAuthToken = () : string | undefined => {
    const username = getSDKAuthUsername();

    if (!username) {
        return;
    }

    return btoa(`${ username }:`);
};

export const getSDKAuthHeader = () : string | undefined => {
    const authToken = getSDKAuthToken();

    if (!authToken) {
        return;
    }

    return `Basic ${ authToken }`;
};

let currentScriptModifiedAt : string | undefined;

export const hotReloadPageOnSDKUpdate = async () : Promise<void> => {
    const script = getSDKUrl();

    const res = await fetch(script, {
        method: HTTP_METHOD.HEAD
    });

    const lastModified = res.headers.get('Last-Modified') ?? undefined;
    currentScriptModifiedAt ??= lastModified;

    if (lastModified) {
        if (lastModified === currentScriptModifiedAt) {
            await delay(1000 as Milliseconds);
            void hotReloadPageOnSDKUpdate();
        } else {
            window.location.reload();
        }
    }
};

export const getSDKPopupID = () : string | undefined => {
    return (
        getURLQueryParam(QUERY_PARAM.POPUP_ID) ??
        getSDKAttribute(SDK_ATTRIBUTE.POPUP_ID) ??
        getSDKQueryParam(QUERY_PARAM.POPUP_ID)
    );
};

type IsTokenTypeOptions<
    CurrentTokenType extends TOKEN
> = {
    env : ENV,
    type : CurrentTokenType,
};

export const isTokenType = <
    CurrentTokenType extends TOKEN
>(potentialToken : string, {
    env,
    type
} : IsTokenTypeOptions<CurrentTokenType>) : potentialToken is TokenType<CurrentTokenType> => {
    try {
        const tokenParts = potentialToken.split('_');

        const tokenOneText = tokenParts.shift();
        const tokenUUID = tokenParts.pop();
        const tokenEnv = tokenParts.pop();
        const tokenType = tokenParts.join('_');

        if (!tokenOneText || tokenOneText !== ONETEXT) {
            return false;
        }

        if (!tokenType || tokenType !== type) {
            return false;
        }

        if (!tokenEnv || tokenEnv !== env) {
            return false;
        }

        if (!tokenUUID || !isUUID(tokenUUID)) {
            return false;
        }

        return true;
    } catch {
        return false;
    }
};

export const parseTokenID = (token : string) : string | undefined => {
    try {
        const tokenParts = token.split('_');
        const tokenUUID = tokenParts.pop();

        if (!tokenUUID || !isUUID(tokenUUID)) {
            return undefined;
        }

        return tokenUUID;
    } catch {
        return undefined;
    }
};
