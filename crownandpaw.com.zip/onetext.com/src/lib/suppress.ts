import { getStoredAccountToken } from '../biz';
import { LOCALSTORAGE_KEY } from '../constants';

import { isCoolingDown } from './cooldown';
import { isDevelopment, isEditorMode, isPreviewMode } from './sdk';
import { localStorageGet } from './util';

import type { GetPopupAPIResponse, PopupConfig } from '@onetext/api';
import { MODAL_TYPE } from '@onetext/api';

enum SUPPRESS_REASON {
    SUPPRESSED_ROUTE = 'suppressed_route',
    COOLING_DOWN = 'cooling_down',
    CUSTOMER_RECOGNIZED = 'customer_recognized',
    SUPPRESSED_COUNTRY = 'suppressed_country',
    RENDERED_IN_IFRAME = 'rendered_in_iframe',
    SUPPRESSED_POPUP_PERMANENTLY = 'suppressed_popup_permanently',
    SUBMITTED_POPUP = 'submitted_popup'
}

type ShouldSuppressOptions = {
    popup : GetPopupAPIResponse,
    hasSubmittedPopup ?: boolean,
    suppressedRoutes ?: ReadonlyArray<string>,
    suppressedKeywords ?: ReadonlyArray<string>,
    suppressedQueryParams ?: ReadonlyArray<string>,
    type : MODAL_TYPE,
    shownToCountries ?: ReadonlyArray<string>,
    brandConfig ?: PopupConfig,
};

export type ShouldSuppressResult =
    | {
        suppressed : true,
        reason : SUPPRESS_REASON,
    }
    | {
        suppressed : false,
    };

const shouldSuppress = ({
    popup,
    hasSubmittedPopup = false,
    suppressedRoutes = [],
    suppressedKeywords = [],
    suppressedQueryParams = [],
    type,
    shownToCountries = [],
    brandConfig
} : ShouldSuppressOptions) : ShouldSuppressResult => {
    if (isDevelopment() || isPreviewMode() || isEditorMode()) {
        return { suppressed: false };
    }

    if (window.self !== window.top) {
        return {
            suppressed: true,
            reason:     SUPPRESS_REASON.RENDERED_IN_IFRAME
        };
    }

    if (hasSubmittedPopup) {
        return {
            suppressed: true,
            reason:     SUPPRESS_REASON.SUBMITTED_POPUP
        };
    }

    const currentURL = window.location.href;
    const currentPath = window.location.pathname;
    const currentSearch = window.location.search;
    const searchParams = new URLSearchParams(currentSearch);

    const isSuppressedCountry = popup.customerCountry &&
        shownToCountries.length &&
        !shownToCountries.includes(popup.customerCountry);

    if (isSuppressedCountry) {
        return {
            suppressed: true,
            reason:     SUPPRESS_REASON.SUPPRESSED_COUNTRY
        };
    }

    const isSuppressedRouteResult = {
        suppressed: true,
        reason:     SUPPRESS_REASON.SUPPRESSED_ROUTE
    };

    if (suppressedRoutes.some((route : string) => currentPath.startsWith(route))) {
        return isSuppressedRouteResult;
    }

    if (suppressedKeywords.some((keyword : string) => currentURL.includes(keyword))) {
        return isSuppressedRouteResult;
    }

    if (suppressedQueryParams.some((param : string) => {
        if (param.includes('=')) {
            const [ key, expectedValue ] = param.split('=');
            const actualValue = searchParams.get(key ?? '');
            return actualValue === expectedValue;
        }

        return searchParams.has(param);
    })) {
        return isSuppressedRouteResult;
    }

    if (getStoredAccountToken()) {
        return {
            suppressed: true,
            reason:     SUPPRESS_REASON.CUSTOMER_RECOGNIZED
        };
    }

    const suppressPermanently = localStorageGet(LOCALSTORAGE_KEY.SUPPRESS_POPUP_PERMANENTLY);

    if (suppressPermanently) {
        return {
            suppressed: true,
            reason:     SUPPRESS_REASON.SUPPRESSED_POPUP_PERMANENTLY
        };
    }

    if (isCoolingDown({ type, brandConfig })) {
        return {
            suppressed: true,
            reason:     SUPPRESS_REASON.COOLING_DOWN
        };
    }

    return { suppressed: false };
};

export const shouldSuppressTeaser = (options : Omit<ShouldSuppressOptions, 'type'>) : ShouldSuppressResult =>
    shouldSuppress({ ...options, type: MODAL_TYPE.TEASER });

export const shouldSuppressPopup = (options : Omit<ShouldSuppressOptions, 'type'>) : ShouldSuppressResult =>
    shouldSuppress({ ...options, type: MODAL_TYPE.POPUP });
