import type { PopupCommonStyle } from '@onetext/api';

export const getTextShadowStyles = (styles : PopupCommonStyle | undefined) : string | undefined => {
    if (!styles) {
        return undefined;
    }

    const {
        textShadowColor,
        textShadowOffsetX,
        textShadowOffsetY,
        textShadowBlur
    } = styles;

    const textShadow = textShadowColor && textShadowOffsetX && textShadowOffsetY && textShadowBlur
        ? `${ textShadowOffsetX } ${ textShadowOffsetY } ${ textShadowBlur } ${ textShadowColor }`
        : undefined;

    return textShadow;
};

export const getBoxShadowStyles = (styles : PopupCommonStyle | undefined) : string | undefined => {
    if (!styles) {
        return undefined;
    }

    const {
        boxShadowColor,
        boxShadowOffsetX,
        boxShadowOffsetY,
        boxShadowBlur,
        boxShadowSpread
    } = styles;

    const boxShadow = boxShadowColor && boxShadowOffsetX && boxShadowOffsetY && boxShadowBlur && boxShadowSpread
        ? `${ boxShadowColor } ${ boxShadowOffsetX } ${ boxShadowOffsetY } ${ boxShadowBlur } ${ boxShadowSpread }`
        : undefined;

    return boxShadow;
};

export const getTextStrokeStyles = (styles : PopupCommonStyle | undefined) :
{ [key : string] : string } | undefined => {
    if (!styles) {
        return undefined;
    }

    const {
        textStrokeColor,
        textStrokeWidth
    } = styles;

    const textStroke = textStrokeColor && textStrokeWidth
        ? { '-webkit-text-stroke': `${ textStrokeWidth } ${ textStrokeColor }` }
        : undefined;

    return textStroke;
};
