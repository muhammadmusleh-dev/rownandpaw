import { callOneTextAPI } from '../api';
import { eventEmitter, isEditorMode } from '../lib';

import { getStoredAccountToken, getStoredBrowserIdentifier, getStoredBrowserSessionIdentifier } from './customer';

import type { Email, PostEventTrackAPIRequest, PUBLIC_BUYER_EVENT } from '@onetext/api';
import { HTTP_METHOD } from '@onetext/api';

type EventsPayload = PostEventTrackAPIRequest['events'];
type EventPayload = EventsPayload[number];

type CommonFields = {
    customerAccountToken ?: string,
    customerBrowserIdentifier : string,
    customerBrowserSessionIdentifier : string,
};

type BuyerEventPayload<T> = T extends { buyerEvent : PUBLIC_BUYER_EVENT, payload : infer P }
    ? Omit<P, keyof CommonFields>
    : never;

type TrackBuyerEventOptions<T extends EventPayload> = {
    buyerEvent : T['buyerEvent'],
    payload : BuyerEventPayload<T>,
};

export const trackBuyerEvent = <T extends EventPayload>({
    buyerEvent,
    payload
} : TrackBuyerEventOptions<T>) : void => {
    if (isEditorMode()) {
        return;
    }

    void callOneTextAPI({
        method: HTTP_METHOD.POST,
        path:   '/state',
        body:   {
            events: [ {
                buyerEvent,
                payload: {
                    ...payload,
                    customerAccountToken:             getStoredAccountToken(),
                    customerBrowserIdentifier:        getStoredBrowserIdentifier(),
                    customerBrowserSessionIdentifier: getStoredBrowserSessionIdentifier()
                }
            } ]
        }
    });
};

export const onPopupEmailSubmit = eventEmitter<{
    email : Email,
}>();

export const onPopupPhoneSubmit = eventEmitter<{
    phone : string,
}>();

export const events = {
    popup: {
        email: {
            submit: onPopupEmailSubmit
        },
        phone: {
            submit: onPopupPhoneSubmit
        }
    }
};
