import { v4 as uuid } from 'uuid';

import { associate } from '../../api';
import { LOCALSTORAGE_KEY, SESSIONSTORAGE_KEY } from '../../constants';
import { userIdentifiedEvent } from '../../event';
import {
    debouncePromise, getSDKEnv, getURLQueryParam, isLocalStorageEnabled, isTokenType,
    localStorageGet, localStorageSet, promiseTry, sessionStorageGet, sessionStorageSet
} from '../../lib';

import type { Email, PhoneNumber, TokenType } from '@onetext/api';
import { QUERY_PARAM, TOKEN, UTM_QUERY_PARAM } from '@onetext/api';

export const getStoredAccountToken = () : TokenType<TOKEN.ACCOUNT> | undefined => {
    const queryAccountToken = getURLQueryParam(QUERY_PARAM.ACCOUNT_TOKEN);
    const localStorageAccountToken = localStorageGet(LOCALSTORAGE_KEY.ONETEXT_ACCOUNT_TOKEN);
    const potentialUTMAccountToken = getURLQueryParam(UTM_QUERY_PARAM.CONTENT);

    const utmAccountToken = potentialUTMAccountToken && isTokenType(potentialUTMAccountToken, {
        env:  getSDKEnv(),
        type: TOKEN.ACCOUNT
    })
        ? potentialUTMAccountToken
        : undefined;

    const accountToken = (
        queryAccountToken ??
        localStorageAccountToken ??
        utmAccountToken
    ) as TokenType<TOKEN.ACCOUNT> | undefined;

    if (accountToken && accountToken !== localStorageAccountToken) {
        localStorageSet(LOCALSTORAGE_KEY.ONETEXT_ACCOUNT_TOKEN, accountToken);
    }

    return accountToken;
};

export const isCustomerRecognized = () : boolean => {
    return Boolean(getStoredAccountToken());
};

export const storeAccountLocally = (accountToken : string) : void => {
    const localStorageEnabled = isLocalStorageEnabled();

    if (accountToken && localStorageEnabled) {
        localStorageSet(LOCALSTORAGE_KEY.ONETEXT_ACCOUNT_TOKEN, accountToken);
    }
};

type Customer = {
    recognized : boolean,
};

export const getCustomer = () : Promise<Customer> => {
    return promiseTry(() => {
        const recognized = isCustomerRecognized();

        return {
            recognized
        };
    });
};

export const getStoredBrowserIdentifier = () : string => {
    const identifier = localStorageGet<string>(LOCALSTORAGE_KEY.BROWSER_IDENTIFIER);

    if (identifier) {
        return identifier;
    }

    const browserIdentifier = uuid();

    localStorageSet(LOCALSTORAGE_KEY.BROWSER_IDENTIFIER, browserIdentifier);

    return browserIdentifier;
};

export const getStoredBrowserSessionIdentifier = () : string => {
    const identifier = sessionStorageGet(SESSIONSTORAGE_KEY.BROWSER_SESSION_IDENTIFIER);

    if (identifier) {
        return identifier;
    }

    const browserSessionIdentifier = uuid();

    sessionStorageSet(
        SESSIONSTORAGE_KEY.BROWSER_SESSION_IDENTIFIER,
        browserSessionIdentifier
    );

    return browserSessionIdentifier;
};

type CustomerIdentity = {
    klaviyoID ?: string,
    accountToken ?: TokenType<TOKEN.ACCOUNT>,
    phone ?: PhoneNumber,
    email ?: Email,
    cartToken ?: string,
    customerBrowserIdentifier ?: string,
    customerBrowserSessionIdentifier ?: string,
};

const identifierState : CustomerIdentity = {
    accountToken:                     getStoredAccountToken(),
    customerBrowserIdentifier:        getStoredBrowserIdentifier(),
    customerBrowserSessionIdentifier: getStoredBrowserSessionIdentifier()
};

type NewCustomerIdentity = {
    klaviyoID ?: string,
    phone ?: PhoneNumber,
    email ?: Email,
    cartToken ?: string,
};

const updateIdentifierState = ({
    klaviyoID,
    phone,
    email,
    cartToken
} : NewCustomerIdentity) : {
    updated : boolean,
} => {
    let updated = false;

    if (klaviyoID && klaviyoID !== identifierState.klaviyoID) {
        identifierState.klaviyoID = klaviyoID;
        updated = true;
    }

    if (phone && phone !== identifierState.phone) {
        identifierState.phone = phone;
        updated = true;
    }

    if (email && email !== identifierState.email) {
        identifierState.email = email;
        updated = true;
    }

    if (cartToken && cartToken !== identifierState.cartToken) {
        identifierState.cartToken = cartToken;
        updated = true;
    }

    return {
        updated
    };
};

const debouncedAssociateCustomer = debouncePromise(async () => {
    const {
        body: {
            accountToken
        }
    } = await associate(identifierState);

    return {
        accountToken
    };
}, 1000);

export const identifyCustomer = (newIdentifiers : NewCustomerIdentity) : Promise<void> => {
    return promiseTry(() => {
        const { updated } = updateIdentifierState(newIdentifiers);

        if (!updated) {
            return;
        }

        const existingAccountToken = identifierState.accountToken;

        return debouncedAssociateCustomer().then(({ accountToken }) => {
            if (accountToken && accountToken !== existingAccountToken) {
                identifierState.accountToken = accountToken;
                storeAccountLocally(accountToken);
                userIdentifiedEvent.emit({ accountToken });
            }
        });
    });
};

export const initializeCustomer = async () : Promise<void> => {
    if (identifierState.accountToken) {
        userIdentifiedEvent.emit({
            accountToken: identifierState.accountToken
        });
    }

    await debouncedAssociateCustomer();
};
